"""Real key presses for the virtual keyboard. Each key is sent with the same input a keyboard makes, so it reaches the
window that has the keyboard: the window you clicked, or the desk.

A character is sent as a Unicode packet, one key-down and one key-up for each UTF-16 unit, so each character arrives
exactly once. The event lists are plain Python and are tested anywhere; the sending needs Windows.
"""
import ctypes
import os
from ctypes import wintypes

from hand_tracking import label_text

INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004


def key_events(text=None, vk=None):
    """The (vk, scan, flags) events for one key. A character is a Unicode packet (vk 0, the code in scan); a virtual
    key is its code. Each one is a key-down followed by a key-up."""
    if vk is not None:
        return [(vk, 0, 0), (vk, 0, KEYEVENTF_KEYUP)]
    events = []
    for ch in text:
        code = ord(ch)
        units = [code] if code <= 0xFFFF else [0xD800 + ((code - 0x10000) >> 10), 0xDC00 + ((code - 0x10000) & 0x3FF)]
        for unit in units:
            events.append((0, unit, KEYEVENTF_UNICODE))
            events.append((0, unit, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP))
    return events


if os.name == "nt":
    user32 = ctypes.WinDLL("user32", use_last_error=True)

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

    class _KeyUnion(ctypes.Union):
        # Windows sizes the union by its largest member (the mouse one, 32 bytes), so this matches it.
        _fields_ = [("ki", KEYBDINPUT), ("padding", ctypes.c_byte * 32)]

    class KEY_INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _KeyUnion)]

    user32.SendInput.argtypes = [wintypes.UINT, ctypes.c_void_p, ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT


def send(events):
    """Sends the events, in order. Returns True when every one was accepted."""
    if os.name != "nt" or not events:
        return False
    arr = (KEY_INPUT * len(events))()
    for i, (vk, scan, flags) in enumerate(events):
        arr[i].type = INPUT_KEYBOARD
        arr[i].u.ki = KEYBDINPUT(vk, scan, flags, 0, 0)
    sent = user32.SendInput(len(events), arr, ctypes.sizeof(KEY_INPUT))
    return sent == len(events)


def press_label(label, shift):
    """Presses one virtual key. Returns the shift state for the next letter."""
    text, vk, next_shift = label_text(label, shift)
    if text is not None:
        send(key_events(text=text))
    elif vk is not None:
        send(key_events(vk=vk))
    return next_shift
