"""Installs WireGuard, the program Virtual Box runs on, when it is missing.

Windows: the newest official MSI is taken from download.wireguard.com (the index lists every release). It is saved to a
temporary folder, its digital signature is checked (it must be valid and signed by WireGuard LLC), and only then is it
installed silently with administrator permission. Windows shows its own permission prompt for that; if you click No,
nothing is installed.

macOS: wireguard-tools and wireguard-go are installed with Homebrew, if Homebrew is on this Mac. Homebrew is not installed automatically.

Nothing here touches Qt. The window (airneo_ui) shows the progress messages it reports.
"""
import base64
import os
import platform
import re
import shutil
import subprocess
import tempfile
import threading
import urllib.request

INDEX_URL = "https://download.wireguard.com/windows-client/"
SIGNER = "WireGuard LLC"
MIN_MSI_BYTES = 500_000          # a real installer is a few MB; anything much smaller is an error page
MSI_OK_CODES = (0, 3010)         # 3010: installed, a restart is wanted
_state = {"running": False}
_state_lock = threading.Lock()


def msi_arch(machine):
    """The MSI for this computer's processor: amd64 for 64-bit Intel and AMD, arm64 for ARM, x86 otherwise."""
    m = (machine or "").upper()
    if m in ("ARM64", "AARCH64"):
        return "arm64"
    if m in ("AMD64", "X86_64", "X64"):
        return "amd64"
    return "x86"


def latest_msi(index_html, arch):
    """The newest installer for arch in the download index, as (file name, version text), or None.
    Versions compare as numbers, so 0.10.0 is newer than 0.9.1."""
    pattern = re.compile(r"wireguard-%s-(\d+(?:\.\d+)+)\.msi" % re.escape(arch))
    best = None
    for m in pattern.finditer(index_html):
        version = tuple(int(part) for part in m.group(1).split("."))
        if best is None or version > best[0]:
            best = (version, m.group(0))
    if best is None:
        return None
    return best[1], ".".join(str(part) for part in best[0])


def is_wireguard_signature(status, subject):
    """True only for a valid signature from WireGuard LLC. Anything else must not be run."""
    return (status or "").strip() == "Valid" and SIGNER in (subject or "")


# ---- PowerShell, run with -EncodedCommand. The file path only ever arrives in an environment variable, so a folder
# with spaces, quotes or non-ASCII letters cannot change the command.
SIGNATURE_SCRIPT = (
    "$s = Get-AuthenticodeSignature -LiteralPath $env:SD_MSI; "
    "Write-Output $s.Status; "
    "Write-Output $s.SignerCertificate.Subject"
)
INSTALL_SCRIPT = (
    "$msiArgs = '/i \"' + $env:SD_MSI + '\" DO_NOT_LAUNCH=1 /qn'; "
    "try { $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList $msiArgs -Verb RunAs -Wait -PassThru } "
    "catch { Write-Output $_.Exception.Message; exit 1 }; "
    "exit $p.ExitCode"
)


def powershell_args(script):
    """The command line that runs one PowerShell script, with the script encoded so nothing is re-parsed."""
    encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    return ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-EncodedCommand", encoded]


def fetch(url, timeout=60):
    """The bytes at url. Raises on any network or HTTP error."""
    request = urllib.request.Request(url, headers={"User-Agent": "SpatialDesk"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def run_powershell(script, env_values):
    """Runs a PowerShell script with the given environment values. Returns (exit code, output text)."""
    env = dict(os.environ, **env_values)
    done = subprocess.run(powershell_args(script), env=env, capture_output=True, timeout=900,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return done.returncode, done.stdout.decode("utf-8", errors="replace")


def _windows_signature_ok(path):
    """Checks the file's digital signature. Returns (ok, the text the check printed)."""
    _code, text = run_powershell(SIGNATURE_SCRIPT, {"SD_MSI": path})
    lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
    status = lines[0] if lines else ""
    subject = " ".join(lines[1:])
    return is_wireguard_signature(status, subject), text.strip()


def _install_windows(report, machine):
    report("Looking up the newest WireGuard (the program Virtual Box uses)...")
    try:
        index = fetch(INDEX_URL).decode("utf-8", errors="replace")
    except Exception as e:
        report(f"Could not reach the WireGuard download site ({e}).")
        return False
    picked = latest_msi(index, msi_arch(machine))
    if picked is None:
        report("The WireGuard download site did not list an installer for this computer.")
        return False
    name, version = picked
    report(f"Downloading WireGuard {version}...")
    try:
        data = fetch(INDEX_URL + name, timeout=300)
    except Exception as e:
        report(f"The download failed ({e}).")
        return False
    if len(data) < MIN_MSI_BYTES:
        report("The download was too small to be the installer, so it was not run.")
        return False
    folder = tempfile.mkdtemp(prefix="sd_wireguard_")
    path = os.path.join(folder, name)
    try:
        with open(path, "wb") as f:
            f.write(data)
        report("Checking the installer's signature...")
        ok, detail = _windows_signature_ok(path)
        if not ok:
            report(f"The installer is not signed by {SIGNER}, so it was not run. ({detail or 'no signature'})")
            return False
        report("Installing WireGuard. Windows will ask for permission: choose Yes.")
        _code, output = run_powershell(INSTALL_SCRIPT, {"SD_MSI": path})
        exit_code = _code
        if exit_code in MSI_OK_CODES:
            report("WireGuard is installed. Virtual Box can continue.")
            return True
        last = output.strip().splitlines()[-1] if output.strip() else ""
        report(f"The install did not finish (code {exit_code}). {last} Install WireGuard from wireguard.com/install "
               "if this keeps happening.")
        return False
    except (OSError, subprocess.SubprocessError) as e:
        report(f"The install could not start ({e}).")
        return False
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def _brew_path():
    found = shutil.which("brew")
    if found:
        return found
    for candidate in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew"):
        if os.path.isfile(candidate):
            return candidate
    return None


def _install_mac(report):
    brew = _brew_path()
    if brew is None:
        report("Virtual Box needs Homebrew to install WireGuard on a Mac. Install Homebrew from brew.sh, then try "
               "again, or install WireGuard from wireguard.com/install.")
        return False
    report("Installing WireGuard tools with Homebrew. This can take a few minutes...")
    try:
        done = subprocess.run([brew, "install", "wireguard-tools", "wireguard-go"], capture_output=True, text=True, timeout=1800)
    except (OSError, subprocess.SubprocessError) as e:
        report(f"Homebrew could not run ({e}).")
        return False
    if done.returncode == 0:
        report("WireGuard tools are installed. Virtual Box can continue.")
        return True
    last = (done.stderr or done.stdout or "").strip().splitlines()
    report(f"Homebrew did not finish the install. {last[-1] if last else ''}".strip())
    return False


def install(os_name, report, machine=None):
    """Installs WireGuard for os_name ('windows' or 'macos'). report(text) is called with each step. Returns True
    once WireGuard is installed. Never raises."""
    try:
        if os_name == "windows":
            return _install_windows(report, machine or platform.machine())
        if os_name == "macos":
            return _install_mac(report)
        report("Virtual Box cannot install WireGuard automatically on this system. Install it from wireguard.com.")
        return False
    except Exception as e:                       # report it; the desk keeps running
        report(f"Virtual Box could not be installed ({e}).")
        return False


def start(os_name, report, done):
    """Runs install() on a background thread, so the desk never waits for it. done(ok, last_message) is called at the
    end. Returns False, and does nothing, if an install is already running."""
    with _state_lock:
        if _state["running"]:
            return False
        _state["running"] = True
    last = {"text": ""}

    def relay(text):
        last["text"] = text
        report(text)

    def work():
        ok = False
        try:
            ok = install(os_name, relay)
        finally:
            with _state_lock:
                _state["running"] = False
            done(ok, last["text"])

    threading.Thread(target=work, daemon=True).start()
    return True


def is_running():
    with _state_lock:
        return _state["running"]
