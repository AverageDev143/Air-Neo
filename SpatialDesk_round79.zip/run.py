"""Starts Spatial Desk. Works on Windows and macOS.

First run: creates a private .venv folder next to this file and installs requirements.txt into it. Your
computer's own Python is left alone. Later runs skip straight to the app.

Run it from a terminal in this folder:
    Windows:  py run.py        (or: python run.py)
    Mac:      python3 run.py
"""
import os
import subprocess
import sys
import venv

HERE = os.path.dirname(os.path.abspath(__file__))
VENV = os.path.join(HERE, ".venv")
REQUIREMENTS = os.path.join(HERE, "requirements.txt")


def venv_python():
    if os.name == "nt":
        return os.path.join(VENV, "Scripts", "python.exe")
    return os.path.join(VENV, "bin", "python")


def wait_and_fail(message):
    print(message)
    try:
        input("Press Enter to close.")
    except EOFError:
        pass
    return 1


def main():
    py = venv_python()
    if not os.path.isfile(py):
        print("Creating the Python environment in .venv (first run only)...")
        try:
            venv.EnvBuilder(with_pip=True).create(VENV)
        except Exception as e:
            return wait_and_fail(f"Could not create the environment: {e}")
    if subprocess.call([py, "-m", "pip", "install", "-q", "-r", REQUIREMENTS]) != 0:
        return wait_and_fail("Could not install the packages. Check the internet connection, then run this again.")
    return subprocess.call([py, os.path.join(HERE, "spatial_desk.py")])


if __name__ == "__main__":
    sys.exit(main())
