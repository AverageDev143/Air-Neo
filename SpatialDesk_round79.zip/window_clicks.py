"""How a click reaches a window shown in the room.

Three routes, tried in order. Each one is a method other Windows automation tools use:

1. "uia": UI Automation (the accessibility interface every modern Windows app exposes). The control under the spot is
   asked to act (its Invoke, Toggle or Select pattern). The pointer does not move. Works in WPF, WinUI, Electron and
   browsers, and in classic apps with accessibility support. It needs the window to be the top one at the spot.
2. "post": a mouse message posted straight to the control under the spot. The pointer does not move, the window does
   not come forward, and it works even while the room covers the window. Works for classic Win32 controls (buttons,
   lists, tabs). Browsers and many custom-drawn controls ignore it.
3. "send": a real click (SendInput) with the pointer moved to the spot and back. Works everywhere a person's mouse
   works, but the window comes to the front and the pointer moves for a moment. Also the only route that gives a
   text field real keyboard focus. spatial_desk.py does this one.

choose_routes() decides the order from the window and control class names. It is plain Python, so it is tested
anywhere. Everything that touches Windows is guarded by IS_WIN.
"""
import atexit
import base64
import ctypes
import os
import subprocess
import threading
import time
from ctypes import wintypes

IS_WIN = os.name == "nt"

WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP = 0x0200, 0x0201, 0x0202
MK_LBUTTON = 0x0001
CWP_SKIPINVISIBLE = 0x0001
CREATE_NO_WINDOW = 0x08000000

# Controls where keyboard focus matters: only the real click gives them focus in the foreground window.
TEXT_CLASSES = ("edit", "richedit", "scintilla", "tkchild", "combobox")
# Browsers and the engines inside them (Chromium, Firefox, Electron): posted mouse messages are dropped here.
BROWSER_CLASSES = ("chrome_widgetwin", "chrome_renderwidgethosthwnd", "mozillawindowclass",
                   "mozillacontentwindowclass", "intermediate d3d window")
# Classic Win32 controls that handle posted mouse messages.
CLASSIC_CONTROLS = ("button", "static", "syslistview32", "systreeview32", "listbox", "systabcontrol32",
                    "toolbarwindow32", "sysmonthcal32", "msctls_statusbar32", "syslink")


def choose_routes(window_class, child_class, has_child):
    """The routes to try, in order. Always ends with "send", so a click is always attempted."""
    w = (window_class or "").lower()
    c = (child_class or "").lower()
    if has_child and c.startswith(TEXT_CLASSES):
        return ["send"]                                   # a text field needs real focus
    browser = w.startswith(BROWSER_CLASSES) or c.startswith(BROWSER_CLASSES)
    if has_child and not browser and c.startswith(CLASSIC_CONTROLS):
        return ["post", "uia", "send"]
    return ["uia", "send"]


# ---------- Windows calls (only defined on Windows) ----------
if IS_WIN:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.ScreenToClient.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
    user32.ScreenToClient.restype = wintypes.BOOL
    user32.ChildWindowFromPointEx.argtypes = [wintypes.HWND, wintypes.POINT, wintypes.UINT]
    user32.ChildWindowFromPointEx.restype = wintypes.HWND
    user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.PostMessageW.restype = wintypes.BOOL
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.restype = ctypes.c_int
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD


def class_name(hwnd):
    """The window class of a window ('' when unknown). Windows only."""
    if not IS_WIN or not hwnd:
        return ""
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def process_id(hwnd):
    """The process that owns a window (0 when unknown). Windows only."""
    if not IS_WIN or not hwnd:
        return 0
    pid = wintypes.DWORD(0)
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def child_at(parent, x, y):
    """The control at the screen spot (x, y) inside parent, down to the deepest one, or 0 when there is none. Windows
    gives only the direct child at a point, so a group box that holds a button is searched into, and the button (the
    control a real click would reach) is returned. Windows only."""
    if not IS_WIN or not parent:
        return 0
    current, found = parent, 0
    for _ in range(16):
        pt = wintypes.POINT(int(x), int(y))
        user32.ScreenToClient(current, ctypes.byref(pt))
        nxt = int(user32.ChildWindowFromPointEx(current, pt, CWP_SKIPINVISIBLE) or 0)
        if not nxt or nxt == current:
            break
        found, current = nxt, nxt
    return found


def post_click(target, child, x, y):
    """A left click posted to the control, with the pointer not moved. Returns False if Windows refused a message.
    Windows only."""
    if not IS_WIN or not child:
        return False
    pt = wintypes.POINT(int(x), int(y))
    user32.ScreenToClient(child, ctypes.byref(pt))           # the control's own coordinates
    lparam = ((pt.y & 0xFFFF) << 16) | (pt.x & 0xFFFF)
    ok = bool(user32.PostMessageW(child, WM_MOUSEMOVE, 0, lparam))
    time.sleep(0.005)                                         # the control sees the pointer over it first
    ok = bool(user32.PostMessageW(child, WM_LBUTTONDOWN, MK_LBUTTON, lparam)) and ok
    time.sleep(0.012)
    ok = bool(user32.PostMessageW(child, WM_LBUTTONUP, 0, lparam)) and ok
    return ok


# ---------- UI Automation, through a helper PowerShell process ----------
# PowerShell is on every Windows 10 and 11 PC, and so is the UI Automation library it loads. One helper process
# stays running; each request is a line "hwnd pid x y" (physical screen pixels) and each answer is one word:
#   invoked  the control was asked to act (Invoke, Toggle or Select)
#   edit     the control is a text field: the caller must use a real click, so the field gets focus
#   none     nothing there can act
#   error    the request failed
UIA_SCRIPT = r"""
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName WindowsBase
Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();' -Name Native -Namespace SpatialDesk
[void][SpatialDesk.Native]::SetProcessDPIAware()
$walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
[Console]::Out.WriteLine('ready')
[Console]::Out.Flush()
while ($true) {
    $line = [Console]::In.ReadLine()
    if ($line -eq $null) { break }
    $answer = 'none'
    try {
        $p = $line.Split(' ')
        $hwnd = [long]$p[0]; $owner = [int]$p[1]; $x = [double]$p[2]; $y = [double]$p[3]
        $cur = [System.Windows.Automation.AutomationElement]::FromPoint((New-Object System.Windows.Point($x, $y)))
        for ($i = 0; $i -lt 8 -and $cur -ne $null; $i++) {
            if ($cur.Current.ProcessId -ne $owner) { break }
            $type = $cur.Current.ControlType.ProgrammaticName
            if ($type -in @('ControlType.Edit', 'ControlType.Document', 'ControlType.ComboBox', 'ControlType.Spinner')) { $answer = 'edit'; break }
            $pat = $null
            if ($cur.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$pat)) { $pat.Invoke(); $answer = 'invoked'; break }
            if ($cur.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern, [ref]$pat)) { $pat.Toggle(); $answer = 'invoked'; break }
            if ($cur.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern, [ref]$pat)) { $pat.Select(); $answer = 'invoked'; break }
            if ([long]$cur.Current.NativeWindowHandle -eq $hwnd) { break }      # reached the window itself: stop
            $cur = $walker.GetParent($cur)
        }
    } catch {
        $answer = 'error'
    }
    [Console]::Out.WriteLine($answer)
    [Console]::Out.Flush()
}
"""


class UiaClicker:
    """Talks to the helper PowerShell process, one request at a time. An answer of 'error' is a request that failed,
    and the helper is kept. Anything that is not an answer word means the helper is stopped or out of step, so it is
    started again. After repeated failures it stops trying, and clicks fall back to the other routes."""

    TIMEOUT_S = 6.0            # for one request
    START_TIMEOUT_S = 15.0     # for the helper to start: PowerShell compiles a little C# on its first run, which can be slow
    MAX_FAILURES = 3
    ANSWERS = ("invoked", "edit", "none", "error")

    def __init__(self):
        self._proc = None
        self._lock = threading.Lock()
        self._failures = 0
        self._disabled = not IS_WIN

    def _start(self):
        encoded = base64.b64encode(UIA_SCRIPT.encode("utf-16-le")).decode("ascii")
        proc = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1,
            creationflags=CREATE_NO_WINDOW)
        self._proc = proc
        # Wait until the helper says it is ready. Anything printed before that is skipped, and a helper that never
        # says so is stopped by the watchdog rather than waited on.
        watchdog = threading.Timer(self.START_TIMEOUT_S, self._stop_proc, args=(proc,))
        watchdog.start()
        try:
            for _ in range(20):
                line = proc.stdout.readline()
                if line == "":
                    raise RuntimeError("the helper stopped before it was ready")
                if line.strip() == "ready":
                    return
            raise RuntimeError("the helper did not say it was ready")
        finally:
            watchdog.cancel()

    def _stop_proc(self, proc):
        try:
            proc.kill()
        except OSError:
            pass
        if self._proc is proc:
            self._proc = None

    def _stop(self):
        if self._proc is not None:
            self._stop_proc(self._proc)
        self._proc = None

    def _ask(self, proc, line):
        """Sends one request and returns the helper's answer, or None when there is none. Text that is not an answer
        word (printed by mistake) is skipped, a few lines at most. The watchdog stops a helper that does not answer."""
        watchdog = threading.Timer(self.TIMEOUT_S, self._stop_proc, args=(proc,))
        watchdog.start()
        try:
            proc.stdin.write(line)
            proc.stdin.flush()
            for _ in range(5):
                reply = proc.stdout.readline()
                if reply == "":
                    return None                      # the helper has stopped
                if reply.strip() in self.ANSWERS:
                    return reply.strip()
            return None
        finally:
            watchdog.cancel()

    def invoke(self, hwnd, pid, x, y):
        """Asks the control at the screen spot (x, y) to act. Returns invoked, edit, none or error."""
        if self._disabled:
            return "none"
        answer = None
        with self._lock:
            try:
                if self._proc is None or self._proc.poll() is not None:
                    self._start()
                proc = self._proc
                if proc is not None:
                    answer = self._ask(proc, f"{int(hwnd)} {int(pid)} {int(x)} {int(y)}\n")
            except (OSError, ValueError, RuntimeError):
                answer = None
            if answer in self.ANSWERS:
                self._failures = 0
                return answer
            self._stop()                             # no usable reply: start the helper again next time
            self._failures += 1
            if self._failures >= self.MAX_FAILURES:
                self._disabled = True
            return "error"

    def warm(self):
        """Starts the helper now, so the first click does not wait for PowerShell to start."""
        if self._disabled:
            return
        with self._lock:
            try:
                if self._proc is None or self._proc.poll() is not None:
                    self._start()
            except (OSError, RuntimeError):
                self._stop()
                self._failures += 1

    def close(self):
        with self._lock:
            self._stop()


UIA = UiaClicker()
atexit.register(UIA.close)
