"""
Spatial Desk: a native Windows app for RayNeo Air glasses, styled after INAIR OS.

Frameless window, OpenGL starfield space, floating windows at variable depth, hover and follow
modes, and head tracking from rayneo_helper.py (same folder).
Run:  py spatial_desk.py
"""
import ctypes
import json
import math
import os
import platform
import sys
import threading
import time
import webbrowser
from ctypes import wintypes

import numpy as np
import depth_model
import airneo_core
import dock_profiles
from airneo_ui import AirNeoPanel, TunnelRunner
from tuner_ui import WindowTuner
from login_ui import LoginGate
import app_icon as spatial_icon
import app_install
import app_paths
import camera_view
import hand_tracking
import keyboard_input
import pointer_art
import window_clicks as wc            # the routes a click can take into a window (UI Automation, posted message, real click)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
# A bundled app runs from inside its own .app folder, which is not a place to save files, so the files it writes
# (Virtual Box's keys and settings) go to the user's data folder instead.
DATA_HERE = app_paths.data_dir() if getattr(sys, "frozen", False) else HERE
IS_WIN = platform.system() == "Windows"
import platform_support                  # which computer this is, and what it can do
PROFILE = platform_support.detect()
IS_MAC = PROFILE.os == "macos"

if IS_WIN:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # per-monitor DPI aware, before any window exists
    except Exception:
        pass

from PySide6.QtCore import Qt, QTimer, QPoint, QPointF, QSize
from PySide6.QtCore import QRectF, QObject, QEvent, QFileInfo, Signal
from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtGui import QCursor
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QIcon, QImage, QLinearGradient, QPainter, QPainterPath, QRadialGradient,
                           QPalette, QPen, QPixmap, QPolygonF, QSurfaceFormat)
from PySide6.QtWidgets import QAbstractButton, QLineEdit, QStackedWidget
from PySide6.QtWidgets import QMenu
from PySide6.QtWidgets import QFileIconProvider
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QFileIconProvider, QComboBox, QFileDialog, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QProgressBar, QPushButton, QScrollArea, QSlider, QSpinBox, QToolButton,
    QVBoxLayout, QWidget,
)
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL import GL as gl

import rayneo_helper as rh

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PANEL_W = 2.8                   # default width of a window, metres
VIEW_FILL = 0.82                # a window's frame may use this share of the visible height (the rest is margin)
POINTER_HOLD_S = 0.15           # the arrow stays this long after the pointer leaves a window (stops edge flicker)
HDR_W, HDR_H = 1024, 88        # title bar texture size, pixels
DEFAULT_DIST = 2.6              # default distance from you, metres
MIN_DIST, MAX_DIST = 1.2, 8.0
MAX_BEARING = 2.6                # how far round you a window can be slid sideways, radians (about 150 degrees)
MIN_SIZE, MAX_SIZE = 0.5, 1.5    # a window can be made half as wide again, or one and a half times wider
EXPAND_FACTOR = 1.6             # a window made "fullscreen" is this many times wider
FOV_DEFAULT, FOV_MIN, FOV_MAX = 62.0, 40.0, 90.0   # vertical field of view of the room camera
MAX_PANELS_DEFAULT = 4
MAX_PANELS_LIMIT = 8
PANEL_CORNER = 0.07             # corner radius of a window in space, metres
SHAPE_LABELS = {"auto": "Match the app", "landscape": "Landscape 16:9", "widescreen": "Widescreen 21:9", "portrait": "Portrait 9:16"}
RATIOS = {"auto": None, "landscape": 9 / 16, "widescreen": 9 / 21, "portrait": 16 / 9}   # height / width
CORNER_RADIUS = 30              # corner radius of the app window, pixels
GLOW_PAD = 0.16                 # how far the soft glow behind a window reaches, metres
ACCENT = (0.92, 0.94, 0.97)     # the one accent colour of the interface, RGB 0..1
ACCENT_HEX = "#eceff4"
SETTINGS_PATH = app_paths.settings_file()     # in the user's data folder, the same however the app is started

# Window arrangements, in the order the layout button cycles through: (key, label)
LAYOUTS = (("focus", "Focus"), ("code", "Stage"), ("wide", "Arc"), ("layers", "Layers"))
CODE_MAIN_MIN_DIST = 3.6           # "code" layout: the main window sits at least this far away
CODE_SIDE_MIN_DIST = 4.0           # "code" layout: side windows sit at least this far away
LAYOUT_GAP = {"focus": 0.12, "code": 0.22, "wide": 0.32, "layers": 0.0}   # space between windows, radians
THEMES = {                      # name: (top colour, bottom colour), RGB 0..1
    "space": ((0.080, 0.082, 0.090), (0.012, 0.012, 0.014)),
    "aurora": ((0.070, 0.078, 0.082), (0.010, 0.012, 0.014)),
    "dusk": ((0.095, 0.085, 0.080), (0.014, 0.012, 0.012)),
}
DEFAULT_SETTINGS = {
    "theme": "space", "layout": "code", "follow": False, "fov": FOV_DEFAULT,
    "max_panels": MAX_PANELS_DEFAULT, "fade_ms": 1200, "notify": True, "intro": True, "bg_path": "",
    "look_speed": 1.0, "camera_on": False, "curve": 100, "depth_on": False, "depth_pct": 50, "shape": "auto",
}


def load_settings():
    data = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            data.update({k: v for k, v in saved.items() if k in DEFAULT_SETTINGS})
    except Exception:
        pass
    if data["theme"] not in THEMES:
        data["theme"] = "space"
    if data["layout"] not in dict(LAYOUTS):
        data["layout"] = "code"
    return data


def save_settings(data):
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)   # the data folder may not exist yet
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, SETTINGS_PATH)
    except Exception:
        rh.log.exception("could not save settings to %s", SETTINGS_PATH)


# ---------------------------------------------------------------------------
# Windows API (window list, window pictures, capture exclusion)
# ---------------------------------------------------------------------------
HANDLE = ctypes.c_void_p

if IS_WIN:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    dwmapi = ctypes.WinDLL("dwmapi")

    class RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                    ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                    ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                    ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                    ("biClrImportant", wintypes.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 1)]

    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, HANDLE, wintypes.LPARAM)

    user32.GetWindowRect.argtypes = [HANDLE, ctypes.POINTER(RECT)]
    user32.GetWindowRect.restype = wintypes.BOOL
    user32.IsIconic.argtypes = [HANDLE]
    user32.IsIconic.restype = wintypes.BOOL
    user32.IsWindowVisible.argtypes = [HANDLE]
    user32.IsWindowVisible.restype = wintypes.BOOL
    user32.GetWindowTextLengthW.argtypes = [HANDLE]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [HANDLE, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
    user32.EnumWindows.restype = wintypes.BOOL
    user32.GetWindowDC.argtypes = [HANDLE]
    user32.GetWindowDC.restype = HANDLE
    user32.ReleaseDC.argtypes = [HANDLE, HANDLE]
    user32.ReleaseDC.restype = ctypes.c_int
    user32.PrintWindow.argtypes = [HANDLE, HANDLE, wintypes.UINT]
    user32.PrintWindow.restype = wintypes.BOOL
    user32.SetWindowDisplayAffinity.argtypes = [HANDLE, wintypes.DWORD]
    user32.SetWindowDisplayAffinity.restype = wintypes.BOOL
    gdi32.CreateCompatibleDC.argtypes = [HANDLE]
    gdi32.CreateCompatibleDC.restype = HANDLE
    gdi32.CreateCompatibleBitmap.argtypes = [HANDLE, ctypes.c_int, ctypes.c_int]
    gdi32.CreateCompatibleBitmap.restype = HANDLE
    gdi32.SelectObject.argtypes = [HANDLE, HANDLE]
    gdi32.SelectObject.restype = HANDLE
    gdi32.DeleteObject.argtypes = [HANDLE]
    gdi32.DeleteObject.restype = wintypes.BOOL
    gdi32.DeleteDC.argtypes = [HANDLE]
    gdi32.DeleteDC.restype = wintypes.BOOL
    gdi32.GetDIBits.argtypes = [HANDLE, HANDLE, wintypes.UINT, wintypes.UINT, ctypes.c_void_p,
                                ctypes.POINTER(BITMAPINFO), wintypes.UINT]
    gdi32.GetDIBits.restype = ctypes.c_int


DWMWA_EXTENDED_FRAME_BOUNDS = 9


def full_window_rect(hwnd):
    """The window's outer rectangle, including the invisible resize border that Windows adds."""
    if not IS_WIN:
        return None
    rc = RECT()
    if user32.GetWindowRect(hwnd, ctypes.byref(rc)):
        return rc.left, rc.top, rc.right, rc.bottom
    return None


def window_rect(hwnd):
    """The visible frame of a window in screen pixels, so edges and clicks line up with what you see."""
    full = full_window_rect(hwnd)
    if full is None:
        return None
    rc = RECT()
    if dwmapi.DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, ctypes.byref(rc), ctypes.sizeof(rc)) == 0 \
            and rc.right > rc.left and rc.bottom > rc.top:
        return rc.left, rc.top, rc.right, rc.bottom
    return full


def visible_crop(full, vis):
    """Where the visible frame sits inside the full capture: (x, y, width, height), or None if it does not fit."""
    x, y = vis[0] - full[0], vis[1] - full[1]
    w, h = vis[2] - vis[0], vis[3] - vis[1]
    if x < 0 or y < 0 or w <= 0 or h <= 0 or x + w > full[2] - full[0] or y + h > full[3] - full[1]:
        return None
    return x, y, w, h


def crop_picture(picture, full, vis):
    """The visible frame cut from a full-window capture, one pixel in from each side. Without this, the invisible
    resize border shows up as a dark or see-through fringe around every window."""
    crop = visible_crop(full, vis)
    if crop is None:
        return picture
    x, y, w, h = crop
    x, y, w, h = x + 1, y + 1, w - 2, h - 2
    if w <= 0 or h <= 0:
        return picture
    return np.ascontiguousarray(picture[y:y + h, x:x + w])


def list_windows(own_hwnd):
    """Visible, titled, reasonably sized windows, excluding this app."""
    if not IS_WIN:
        return []
    found = []

    def visit(hwnd, _lparam):
        if hwnd == own_hwnd or not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length == 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value.strip()
        rect = window_rect(hwnd)
        if title and rect and rect[2] - rect[0] >= 240 and rect[3] - rect[1] >= 160 and title != "Program Manager":
            found.append((hwnd, title))
        return True

    proc = WNDENUMPROC(visit)  # keep a reference alive for the call
    user32.EnumWindows(proc, 0)
    return found


def list_screens():
    import mss
    with mss.MSS() as sct:
        return [(i, f"Screen {i}") for i in range(1, len(sct.monitors))]


def capture_window_pixels(hwnd, w, h):
    """
    The window's own picture as BGRA rows (top to bottom), even when other windows cover it.
    Returns None if Windows refuses, so the caller can fall back to a screen grab.
    """
    if not IS_WIN or w <= 0 or h <= 0:
        return None
    hdc_win = user32.GetWindowDC(hwnd)
    if not hdc_win:
        return None
    hdc_mem = gdi32.CreateCompatibleDC(hdc_win)
    bmp = gdi32.CreateCompatibleBitmap(hdc_win, w, h)
    old = gdi32.SelectObject(hdc_mem, bmp)
    try:
        if not user32.PrintWindow(hwnd, hdc_mem, 2):  # 2 = PW_RENDERFULLCONTENT
            return None
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = w
        info.bmiHeader.biHeight = -h  # negative height = rows top to bottom
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0  # BI_RGB
        buf = (ctypes.c_ubyte * (w * h * 4))()
        lines = gdi32.GetDIBits(hdc_mem, bmp, 0, h, ctypes.cast(buf, ctypes.c_void_p), ctypes.pointer(info), 0)
        if lines != h:
            return None
        return np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 4).copy()
    finally:
        gdi32.SelectObject(hdc_mem, old)
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(hwnd, hdc_win)


if IS_WIN:
    user32.ScreenToClient.argtypes = [HANDLE, ctypes.POINTER(wintypes.POINT)]
    user32.ScreenToClient.restype = wintypes.BOOL
    user32.ChildWindowFromPoint.argtypes = [HANDLE, wintypes.POINT]
    user32.ChildWindowFromPoint.restype = HANDLE
    user32.SetForegroundWindow.argtypes = [HANDLE]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    user32.SetCursorPos.restype = wintypes.BOOL
    user32.ShowCursor.argtypes = [wintypes.BOOL]
    user32.ShowCursor.restype = ctypes.c_int
    user32.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t]
    user32.mouse_event.restype = None

    user32.GetClientRect.argtypes = [HANDLE, ctypes.POINTER(RECT)]
    user32.GetClientRect.restype = wintypes.BOOL
    user32.IsWindow.argtypes = [HANDLE]
    user32.IsWindow.restype = wintypes.BOOL
    user32.GetWindowThreadProcessId.argtypes = [HANDLE, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.SetWindowPos.argtypes = [HANDLE, HANDLE, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                    wintypes.UINT]
    user32.SetWindowPos.restype = wintypes.BOOL
    dwmapi.DwmGetWindowAttribute.argtypes = [HANDLE, wintypes.DWORD, ctypes.POINTER(RECT), wintypes.DWORD]
    dwmapi.DwmGetWindowAttribute.restype = ctypes.c_long
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = HANDLE
    user32.GetForegroundWindow.restype = HANDLE
    user32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
    user32.GetCursorPos.restype = wintypes.BOOL
    user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    user32.SetCursorPos.restype = wintypes.BOOL


MOUSEEVENTF_MOVE, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0001, 0x0002, 0x0004
MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_VIRTUALDESK = 0x8000, 0x4000
INPUT_MOUSE = 0


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class _INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUT_UNION)]


if IS_WIN:
    user32.SendInput.argtypes = [wintypes.UINT, ctypes.c_void_p, ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    user32.WindowFromPoint.argtypes = [wintypes.POINT]
    user32.WindowFromPoint.restype = HANDLE
    user32.GetAncestor.argtypes = [HANDLE, wintypes.UINT]
    user32.GetAncestor.restype = HANDLE
    user32.SetForegroundWindow.argtypes = [HANDLE]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    user32.AttachThreadInput.restype = wintypes.BOOL
    ctypes.WinDLL("kernel32").GetCurrentThreadId.restype = wintypes.DWORD
    user32.GetSystemMetrics.argtypes = [ctypes.c_int]
    user32.GetSystemMetrics.restype = ctypes.c_int
    user32.GetForegroundWindow.restype = HANDLE


def _send_click(x, y):
    """One left click at absolute screen (x, y). Each event carries its own position. Returns False when Windows
    refused an event: that happens when the window belongs to a program running as administrator, which a normal
    program is not allowed to click."""
    vl, vt = user32.GetSystemMetrics(76), user32.GetSystemMetrics(77)          # virtual desktop origin
    vw, vh = user32.GetSystemMetrics(78), user32.GetSystemMetrics(79)          # virtual desktop size
    vw, vh = max(2, vw), max(2, vh)
    dx = int((x - vl) * 65535 / (vw - 1))
    dy = int((y - vt) * 65535 / (vh - 1))
    base = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK | MOUSEEVENTF_MOVE
    accepted = True
    # Move first and let the program see the pointer over the control (many programs only react after a hover),
    # then press and release with a short gap, the way a person's click lasts.
    for flags, pause in ((base, 0.008), (base | MOUSEEVENTF_LEFTDOWN, 0.012), (base | MOUSEEVENTF_LEFTUP, 0.0)):
        ev = INPUT()
        ev.type = INPUT_MOUSE
        ev.u.mi = MOUSEINPUT(dx, dy, 0, flags, 0, 0)
        if user32.SendInput(1, ctypes.byref(ev), ctypes.sizeof(INPUT)) != 1:
            accepted = False
        time.sleep(pause)
    return accepted


def _activate(hwnd):
    """Makes the window the foreground window before a click. Some programs ignore a click on a window that is not
    active. Windows lets this program do it while it is in front (it is, when you have just clicked the room), and
    AttachThreadInput is the usual way to make it reliable."""
    if not hwnd or user32.GetForegroundWindow() == hwnd:
        return
    target_thread = user32.GetWindowThreadProcessId(hwnd, None)
    me = ctypes.WinDLL("kernel32").GetCurrentThreadId()
    attached = bool(target_thread) and target_thread != me and bool(user32.AttachThreadInput(me, target_thread, True))
    try:
        user32.SetForegroundWindow(hwnd)
    finally:
        if attached:
            user32.AttachThreadInput(me, target_thread, False)
    _wait_until(lambda: user32.GetForegroundWindow() == hwnd, 0.1)


def _wait_until(done, limit_s, step_s=0.004):
    """Waits until done() is true, checking every few milliseconds, for at most limit_s seconds."""
    end = time.monotonic() + limit_s
    while not done() and time.monotonic() < end:
        time.sleep(step_s)


def _lower_window(hwnd):
    """Moves a window to the bottom of the stacking order, behind the desktop's windows, without activating it."""
    if hwnd:
        user32.SetWindowPos(hwnd, 1, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)   # 1 = HWND_BOTTOM


def click_plan(target, desk, x, y, cursor):
    """The steps of one real click on a window in the room, in order. click_window_at runs them.

    The window is raised above the room without being activated, so the click lands on it and not on whatever covers
    it. The click itself makes the window the active one, so from then on the keyboard types into it, as on any screen.
    The room is raised again, still without being activated, so it stays in front of you. Then the pointer goes back.
    """
    return [("raise", target), ("click", x, y), ("pause", 0.02), ("cursor", cursor[0], cursor[1]), ("raise", desk)]


def _raise_window(hwnd):
    """Moves a window to the top of the stacking order without activating it."""
    if hwnd:
        user32.SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)


def _hide_system_cursor():
    """Hides the system cursor, counted: every call must be matched by _show_system_cursor (a finally block)."""
    if IS_WIN:
        user32.ShowCursor(False)


def _show_system_cursor():
    if IS_WIN:
        user32.ShowCursor(True)


GA_ROOT = 2
CLICK_MESSAGES = {
    "gone": "That window has closed.",
    "minimised": "That window is minimised. Restore it, then click again.",
    "covered": "Something else is on top of that window, so the click was not sent.",
    "blocked": "Windows did not accept the click. The program is probably running as administrator, which "
               "Spatial Desk cannot click into.",
}


def is_target_top(top_root, target_root):
    """True when the window at the click spot is the target window. Nothing at the spot (0) is not the target."""
    return bool(top_root) and top_root == target_root


def _root_window(hwnd):
    """The top-level window that hwnd belongs to (a control inside a window gives its window)."""
    root = user32.GetAncestor(hwnd, GA_ROOT) if hwnd else 0
    return root or hwnd


def _click_when_top(hwnd, x, y, attempts=3):
    """Sends the click only when the target is the window at that spot. If something else is on top, the target is
    raised again a few times. Returns 'ok', 'covered' or 'blocked'. A click that is never sent cannot reach the room
    or another window by mistake."""
    target = _root_window(hwnd)
    _activate(target)
    for _attempt in range(attempts):
        top = user32.WindowFromPoint(wintypes.POINT(x, y))
        if is_target_top(_root_window(top), target):
            return "ok" if _send_click(x, y) else "blocked"
        _raise_window(hwnd)
        time.sleep(0.01)
    return "covered"


def click_window_at(hwnd, u, v, desk=0, rest=None):
    """
    A click at (u, v) inside another window, by the first route that works (see window_clicks.py): UI Automation
    (the control is asked to act, the pointer does not move), then a message posted to the control (the pointer does
    not move, and the window does not come forward), then a real click. Returns 'ok', or the reason the click was not
    sent (see CLICK_MESSAGES).
    """
    rect = window_rect(hwnd)
    if not IS_WIN or rect is None or not user32.IsWindow(hwnd):
        return "gone"
    if user32.IsIconic(hwnd):
        return "minimised"
    x = rect[0] + int(round(u * (rect[2] - rect[0])))
    y = rect[1] + int(round(v * (rect[3] - rect[1])))
    target = _root_window(hwnd)
    child = wc.child_at(target, x, y)
    routes = wc.choose_routes(wc.class_name(target), wc.class_name(child) if child else "", bool(child))
    for route in routes:
        if route == "post":
            sent = wc.post_click(target, child, x, y)
            rh.log.info("click route post to %s: %s", wc.class_name(child), "sent" if sent else "refused")
            if sent:
                return "ok"
        elif route == "uia":
            outcome = _uia_click(target, desk, x, y)
            rh.log.info("click route uia: %s", outcome)
            if outcome == "invoked":
                return "ok"
            if outcome == "edit":            # a text field needs real focus
                break
        elif route == "send":
            break
    rh.log.info("click route send (real click)")
    return _real_click(target, desk, x, y, rest)


def _uia_click(target, desk, x, y):
    """Asks the control under the spot to act through UI Automation. That needs the window to be the top one there,
    so it is raised for the moment (without being activated) and the room is raised back after. The pointer does not
    move. Returns invoked, edit, none, error or covered."""
    raised = False
    try:
        if not is_target_top(_root_window(user32.WindowFromPoint(wintypes.POINT(x, y))), target):
            _raise_window(target)
            raised = True
            _wait_until(lambda: is_target_top(_root_window(user32.WindowFromPoint(wintypes.POINT(x, y))), target),
                        0.08, 0.004)
            if not is_target_top(_root_window(user32.WindowFromPoint(wintypes.POINT(x, y))), target):
                return "covered"
        return wc.UIA.invoke(target, wc.process_id(target), x, y)
    finally:
        if raised and desk:
            _raise_window(desk)


def _real_click(hwnd, desk, x, y, rest):
    """The real click: the pointer goes to the spot, the click is sent, and the pointer comes back (or rests in the
    middle of a newly focused window). The room is raised again afterwards. Returns 'ok' or the reason it was not sent.

    The system cursor is hidden for the whole click. The click has to move the real pointer onto the real window,
    and without this the arrow would be seen jumping there and back. The room draws its own dot where you are
    pointing, so nothing is lost by hiding the system cursor."""
    saved = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(saved))
    status = "ok"
    back = rest if rest is not None else (saved.x, saved.y)   # where the pointer ends: the window's middle after a focus
    _hide_system_cursor()
    try:
        for step in click_plan(hwnd, desk, x, y, back):
            if step[0] == "raise":
                _raise_window(step[1])
            elif step[0] == "click":
                status = _click_when_top(hwnd, step[1], step[2])
            elif step[0] == "pause":
                if status == "ok":
                    time.sleep(step[1])
            elif step[0] == "cursor":
                user32.SetCursorPos(step[1], step[2])     # the pointer goes back even when the click was not sent
    finally:
        _show_system_cursor()
    return status

def _click_screen_at(x, y):
    saved = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(saved))
    _hide_system_cursor()
    try:
        _send_click(x, y)
        user32.SetCursorPos(saved.x, saved.y)
    finally:
        _show_system_cursor()
    return True


MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
HWND_TOP = 0
SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE = 0x0001, 0x0002, 0x0010


def click_grab(grab, u, v, desk=0, rest=None):
    if grab.kind == "window":
        return click_window_at(grab.ident, u, v, desk, rest)
    import mss
    with mss.MSS() as sct:
        m = sct.monitors[grab.ident]
        x = m["left"] + int(u * m["width"])
        y = m["top"] + int(v * m["height"])
    # The room covers the screen, so for a click on the desktop it goes behind the desktop, and is raised again after.
    if not IS_WIN:
        return False
    if desk:
        _lower_window(desk)
    try:
        return _click_screen_at(x, y)
    finally:
        if desk:
            _raise_window(desk)


def exclude_from_capture(hwnd):
    """Stops this app's own window appearing in screen captures (prevents the mirror loop)."""
    if IS_WIN:
        try:
            user32.SetWindowDisplayAffinity(hwnd, 0x11)  # WDA_EXCLUDEFROMCAPTURE
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Frame capture. Each source runs in its own thread and keeps the latest frame.
# ---------------------------------------------------------------------------
def blur_backdrop(image, width, height):
    """Blurred, slightly dimmed copy of the 3D scene, used behind liquid-glass surfaces."""
    small = image.scaled(max(8, width // 6), max(8, height // 6),
                         Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    small = small.convertToFormat(QImage.Format.Format_RGBA8888)
    w, h, stride = small.width(), small.height(), small.bytesPerLine()
    raw = np.frombuffer(small.constBits(), dtype=np.uint8, count=h * stride).reshape(h, stride // 4, 4)[:, :w]
    a = raw.astype(np.float32)
    for _ in range(4):                                  # repeated cross blur ~ gaussian
        p = np.pad(a, ((1, 1), (1, 1), (0, 0)), mode="edge")
        a = (p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:] + 4.0 * a) / 8.0
    a = np.clip(a * 0.78, 0, 255).astype(np.uint8)      # slightly dimmer so the glass reads
    a = np.ascontiguousarray(a)
    out = QImage(a.data, w, h, w * 4, QImage.Format.Format_RGBA8888).copy()
    return QPixmap.fromImage(out).scaled(width, height, Qt.AspectRatioMode.IgnoreAspectRatio,
                                         Qt.TransformationMode.SmoothTransformation)


def read_battery():
    """(percent, on_charger) from Windows, or None when this PC has no battery."""
    if not IS_WIN:
        return None
    try:
        class SYSTEM_POWER_STATUS(ctypes.Structure):
            _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                        ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                        ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]
        st = SYSTEM_POWER_STATUS()
        kernel32 = ctypes.WinDLL("kernel32")
        if not kernel32.GetSystemPowerStatus(ctypes.byref(st)):
            return None
        pct = st.BatteryLifePercent
        if pct == 255 or (st.BatteryFlag & 128):          # 255 = unknown, 128 = no system battery
            return None
        return int(pct), st.ACLineStatus == 1
    except Exception:
        return None


QUICK_QSS = """
QLabel#qtime { color: #f4f6fa; font-size: 30pt; font-weight: 300; background: transparent; }
QLabel#qdate { color: #9aa3b5; font-size: 10pt; background: transparent; }
QLabel#qhint { color: #8b93a6; font-size: 9pt; background: transparent; }
QLabel#qrow { color: #eef1f6; font-size: 10pt; background: transparent; }
QPushButton#qtile { background: rgba(255,255,255,0.07); border: 0; border-radius: 22px;
                    color: #eef1f6; text-align: left; padding: 12px 14px; font-size: 10pt; font-weight: 600; }
QPushButton#qtile:hover { background: rgba(255,255,255,0.12); }
QPushButton#qtile:checked { background: rgba(246,248,252,0.94); color: #0c0c0e; }
QPushButton#qround { background: rgba(255,255,255,0.07); border: 0; border-radius: 26px; }
QPushButton#qround:hover { background: rgba(255,255,255,0.12); }
QPushButton#qround:checked { background: rgba(246,248,252,0.94); }
QPushButton#qghost { background: rgba(255,255,255,0.07); border: 0; border-radius: 16px;
                     color: #eef1f6; padding: 8px 16px; font-size: 9pt; }
QPushButton#qghost:hover { background: rgba(255,255,255,0.14); }
QPushButton#qx { background: transparent; border: 0; border-radius: 14px; }
QPushButton#qx:hover { background: rgba(255,255,255,0.12); }
QFrame#qlist { background: rgba(255,255,255,0.06); border-radius: 22px; }
QSlider#qslider::groove:horizontal { background: rgba(255,255,255,0.14); height: 14px; border-radius: 7px; }
QSlider#qslider::sub-page:horizontal { background: #f4f6fa; height: 14px; border-radius: 7px; }
QSlider#qslider::add-page:horizontal { background: rgba(255,255,255,0.14); height: 14px; border-radius: 7px; }
QSlider#qslider::handle:horizontal { background: #f4f6fa; width: 14px; margin: -2px 0; border-radius: 7px; }
"""


SETTINGS_QSS = """
QWidget#setbody { background: transparent; font-family: "Segoe UI Variable Text", "Segoe UI", sans-serif; }
QScrollArea#setscroll { background: transparent; border: 0; }
QLabel#settitle { color: #f5f6f8; font-family: "Segoe UI Variable Display", "Segoe UI"; font-size: 26pt; font-weight: 600; background: transparent; }
QLabel#setpagetitle { color: #f5f6f8; font-size: 12pt; font-weight: 600; background: transparent; }
QLabel#setsection { color: #7b8294; font-size: 8pt; font-weight: 600; background: transparent; padding: 0 6px; }
QLabel#setrowtitle { color: #eef0f4; font-size: 10.5pt; background: transparent; }
QLabel#setrowvalue { color: #8a92a3; font-size: 10pt; background: transparent; }
QLabel#setchev { color: #4f5667; font-size: 14pt; background: transparent; }
QLabel#setdesc { color: #7b8294; font-size: 9pt; background: transparent; padding: 0 6px; }
QLabel#setkey { color: #eef0f4; font-size: 9pt; font-weight: 600; background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.08); border-radius: 7px; padding: 3px 9px; }
QFrame#setgroup { background: rgba(255,255,255,0.035); border: 1px solid rgba(255,255,255,0.06); border-radius: 18px; }
QFrame#setsep { background: rgba(255,255,255,0.06); border: 0; }
QFrame#setrow { background: transparent; border: 0; }
QFrame#setrow:hover { background: rgba(255,255,255,0.035); border-radius: 14px; }
QPushButton#setback { background: transparent; border: 0; color: #c9ced9; font-size: 10.5pt; padding: 6px 4px; }
QPushButton#setback:hover { color: #ffffff; }
QPushButton#setdone { background: #eef0f4; border: 0; border-radius: 15px; color: #0b0c0f; padding: 7px 18px; font-size: 9.5pt; font-weight: 600; }
QPushButton#setdone:hover { background: #ffffff; }
QLineEdit#setsearch { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.07); border-radius: 14px; color: #eef0f4; padding: 10px 16px; font-size: 10.5pt; selection-background-color: #5a6275; }
QLineEdit#setsearch:focus { border: 1px solid rgba(255,255,255,0.18); }
QSpinBox#setspin { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.07); border-radius: 10px; color: #eef0f4; padding: 5px 10px; font-size: 10.5pt; min-width: 84px; }
QSlider#qslider::groove:horizontal { background: rgba(255,255,255,0.12); height: 6px; border-radius: 3px; }
QSlider#qslider::sub-page:horizontal { background: #eef0f4; height: 6px; border-radius: 3px; }
QSlider#qslider::add-page:horizontal { background: rgba(255,255,255,0.12); height: 6px; border-radius: 3px; }
QSlider#qslider::handle:horizontal { background: #ffffff; width: 16px; margin: -6px 0; border-radius: 8px; }
"""

SHORTCUT_LIST = (
    ("Space", "Switch between 3D and flat"),
    ("H", "Hover or follow"),
    ("L", "Arrangement"),
    ("R", "Recenter"),
    ("T", "Window ratio"),
    ("Home", "Home screen"),
    ("A", "Launcher"),
    ("P", "Windows"),
    ("F11", "Full screen"),
    ("Esc", "Back"),
    ("Scroll over a window", "Pull or push"),
    ("Shift + scroll over a window", "Slide it sideways"),
    ("Ctrl + scroll over a window", "Make it bigger or smaller"),
    ("Alt + drag", "Move a window"),
)


class ToggleSwitch(QAbstractButton):
    """An on/off switch in the style of a phone settings app."""
    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(bool(checked))
        self.setFixedSize(48, 28)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        on = self.isChecked()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(238, 240, 244) if on else QColor(255, 255, 255, 36))
        r = self.height() / 2.0
        p.drawRoundedRect(QRectF(0, 0, self.width(), self.height()), r, r)
        d = self.height() - 6
        x = self.width() - d - 3 if on else 3
        p.setBrush(QColor(12, 13, 16) if on else QColor(236, 238, 244))
        p.drawEllipse(QRectF(x, 3, d, d))
        p.end()


class SettingsRow(QFrame):
    """One line in a settings group: a coloured icon tile, a title, an optional value, then a switch,
    a control, or a chevron when the row opens a page."""
    def __init__(self, icon_kind, tile_color, title, value="", on_click=None, trailing=None,
                 chevron=True, parent=None):
        super().__init__(parent)
        self.setObjectName("setrow")
        self.setAttribute(Qt.WidgetAttribute.WA_Hover, True)
        self.setMinimumHeight(50)
        self.title_text = title
        self._on_click = on_click
        self._trailing = trailing
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 7, 14, 7)
        lay.setSpacing(12)
        tile = QLabel()
        tile.setFixedSize(30, 30)
        tile.setAlignment(Qt.AlignmentFlag.AlignCenter)
        tile.setPixmap(make_icon(icon_kind, QColor(226, 230, 238), px=60).pixmap(17, 17))
        tile.setStyleSheet("background: rgba(255,255,255,0.08); border-radius: 9px;")   # one neutral tile for every row
        lay.addWidget(tile)
        name = QLabel(title)
        name.setObjectName("setrowtitle")
        lay.addWidget(name, 1)
        if value:
            val = QLabel(value)
            val.setObjectName("setrowvalue")
            lay.addWidget(val)
        if trailing is not None:
            lay.addWidget(trailing)
        elif chevron:
            chev = QLabel("\u203a")
            chev.setObjectName("setchev")
            lay.addWidget(chev)
        if on_click is not None or isinstance(trailing, ToggleSwitch):
            self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.LeftButton:
            if isinstance(self._trailing, ToggleSwitch):
                self._trailing.toggle()
            elif self._on_click is not None:
                self._on_click()
        super().mousePressEvent(ev)


class StatusStrip(QWidget):
    """Small line under the dock: screen cast, notifications and Wi-Fi, the battery when the PC has one,
    then the clock, all packed on one line and centred under the dock."""
    CAST_CX = 9.0
    BELL_CX = 33.0
    WIFI_CX = 57.0
    BATTERY_X = 72.0
    CLOCK_W = 64                # room for the 12-hour clock, e.g. "12:05 PM"
    ZONES = ((0, 22, "cast_clicked"), (22, 46, "bell_clicked"), (46, 70, "wifi_clicked"))

    clicked = Signal()          # the battery and clock: opens the control centre
    cast_clicked = Signal()
    bell_clicked = Signal()
    wifi_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._battery = None
        self._battery_t = None
        self.bell_on = True
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_power()

    def _clock_x(self):
        return self.BATTERY_X + 30 if self._battery else self.BATTERY_X

    def mousePressEvent(self, ev):
        if ev.button() != Qt.MouseButton.LeftButton:
            return
        x = ev.position().x()
        for lo, hi, name in self.ZONES:
            if lo <= x < hi:
                getattr(self, name).emit()
                return
        self.clicked.emit()

    def refresh_power(self):
        """Re-reads the battery about every 30 seconds. Returns True if the width changed."""
        now = time.monotonic()
        if self._battery_t is not None and now - self._battery_t < 30.0:
            return False
        self._battery_t = now
        before = self.width()
        self._battery = read_battery()
        self.setFixedSize(int(self._clock_x() + self.CLOCK_W), 22)
        return self.width() != before

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        mid = self.height() / 2.0
        ink = QColor(240, 243, 248, 225)
        bell_ink = ink if self.bell_on else QColor(240, 243, 248, 80)
        p.setBrush(Qt.BrushStyle.NoBrush)

        # screen cast: a monitor with its stand
        cx = self.CAST_CX
        p.setPen(QPen(ink, 1.3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawRoundedRect(QRectF(cx - 7.5, mid - 5.5, 15, 10.5), 2.0, 2.0)
        p.drawLine(QPointF(cx - 3.5, mid + 7.5), QPointF(cx + 3.5, mid + 7.5))

        # notifications: a bell (the arc runs over the top, from left to right)
        bx = self.BELL_CX
        p.setPen(QPen(bell_ink, 1.3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        bell = QPainterPath()
        bell.moveTo(bx - 5.0, mid + 3.0)
        bell.lineTo(bx - 5.0, mid - 1.5)
        bell.arcTo(QRectF(bx - 5.0, mid - 6.5, 10.0, 10.0), 180, -180)
        bell.lineTo(bx + 5.0, mid + 3.0)
        bell.closeSubpath()
        p.drawPath(bell)
        p.drawLine(QPointF(bx - 6.5, mid + 3.0), QPointF(bx + 6.5, mid + 3.0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bell_ink)
        p.drawEllipse(QPointF(bx, mid + 5.8), 1.2, 1.2)
        p.setBrush(Qt.BrushStyle.NoBrush)

        # Wi-Fi: three arcs fanning up from a base dot, centred on the same line as the other icons
        p.setPen(QPen(ink, 1.3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        wx, base = self.WIFI_CX, mid + 4.0
        for r in (3.6, 7.0, 10.4):
            p.drawArc(QRectF(wx - r, base - r, 2 * r, 2 * r), 45 * 16, 90 * 16)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(ink)
        p.drawEllipse(QPointF(wx, base), 1.3, 1.3)
        p.setBrush(Qt.BrushStyle.NoBrush)

        # battery, if the PC has one
        if self._battery:
            pct, _charging = self._battery
            x0 = self.BATTERY_X
            p.setPen(QPen(ink, 1.2))
            p.drawRoundedRect(QRectF(x0, mid - 5, 20, 10), 2.6, 2.6)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(ink)
            p.drawRoundedRect(QRectF(x0 + 2, mid - 3, max(0.0, 16.0 * pct / 100.0), 6), 1.2, 1.2)
            p.drawRoundedRect(QRectF(x0 + 20.6, mid - 2.2, 1.8, 4.4), 0.8, 0.8)
            p.setBrush(Qt.BrushStyle.NoBrush)

        # clock
        p.setPen(ink)
        font = QFont("Segoe UI Variable Text", 9)
        font.setWeight(QFont.Weight.Medium)
        p.setFont(font)
        p.drawText(QRectF(self._clock_x(), 0, self.CLOCK_W, self.height()),
                   Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, clock_text())
        p.end()


class GlassFrame(QFrame):
    """
    Liquid-glass surface. It shows the blurred 3D scene behind it (the window keeps that picture
    up to date), then adds a light tint, a soft specular band across the top, and a lit rim.
    """
    def __init__(self, parent=None, radius=26, strength=1.0, soft=False):
        super().__init__(parent)
        self.radius = radius
        self.strength = strength
        self.soft = soft          # flat modern glass: no gloss band, a thin light edge only
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)

    def paintEvent(self, ev):
        s = self.strength
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        rad = min(self.radius, r.height() / 2.0)
        path = QPainterPath()
        path.addRoundedRect(r, rad, rad)

        # 1. the blurred scene behind the glass
        win = self.window()
        backdrop = getattr(win, "backdrop", None)
        if backdrop is not None:
            origin = self.mapTo(win, QPoint(0, 0))
            p.save()
            p.setClipPath(path)
            src_rect = QRectF(origin.x() + r.x(), origin.y() + r.y(), r.width(), r.height())
            p.drawPixmap(r, backdrop, src_rect)
            p.restore()
        else:
            p.fillPath(path, QColor(18, 18, 22, int(200 * s)))

        # 2. light tint, brighter toward the top
        tint = QLinearGradient(r.topLeft(), r.bottomLeft())
        tint.setColorAt(0.0, QColor(255, 255, 255, int((12 if self.soft else 30) * s)))
        tint.setColorAt(1.0, QColor(255, 255, 255, int((4 if self.soft else 6) * s)))
        p.fillPath(path, tint)

        # 3. specular band across the upper edge (skipped for flat glass)
        band_h = min(r.height() * 0.22, 26.0)
        band = QPainterPath()
        band_rect = QRectF(r.left() + rad * 0.6, r.top() + 2.5, r.width() - rad * 1.2, band_h)
        band.addRoundedRect(band_rect, band_h / 2.0, band_h / 2.0)
        bg = QLinearGradient(band_rect.topLeft(), band_rect.bottomLeft())
        bg.setColorAt(0.0, QColor(255, 255, 255, 0 if self.soft else int(46 * s)))
        bg.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.fillPath(band, bg)

        # 4. rim: a bright thin edge plus an inner highlight just inside it
        inner = QPainterPath()
        inner.addRoundedRect(r.adjusted(2.5, 2.5, -2.5, -2.5), max(rad - 2.5, 0), max(rad - 2.5, 0))
        ig = QLinearGradient(r.topLeft(), r.bottomRight())
        ig.setColorAt(0.0, QColor(255, 255, 255, int((22 if self.soft else 70) * s)))
        ig.setColorAt(0.5, QColor(255, 255, 255, 0))
        ig.setColorAt(1.0, QColor(255, 255, 255, int((10 if self.soft else 30) * s)))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QBrush(ig), 1.0))
        p.drawPath(inner)
        edge = QLinearGradient(r.topLeft(), r.bottomRight())
        edge.setColorAt(0.0, QColor(255, 255, 255, int((120 if self.soft else 170) * s)))
        edge.setColorAt(0.5, QColor(255, 255, 255, int((28 if self.soft else 40) * s)))
        edge.setColorAt(1.0, QColor(255, 255, 255, int((70 if self.soft else 110) * s)))
        p.setPen(QPen(QBrush(edge), 1.0 if self.soft else 1.3))
        p.drawPath(path)
        p.end()


# ----- home screen cards, painted to match the INAIR home reference
HOME_SIZES = {"calendar": (156, 186), "mail": (156, 88), "drive": (156, 88),
              "room": (264, 168), "windows": (264, 168), "pc": (322, 132),
              "hover": (124, 168), "recenter": (124, 168), "layout": (124, 168), "calibrate": (124, 168),
              }
HOME_RADIUS = {"calendar": 30, "mail": 24, "drive": 24, "room": 32, "windows": 32, "pc": 30,
               "hover": 26, "recenter": 26, "layout": 26, "calibrate": 26}
# gradient background for each widget card: (top colour, bottom colour)
HOME_GRADIENT = {"calendar": ("#ffffff", "#e3e8f1"), "mail": ("#ffd77a", "#f2a92e"),
                 "drive": ("#e4f0ff", "#a9c8f5")}
# the four action cards: dock colour, icon and title (the gradient is made from the colour)
HOME_ACTIONS = {"hover": ("#ff9f1a", "hover", "Hover"),
                "recenter": ("#34c759", "recenter", "Recenter"),
                "layout": ("#8b5cf6", "layers", "Layout"),
                "calibrate": ("#ff4d6d", "calibrate", "Calibrate")}
_HL = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
_HC = Qt.AlignmentFlag.AlignCenter
def _home_font(pt, weight=QFont.Weight.Normal):
    f = QFont()
    f.setFamilies(["Segoe UI Variable Text", "Segoe UI", "Helvetica Neue", "Arial"])
    f.setPointSizeF(pt)
    f.setWeight(weight)
    return f


def _home_text(p, rect, text, pt, color, weight=QFont.Weight.Normal, align=_HL):
    f = _home_font(pt, weight)
    p.setFont(f)
    p.setPen(QColor(color))
    text = QFontMetrics(f).elidedText(text, Qt.TextElideMode.ElideRight, int(rect.width()))
    p.drawText(rect, align, text)


class HomeCard(QAbstractButton):
    """A home-screen card. Kinds: calendar and pc (status only), mail and drive (open the web app),
    room (3D space), windows (the window list) and the four action cards (hover, recenter, layout,
    calibrate). Everything except calendar and pc acts when clicked."""

    CLICKABLE = ("mail", "drive", "room", "windows") + tuple(HOME_ACTIONS)

    def __init__(self, kind, text=None, parent=None):
        super().__init__(parent)
        self.kind = kind
        self.setFixedSize(*HOME_SIZES[kind])
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._text = dict(text or {})
        self._wall_path = None
        self.wallpaper = None
        if kind in self.CLICKABLE:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
        else:
            self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

    def set_text(self, **kw):
        if any(self._text.get(k) != v for k, v in kw.items()):
            self._text.update(kw)
            self.update()

    def set_wallpaper(self, path):
        if path == self._wall_path:
            return
        self._wall_path = path
        pm = QPixmap(path) if path and os.path.exists(path) else QPixmap()
        self.wallpaper = None if pm.isNull() else pm
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)   # half a pixel in, so the outline is not cut at the edge
        rad = HOME_RADIUS[self.kind]
        clip = QPainterPath()
        clip.addRoundedRect(r, rad, rad)
        p.setClipPath(clip)
        if self.kind == "calendar":
            self._paint_calendar(p, r)
        elif self.kind in ("mail", "drive"):
            self._paint_link(p, r)
        elif self.kind == "room":
            self._paint_room(p, r)
        elif self.kind == "windows":
            self._paint_windows(p, r)
        elif self.kind in HOME_ACTIONS:
            self._paint_action(p, r)
        else:
            self._paint_pc(p, r)
        p.setClipping(False)
        if self.kind in self.CLICKABLE and (self.isDown() or self.underMouse()):
            p.fillPath(clip, QColor(0, 0, 0, 40) if self.isDown() else QColor(255, 255, 255, 22))
        on = bool(self._text.get("on"))            # a switched-on action gets a brighter rim
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(255, 255, 255, 170 if on else 46), 2.0 if on else 1.0))
        p.drawPath(clip)
        p.end()

    # --- kinds
    def _paint_calendar(self, p, r):
        self._paint_gradient(p, r, *HOME_GRADIENT["calendar"])
        _home_text(p, QRectF(18, 14, r.width() - 36, 22), self._text.get("week", ""), 11, "#2f6df6",
                   QFont.Weight.Bold)
        _home_text(p, QRectF(14, 26, r.width() - 24, 100), self._text.get("day", ""), 66, "#111318",
                   QFont.Weight.Light)
        _home_text(p, QRectF(18, r.height() - 40, r.width() - 36, 24), "Calendar", 10.5, "#6b7280",
                   QFont.Weight.DemiBold)

    def _paint_link(self, p, r):
        self._paint_gradient(p, r, *HOME_GRADIENT[self.kind])
        p.save()
        p.translate(14, 12)
        p.scale(0.34, 0.34)                  # the logo is drawn on a 100 x 100 grid
        if self.kind == "mail":
            self._draw_gmail(p)
        else:
            self._draw_drive(p)
        p.restore()
        _home_text(p, QRectF(r.width() - 34, 8, 22, 32), "\u203A", 16, "#15161a", QFont.Weight.Normal, _HC)
        _home_text(p, QRectF(16, r.height() - 36, r.width() - 32, 24), self._text.get("label", ""), 11,
                   "#15161a", QFont.Weight.DemiBold)

    def _draw_gmail(self, p):
        """The Gmail M from the photo: pink-to-red left leg and V, yellow-green-blue right leg."""
        def leg(a, b, stops):
            g = QLinearGradient(QPointF(*a), QPointF(*b))
            for pos, col in stops:
                g.setColorAt(pos, QColor(col))
            p.setPen(QPen(QBrush(g), 18, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            p.drawLine(QPointF(*a), QPointF(*b))
        leg((15, 86), (15, 22), [(0.0, "#EA4335"), (1.0, "#EA4335")])
        leg((15, 22), (50, 58), [(0.0, "#E8457F"), (1.0, "#EA4335")])
        leg((50, 58), (85, 22), [(0.0, "#EA4335"), (1.0, "#FBBC04")])
        leg((85, 22), (85, 86), [(0.0, "#FBBC04"), (0.5, "#34A853"), (1.0, "#4285F4")])

    def _draw_drive(self, p):
        """The Drive triangle from the photo: green top, blue lower left, yellow lower right, white centre."""
        def poly(color, pts):
            p.setBrush(QColor(color))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawPolygon(QPolygonF([QPointF(x, y) for x, y in pts]))
        poly("#34A853", [(50, 8), (72.6, 48), (27.4, 48)])            # green top
        poly("#4285F4", [(27.4, 48), (50, 48), (50, 86), (6, 86)])    # blue lower left
        poly("#FBBC04", [(72.6, 48), (94, 86), (50, 86), (50, 48)])   # yellow lower right
        poly("#F6F8FB", [(50, 48), (36, 74), (64, 74)])               # white centre

    def _paint_room(self, p, r):
        if self.wallpaper is not None:
            pm = self.wallpaper.scaled(int(r.width()), int(r.height()),
                                       Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                       Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap(QPointF(-(pm.width() - r.width()) / 2, -(pm.height() - r.height()) / 2), pm)
        else:
            grad = QLinearGradient(0, 0, r.width(), r.height())
            grad.setColorAt(0.0, QColor("#3fd0ec"))
            grad.setColorAt(1.0, QColor("#0d5d86"))
            p.fillRect(r, grad)
        self._paint_shade(p, r)
        self._paint_badge(p, 18, 18, "3d", "#ffffff", "#0d3b52")
        self._paint_caption(p, r)

    def _paint_windows(self, p, r):
        grad = QLinearGradient(0, 0, 0, r.height())
        grad.setColorAt(0.0, QColor("#6e4a27"))
        grad.setColorAt(1.0, QColor("#2b1c10"))
        p.fillRect(r, grad)
        cx, cy = r.width() * 0.70, r.height() * 0.44
        p.setPen(Qt.PenStyle.NoPen)
        # three windows fanned out, as the books sit in the reference
        for dx, ang, body, bar in ((-16, -12, "#e59a35", "#bd7420"),
                                   (-4, -4, "#f3c765", "#d8a040"),
                                   (8, 7, "#fbe6ad", "#e6cc86")):
            p.save()
            p.translate(cx + dx, cy)
            p.rotate(ang)
            p.setBrush(QColor(body))
            p.drawRoundedRect(QRectF(-40, -46, 80, 92), 10, 10)
            p.setBrush(QColor(bar))
            p.drawRoundedRect(QRectF(-40, -46, 80, 14), 7, 7)
            p.restore()
        self._paint_shade(p, r)
        self._paint_badge(p, 18, 18, "windows", "#f4b43a", "#2a1a0c")
        self._paint_caption(p, r)

    def _paint_action(self, p, r):
        tint, icon, title = HOME_ACTIONS[self.kind]
        c = QColor(tint)
        self._paint_gradient(p, r, c.lighter(118).name(), c.darker(112).name())
        self._paint_shade(p, r, strength=80)
        self._paint_badge(p, 14, 14, icon, "#ffffff", c.darker(170).name())
        _home_text(p, QRectF(14, r.height() - 56, r.width() - 28, 24), title, 14, "#ffffff",
                   QFont.Weight.DemiBold)
        _home_text(p, QRectF(14, r.height() - 32, r.width() - 28, 18), self._text.get("sub", ""), 9, "#f4f6fa")

    def _paint_pc(self, p, r):
        grad = QLinearGradient(0, 0, r.width() * 0.6, r.height())
        grad.setColorAt(0.0, QColor("#2e3847"))
        grad.setColorAt(1.0, QColor("#121822"))
        p.fillRect(r, grad)
        glow = QRadialGradient(QPointF(r.width() * 0.78, r.height() * 0.30), r.width() * 0.36)
        glow.setColorAt(0.0, QColor(143, 184, 255, 70))
        glow.setColorAt(1.0, QColor(143, 184, 255, 0))
        p.fillRect(r, glow)
        # a small laptop, bottom right
        screen = QRectF(r.width() * 0.62, r.height() * 0.50, 72, 46)
        p.setPen(QPen(QColor(205, 218, 238, 170), 1.2))
        p.setBrush(QColor("#0a0e15"))
        p.drawRoundedRect(screen, 5, 5)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(205, 218, 238, 200))
        p.drawRoundedRect(QRectF(screen.left() - 9, screen.bottom() + 3, screen.width() + 18, 5), 2.5, 2.5)
        _home_text(p, QRectF(18, 14, r.width() - 36, 18), self._text.get("label", ""), 9, "#8fb8ff",
                   QFont.Weight.DemiBold)
        _home_text(p, QRectF(18, 34, r.width() * 0.6, 26), self._text.get("title", ""), 13.5, "#f4f6f9",
                   QFont.Weight.DemiBold)
        _home_text(p, QRectF(18, 58, r.width() * 0.6, 20), self._text.get("sub", ""), 9.5, "#b4bccb")

    # --- shared pieces
    def _paint_gradient(self, p, r, top, bottom):
        g = QLinearGradient(0, 0, 0, r.height())
        g.setColorAt(0.0, QColor(top))
        g.setColorAt(1.0, QColor(bottom))
        p.fillRect(r, g)

    def _paint_shade(self, p, r, strength=150):
        g = QLinearGradient(0, r.height() * 0.42, 0, r.height())
        g.setColorAt(0.0, QColor(0, 0, 0, 0))
        g.setColorAt(1.0, QColor(0, 0, 0, strength))
        p.fillRect(r, g)

    def _paint_caption(self, p, r):
        _home_text(p, QRectF(18, r.height() - 60, r.width() - 36, 26), self._text.get("title", ""), 15,
                   "#ffffff", QFont.Weight.DemiBold)
        _home_text(p, QRectF(18, r.height() - 33, r.width() - 36, 20), self._text.get("sub", ""), 9.5, "#e6e9f0")

    def _paint_badge(self, p, x, y, icon, fill, ink):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(fill))
        p.drawEllipse(QRectF(x, y, 36, 36))
        p.drawPixmap(QPointF(x + 8, y + 8), make_icon(icon, QColor(ink), px=64).pixmap(QSize(20, 20)))


class _SheetWatch(QObject):
    """Restores the home screen whenever the launcher sheet opens or closes."""
    def __init__(self, win):
        super().__init__(win)
        self.win = win

    def eventFilter(self, obj, ev):
        if ev.type() in (QEvent.Type.Show, QEvent.Type.Hide):
            QTimer.singleShot(0, self.win._refresh_home)
        return False


class _TunerWatch(QObject):
    """Closes the window card when this window is pressed outside the card."""
    def __init__(self, win):
        super().__init__(win)
        self.win = win

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.MouseButtonPress:
            self.win._tuner_outside_press(obj, ev)
        return False


def downscale_frame(shot, max_w):
    """Shrinks a capture to max_w pixels wide with smooth filtering, so text stays readable."""
    h, w = shot.shape[:2]
    if w <= max_w:
        return np.ascontiguousarray(shot)
    nh = max(1, int(round(h * max_w / w)))
    src = np.ascontiguousarray(shot)
    img = QImage(src.data, w, h, w * 4, QImage.Format.Format_ARGB32)
    small = img.scaled(max_w, nh, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    small = small.convertToFormat(QImage.Format.Format_ARGB32)
    return np.frombuffer(small.constBits(), dtype=np.uint8, count=nh * max_w * 4).reshape(nh, max_w, 4).copy()


DEPTH_PERIOD = 0.5           # seconds between depth estimates for one window
DEPTH_MAX_M = 0.15           # how far, in metres, the nearest parts of a window come toward you at 100%


TASKBAR_W = 3.2              # metres: the taskbar's width in the room
TASKBAR_Y = -0.92            # metres: below the eye, just under the row of windows (was -1.05, too far down)
TASKBAR_DIST = DEFAULT_DIST  # metres: how far away it sits
TASKBAR_ANGLE = math.atan2(-TASKBAR_Y, TASKBAR_DIST)   # radians below your eye to the taskbar (about 19 degrees)
TASKBAR_TILT = 0.12          # radians: leans a little toward you
TASKBAR_SLIDE = 0.06         # metres: how far it rises into view as you look down
TASKBAR_KEY_LO, TASKBAR_KEY_HI = 10.0, 30.0   # colour distances (0..255) where the background fades out


def taskbar_visibility(pitch):
    """0 while you look ahead, 1 once you look at the taskbar (negative pitch is down). It starts to show at half the
    angle the taskbar sits at and is fully there at nine tenths of it, so a small look down is enough."""
    return _smooth(TASKBAR_ANGLE * 0.5, TASKBAR_ANGLE * 0.9, -pitch)


def key_background(frame):
    """Makes the background of a picture transparent, so only the icons and text are left. The background is taken
    as the median colour of the picture, which is right for a taskbar, where icons cover only a small part."""
    if frame.ndim != 3 or frame.shape[2] != 4:
        return frame
    bg = np.median(frame[::4, ::4, :3].reshape(-1, 3), axis=0)
    dist = np.abs(frame[:, :, :3].astype(np.float32) - bg).max(axis=2)
    alpha = np.clip((dist - TASKBAR_KEY_LO) / (TASKBAR_KEY_HI - TASKBAR_KEY_LO), 0.0, 1.0)
    out = frame.copy()
    out[:, :, 3] = (alpha * 255.0).astype(np.uint8)
    return out


def find_taskbar():
    """The Windows taskbar window, or None when there is none (other systems, or it is not running)."""
    if not IS_WIN:
        return None
    return user32.FindWindowW("Shell_TrayWnd", None) or None


TASKBAR_PIC_W, TASKBAR_PIC_H = 1024, 72     # the taskbar picture, in pixels
TASKBAR_ICON, TASKBAR_GAP = 52, 14          # an app icon's size and the space between icons, in pixels
WS_EX_TOOLWINDOW, GWL_EXSTYLE = 0x00000080, -20
_NOT_APPS = ("Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd")


class StaticPicture:
    """A picture the app draws itself, shaped like a Grabber, so the texture code can use it."""
    kind = "static"
    ident = None
    keyed = False

    def __init__(self, frame):
        self._frame = frame
        self._version = 1

    def latest(self):
        return self._version, self._frame

    def latest_depth(self):
        return 0, None

    def set_frame(self, frame):
        self._frame = frame
        self._version += 1

    def stop(self):
        pass


def taskbar_slots(n, width=TASKBAR_PIC_W, icon=TASKBAR_ICON, gap=TASKBAR_GAP):
    """Where each of n app icons goes on the taskbar picture, as (x0, x1) pairs, centred in a row."""
    if n <= 0:
        return []
    pitch = min(icon + gap, (width - 16) / float(n))
    start = (width - pitch * n) / 2.0
    return [(start + k * pitch + (pitch - icon) / 2.0, start + k * pitch + (pitch - icon) / 2.0 + icon) for k in range(n)]


def taskbar_slot_at(slots, x):
    """The index of the icon at picture column x, or None. A little slack either side of each icon."""
    for k, (x0, x1) in enumerate(slots):
        if x0 - 6 <= x <= x1 + 6:
            return k
    return None


def program_path(hwnd):
    """The program file behind a window, or "" when it cannot be read. Windows only."""
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = HANDLE
    kernel32.QueryFullProcessImageNameW.argtypes = [HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [HANDLE]
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    handle = kernel32.OpenProcess(0x1000, False, pid.value)          # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return ""
    try:
        size = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(1024)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return buf.value
        return ""
    finally:
        kernel32.CloseHandle(handle)


def foreground_program():
    """The program file of the window in front of you, or "" off Windows or when there is none."""
    if not IS_WIN:
        return ""
    hwnd = user32.GetForegroundWindow()
    return program_path(hwnd) if hwnd else ""


def list_taskbar_apps():
    """The open app windows, as the taskbar lists them: (hwnd, title, program path). Minimised windows are included.
    Returns [] off Windows."""
    if not IS_WIN:
        return []
    own_pid = os.getpid()
    found = []
    proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def visit(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length == 0 or user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW:
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == own_pid:
            return True
        cls = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, cls, 256)
        if cls.value in _NOT_APPS:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        found.append((int(hwnd), buf.value, program_path(hwnd)))
        return True

    user32.EnumWindows(proc_type(visit), 0)
    return found


_ICON_CACHE = {}


def app_icon(path):
    """A program's icon as an RGBA array, read by Qt from the program file. None when there is no file."""
    if not path:
        return None
    if path not in _ICON_CACHE:
        icon = QFileIconProvider().icon(QFileInfo(path))
        img = icon.pixmap(TASKBAR_ICON, TASKBAR_ICON).toImage().convertToFormat(QImage.Format.Format_RGBA8888)
        arr = np.frombuffer(img.constBits(), dtype=np.uint8, count=img.sizeInBytes())
        _ICON_CACHE[path] = arr.reshape(img.height(), img.width(), 4).copy()
    return _ICON_CACHE[path]


def render_taskbar(apps, room_hwnds):
    """The taskbar picture: each app's icon in a row, with a dot under the apps that are in the room.
    Returns (BGRA picture for the texture, slots as (x0, x1, hwnd, title, path))."""
    img = QImage(TASKBAR_PIC_W, TASKBAR_PIC_H, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    slots = []
    for (x0, x1), (hwnd, title, path) in zip(taskbar_slots(len(apps)), apps):
        y0 = (TASKBAR_PIC_H - TASKBAR_ICON) / 2.0 - 4
        icon = app_icon(path)
        if icon is not None:
            h, w = icon.shape[:2]
            p.drawImage(QRectF(x0, y0, TASKBAR_ICON, TASKBAR_ICON),
                        QImage(icon.data, w, h, 4 * w, QImage.Format.Format_RGBA8888))
        if hwnd in room_hwnds:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 255, 255, 235))
            p.drawEllipse(QPointF((x0 + x1) / 2.0, TASKBAR_PIC_H - 7), 3.0, 3.0)
        slots.append((x0, x1, hwnd, title, path))
    p.end()
    rgba = img.convertToFormat(QImage.Format.Format_RGBA8888)
    arr = np.frombuffer(rgba.constBits(), dtype=np.uint8, count=rgba.sizeInBytes())
    arr = arr.reshape(TASKBAR_PIC_H, TASKBAR_PIC_W, 4)
    return arr[..., [2, 1, 0, 3]].copy(), slots


def make_taskbar():
    """The taskbar: the open apps as icons, drawn by the app. It does not copy the real taskbar, so it works
    whether or not the real one hides itself."""
    blank = np.zeros((TASKBAR_PIC_H, TASKBAR_PIC_W, 4), np.uint8)
    return {"grab": StaticPicture(blank), "name": "Taskbar", "tex": None, "shape": None, "slots": []}


class Grabber:
    depth_worker = None      # set when 2D to 3D is switched on (depth_model.DepthWorker)
    depth_on = False
    MAX_WIDTH = 2560  # frames are downscaled to this width; higher keeps text sharp up close

    def __init__(self, kind, ident, fps=24):
        self.kind = kind          # "screen" (ident = monitor index) or "window" (ident = hwnd)
        self.ident = ident
        self.fps = fps
        self.started = time.monotonic()
        self.error = None         # last problem, shown in the window list
        self._lock = threading.Lock()
        self._frame = None
        self._version = 0
        self._depth = None
        self._depth_version = 0
        self._last_depth = 0.0
        self.keyed = False                       # True makes the background transparent (the taskbar)
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _grab_taskbar(self, sct):
        """The taskbar is read from the screen under it, because its own window picture is often blank."""
        rect = window_rect(self.ident)
        if rect is None:
            return None
        return np.asarray(sct.grab({"left": rect[0], "top": rect[1], "width": rect[2] - rect[0],
                                    "height": rect[3] - rect[1]}))

    def _grab_window(self, sct):
        full = full_window_rect(self.ident)
        rect = window_rect(self.ident)
        if full is None or rect is None or user32.IsIconic(self.ident):
            return None
        picture = capture_window_pixels(self.ident, full[2] - full[0], full[3] - full[1])
        if picture is not None:
            return crop_picture(picture, full, rect)
        # Fallback: copy the screen under the window (fails if something covers it).
        region = {"left": rect[0], "top": rect[1], "width": rect[2] - rect[0], "height": rect[3] - rect[1]}
        return np.asarray(sct.grab(region))

    def _run(self):
        import mss
        period = 1.0 / self.fps
        try:
            with mss.MSS() as sct:
                while not self._stop.is_set():
                    started = time.monotonic()
                    try:
                        if self.kind == "screen":
                            shot = np.asarray(sct.grab(dict(sct.monitors[self.ident])))
                        elif self.kind == "taskbar":
                            shot = self._grab_taskbar(sct)
                            if shot is None:
                                time.sleep(0.25)
                                continue
                        else:
                            shot = self._grab_window(sct)
                            if shot is None:
                                self.error = "window is closed or minimised"
                                time.sleep(0.25)
                                continue
                        self.error = None
                        frame = downscale_frame(shot, self.MAX_WIDTH)
                        if self.keyed:
                            frame = key_background(frame)
                        with self._lock:
                            self._frame = frame
                            self._version += 1
                        self._maybe_ask_depth(frame)
                    except Exception as e:
                        self.error = f"{type(e).__name__}: {e}"
                        rh.log.exception("capture failed for %s %s", self.kind, self.ident)
                        time.sleep(0.5)
                    spent = time.monotonic() - started
                    if spent < period:
                        time.sleep(period - spent)
        except Exception:
            rh.log.exception("capture thread stopped")

    def _maybe_ask_depth(self, frame):
        """Gives the depth worker a small RGB copy of the picture, at most twice a second, while 2D to 3D is on."""
        worker = Grabber.depth_worker
        now = time.monotonic()
        if worker is None or not Grabber.depth_on or now - self._last_depth < DEPTH_PERIOD:
            return
        self._last_depth = now
        step = max(1, frame.shape[1] // 640)
        worker.submit(self, frame[::step, ::step, [2, 1, 0]])      # BGRA -> RGB, smaller

    def set_depth(self, depth):
        with self._lock:
            self._depth = depth
            self._depth_version += 1

    def latest_depth(self):
        with self._lock:
            return self._depth_version, self._depth

    def latest(self):
        with self._lock:
            return self._version, self._frame

    def has_picture(self):
        with self._lock:
            return self._frame is not None

    def age(self):
        return time.monotonic() - self.started

    def stop(self):
        self._stop.set()


# ---------------------------------------------------------------------------
# Matrix helpers (row-major, used with GL_TRUE transpose)
# ---------------------------------------------------------------------------
def curved_hit(origin, direction, place, w, h, kappa):
    """Where a view ray meets a window: (t, u, v) with u, v in texture coordinates (0..1, from the top left),
    or None if the ray misses. origin and direction are world-space 4-vectors. place is the window's placement
    without its size; the window is w by h metres and bends round you with curvature kappa (1 / bend radius)."""
    inv = np.linalg.inv(np.asarray(place, np.float64))
    lo = (inv @ np.asarray(origin, np.float64))[:3]
    ld = (inv @ np.asarray(direction, np.float64))[:3]
    if kappa <= 1e-9:
        if abs(ld[2]) < 1e-12:
            return None
        candidates, R = [-lo[2] / ld[2]], 0.0
    else:
        R = 1.0 / kappa
        oz = lo[2] - R                      # the bent window lies on a cylinder of radius R, centred on (0, R)
        a = ld[0] * ld[0] + ld[2] * ld[2]
        if a < 1e-12:
            return None
        b = 2.0 * (lo[0] * ld[0] + oz * ld[2])
        c = lo[0] * lo[0] + oz * oz - R * R
        disc = b * b - 4.0 * a * c
        if disc < 0.0:
            return None
        s = math.sqrt(disc)
        candidates = [(-b - s) / (2.0 * a), (-b + s) / (2.0 * a)]
    for t in sorted(candidates):
        if t <= 0.0:
            continue
        q = lo + t * ld
        x = R * math.atan2(q[0], R - q[2]) if R else q[0]    # arc length along the bent window
        u, v = x / w, q[1] / h
        if abs(u) <= 0.5 and abs(v) <= 0.5:
            return t, u + 0.5, 0.5 - v
    return None


def perspective(fovy_deg, aspect, near, far):
    f = 1.0 / math.tan(math.radians(fovy_deg) / 2.0)
    m = np.zeros((4, 4), np.float32)
    m[0, 0] = f / aspect
    m[1, 1] = f
    m[2, 2] = (far + near) / (near - far)
    m[2, 3] = 2.0 * far * near / (near - far)
    m[3, 2] = -1.0
    return m


def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1]], np.float32)


def rot_y(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]], np.float32)


def translate(x, y, z):
    m = np.eye(4, dtype=np.float32)
    m[0, 3], m[1, 3], m[2, 3] = x, y, z
    return m


def scale(x, y, z):
    return np.diag([x, y, z, 1.0]).astype(np.float32)


# Two triangles covering a unit square centred on the origin. Columns: x, y, z, u, v.
QUAD = np.array([
    -0.5, -0.5, 0.0, 0.0, 1.0,
     0.5, -0.5, 0.0, 1.0, 1.0,
     0.5,  0.5, 0.0, 1.0, 0.0,
    -0.5, -0.5, 0.0, 0.0, 1.0,
     0.5,  0.5, 0.0, 1.0, 0.0,
    -0.5,  0.5, 0.0, 0.0, 0.0,
], np.float32)
SCALE2 = scale(2.0, 2.0, 1.0)  # covers the whole screen in clip space


def build_panel_grid(cols=32, rows=24):
    """A window's quad cut into a grid, so the vertex shader can bend it. Same layout as QUAD: x, y, z, u, v."""
    out = []
    for i in range(cols):
        x0, x1 = -0.5 + i / cols, -0.5 + (i + 1) / cols
        for j in range(rows):
            y0, y1 = -0.5 + j / rows, -0.5 + (j + 1) / rows
            for x, y in ((x0, y0), (x1, y0), (x1, y1), (x0, y0), (x1, y1), (x0, y1)):
                out += [x, y, 0.0, x + 0.5, 0.5 - y]
    return np.array(out, np.float32)


VS = """#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
uniform mat4 uMvp;
out vec2 vUv;
void main() { vUv = aUv; gl_Position = uMvp * vec4(aPos, 1.0); }
"""
VS_PANEL = """#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
uniform mat4 uMvp;         // projection * view * placement (the size is applied here, not in the matrix)
uniform vec2 uSize;        // width and height in metres
uniform float uCurve;      // 1 / bend radius in metres; 0 keeps the window flat
uniform vec2 uCrop;        // the part of the picture shown (same as the fragment shader)
uniform sampler2D uDepth;  // the picture's depth: 1 = nearer, 0 = further
uniform float uDepthAmt;   // how far, in metres, the nearest parts come toward you (0 = off)
out vec2 vUv;
out vec2 vLocal;
void main() {
    vUv = aUv;
    vec2 m = aPos.xy * uSize;                           // metres, centred on the window
    vLocal = m;
    vec3 p = vec3(m, 0.0);
    if (uCurve > 1e-6) {
        float phi = m.x * uCurve;                       // the window wraps round an axis through you
        p = vec3(sin(phi) / uCurve, m.y, (1.0 - cos(phi)) / uCurve);
    }
    if (uDepthAmt > 0.0) {
        vec2 duv = (aUv - 0.5) * uCrop + 0.5;           // the same part of the depth map as of the picture
        p.z += uDepthAmt * textureLod(uDepth, duv, 0.0).r;
    }
    gl_Position = uMvp * vec4(p, 1.0);
}
"""
FS_PANEL = """#version 330 core
in vec2 vUv;
in vec2 vLocal;
out vec4 fragColor;
uniform sampler2D uTex;
uniform float uAlpha;
uniform float uDim;
uniform vec2 uSize;
uniform float uRadius;
uniform vec3 uEdge;
uniform float uEdgeAmt;
uniform vec2 uCrop;                                    // part of the picture shown, so a new shape is cropped, not stretched
void main() {
    vec2 half_size = uSize * 0.5;
    vec2 q = abs(vLocal) - (half_size - vec2(uRadius));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
    float aa = clamp(0.5 - d / max(fwidth(d), 1e-6), 0.0, 1.0);   // antialiased rounded corners
    if (aa <= 0.0) discard;
    vec2 tuv = (vUv - 0.5) * uCrop + 0.5;
    // Distance to the picture's nearest edge, in picture units (negative outside it). Edge pixels stay fully opaque,
    // and the edge of a letterboxed or cropped picture is soft over one pixel instead of jagged.
    float inside = min(min(tuv.x, 1.0 - tuv.x), min(tuv.y, 1.0 - tuv.y));
    float pic = clamp(inside / max(fwidth(inside), 1e-6) + 1.0, 0.0, 1.0);
    if (pic <= 0.0) discard;                           // outside the picture: transparent
    vec4 t = texture(uTex, tuv);
    float rim = smoothstep(-0.010, -0.002, d);         // thin lit edge, like a pane of glass
    vec3 c = mix(t.rgb, uEdge, rim * uEdgeAmt);
    fragColor = vec4(c * (1.0 - uDim), t.a * uAlpha * aa * pic);
}
"""
FS_GLOW = """#version 330 core
in vec2 vUv;
in vec2 vLocal;
out vec4 fragColor;
uniform vec2 uSize;      // size of the whole glow quad, window plus padding
uniform float uRadius;
uniform float uPad;
uniform float uFalloff;
uniform vec3 uColor;
uniform float uAlpha;
void main() {
    vec2 half_size = uSize * 0.5 - vec2(uPad);
    vec2 q = abs(vLocal) - (half_size - vec2(uRadius));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
    float a = exp(-max(d, 0.0) * uFalloff) * (1.0 - smoothstep(uPad * 0.6, uPad, d));
    a *= smoothstep(-0.006, 0.0, d);                    // nothing under the window itself
    fragColor = vec4(uColor, a * uAlpha);
}
"""
FS_BG = """#version 330 core
in vec2 vUv;
out vec4 fragColor;
uniform vec3 uTop;
uniform vec3 uBottom;
uniform sampler2D uBg;
uniform int uUseTex;
uniform float uDim;
uniform vec2 uRes;
uniform float uRadius;
void main() {
    vec2 half_size = uRes * 0.5;
    vec2 q = abs(gl_FragCoord.xy - half_size) - (half_size - vec2(uRadius));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
    if (d > 0.0) discard;
    vec3 c = mix(uBottom, uTop, 1.0 - vUv.y);
    vec2 g = vUv - vec2(0.5, 0.30);                    // a soft glow of colour high in the void
    c += uTop * 0.9 * exp(-dot(g, g) * 7.0);
    if (uUseTex == 1) c = texture(uBg, vUv).rgb;
    fragColor = vec4(c * (1.0 - uDim), 1.0);
}
"""
UNIFORMS = ("uMvp", "uTex", "uAlpha", "uDim", "uTop", "uBottom", "uBg", "uUseTex", "uRes", "uRadius", "uSize",
            "uColor", "uTime", "uScale", "uWarp", "uEdge", "uEdgeAmt", "uPad", "uFalloff", "uCrop", "uCurve", "uDepth", "uDepthAmt")

FS_FADE = """#version 330 core
out vec4 fragColor;
uniform float uAlpha;
void main() { fragColor = vec4(0.0, 0.0, 0.0, uAlpha); }
"""
INTRO_STARS_END = 2.6          # seconds: the starfield has slowed and the title has gone
INTRO_REVEAL = 2.2               # seconds: the title letters arrive, one after another
INTRO_TITLE = "Spatial Desk"
INTRO_END = 3.4                # seconds: windows have faded in and the launch animation hands over

VS_STAR = """#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in float aSize;
layout(location = 2) in float aPhase;
uniform mat4 uMvp;
uniform float uTime;
uniform float uScale;
uniform float uWarp;
out float vB;
void main() {
    vec4 p = uMvp * vec4(aPos, 1.0);
    p.xy *= 1.0 + uWarp * 3.0;                         // warp: stars rush outward from the centre of view
    gl_Position = p;
    gl_PointSize = aSize * uScale * (0.8 + 0.2 * sin(uTime * 1.7 + aPhase)) * (1.0 + uWarp * 2.2);
    vB = (0.55 + 0.45 * sin(uTime * 1.3 + aPhase)) * (1.0 + 0.6 * uWarp);
}
"""
FS_STAR = """#version 330 core
in float vB;
out vec4 fragColor;
uniform float uAlpha;
void main() {
    float d = length(gl_PointCoord - vec2(0.5));
    float a = smoothstep(0.5, 0.0, d);
    fragColor = vec4(vec3(0.86, 0.93, 1.0), a * min(vB, 1.0) * uAlpha);
}
"""


def build_stars(count=1400, radius=40.0, seed=7):
    """Random stars on a far sphere: x, y, z, size, phase per star."""
    rng = np.random.default_rng(seed)
    v = rng.normal(size=(count, 3))
    v /= np.linalg.norm(v, axis=1, keepdims=True)
    size = rng.uniform(1.0, 3.4, size=(count, 1)) ** 1.5
    phase = rng.uniform(0, 2 * math.pi, size=(count, 1))
    return np.hstack([v * radius, size, phase]).astype(np.float32).ravel()


def letter_reveal(progress, index, count, spread=0.55):
    """How far one letter has arrived: 0 not yet, 1 in place. The letters arrive one after another."""
    start = (index / max(1, count)) * spread
    return _smooth(0.0, 1.0, (progress - start) / (1.0 - spread))


OPEN_MS, CLOSE_MS = 380.0, 260.0      # how long a window takes to open and to close, in milliseconds
INTRO_TITLE_OUT = 2.3                 # seconds: the title starts to leave once every letter is in place


def window_motion(now, opened, closing):
    """How a window looks during its open or close animation, as (visible, scale): 1 for a settled window.
    opened is when it first appeared; closing is when it started to close, or None while it is open."""
    if closing is not None:
        k = _smooth(0.0, 1.0, (now - closing) * 1000.0 / CLOSE_MS)
        return 1.0 - k, 1.0 - 0.10 * k
    k = min(1.0, max(0.0, (now - opened) * 1000.0 / OPEN_MS))
    eased = 1.0 - (1.0 - k) ** 3                  # quick to start, soft to land
    return eased, 0.90 + 0.10 * eased


def inside_rounded(u, v, w, h, r):
    """Whether a point of a window's shape (u, v in 0..1 across the quad) is inside its rounded corners. w, h, r are in
    metres. The corners are rounded in the picture, the same way the shader rounds them, so a click on a corner that is
    not drawn is not a click on the window."""
    r = min(r, w / 2.0, h / 2.0)
    qx = abs((u - 0.5) * w) - (w / 2.0 - r)
    qy = abs((v - 0.5) * h) - (h / 2.0 - r)
    outside = math.hypot(max(qx, 0.0), max(qy, 0.0))
    return outside + min(max(qx, qy), 0.0) - r <= 1e-9


def visible_point(u, v, crop):
    """Where a point on a window's shape lies on its picture, as texture coordinates. None when it falls on the empty
    space round a picture that does not match the shape, which the picture does not cover. crop is from fit_scale()."""
    fx, fy = crop
    tu = (u - 0.5) * fx + 0.5
    tv = (v - 0.5) * fy + 0.5
    if tu < 0.0 or tu > 1.0 or tv < 0.0 or tv > 1.0:
        return None
    return tu, tv


def intro_progress(t, skip=False):
    """How far the intro title has been revealed, 0 to 1, at intro time t in seconds."""
    if skip:
        return 1.0
    return min(1.0, max(0.0, t / INTRO_REVEAL))


def fit_scale(quad_aspect, content_aspect):
    """How the picture sits on a window's shape, as (fx, fy) texture scales (height / width for both aspects).

    The picture keeps its own proportions: the side that limits it fills the shape, and the other side is above 1, so
    the picture sits in the middle with transparent space round it. Nothing is cut off and nothing is stretched:
    quad_aspect * fx / fy always equals content_aspect (the proportions the picture is shown at).
    """
    if quad_aspect < content_aspect:      # the shape is wider than the picture: the height fills, the sides are empty
        return content_aspect / quad_aspect, 1.0
    return 1.0, quad_aspect / content_aspect   # the shape is taller: the width fills, the top and bottom are empty


def make_intro_image(progress=1.0):
    """The product name and device name, drawn for one moment of the intro (progress 0 to 1) as a transparent image."""
    img = QImage(1600, 500, QImage.Format.Format_RGBA8888)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
    big = QFont("Segoe UI Variable Display", 104)
    big.setWeight(QFont.Weight.DemiBold)
    big.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 10)
    p.setFont(big)
    metrics = QFontMetrics(big)
    advances = [metrics.horizontalAdvance(ch) for ch in INTRO_TITLE]
    x = (1600 - sum(advances)) / 2.0
    for i, ch in enumerate(INTRO_TITLE):
        a = letter_reveal(progress, i, len(INTRO_TITLE))
        if a > 0.0:
            p.setOpacity(a)
            p.setPen(QColor(240, 246, 252, 255))
            p.drawText(QPointF(x, 230 + (1.0 - a) * 34.0), ch)
        x += advances[i]
    p.setOpacity(_smooth(0.62, 1.0, progress))
    small = QFont("Segoe UI Variable Text", 28)
    small.setWeight(QFont.Weight.Medium)
    small.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 9)
    p.setFont(small)
    p.setPen(QColor(int(ACCENT[0] * 255), int(ACCENT[1] * 255), int(ACCENT[2] * 255), 230))
    p.drawText(QRectF(0, 330, 1600, 80), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter,
               "RAYNEO AIR 3S PRO")
    p.end()
    return np.frombuffer(img.constBits(), dtype=np.uint8, count=1600 * 500 * 4).reshape(500, 1600, 4).copy()


def _smooth(a, b, x):
    t = min(1.0, max(0.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)


def clock_text(now=None):
    """The time in 12-hour form, the way the Windows clock shows it: 8:33 PM, 12:05 AM (no leading zero)."""
    t = now or time.localtime()
    hour = t.tm_hour % 12 or 12
    return f"{hour}:{t.tm_min:02d} {'AM' if t.tm_hour < 12 else 'PM'}"


def paint_icon(p, kind, r, color):
    """Simple line icons drawn with QPainter."""
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    cx, cy = x + w / 2.0, y + h / 2.0
    m = min(w, h) * 0.24
    pen = QPen(color, max(1.6, min(w, h) * 0.085))
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.save()
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)

    def line(a, b, c, d):
        p.drawLine(QPointF(a, b), QPointF(c, d))

    if kind == "add":
        line(cx, y + m, cx, y + h - m)
        line(x + m, cy, x + w - m, cy)
    elif kind == "minus":
        line(x + m, cy, x + w - m, cy)
    elif kind == "3d":
        p.drawPolygon(QPolygonF([QPointF(cx, y + m), QPointF(x + w - m, cy),
                                 QPointF(cx, y + h - m), QPointF(x + m, cy)]))
        line(x + m, cy, x + w - m, cy)
    elif kind == "flat":
        p.drawRoundedRect(QRectF(x + m, y + m, w - 2 * m, h * 0.55 - m), 3, 3)
        line(x + m, y + h - m, x + w - m, y + h - m)
    elif kind == "recenter":
        p.drawEllipse(QPointF(cx, cy), w * 0.26, h * 0.26)
        line(cx, y + m * 0.5, cx, y + m * 1.1)
        line(cx, y + h - m * 1.1, cx, y + h - m * 0.5)
        line(x + m * 0.5, cy, x + m * 1.1, cy)
        line(x + w - m * 1.1, cy, x + w - m * 0.5, cy)
    elif kind == "calibrate":
        p.drawEllipse(QPointF(cx, cy), w * 0.3, h * 0.3)
        p.drawPoint(QPointF(cx, cy))
    elif kind == "windows":
        p.drawRoundedRect(QRectF(x + m * 0.7, y + m * 0.9, w - m * 1.4, h - m * 1.8), 3, 3)
        line(x + w * 0.62, y + m * 0.9, x + w * 0.62, y + h - m * 0.9)
    elif kind == "settings":
        for k in (0.3, 0.5, 0.7):
            line(x + m, y + h * k, x + w - m, y + h * k)
    elif kind == "fullscreen":
        s_ = m * 0.9
        for ax, ay, dx, dy in ((x + m, y + m, 1, 1), (x + w - m, y + m, -1, 1),
                               (x + m, y + h - m, 1, -1), (x + w - m, y + h - m, -1, -1)):
            line(ax, ay, ax + dx * s_, ay)
            line(ax, ay, ax, ay + dy * s_)
    elif kind == "minimise":
        line(x + m, y + h - m, x + w - m, y + h - m)
    elif kind == "close":
        line(x + m, y + m, x + w - m, y + h - m)
        line(x + w - m, y + m, x + m, y + h - m)
    elif kind == "maximise":
        p.drawRoundedRect(QRectF(x + m, y + m, w - 2 * m, h - 2 * m), 3, 3)
    elif kind == "restore":
        p.drawRoundedRect(QRectF(x + m * 1.5, y + m * 0.7, w - 2.2 * m - m * 0.8, h - 2.2 * m - m * 0.8), 3, 3)
        p.drawRoundedRect(QRectF(x + m * 0.8, y + m * 1.5, w - 2.2 * m - m * 0.8, h - 2.2 * m - m * 0.8), 3, 3)
    elif kind == "hover":      # windows pinned in the room
        p.drawEllipse(QPointF(cx, cy - h * 0.12), w * 0.17, h * 0.17)
        line(cx, cy + h * 0.05, cx, y + h - m)
    elif kind == "follow":     # windows that travel with your gaze
        p.drawRoundedRect(QRectF(x + m, cy - h * 0.2, w * 0.4, h * 0.4), 3, 3)
        p.drawPolyline(QPolygonF([QPointF(x + w * 0.64, cy - h * 0.17), QPointF(x + w - m, cy),
                                  QPointF(x + w * 0.64, cy + h * 0.17)]))
    elif kind == "layers":
        p.drawRoundedRect(QRectF(x + m * 1.5, y + m * 0.8, w - 3 * m, h * 0.42), 3, 3)
        p.drawRoundedRect(QRectF(x + m, y + h * 0.42, w - 3 * m, h * 0.42), 3, 3)
    elif kind == "home":
        p.drawPolygon(QPolygonF([QPointF(cx, y + m * 0.6), QPointF(x + w - m, cy), QPointF(x + w - m * 1.3, cy),
                                 QPointF(x + w - m * 1.3, y + h - m), QPointF(x + m * 1.3, y + h - m),
                                 QPointF(x + m * 1.3, cy), QPointF(x + m, cy)]))
    elif kind == "shield":      # Air Neo: a shield with a check mark
        sh = QPolygonF([QPointF(cx, y + m * 0.6), QPointF(x + w - m * 1.2, y + m * 1.7), QPointF(x + w - m * 1.2, cy),
                        QPointF(cx, y + h - m * 0.6), QPointF(x + m * 1.2, cy), QPointF(x + m * 1.2, y + m * 1.7)])
        p.setPen(QPen(color, max(1.4, min(w, h) * 0.055), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPolygon(sh)
        p.drawPolyline(QPolygonF([QPointF(x + w * 0.37, cy), QPointF(x + w * 0.47, cy + h * 0.12),
                                  QPointF(x + w * 0.64, cy - h * 0.1)]))
    elif kind == "grid":
        s_ = (w - 2 * m) * 0.4
        p.setPen(QPen(color, max(1.4, min(w, h) * 0.055), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        for gx in (x + m, x + w - m - s_):
            for gy in (y + m, y + h - m - s_):
                p.drawRoundedRect(QRectF(gx, gy, s_, s_), 2, 2)
    p.restore()


def make_icon(kind, color=None, px=64):
    c = color or QColor(236, 242, 250)
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    paint_icon(p, kind, QRectF(0, 0, px, px), c)
    p.end()
    return QIcon(QPixmap.fromImage(img))


DOCK_TILE = 46                  # size of the glyph inside a dock tile, pixels
DOCK_BTN = 44                   # a dock tile is a squircle this size
DOCK_ICON = 30                  # the glyph inside a dock tile


def make_tile_icon(kind, top, bottom, glyph, size=DOCK_TILE):
    """A solid app-style squircle: a vivid colour, a bright rim along the top edge, and a solid glyph."""
    px = size * 2
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    r = QRectF(0, 0, px, px).adjusted(1, 1, -1, -1)
    path = QPainterPath()
    path.addRoundedRect(r, px * 0.27, px * 0.27)
    grad = QLinearGradient(r.topLeft(), r.bottomLeft())
    grad.setColorAt(0.0, top)
    grad.setColorAt(1.0, bottom)
    p.fillPath(path, grad)
    rim = QLinearGradient(r.topLeft(), QPointF(r.left(), r.top() + r.height() * 0.35))
    rim.setColorAt(0.0, QColor(255, 255, 255, 110))
    rim.setColorAt(1.0, QColor(255, 255, 255, 0))
    p.setPen(QPen(QBrush(rim), 2.4))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawPath(path)
    paint_icon(p, kind, QRectF(px * 0.22, px * 0.22, px * 0.56, px * 0.56), glyph)
    p.end()
    return QIcon(QPixmap.fromImage(img))


def find_installed_apps():
    """
    Microsoft apps installed on this PC, as (name, exe path). Each icon is read from the program
    itself, so the logos are the real ones. Only apps that exist are returned.
    """
    if not IS_WIN:
        return []
    import glob
    roots = [os.environ.get("ProgramFiles", r"C:\Program Files"),
             os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")]
    sysroot = os.environ.get("SystemRoot", r"C:\Windows")
    office = r"Microsoft Office\root\Office*\{}"
    patterns = [
        ("Word", office.format("WINWORD.EXE")),
        ("Excel", office.format("EXCEL.EXE")),
        ("PowerPoint", office.format("POWERPNT.EXE")),
        ("Outlook", office.format("OUTLOOK.EXE")),
        ("OneNote", office.format("ONENOTE.EXE")),
        ("Edge", r"Microsoft\Edge\Application\msedge.exe"),
        ("Teams", r"Microsoft\Teams\current\Teams.exe"),
    ]
    found = []
    for name, rel in patterns:
        for root in roots:
            hits = sorted(glob.glob(os.path.join(root, rel)), reverse=True)   # newest version first
            if hits:
                found.append((name, hits[0]))
                break
    for name, exe in (("Explorer", "explorer.exe"), ("Notepad", "notepad.exe")):
        path = os.path.join(sysroot, exe)
        if os.path.exists(path):
            found.append((name, path))
    return found


def make_app_icon(exe_path):
    """The program's own logo at dock size, or a null icon if Windows gives none (then the app is skipped)."""
    px = DOCK_TILE * 2
    pm = QFileIconProvider().icon(QFileInfo(exe_path)).pixmap(QSize(px, px))
    if pm.isNull():
        return QIcon()
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    p.drawPixmap(QRectF(0, 0, px, px), pm, QRectF(pm.rect()))
    p.end()
    return QIcon(QPixmap.fromImage(img))


def make_glyph_icon(kind, size=DOCK_TILE, color=None):
    """A plain glyph (white unless a colour is given) with no tile behind it."""
    px = size * 4
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    paint_icon(p, kind, QRectF(px * 0.2, px * 0.2, px * 0.6, px * 0.6), color or QColor(246, 248, 252, 240))
    p.end()
    return QIcon(QPixmap.fromImage(img))


def make_ai_icon(px=22, color=None):
    """The AI ring from the reference: a ring with a dot in the middle."""
    c = color or QColor(232, 241, 255)
    s = px * 2
    img = QImage(s, s, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setPen(QPen(c, s * 0.09))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawEllipse(QPointF(s / 2, s / 2), s * 0.36, s * 0.36)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(c)
    p.drawEllipse(QPointF(s / 2, s / 2), s * 0.1, s * 0.1)
    p.end()
    return QIcon(QPixmap.fromImage(img))


def _chevron_icon(color, px=22):
    """A left-pointing chevron for the back button."""
    s = px * 2
    img = QImage(s, s, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setPen(QPen(color, s * 0.09, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawPolyline(QPolygonF([QPointF(s * 0.62, s * 0.28), QPointF(s * 0.38, s * 0.5), QPointF(s * 0.62, s * 0.72)]))
    p.end()
    return QIcon(QPixmap.fromImage(img))


def _tile_style(top, bottom, hover, text_color=None):
    """Squircle styling for a dock tile: a vertical gradient, a lighter hover and a ring when checked."""
    body = f"background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {top}, stop:1 {bottom}); border: 0; border-radius: 16px; padding: 0;"
    text = f" color: {text_color}; font-size: 13pt; font-weight: 600;" if text_color else ""
    return (f"QPushButton {{ {body}{text} }}"
            f"QPushButton:hover {{ background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {hover}, stop:1 {top}); }}"
            f"QPushButton:pressed {{ background: {bottom}; }}"
            f"QPushButton:checked {{ border: 2px solid rgba(255,255,255,220); }}")


def make_icon_button(kind, slot, tip, primary=False, checkable=False, tint=None):
    """One dock control: a glyph on a quiet squircle, all the same size. The 3D button is near-white."""
    glyph = QColor(255, 255, 255, 240)
    b = QPushButton()
    b.setObjectName("apptile")
    b.setIcon(make_glyph_icon(kind, DOCK_ICON, glyph))
    b.setIconSize(QSize(DOCK_ICON, DOCK_ICON))
    b.setToolTip(tip)
    b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    b.setCheckable(checkable)
    b.setFixedSize(DOCK_BTN, DOCK_BTN)
    if primary:
        b.setStyleSheet("QPushButton { background: rgba(255,255,255,58); border: 0; border-radius: 14px; }"
                        "QPushButton:hover { background: rgba(255,255,255,84); }"
                        "QPushButton:pressed { background: rgba(255,255,255,40); }")
    b.clicked.connect(slot)
    return b


# Title bar above each window: a black, slightly see-through capsule with six icon buttons and no text,
# as in the approved design. Positions are in texture pixels.
BAR_W = round(HDR_W * 0.36)                           # about 36% of the window width
BAR_X0 = (HDR_W - BAR_W) / 2.0
BAR_X1 = BAR_X0 + BAR_W
BAR_TOP, BAR_H = 26.0, 40.0                           # rows of the capsule inside the title bar texture
BAR_ICON_SIZE = 18.0                                  # icon size in texture pixels
HDR_BTN_HALF = 16                                     # each button is 32 pixels across
HDR_BTNS = (("sidebar", BAR_X0 + 25), ("apps", BAR_X0 + 62), ("focus", (BAR_X0 + BAR_X1) / 2.0),
            ("min", BAR_X1 - 99), ("max", BAR_X1 - 62), ("close", BAR_X1 - 25))
BAR_ICON = {"sidebar": "sidebar", "apps": "apps", "focus": "focus",
            "min": "minimise", "max": "maximise", "close": "close"}


def title_hit(u):
    """Which title bar button sits at horizontal position u (0..1), or None."""
    x = u * HDR_W
    for key, cx in HDR_BTNS:
        if abs(x - cx) <= HDR_BTN_HALF:
            return key
    return None


def paint_bar_icon(p, kind, cx, cy, size, color):
    """One title bar icon, drawn on the same 24-unit grid as the design's icons."""
    k = size / 24.0
    p.save()
    p.translate(cx - size / 2.0, cy - size / 2.0)
    p.scale(k, k)
    pen = QPen(color, 1.6)                            # 1.6 units on the 24-unit grid, so it scales with the icon
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    if kind == "sidebar":
        p.drawRoundedRect(QRectF(4, 5, 16, 14), 3, 3)
        p.drawLine(QPointF(10, 5), QPointF(10, 19))
    elif kind == "apps":
        for x, y in ((5, 5), (14, 5), (5, 14), (14, 14)):
            p.drawRoundedRect(QRectF(x, y, 5, 5), 1.2, 1.2)
    elif kind == "focus":
        p.drawEllipse(QPointF(12, 12), 6, 6)
    elif kind == "minimise":
        p.drawLine(QPointF(6, 12), QPointF(18, 12))
    elif kind == "maximise":
        p.drawRoundedRect(QRectF(6, 6, 12, 12), 2, 2)
    elif kind == "close":
        p.drawLine(QPointF(7, 7), QPointF(17, 17))
        p.drawLine(QPointF(17, 7), QPointF(7, 17))
    p.restore()


def make_title_bar(name, has_picture, focused, dist, expanded):
    """The title bar texture: a black capsule, 85% opaque when the window is focused, 72% otherwise, with the icons.
    The name is not drawn, and the icons are the same in every state."""
    img = QImage(HDR_W, HDR_H, QImage.Format.Format_RGBA8888)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    path = QPainterPath()
    path.addRoundedRect(QRectF(BAR_X0, BAR_TOP, BAR_W, BAR_H), BAR_H / 2.0, BAR_H / 2.0)
    p.setPen(Qt.PenStyle.NoPen)
    p.fillPath(path, QColor(0, 0, 0, 217 if focused else 184))
    ink = QColor(236, 239, 244, 214 if focused else 150)
    mid = BAR_TOP + BAR_H / 2.0
    for key, cx in HDR_BTNS:
        paint_bar_icon(p, BAR_ICON[key], cx, mid, BAR_ICON_SIZE, ink)
    p.end()
    ptr = img.constBits()
    return np.frombuffer(ptr, dtype=np.uint8, count=HDR_W * HDR_H * 4).reshape(HDR_H, HDR_W, 4).copy()


def _program(vs_src, fs_src):
    def shader(kind, src):
        s = gl.glCreateShader(kind)
        gl.glShaderSource(s, src)
        gl.glCompileShader(s)
        if not gl.glGetShaderiv(s, gl.GL_COMPILE_STATUS):
            raise RuntimeError(gl.glGetShaderInfoLog(s).decode(errors="replace"))
        return s

    prog = gl.glCreateProgram()
    gl.glAttachShader(prog, shader(gl.GL_VERTEX_SHADER, vs_src))
    gl.glAttachShader(prog, shader(gl.GL_FRAGMENT_SHADER, fs_src))
    gl.glLinkProgram(prog)
    if not gl.glGetProgramiv(prog, gl.GL_LINK_STATUS):
        raise RuntimeError(gl.glGetProgramInfoLog(prog).decode(errors="replace"))
    return prog


def _make_texture(width, height, data=None, fmt=None, mip=False):
    tex = gl.glGenTextures(1)
    gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
    for pname, val in ((gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR_MIPMAP_LINEAR if mip else gl.GL_LINEAR), (gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR),
                       (gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE), (gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)):
        gl.glTexParameteri(gl.GL_TEXTURE_2D, pname, val)
    if mip:
        try:
            gl.glTexParameterf(gl.GL_TEXTURE_2D, 0x84FE, 8.0)   # GL_TEXTURE_MAX_ANISOTROPY_EXT
        except Exception:
            pass
    if data is not None:
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, width, height, 0, fmt or gl.GL_RGBA,
                        gl.GL_UNSIGNED_BYTE, data)
    return tex


# ---------------------------------------------------------------------------
# 3D scene: a starfield void with windows floating at their own depth
# ---------------------------------------------------------------------------
class Scene(QOpenGLWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.start_time = None          # set on the first frame, so the intro is always seen
        self.skip_intro = False
        self.intro_ended = False
        self.on_intro_end = None
        self.panels = []
        self.focused = None             # the window you last touched; gets the accent glow
        self.layout_name = "code"
        self.fov = FOV_DEFAULT
        self.follow = False             # False = hover (windows fixed in the room), True = follow your gaze
        self.curve = 1.0                # how far windows wrap round you: 0 flat, 1 a full wrap
        self.depth_amt = 0.0            # how far the nearest parts of a window come toward you, metres (0 = off)
        self.taskbar = None             # the streamed taskbar (make_taskbar), or None
        self._taskbar_vis = 0.0         # how far the taskbar is showing this frame, 0..1
        self._taskbar_hit = None        # where the taskbar was drawn this frame, for clicks
        self._fy = self._fp = 0.0       # where the follow rig currently points
        self.bg_top, self.bg_bottom = THEMES["space"]
        self.bg_tex = None
        self.bg_use = False
        self.bg_pending = None
        self.yaw = self.pitch = self.e = self.dim = 0.0
        self._last_view = np.eye(4, dtype=np.float32)
        self.on_click = None
        self.on_wheel = None
        self._press = None
        self.on_look = None
        self.on_gl_error = None
        self._drag = None
        self._to_delete = []
        self._uniforms = {}
        self._gl_failed = False
        self._warp_amp = 0.0
        self._warp_t0 = 0.0
        self._warp_dur = 0.2
        self._last_paint = None
        self.reserved_right = 0   # pixels on the right taken by the window list
        self.setMinimumSize(640, 400)
        self.setMouseTracking(True)             # the cursor follows the mouse with no button held
        self.cam_on = False                     # camera mode: the picture behind the room
        self.cam_pending = None
        self.cam_tex = None
        self.cam_size = None
        self.pointer = None                     # where the cursor is, in the room: (x, y), or None
        self.pointer_kind = "mouse"             # "mouse" or "hand" (a fingertip)
        self.pointer_over = False               # over a window? (held a moment after it leaves one)
        self._over_seen = -1e9                  # when the pointer was last over a window
        self.keys_rect = None                   # the virtual keyboard, (x, y, w, h), when camera mode is on
        self.keys_hover = None
        self.keys_pressed = None
        self.keys_tex = None
        self._keys_sig = None
        self.dot_tex = None
        self.ring_tex = None
        self._cursor_shape = Qt.CursorShape.BlankCursor
        self.setCursor(Qt.CursorShape.BlankCursor)   # the white dot is the cursor everywhere in the room

    # ----- starfield transition and follow rig
    def kick_warp(self, amount, dur=0.2):
        """Starfield rush: the signature transition when windows grow, shrink, open, close or move in depth."""
        self._warp_amp = max(amount, self._current_warp())
        self._warp_t0 = time.monotonic()
        self._warp_dur = dur

    def _current_warp(self):
        if self._warp_amp <= 0.0:
            return 0.0
        x = (time.monotonic() - self._warp_t0) / self._warp_dur
        if x >= 6.0:
            self._warp_amp = 0.0
            return 0.0
        return self._warp_amp * x * math.exp(1.0 - x)   # quick rise, long soft settle

    def set_follow(self, on):
        self.follow = bool(on)

    def reset_follow(self):
        self._fy = self._fp = 0.0

    def _follow_step(self, dt):
        """Windows stay put for small head movements, then drift after your gaze. Bigger windows drift slower."""
        if not self.follow:
            return
        widest = max([p.get("w_space", PANEL_W) for p in self.panels] or [PANEL_W])
        rate = 5.0 / (0.5 + widest)
        a = 1.0 - math.exp(-dt * rate)
        for attr, target, dead in (("_fy", self.yaw, 0.06), ("_fp", self.pitch, 0.05)):
            cur = getattr(self, attr)
            d = target - cur
            if abs(d) > dead:
                cur += (d - math.copysign(dead, d)) * a
                setattr(self, attr, cur)

    # ----- layout
    def _half_width_at(self, d):
        aspect = max(1.2, self.width() / max(1, self.height())) if self.height() else 1.6
        return math.tan(math.radians(self.fov) / 2.0) * aspect * d

    @staticmethod
    def _angle_for(width, dist):
        return 2.0 * math.asin(min(0.95, width / (2.0 * dist)))

    def _fit_width(self, hr, dist):
        """The widest a frame of height/width hr can be at distance dist, with its whole height inside the view."""
        half_h = math.tan(math.radians(self.fov) / 2.0) * dist             # half the visible height, in metres
        return (2.0 * half_h * VIEW_FILL) / max(0.05, hr)

    def _screen_of(self, world):
        """Where a point of the room (world coordinates) appears on screen, in the view's pixels. It uses the same view
        and field of view as pick(), so it is the inverse of pick(). None when the point is behind you."""
        W, H = max(1, self.width()), max(1, self.height())
        v = np.asarray(self._last_view, dtype=np.float64) @ np.array([world[0], world[1], world[2], 1.0])
        if v[2] >= -1e-6:
            return None
        tan_h = math.tan(math.radians(self.fov) / 2.0)
        x_ndc = (v[0] / -v[2]) / (tan_h * (W / H))
        y_ndc = (v[1] / -v[2]) / tan_h
        return ((x_ndc + 1.0) * 0.5 * W, (1.0 - y_ndc) * 0.5 * H)

    def _max_width_for(self, p, dist):
        """The widest a window can be at distance dist, with its whole frame (its shape) still inside the view."""
        shape = RATIOS.get(p.get("ratio", "auto"))
        hr = shape if shape is not None else p.get("aspect", 0.5625)       # height / width of the frame
        return self._fit_width(hr, dist)

    def _fit_row(self, widths, usable, gap):
        """Fits a row of windows into usable metres. Returns (widths, gap). The row always fits, however many windows
        there are and however close the first one is: the gap shrinks first, then the windows. Before, a row that
        was already too wide was left alone, so one window could fill the whole view."""
        n = len(widths)
        if n == 0:
            return [], gap
        usable = max(0.05, usable)
        gap = min(gap, 0.25 * usable / (n - 1)) if n > 1 else 0.0
        free = usable - gap * (n - 1)
        total = sum(widths)
        if total > free:
            f = free / total
            widths = [w * f for w in widths]
        return widths, gap

    def _panel_width(self, p, dist=None):
        """A window's width in metres: the default, scaled by its own size and by fullscreen, and narrowed when a tall
        shape (Portrait, or a tall app) would run off the top or bottom of the view."""
        width = PANEL_W * p.get("size", 1.0) * (EXPAND_FACTOR if p.get("expanded") else 1.0)
        return min(width, self._max_width_for(p, dist if dist is not None else p.get("dist", DEFAULT_DIST)))

    def relayout(self):
        """Places every window: a fitted row in setup, and an arrangement in 3D that avoids overlap."""
        panels = [p for p in self.panels if not p.get("hidden") and p.get("closing") is None]  # minimised or closing: no place
        n = len(panels)
        if n == 0:
            self.update()
            return
        gap_flat = 0.18
        # Setup row: sized to fit the space left of the window list, so nothing overlaps or runs off the edge.
        d0 = panels[0].get("dist", DEFAULT_DIST)
        widths = [self._panel_width(p, d0) for p in panels]
        half = self._half_width_at(d0)
        view_w = max(1, self.width())
        visible_frac = max(0.3, (view_w - self.reserved_right) / view_w)
        usable = 2.0 * half * visible_frac * 0.86
        widths, gap_row = self._fit_row(widths, usable, gap_flat)
        shift = -(self.reserved_right / view_w) * half  # centre the row in the visible area
        x = shift - (sum(widths) + gap_row * (n - 1)) / 2.0
        for p, w in zip(panels, widths):
            p["w_flat"] = w
            p["flat"] = np.array([x + w / 2.0, 0.0, -d0], np.float32)
            x += w + gap_row

        gap = LAYOUT_GAP[self.layout_name]
        if self.layout_name == "code":
            # Main window in the middle, the others in columns on either side, further back.
            main = next((i for i, p in enumerate(panels) if p.get("expanded")), 0)
            main_w = self._panel_width(panels[main])
            # Keep the whole arrangement inside the view: the main window sits a little further back,
            # and the side windows sit further still and a bit narrower, so both stay in frame.
            main_d = max(panels[main].get("dist", DEFAULT_DIST), CODE_MAIN_MIN_DIST)
            centres = {main: 0.0}
            spans = {main: main_w}
            right = self._angle_for(main_w, main_d) / 2.0 + gap
            left = -right
            side_w = PANEL_W * 0.78
            for k, i in enumerate([i for i in range(n) if i != main]):
                d = max(panels[i].get("dist", DEFAULT_DIST) + 0.8, CODE_SIDE_MIN_DIST)
                w = side_w * panels[i].get("size", 1.0)
                ang = self._angle_for(w, d)
                if k % 2 == 0:
                    centres[i] = right + ang / 2.0
                    right += ang + gap
                else:
                    centres[i] = left - ang / 2.0
                    left -= ang + gap
                spans[i] = w
            for i, p in enumerate(panels):
                d = max(p.get("dist", DEFAULT_DIST) + 0.8, CODE_SIDE_MIN_DIST) if i != main else main_d
                self._set_space(p, centres[i] + p.get("bearing", 0.0), d, spans[i])
        elif self.layout_name == "layers":
            # Windows stacked front to back, each on its own depth, fanned out a little so every one shows.
            main = next((i for i, p in enumerate(panels) if p.get("expanded")), 0)
            order = [main] + [i for i in range(n) if i != main]
            for rank, i in enumerate(order):
                p = panels[i]
                own = p.get("dist", DEFAULT_DIST)
                d = own + 0.55 * rank
                base_w = self._panel_width(p)
                w = base_w * (d / own) * (0.92 ** rank)       # farther windows keep about the same apparent size
                step = (rank + 1) // 2
                centre = (1 if rank % 2 else -1) * 0.17 * step if rank else 0.0
                self._set_space(p, centre + p.get("bearing", 0.0), d, w, y=0.11 * rank)
        else:
            # Ring around you: each window takes its own angle, with a gap between neighbours.
            widths = [self._panel_width(p) for p in panels]
            dists = [p.get("dist", DEFAULT_DIST) for p in panels]
            spans = [self._angle_for(w, d) for w, d in zip(widths, dists)]
            total = sum(spans) + gap * (n - 1)
            if n >= 3:                          # side windows sit closer to the edge; keep them inside the view
                widths = [w * 0.75 for w in widths]
            limit = min(5.4, 0.5 + 0.25 * n)   # a gentle arc that stays inside the view (about 90 deg for 3 windows)
            if total > limit:
                f = limit / total
                widths = [w * f for w in widths]
                spans = [self._angle_for(w, d) for w, d in zip(widths, dists)]
                total = sum(spans) + gap * (n - 1)
            cursor = -total / 2.0
            for i, p in enumerate(panels):
                c = cursor + spans[i] / 2.0 + p.get("bearing", 0.0)   # a window moved sideways keeps that place
                self._set_space(p, c, dists[i], widths[i])
                cursor += spans[i] + gap
        self.update()

    @staticmethod
    def _set_space(p, centre, dist, width, y=0.0):
        p["space"] = np.array([math.sin(centre) * dist, y, -math.cos(centre) * dist], np.float32)
        p["rot_space"] = -centre  # turns each window to face you
        p["w_space"] = width

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.relayout()

    def set_layout(self, name):
        self.layout_name = name
        self.relayout()

    def set_fov(self, degrees):
        self.fov = float(min(FOV_MAX, max(FOV_MIN, degrees)))
        self.relayout()

    def drop_panel(self, p):
        if p.get("tex") is not None:
            self._to_delete.append(p["tex"])
        if p.get("hdr_tex") is not None:
            self._to_delete.append(p["hdr_tex"])
        if p is self.focused:
            self.focused = None
        self.panels = [q for q in self.panels if q is not p]
        self.relayout()

    def set_view(self, yaw, pitch, e, dim):
        self.yaw, self.pitch, self.e, self.dim = yaw, pitch, e, dim
        self.update()

    def set_theme(self, name):
        self.bg_top, self.bg_bottom = THEMES[name]
        self.bg_use = False
        self.update()

    def set_background_image(self, path):
        img = QImage(path)
        if img.isNull():
            return False
        img = img.convertToFormat(QImage.Format.Format_RGBA8888)
        w, h = img.width(), img.height()
        bpl = img.bytesPerLine()
        raw = np.frombuffer(img.constBits(), dtype=np.uint8, count=bpl * h)
        raw = raw.reshape(h, bpl)[:, : w * 4].reshape(h, w, 4).copy()
        self.bg_pending = (w, h, raw)
        self.update()
        return True

    # ----- GL setup
    def initializeGL(self):
        try:
            rh.log.info("OpenGL %s on %s", gl.glGetString(gl.GL_VERSION).decode(errors="replace"),
                        gl.glGetString(gl.GL_RENDERER).decode(errors="replace"))
        except Exception:
            pass
        gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
        self.prog_panel = _program(VS_PANEL, FS_PANEL)
        self.prog_glow = _program(VS_PANEL, FS_GLOW)
        self.prog_bg = _program(VS, FS_BG)
        self.prog_star = _program(VS_STAR, FS_STAR)
        self.prog_fade = _program(VS, FS_FADE)
        for prog in (self.prog_panel, self.prog_glow, self.prog_bg, self.prog_star, self.prog_fade):
            self._uniforms[prog] = {n: gl.glGetUniformLocation(prog, n) for n in UNIFORMS}

        self.vao = gl.glGenVertexArrays(1)
        self.vbo = gl.glGenBuffers(1)
        gl.glBindVertexArray(self.vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, QUAD.nbytes, QUAD, gl.GL_STATIC_DRAW)
        gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(0))
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(1, 2, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(12))
        gl.glEnableVertexAttribArray(1)

        self.dot_tex = _make_texture(pointer_art.DOT_TEX, pointer_art.DOT_TEX,
                                     pointer_art.image_bytes(pointer_art.dot_image()))
        self.ring_tex = _make_texture(pointer_art.DOT_TEX, pointer_art.DOT_TEX,
                                      pointer_art.image_bytes(pointer_art.ring_image()))
        self.grid_vao = gl.glGenVertexArrays(1)
        self.grid_vbo = gl.glGenBuffers(1)
        grid = build_panel_grid()
        self.grid_count = len(grid) // 5
        gl.glBindVertexArray(self.grid_vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.grid_vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, grid.nbytes, grid, gl.GL_STATIC_DRAW)
        gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(0))
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(1, 2, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(12))
        gl.glEnableVertexAttribArray(1)

        stars = build_stars()
        self.star_count = len(stars) // 5
        self.star_vao = gl.glGenVertexArrays(1)
        self.star_vbo = gl.glGenBuffers(1)
        gl.glBindVertexArray(self.star_vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.star_vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, stars.nbytes, stars, gl.GL_STATIC_DRAW)
        gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(0))
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(1, 1, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(12))
        gl.glEnableVertexAttribArray(1)
        gl.glVertexAttribPointer(2, 1, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(16))
        gl.glEnableVertexAttribArray(2)
        gl.glBindVertexArray(0)

        self.intro_tex = _make_texture(1600, 500, make_intro_image(0.0))
        self._intro_prog = 0.0
        self.white_tex = _make_texture(1, 1, np.array([235, 242, 255, 255], np.uint8))
        self.accent_tex = _make_texture(1, 1, np.array([int(c * 255) for c in ACCENT] + [255], np.uint8))

        gl.glEnable(gl.GL_PROGRAM_POINT_SIZE)
        gl.glEnable(gl.GL_BLEND)
        gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)
        gl.glClearColor(0.0, 0.0, 0.0, 1.0)

    def _upload_depth(self, p, depth):
        """Uploads a window's depth map (1 = nearer) as a one-channel texture for the vertex shader."""
        data = (np.clip(depth, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
        h, w = data.shape
        gl.glActiveTexture(gl.GL_TEXTURE1)
        if p.get("dep_tex") is None:
            p["dep_tex"] = gl.glGenTextures(1)
            gl.glBindTexture(gl.GL_TEXTURE_2D, p["dep_tex"])
            for pname, val in ((gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR), (gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR),
                               (gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE), (gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)):
                gl.glTexParameteri(gl.GL_TEXTURE_2D, pname, val)
        gl.glBindTexture(gl.GL_TEXTURE_2D, p["dep_tex"])
        gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_R8, w, h, 0, gl.GL_RED, gl.GL_UNSIGNED_BYTE, data)
        gl.glActiveTexture(gl.GL_TEXTURE0)

    def _sync_texture(self, p):
        ver_d, dep = p["grab"].latest_depth() if hasattr(p["grab"], "latest_depth") else (0, None)
        if dep is not None and ver_d != p.get("dep_ver"):
            self._upload_depth(p, dep)
            p["dep_ver"] = ver_d
        version, frame = p["grab"].latest()
        if frame is None or version == p.get("ver"):
            return
        p["ver"] = version
        h, w = frame.shape[:2]
        if p.get("tex") is None:
            p["tex"] = _make_texture(w, h, mip=True)
            p["shape"] = None
        gl.glBindTexture(gl.GL_TEXTURE_2D, p["tex"])
        if p.get("shape") != (h, w):
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, w, h, 0, gl.GL_BGRA, gl.GL_UNSIGNED_BYTE, frame)
            p["shape"] = (h, w)
        else:
            gl.glTexSubImage2D(gl.GL_TEXTURE_2D, 0, 0, 0, w, h, gl.GL_BGRA, gl.GL_UNSIGNED_BYTE, frame)
        gl.glGenerateMipmap(gl.GL_TEXTURE_2D)   # smaller copies, so small text does not shimmer or alias
        old_aspect = p.get("aspect")
        p["aspect"] = h / w  # the window keeps the capture's shape, so nothing is stretched
        if old_aspect is None or abs(p["aspect"] - old_aspect) > 0.05 * old_aspect:
            self._layout_dirty = True     # the shape changed: the widths are fitted again before the next frame

    def _t(self):
        now = time.monotonic()
        if self.start_time is None:
            self.start_time = now
        return now - self.start_time

    def _sync_title(self, p, focused):
        has = p["grab"].has_picture()
        key = (p["name"], has, focused, bool(p.get("expanded")), round(p.get("dist", DEFAULT_DIST), 1))
        if p.get("hdr_key") == key:
            return
        p["hdr_key"] = key
        raw = make_title_bar(p["name"], has, focused, p.get("dist", DEFAULT_DIST), bool(p.get("expanded")))
        if p.get("hdr_tex") is None:
            p["hdr_tex"] = _make_texture(HDR_W, HDR_H)
        gl.glBindTexture(gl.GL_TEXTURE_2D, p["hdr_tex"])
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, HDR_W, HDR_H, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, raw)

    # ----- drawing
    def paintGL(self):
        if self._gl_failed:
            return
        try:
            self._paint()
        except Exception:
            self._gl_failed = True
            rh.log.exception("OpenGL drawing failed; the 3D view is disabled. Restart the app to retry.")
            if self.on_gl_error:
                self.on_gl_error()

    def _paint(self):
        for tex in self._to_delete:
            gl.glDeleteTextures([tex])
        self._to_delete = []

        now = time.monotonic()
        dt = min(0.1, now - self._last_paint) if self._last_paint else 0.016
        self._last_paint = now

        dpr = self.devicePixelRatioF()
        pw, ph = max(1, int(self.width() * dpr)), max(1, int(self.height() * dpr))
        gl.glViewport(0, 0, pw, ph)
        gl.glClear(gl.GL_COLOR_BUFFER_BIT)

        if self.bg_pending is not None:
            w, h, raw = self.bg_pending
            self.bg_pending = None
            if self.bg_tex is None:
                self.bg_tex = _make_texture(w, h)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self.bg_tex)
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, w, h, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, raw)
            self.bg_use = True

        # Background (with the rounded frame of the app window)
        gl.glBindVertexArray(self.vao)
        u = self._uniforms[self.prog_bg]
        gl.glUseProgram(self.prog_bg)
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, SCALE2)
        gl.glUniform3f(u["uTop"], *self.bg_top)
        gl.glUniform3f(u["uBottom"], *self.bg_bottom)
        gl.glUniform1f(u["uDim"], self.dim)
        gl.glUniform1i(u["uUseTex"], 1 if self.bg_use else 0)
        gl.glUniform1i(u["uBg"], 1)
        gl.glUniform2f(u["uRes"], pw, ph)
        gl.glUniform1f(u["uRadius"], CORNER_RADIUS * dpr)
        if self.bg_use:
            gl.glActiveTexture(gl.GL_TEXTURE1)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self.bg_tex)
            gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

        aspect = max(0.01, self.width() / max(1, self.height()))
        proj = perspective(self.fov, aspect, 0.05, 60.0)
        # Head movement moves the camera, so windows stay fixed in the room (hover) unless follow carries them.
        view = rot_x(-self.pitch * self.e) @ rot_y(self.yaw * self.e)
        self._last_view = view

        t = self._t()
        if self.skip_intro:
            t = INTRO_END + 1.0
        self._sync_intro(t)     # the title is re-drawn as it reveals, from the first frame, title phase included
        warp = self._current_warp()
        if t < INTRO_STARS_END:
            warp = max(warp, 2.2 * (1.0 - _smooth(0.0, INTRO_STARS_END, t)))   # fly in, then slow to a stop

        # Starfield: far away, so it only follows head rotation
        u = self._uniforms[self.prog_star]
        gl.glUseProgram(self.prog_star)
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view).astype(np.float32))
        gl.glUniform1f(u["uTime"], self._t())
        gl.glUniform1f(u["uScale"], dpr)
        gl.glUniform1f(u["uAlpha"], 1.0)
        gl.glUniform1f(u["uWarp"], warp)
        gl.glBindVertexArray(self.star_vao)
        gl.glDrawArrays(gl.GL_POINTS, 0, self.star_count)

        # Launch animation, part 1: stars rush in from black, then the title shows with the windows still hidden
        if t < INTRO_STARS_END:
            title = _smooth(0.0, 0.3, t) * (1.0 - _smooth(INTRO_TITLE_OUT, INTRO_STARS_END, t))
            if title > 0.0:
                self._draw_title(title)
            black = 1.0 - _smooth(0.0, 0.6, t)
            if black > 0.0:
                self._draw_black(black)
            return

        alpha = _smooth(INTRO_STARS_END - 0.2, INTRO_END, t)   # windows fade in over the stars
        self._draw_camera()
        self._draw_windows(proj, view, dt, alpha)
        self._draw_taskbar(proj, view, alpha)
        self._draw_overlays()

        if t >= INTRO_END and not self.intro_ended:
            self.intro_ended = True
            if self.on_intro_end is not None:
                self.on_intro_end()

    def _kappa(self, p, e):
        """How strongly a window bends round you: 1 / its bend radius, in 1/metres. Flat in the setup row."""
        if p.get("curve_off") or self.curve <= 0.0 or e <= 0.0:
            return 0.0
        dist = max(0.5, float(np.linalg.norm(p["apos"])))
        return self.curve * e / dist

    def _draw_windows(self, proj, view, dt, alpha):
        if getattr(self, "_layout_dirty", False):
            self._layout_dirty = False
            self.relayout()
        e = self.e
        self._follow_step(dt)
        fy, fp = self._fy * e, self._fp * e
        F = rot_y(-fy) @ rot_x(fp)      # the inverse of the view turn, so a following window stays in front of you

        # Ease each window to where it should be, so layout changes glide instead of jump.
        k = 1.0 - math.exp(-dt * 10.0)
        items = []
        now = time.monotonic()
        for p in self.panels:
            if p.get("hidden"):
                continue
            closing = p.get("closing")
            if closing is not None and now - closing >= CLOSE_MS / 1000.0:
                continue            # closed: MainWindow takes the window out of the list
            self._sync_texture(p)
            if p.get("tex") is None or "flat" not in p:
                continue
            if p.get("opened") is None:
                p["opened"] = now   # the open animation starts once the picture is ready
            tw = p["w_flat"] * (1.0 - e) + p.get("w_space", p["w_flat"]) * e
            tpos = p["flat"] * (1.0 - e) + p["space"] * e
            trot = p.get("rot_space", 0.0) * e
            if "aw" not in p:
                p["aw"], p["apos"], p["arot"] = tw, tpos.copy(), trot
            else:
                p["aw"] += (tw - p["aw"]) * k
                p["apos"] = p["apos"] + (tpos - p["apos"]) * k
                p["arot"] += (trot - p["arot"]) * k
            items.append(p)
        items.sort(key=lambda q: -float(np.linalg.norm(q["apos"])))   # far windows first, so near ones cover them

        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindVertexArray(self.grid_vao)
        for p in items:
            focused = p is self.focused
            vis, sc = window_motion(now, p["opened"], p.get("closing"))
            if vis < 0.002:
                continue
            alpha_p = alpha * vis
            w = p["aw"]
            cap = p.get("aspect", 0.5625)
            target = RATIOS.get(p.get("ratio", "auto"))
            want = cap if target is None else target
            hr = p.get("hr", want)
            hr += (want - hr) * min(1.0, dt * 6.0)              # the shape turns over a few tenths of a second
            p["hr"] = hr
            # A window never gets taller than the view allows, whatever shape its app has now. Without this, an app
            # that turned tall kept its old width, and its height ran off the screen until the room was relaid out.
            view_dist = max(0.5, float(np.linalg.norm(p["apos"])))
            w = min(w, self._fit_width(hr, view_dist))
            h = w * hr
            crop = fit_scale(hr, cap)   # the whole picture stays in view: letterboxed, never cut
            base = F @ translate(*p["apos"]) @ rot_y(p["arot"]) @ scale(sc, sc, sc)
            target_kappa = self._kappa(p, e)
            ka = p.get("kappa_a", target_kappa)
            ka += (target_kappa - ka) * min(1.0, dt * 5.0)     # a few tenths of a second
            p["kappa_a"] = ka
            kappa = ka
            p["pick"] = {"place": base, "w": w, "h": h, "kappa": kappa, "crop": crop}

            # Soft glow behind the window: accent for the one you are working in, faint white for the rest
            g = self._uniforms[self.prog_glow]
            gl.glUseProgram(self.prog_glow)
            gw, gh = w + 2 * GLOW_PAD, h + 2 * GLOW_PAD
            gm = base @ translate(0.0, 0.0, -0.003)
            gl.glUniformMatrix4fv(g["uMvp"], 1, gl.GL_TRUE, (proj @ view @ gm).astype(np.float32))
            gl.glUniform2f(g["uSize"], gw, gh)
            gl.glUniform1f(g["uCurve"], kappa)
            gl.glUniform1f(g["uDepthAmt"], 0.0)
            gl.glUniform1f(g["uRadius"], PANEL_CORNER)
            gl.glUniform1f(g["uPad"], GLOW_PAD)
            gl.glUniform1f(g["uFalloff"], 20.0)
            gl.glUniform3f(g["uColor"], *(ACCENT if focused else (0.80, 0.88, 1.0)))
            gl.glUniform1f(g["uAlpha"], 0.0)
            gl.glDrawArrays(gl.GL_TRIANGLES, 0, self.grid_count)

            # The window itself
            u = self._uniforms[self.prog_panel]
            gl.glUseProgram(self.prog_panel)
            gl.glUniform1f(u["uDim"], self.dim)
            gl.glUniform1f(u["uAlpha"], alpha_p)
            gl.glUniform1i(u["uTex"], 0)
            gl.glUniform1f(u["uRadius"], PANEL_CORNER)
            gl.glUniform3f(u["uEdge"], *(ACCENT if focused else (0.85, 0.90, 1.0)))
            gl.glUniform1f(u["uEdgeAmt"], 0.12 if focused else 0.04)
            gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view @ base).astype(np.float32))
            gl.glUniform2f(u["uSize"], w, h)
            gl.glUniform2f(u["uCrop"], *crop)
            gl.glUniform1f(u["uCurve"], kappa)
            dep = p.get("dep_tex")
            gl.glActiveTexture(gl.GL_TEXTURE1)
            gl.glBindTexture(gl.GL_TEXTURE_2D, dep if dep is not None else self.white_tex)
            gl.glActiveTexture(gl.GL_TEXTURE0)
            gl.glUniform1i(u["uDepth"], 1)
            gl.glUniform1f(u["uDepthAmt"], self.depth_amt if dep is not None else 0.0)
            gl.glBindTexture(gl.GL_TEXTURE_2D, p["tex"])
            gl.glDrawArrays(gl.GL_TRIANGLES, 0, self.grid_count)

            # Title capsule above the window
            self._sync_title(p, focused)
            gl.glUniform1f(u["uEdgeAmt"], 0.0)
            gl.glUniform2f(u["uCrop"], 1.0, 1.0)   # the title bar is never cropped
            if p.get("hdr_tex") is not None:
                hh = w * HDR_H / HDR_W
                bar = base @ translate(0.0, h / 2.0 + hh / 2.0 + 0.03, 0.0)
                p["pick_hdr"] = {"place": bar, "w": w, "h": hh, "kappa": kappa}
                gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view @ bar).astype(np.float32))
                gl.glUniform2f(u["uSize"], w, hh)
                gl.glUniform1f(u["uCurve"], kappa)
                gl.glUniform1f(u["uDepthAmt"], 0.0)
                gl.glUniform1f(u["uRadius"], hh * 0.5)
                gl.glBindTexture(gl.GL_TEXTURE_2D, p["hdr_tex"])
                gl.glDrawArrays(gl.GL_TRIANGLES, 0, self.grid_count)

            # Grabber pill under the window
            gpw, gph = 0.30, 0.030
            pill = base @ translate(0.0, -h / 2.0 - 0.07, 0.0)
            gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view @ pill).astype(np.float32))
            gl.glUniform2f(u["uSize"], gpw, gph)
            gl.glUniform1f(u["uCurve"], kappa)
            gl.glUniform1f(u["uDepthAmt"], 0.0)
            gl.glUniform1f(u["uRadius"], gph * 0.5)
            gl.glUniform1f(u["uAlpha"], (0.95 if focused else 0.38) * alpha_p)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self.accent_tex if focused else self.white_tex)
            gl.glDrawArrays(gl.GL_TRIANGLES, 0, self.grid_count)

    def _draw_taskbar(self, proj, view, alpha):
        """The taskbar, below the windows. It shows only while you look down: it fades in and rises as you do."""
        tb = self.taskbar
        look = taskbar_visibility(self.pitch * self.e)
        self._taskbar_vis = look * alpha if tb is not None else 0.0
        if tb is None or self._taskbar_vis <= 0.01:
            return
        self._sync_texture(tb)
        if tb.get("tex") is None:
            return
        w = TASKBAR_W
        h = w * tb.get("aspect", 0.03)
        y = TASKBAR_Y + (1.0 - look) * TASKBAR_SLIDE
        place = translate(0.0, y, -TASKBAR_DIST) @ rot_x(TASKBAR_TILT)
        kappa = self.curve * self.e / TASKBAR_DIST
        self._taskbar_hit = (place, w, h, kappa)
        u = self._uniforms[self.prog_panel]
        gl.glUseProgram(self.prog_panel)
        gl.glBindVertexArray(self.grid_vao)
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view @ place).astype(np.float32))
        gl.glUniform2f(u["uSize"], w, h)
        gl.glUniform2f(u["uCrop"], 1.0, 1.0)
        gl.glUniform1f(u["uCurve"], kappa)
        gl.glUniform1f(u["uDepthAmt"], 0.0)
        gl.glUniform1f(u["uRadius"], 0.0)
        gl.glUniform1f(u["uAlpha"], self._taskbar_vis)
        gl.glUniform1f(u["uDim"], 0.0)
        gl.glUniform1f(u["uEdgeAmt"], 0.0)
        gl.glUniform1i(u["uTex"], 0)
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, tb["tex"])
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, self.grid_count)

    # ----- the cursor, the camera picture behind the room, and the virtual keyboard
    def set_camera_on(self, on):
        self.cam_on = bool(on)
        if not self.cam_on:
            self.cam_pending = None
        self._refresh_cursor()
        self.update()

    def set_camera_frame(self, rgb):
        """A new picture from the camera (RGB, already mirrored). It is uploaded on the next frame."""
        self.cam_pending = rgb
        self.update()

    def set_pointer(self, x, y, kind="mouse"):
        """Where the cursor is, in the room: (x, y), or None for no cursor. kind is "mouse" or "hand"."""
        self.pointer_kind = kind
        self.pointer = None if x is None or y is None else (float(x), float(y))
        self._update_pointer_state()
        self.update()

    def _update_pointer_state(self):
        """Whether the pointer is over a window. It is checked every frame, because a window can move under a still
        pointer, and it holds for a moment after the pointer leaves a window, so the cursor does not flicker on an
        edge."""
        if self.pointer is None:
            self.pointer_over = False
        else:
            now = time.monotonic()
            if self._over_window():
                self._over_seen = now
            self.pointer_over = (now - self._over_seen) < POINTER_HOLD_S
        self._refresh_cursor()

    def _over_window(self):
        if self.pointer is None:
            return False
        try:
            hit = self.pick(*self.pointer)
        except Exception:                       # before the first picture is drawn there is nothing to pick
            return False
        return hit is not None and hit[0] in ("body", "header")

    def _refresh_cursor(self):
        """Two cursors. Outside the windows the room draws its own dot (a small core with a soft glow), and the system
        cursor is hidden. Over a window the system arrow shows instead, so the cursor is the real one where a click
        lands. A fingertip (camera mode) keeps the dot and draws a ring over a window instead of the arrow."""
        arrow = self.pointer_kind == "mouse" and self.pointer_over
        shape = Qt.CursorShape.ArrowCursor if arrow else Qt.CursorShape.BlankCursor
        if self._cursor_shape != shape:              # changed only when the state changes, not on every frame
            self._cursor_shape = shape
            self.setCursor(shape)

    def set_keyboard(self, rect, hover=None, pressed=None):
        """The virtual keyboard: rect = (x, y, w, h) in the room, or None. hover and pressed are key labels."""
        self.keys_rect = rect
        self.keys_hover = hover
        self.keys_pressed = pressed
        self.update()

    @staticmethod
    def _ndc(px, py, w, h):
        return 2.0 * px / w - 1.0, 1.0 - 2.0 * py / h

    def _draw_quad(self, tex, cx, cy, w, h, crop=(1.0, 1.0), alpha=1.0):
        """A picture drawn as a rectangle centred at (cx, cy), w x h, all in screen units (-1 to 1)."""
        u = self._uniforms[self.prog_panel]
        gl.glUseProgram(self.prog_panel)
        gl.glBindVertexArray(self.vao)
        m = np.eye(4, dtype=np.float32)
        m[0, 3], m[1, 3] = cx, cy
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, m)
        gl.glUniform1f(u["uCurve"], 0.0)
        gl.glUniform1f(u["uDepthAmt"], 0.0)
        gl.glUniform2f(u["uCrop"], crop[0], crop[1])
        gl.glUniform2f(u["uSize"], w, h)
        gl.glUniform1f(u["uRadius"], 0.0)
        gl.glUniform1f(u["uAlpha"], alpha)
        gl.glUniform1f(u["uDim"], 0.0)
        gl.glUniform1f(u["uEdgeAmt"], 0.0)
        gl.glUniform1i(u["uTex"], 0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

    def _draw_camera(self):
        """The camera picture, covering the room behind the windows (cropped to fill the screen, never stretched)."""
        if not self.cam_on:
            return
        if self.cam_pending is not None:
            rgb = self.cam_pending
            self.cam_pending = None
            h, w = rgb.shape[:2]
            data = np.ascontiguousarray(rgb).tobytes()
            if self.cam_tex is None or self.cam_size != (w, h):
                if self.cam_tex is not None:
                    self._to_delete.append(self.cam_tex)
                self.cam_tex = _make_texture(w, h, data, fmt=gl.GL_RGB)
                self.cam_size = (w, h)
            else:
                gl.glBindTexture(gl.GL_TEXTURE_2D, self.cam_tex)
                gl.glTexSubImage2D(gl.GL_TEXTURE_2D, 0, 0, 0, w, h, gl.GL_RGB, gl.GL_UNSIGNED_BYTE, data)
        if self.cam_tex is None or self.cam_size is None:
            return
        cw, ch = self.cam_size
        crop = hand_tracking.cover_crop(cw, ch, max(1, self.width()), max(1, self.height()))
        self._draw_quad(self.cam_tex, 0.0, 0.0, 2.0, 2.0, crop, 1.0)

    def _draw_overlays(self):
        """The virtual keyboard (camera mode) and the cursor: drawn last, over everything, once the intro is done."""
        if not self.intro_ended:
            return
        W, H = max(1, self.width()), max(1, self.height())
        dpr = self.devicePixelRatioF()
        if self.cam_on and self.keys_rect is not None:
            x, y, w, h = self.keys_rect
            sig = (round(w, 1), round(h, 1), self.keys_hover, self.keys_pressed, round(dpr, 2))
            if sig != self._keys_sig or self.keys_tex is None:
                self._keys_sig = sig
                img = pointer_art.keyboard_image(w, h, self.keys_hover, self.keys_pressed, scale=dpr)
                if self.keys_tex is not None:
                    self._to_delete.append(self.keys_tex)
                self.keys_tex = _make_texture(img.width(), img.height(), pointer_art.image_bytes(img))
            cx, cy = self._ndc(x + w / 2.0, y + h / 2.0, W, H)
            self._draw_quad(self.keys_tex, cx, cy, 2.0 * w / W, 2.0 * h / H)
        if self.pointer is not None:
            self._update_pointer_state()             # the windows move, so the check runs every frame
        if self.pointer is not None and not (self.pointer_kind == "mouse" and self.pointer_over):
            px, py = self.pointer
            tex = self.ring_tex if self.pointer_over else self.dot_tex
            size = float(pointer_art.DOT_PX)
            cx, cy = self._ndc(px, py, W, H)
            self._draw_quad(tex, cx, cy, 2.0 * size / W, 2.0 * size / H)

    def _draw_title(self, alpha):
        sx = 0.7
        sy = sx * (self.width() / max(1, self.height())) * (500.0 / 1600.0)
        u = self._uniforms[self.prog_panel]
        gl.glUseProgram(self.prog_panel)
        gl.glBindVertexArray(self.vao)
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, np.eye(4, dtype=np.float32))
        gl.glUniform1f(u["uCurve"], 0.0)
        gl.glUniform1f(u["uDepthAmt"], 0.0)
        gl.glUniform2f(u["uCrop"], 1.0, 1.0)   # the whole picture, not one pixel of it
        gl.glUniform2f(u["uSize"], 2 * sx, 2 * sy)
        gl.glUniform1f(u["uRadius"], 0.0)
        gl.glUniform1f(u["uAlpha"], alpha)
        gl.glUniform1f(u["uDim"], 0.0)
        gl.glUniform1f(u["uEdgeAmt"], 0.0)
        gl.glUniform1i(u["uTex"], 0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self.intro_tex)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

    def _sync_intro(self, t):
        """Keeps the intro title's texture in step with the reveal. Runs every frame until the intro has ended."""
        if self.intro_ended:
            return
        prog = intro_progress(t, self.skip_intro)
        if prog != self._intro_prog and (abs(prog - self._intro_prog) >= 0.015 or prog >= 1.0):
            self._intro_prog = prog
            self._upload_intro(prog)

    def _upload_intro(self, prog):
        """Redraws the intro title for this moment, and uploads it into the same texture."""
        data = make_intro_image(prog)
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self.intro_tex)
        gl.glTexSubImage2D(gl.GL_TEXTURE_2D, 0, 0, 0, 1600, 500, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, data)

    def _draw_black(self, alpha):
        gl.glUseProgram(self.prog_fade)
        gl.glBindVertexArray(self.vao)
        gl.glUniformMatrix4fv(self._uniforms[self.prog_fade]["uMvp"], 1, gl.GL_TRUE, SCALE2)
        gl.glUniform1f(self._uniforms[self.prog_fade]["uAlpha"], alpha)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

    def pick(self, px, py):
        """What is under the cursor: (kind, index, u, v), kind = 'body' or 'header'; u, v run 0..1 from the top-left of
        the window's picture. The empty space round a picture that does not match its shape is not a hit, so a click
        there reaches the window behind it. A window that is closing takes no clicks."""
        W, H = max(1, self.width()), max(1, self.height())
        tan_h = math.tan(math.radians(self.fov) / 2.0)    # the same field of view the picture is drawn with
        dir_view = np.array([(2.0 * px / W - 1.0) * tan_h * (W / H), (1.0 - 2.0 * py / H) * tan_h, -1.0, 0.0])
        inv_view = np.linalg.inv(self._last_view.astype(np.float64))
        origin = inv_view @ np.array([0.0, 0.0, 0.0, 1.0])
        direction = inv_view @ dir_view
        best = None
        for i, p in enumerate(self.panels):
            if p.get("hidden") or p.get("closing") is not None:
                continue
            for key, kind in (("pick", "body"), ("pick_hdr", "header")):
                info = p.get(key)
                if not info:
                    continue
                hit = curved_hit(origin, direction, info["place"], info["w"], info["h"], info["kappa"])
                if hit is None:
                    continue
                t, u, v = hit
                if kind == "body" and not inside_rounded(u, v, info["w"], info["h"], PANEL_CORNER):
                    continue                    # a rounded-off corner is not on the window
                if kind == "body":
                    spot = visible_point(u, v, info.get("crop", (1.0, 1.0)))
                    if spot is None:
                        continue
                    u, v = spot
                if best is None or t < best[0]:
                    best = (t, kind, i, u, v)
        if self.taskbar is not None and self._taskbar_hit is not None and self._taskbar_vis > 0.5:
            place, tw, th, tk = self._taskbar_hit
            hit = curved_hit(origin, direction, place, tw, th, tk)
            if hit is not None and (best is None or hit[0] < best[0]):
                best = (hit[0], "taskbar", -1, hit[1], hit[2])
        if best is None:
            return None
        return best[1], best[2], best[3], best[4]

    # ----- mouse
    def mousePressEvent(self, ev):
        if IS_WIN and (ev.modifiers() & Qt.KeyboardModifier.AltModifier):
            handle = self.window().windowHandle()
            if handle is not None:
                handle.startSystemMove()  # Alt + drag moves the frameless window
            return
        if ev.button() == Qt.MouseButton.LeftButton:
            self._drag = ev.position()
            self._press = ev.position()

    def mouseMoveEvent(self, ev):
        p = ev.position()
        self.set_pointer(p.x(), p.y(), "mouse")
        if self._drag is not None and self.on_look is not None:
            self.on_look(p.x() - self._drag.x(), p.y() - self._drag.y())
            self._drag = p

    def mouseReleaseEvent(self, ev):
        if self._press is not None and ev.button() == Qt.MouseButton.LeftButton:
            moved = (ev.position() - self._press).manhattanLength()
            if moved < 6 and self.on_click is not None:
                self.on_click(ev.position().x(), ev.position().y())
        self._press = None
        self._drag = None

    def wheelEvent(self, ev):
        if self.on_wheel is not None:
            # Ctrl + scroll resizes a window, Shift + scroll slides it sideways, a plain scroll pulls it closer or pushes it away.
            mods = ev.modifiers()
            if mods & Qt.KeyboardModifier.ControlModifier:
                mode = "size"
            elif mods & Qt.KeyboardModifier.ShiftModifier:
                mode = "sideways"
            else:
                mode = "distance"
            delta = ev.angleDelta().y()
            if mode == "sideways" and not delta:
                delta = ev.angleDelta().x()        # some systems turn Shift + scroll into a sideways scroll
            self.on_wheel(ev.position().x(), ev.position().y(), delta, mode)


# ---------------------------------------------------------------------------
# Glasses tracking, using the helper in this process
# ---------------------------------------------------------------------------
class Tracker:
    def __init__(self):
        self.shared = rh.Shared()
        self.stop_event = threading.Event()
        self.available = True
        self.message = "Starting…"   # shown in the status pill while the SDK is set up
        self._thread = None
        if PROFILE.glasses:
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()
        else:
            self.available = False
            self.message = f"Glasses tracking needs Windows (not {PROFILE.name})"

    def _report(self, text):
        self.message = text
        rh.log.info("SDK: %s", text)

    def _run(self):
        path = rh.find_library()
        if not path:
            try:
                rh.ensure_sdk(HERE, report=self._report)  # downloads the SDK once
                path = rh.find_library()
            except Exception as e:
                self._report(f"SDK setup failed: {e}")
                path = None
        if path:
            try:
                rh.RayNeoSdk(path)  # loads the DLL now, so a problem shows up here
                self._report("SDK ready. Looking for glasses…")
            except Exception as e:
                self._report(f"SDK could not load: {e}")
                path = None
        if not path:
            self.available = False
            if self.message.startswith("Starting"):
                self._report("SDK not found in the sdk folder")
        rh.device_loop(self.shared, self.stop_event, path, False)

    def snapshot(self):
        return self.shared.snapshot()

    def calibrate(self):
        self.shared.request_calibrate()

    def recenter(self):
        self.shared.request_recenter()

    def close(self):
        self.stop_event.set()


# ---------------------------------------------------------------------------
# Styling: dark glass capsules with one cool accent
# ---------------------------------------------------------------------------
QSS = """
QWidget { color: #f4f6f9; font-family: "Segoe UI Variable Text", "Segoe UI", sans-serif; font-size: 9pt; }
QFrame#glass {
    background: rgba(12,12,14,222); border: 1px solid rgba(255,255,255,28); border-radius: 26px;
}
QFrame#capsule {
    background: rgba(12,12,14,222); border: 1px solid rgba(255,255,255,28); border-radius: 19px;
}
QFrame#dock { background: transparent; border: 0; }
QFrame#statusbar { background: transparent; border: 0; }
QFrame#winctl { background: transparent; border: 0; }
QFrame#row { background: rgba(255,255,255,12); border: 1px solid transparent; border-radius: 16px; }
QFrame#row[focused="true"] { background: rgba(255,255,255,20); border: 1px solid rgba(255,255,255,140); }
QLabel { background: transparent; }
QLabel#brand { color: rgba(244,246,249,190); font-size: 9pt; font-weight: 600; letter-spacing: 3px; }
QLabel#title { font-size: 17pt; font-weight: 300; letter-spacing: 1px; }
QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; border: 0; }
QFrame#sheet { background: rgba(10,10,12,238); border: 1px solid rgba(255,255,255,14); border-radius: 30px; }
QLabel#sheettitle { font-size: 18pt; font-weight: 300; color: #f4f6f9; }
QLabel#section { color: rgba(244,246,249,115); font-size: 7.5pt; font-weight: 600; letter-spacing: 2px; }
QLabel#muted, QLabel#hint { color: rgba(244,246,249,140); font-size: 8.5pt; }
QLabel#clock { font-size: 9.5pt; font-weight: 600; }
QLabel#status { color: rgba(244,246,249,170); font-size: 8.5pt; letter-spacing: 0.3px; }
QLabel#name { color: #f4f6f9; font-size: 9pt; }
QLabel#dist { color: rgba(244,246,249,130); font-size: 8pt; }
QLabel#warn { color: #f0be64; font-size: 8pt; }
QLabel#badge {
    background: rgba(255,255,255,30); color: #eceff4; border-radius: 9px; font-weight: 700; font-size: 9pt;
}
QPushButton {
    background: transparent; border: 0; border-radius: 12px; padding: 5px 11px; font-size: 9pt; font-weight: 500;
}
QPushButton:hover { background: rgba(255,255,255,22); }
QPushButton:pressed { background: rgba(255,255,255,34); }
QPushButton#primary { background: #eceff4; color: #0c0c0e; border-radius: 17px; padding: 8px 18px; font-weight: 600; }
QPushButton#primary:hover { background: #ffffff; }
QPushButton#dock { min-width: 42px; max-width: 42px; min-height: 42px; max-height: 42px; padding: 0; border-radius: 16px;
    background: transparent; }
QPushButton#dock:hover { background: rgba(255,255,255,30); border: 1px solid rgba(255,255,255,70); }
QPushButton#dock:checked { background: rgba(255,255,255,44); border: 1px solid rgba(255,255,255,170); }
QPushButton#dockmain { min-height: 42px; max-height: 42px; min-width: 54px; max-width: 54px; padding: 0;
    border-radius: 21px; background: #eceff4; }
QPushButton#dockmain:hover { background: #ffffff; }
QPushButton#apptile { background: rgba(255,255,255,14); border: 0; border-radius: 14px; padding: 0; }
QPushButton#apptile:hover { background: rgba(255,255,255,26); }
QPushButton#apptile:checked { background: rgba(255,255,255,40); }
QPushButton#seg { border-radius: 14px; padding: 6px 10px; color: rgba(244,246,249,160); background: rgba(255,255,255,9); }
QPushButton#seg:checked { background: rgba(255,255,255,40); color: #f4f6f9; border: 1px solid rgba(255,255,255,150); }
QPushButton#tool { padding: 0; min-width: 24px; max-width: 24px; min-height: 22px; max-height: 22px;
    border-radius: 11px; background: rgba(255,255,255,14); }
QPushButton#tool:hover { background: rgba(255,255,255,34); }
QPushButton#tool:checked { background: rgba(255,255,255,50); }
QPushButton#remove { padding: 0; min-width: 24px; max-width: 24px; min-height: 22px; max-height: 22px;
    color: rgba(244,246,249,140); border-radius: 11px; }
QPushButton#remove:hover { color: #ff8192; }
QPushButton#ctl { padding: 0; min-width: 32px; max-width: 32px; min-height: 26px; max-height: 26px; border-radius: 13px; }
QPushButton#ctl:hover { background: rgba(255,255,255,26); }
QToolButton#tile {
    background: transparent; border: 1px solid transparent; border-radius: 20px;
    padding: 8px 8px 6px 8px; color: #f4f6f9; font-size: 9pt;
}
QToolButton#tile:hover { background: rgba(255,255,255,14); border: 1px solid rgba(255,255,255,40); }
QProgressBar { background: rgba(255,255,255,20); border: 0; border-radius: 2px; max-height: 4px; min-height: 4px; }
QProgressBar::chunk { background: #eceff4; border-radius: 2px; }
QComboBox, QSpinBox {
    background: rgba(255,255,255,12); border: 1px solid rgba(255,255,255,24); border-radius: 12px; padding: 4px 10px;
}
QComboBox QAbstractItemView { background: #111113; color: #f4f6f9; selection-background-color: #3a3c44; }
QSlider::groove:horizontal { height: 4px; background: rgba(255,255,255,26); border-radius: 2px; }
QSlider::sub-page:horizontal { background: #eceff4; border-radius: 2px; }
QSlider::handle:horizontal { background: #ffffff; width: 16px; height: 16px; margin: -6px 0; border-radius: 8px; }
QCheckBox { spacing: 8px; }
QScrollArea { background: transparent; border: 0; }
QScrollBar:vertical { background: transparent; width: 8px; margin: 2px; }
QScrollBar::handle:vertical { background: rgba(255,255,255,50); border-radius: 4px; min-height: 30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QFrame#home { background: transparent; border: 0; }
QFrame#widgetbox { background: transparent; border: 0; }
QLabel#applabel { color: rgba(244,246,249,235); font-size: 10.5pt; font-weight: 500; background: transparent; }
"""

TILE_W, TILE_H = 224, 126


def make_button(text, slot=None, primary=False, tool=False):
    b = QPushButton(text)
    b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    if primary:
        b.setObjectName("primary")
    if tool:
        b.setObjectName("tool")
    if slot is not None:
        b.clicked.connect(slot)
    return b


def _tile_pixmap(image):
    """A launcher tile picture: the window's own image on a rounded card, or None to leave it blank."""
    pm = QPixmap(TILE_W, TILE_H)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, TILE_W, TILE_H), 14, 14)
    p.setClipPath(clip)
    p.fillRect(QRectF(0, 0, TILE_W, TILE_H), QColor(255, 255, 255, 14))
    if image is not None:
        scaled = image.scaled(TILE_W, TILE_H, Qt.AspectRatioMode.KeepAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)
        p.drawImage(int((TILE_W - scaled.width()) / 2), int((TILE_H - scaled.height()) / 2), scaled)
    p.end()
    return pm


def _letter_tile(name):
    """Fallback tile when a picture is not available: a soft gradient with the first letter."""
    hue = sum(ord(c) for c in name) % 360
    pm = QPixmap(TILE_W, TILE_H)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, TILE_W, TILE_H), 14, 14)
    p.setClipPath(clip)
    grad = QLinearGradient(0, 0, TILE_W, TILE_H)
    grad.setColorAt(0.0, QColor.fromHsv(hue, 110, 120))
    grad.setColorAt(1.0, QColor.fromHsv((hue + 40) % 360, 130, 55))
    p.fillRect(QRectF(0, 0, TILE_W, TILE_H), grad)
    f = QFont("Segoe UI Variable Display", 38)
    f.setWeight(QFont.Weight.Light)
    p.setFont(f)
    p.setPen(QColor(255, 255, 255, 220))
    p.drawText(QRectF(0, 0, TILE_W, TILE_H), Qt.AlignmentFlag.AlignCenter, (name.strip()[:1] or "?").upper())
    p.end()
    return pm


def capture_thumbnail(kind, ident, name):
    """One quick picture of a window or screen for the launcher; falls back to a letter tile."""
    try:
        arr = None
        if kind == "window":
            rect = window_rect(ident)
            if rect:
                arr = capture_window_pixels(ident, rect[2] - rect[0], rect[3] - rect[1])
        else:
            import mss
            with mss.MSS() as sct:
                arr = np.asarray(sct.grab(dict(sct.monitors[ident])))
        if arr is not None:
            step = max(1, arr.shape[1] // 640)
            arr = np.ascontiguousarray(arr[::step, ::step])
            h, w = arr.shape[:2]
            img = QImage(arr.data, w, h, w * 4, QImage.Format.Format_RGB32).copy()   # BGRA bytes, alpha ignored
            return _tile_pixmap(img)
    except Exception:
        rh.log.exception("thumbnail failed for %s", name)
    return _letter_tile(name)


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class PointerDot(QWidget):
    """The room's dot, drawn above the 2D screens (home icons, Virtual Box, the dock). The dot inside the 3D view is
    hidden under those screens, so over them the cursor was missing. It takes no mouse input."""
    RADIUS = 5.0        # the white core, in pixels
    GLOW = 16.0         # the soft glow around it

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._at = None
        self.hide()

    def show_at(self, x, y):
        self._at = (float(x), float(y))
        self.show()
        self.raise_()
        self.update()

    def paintEvent(self, ev):
        if self._at is None:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        x, y = self._at
        glow = QRadialGradient(x, y, self.GLOW)
        glow.setColorAt(0.0, QColor(255, 255, 255, 110))
        glow.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(glow))
        p.drawEllipse(QPointF(x, y), self.GLOW, self.GLOW)
        p.setBrush(QColor(255, 255, 255))
        p.setPen(QPen(QColor(16, 18, 24, 220), 1.0))
        p.drawEllipse(QPointF(x, y), self.RADIUS, self.RADIUS)
        p.end()


class MainWindow(QWidget):
    click_status = Signal(str)          # a click that was not sent, and why, from the worker thread

    def __init__(self):
        super().__init__()
        self.click_status.connect(self.toast)
        self._click_busy = False          # one real click at a time: a click made by us must not start another
        self._tuner = None                # the window card, while it is open (see _open_tuner)
        self.cfg = load_settings()
        self.setWindowTitle("Spatial Desk")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setStyleSheet(QSS)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAutoFillBackground(True)
        pal = self.palette()
        pal.setColor(QPalette.ColorRole.Window, QColor(5, 6, 10))
        self.setPalette(pal)
        self.resize(1600, 960)                 # replaced by the full work area in main()

        self.panels = []                       # dicts: grab, name, dist, expanded, plus GL fields
        self.kb_panel = None                   # the window that receives your keys, or None
        self.max_panels = int(self.cfg["max_panels"])
        self.curve = int(self.cfg["curve"])
        self.shape = self.cfg["shape"]
        self.mode = "setup"
        self.target = 0.0
        self.progress = 0.0
        self.fade_ms = int(self.cfg["fade_ms"])
        self.notify_on = bool(self.cfg["notify"])
        self.follow = bool(self.cfg["follow"])
        self.layout_name = self.cfg["layout"]
        self.theme_name = self.cfg["theme"]
        self.bg_path = self.cfg["bg_path"]
        self.mouse_yaw = 0.0
        self.mouse_pitch = 0.0
        self.live = False
        self.side_wanted = False
        self.show_intro = bool(self.cfg["intro"])
        self.intro_running = self.show_intro
        self.sheet_kind = None
        self._excluded = False
        self.home_wanted = False      # the home screen only shows when you press the home button or Home
        self.look_speed = float(self.cfg.get("look_speed", 1.0))

        self.tracker = Tracker()

        self.scene = Scene(self)
        self.pointer_dot = PointerDot(self)
        self._dot_cursor = False          # True while the dot is the cursor (over the 2D screens)
        self._dot_timer = QTimer(self)
        self._dot_timer.timeout.connect(self._pointer_tick)
        self._dot_timer.start(10)
        self.backdrop = None
        self._backdrop_timer = QTimer(self)
        self._backdrop_timer.timeout.connect(self._update_backdrop)
        self._backdrop_timer.start(250)
        self.scene.on_look = self._look
        self.scene.curve = self.curve / 100.0
        self._init_depth()
        self.scene.on_click = self._on_click
        self.scene.on_wheel = self._on_wheel
        self.scene.taskbar = make_taskbar()
        self._taskbar_key = None
        self.account_name = ""          # the signed-in account, shown in Settings
        self.on_sign_out = None         # set by main(): returns to the login
        self._tb_timer = QTimer(self)
        self._tb_timer.timeout.connect(self._refresh_taskbar)
        self._tb_timer.start(1000)
        QTimer.singleShot(300, self._refresh_taskbar)
        self.scene.on_intro_end = self._end_intro
        self.scene.on_gl_error = lambda: self.toast("3D view failed. See helper.log")
        self.scene.layout_name = self.layout_name
        self.scene.set_fov(self.cfg["fov"])
        self.scene.set_follow(self.follow)
        if self.bg_path and os.path.exists(self.bg_path) and self.scene.set_background_image(self.bg_path):
            pass
        else:
            self.bg_path = ""
            self.scene.set_theme(self.theme_name)
        self.scene.skip_intro = not self.show_intro

        self._build_top()
        self._build_side()
        self._build_dock()
        self._build_empty()
        self._build_sheet()
        self._build_toast()
        self._build_hint()
        self._tuner_watch = _TunerWatch(self)  # a press outside the card closes it
        QApplication.instance().installEventFilter(self._tuner_watch)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(16)
        self.watch_timer = QTimer(self)
        self.watch_timer.timeout.connect(self._watch_pictures)
        self.watch_timer.start(1000)

        self._place()
        self._refresh_list()
        self._refresh_chrome()
        self._apply_visibility()
        if not self.show_intro:
            self._end_intro()
        else:
            QTimer.singleShot(6000, self._end_intro)
        self._resume_camera_if_on()

    # ----- settings
    def _save(self):
        self.cfg.update({
            "theme": self.theme_name, "layout": self.layout_name, "follow": self.follow, "fov": self.scene.fov,
            "max_panels": self.max_panels, "fade_ms": self.fade_ms, "notify": self.notify_on,
            "curve": self.curve,
            "depth_on": self.depth_on, "depth_pct": self.depth_pct,
            "shape": self.shape,
            "intro": self.show_intro, "bg_path": self.bg_path,
        })
        save_settings(self.cfg)

    # ----- construction
    def _capsule(self, parent=None):
        f = QFrame(parent or self)
        f.setObjectName("capsule")
        return f

    def _pill(self, text=""):
        f = self._capsule()
        lay = QHBoxLayout(f)
        lay.setContentsMargins(16, 8, 16, 8)
        lay.setSpacing(8)
        f.dot = QLabel("●")
        f.dot.setStyleSheet("font-size: 9pt; color: #eceff4;")
        f.label = QLabel(text)
        f.label.setObjectName("status")
        lay.addWidget(f.dot)
        lay.addWidget(f.label)
        f.adjustSize()
        return f

    def _build_top(self):
        self.brand = QLabel("SPATIAL DESK", self)
        self.brand.setObjectName("brand")
        self.brand.adjustSize()

        # Status capsule at the top centre: time, glasses, and how windows behave
        self.status = QFrame(self)
        self.status.setObjectName("statusbar")
        lay = QHBoxLayout(self.status)
        lay.setContentsMargins(18, 8, 18, 8)
        lay.setSpacing(10)
        self.clock_lbl = QLabel(clock_text())
        self.clock_lbl.setObjectName("clock")
        self.dot = QLabel("●")
        self.dot.hide()
        self.dot.setStyleSheet("font-size: 9pt; color: #8a96ad;")
        self.track_lbl = QLabel("Connecting…")
        self.track_lbl.setObjectName("status")
        self.mode_lbl = QLabel("Flat setup")
        self.mode_lbl.setObjectName("status")
        sep = QLabel("·")
        sep.setObjectName("muted")
        for w in (self.clock_lbl, self.dot, self.track_lbl, sep, self.mode_lbl):
            lay.addWidget(w)
        self.status.adjustSize()
        self.status.hide()          # the top status line is removed; see _apply_visibility

        # Window controls at the top right
        self.capsule = QFrame(self)
        self.capsule.setObjectName("winctl")
        cap = QHBoxLayout(self.capsule)
        cap.setContentsMargins(6, 4, 6, 4)
        cap.setSpacing(2)
        self.min_btn = QPushButton()
        self.full_btn = QPushButton()
        self.close_btn = QPushButton()
        for b, k, slot in ((self.min_btn, "minimise", self.showMinimized),
                           (self.full_btn, "fullscreen", self.toggle_fullscreen),
                           (self.close_btn, "close", self.close)):
            b.setObjectName("ctl")
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setIcon(make_icon(k, px=32))
            b.setIconSize(QSize(14, 14))
            b.clicked.connect(slot)
            cap.addWidget(b)
        self.capsule.adjustSize()

    def _build_side(self):
        self.side = QFrame(self)
        self.side.setObjectName("glass")
        lay = QVBoxLayout(self.side)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(9)
        self.side_head = QLabel("WINDOWS")
        self.side_head.setObjectName("section")
        lay.addWidget(self.side_head)
        self.list_box = QWidget()
        self.list_lay = QVBoxLayout(self.list_box)
        self.list_lay.setContentsMargins(0, 0, 0, 0)
        self.list_lay.setSpacing(6)
        lay.addWidget(self.list_box)
        lay.addStretch(1)

        lay_head = QLabel("ARRANGEMENT")
        lay_head.setObjectName("section")
        lay.addWidget(lay_head)
        grid = QGridLayout()
        grid.setSpacing(6)
        self.layout_buttons = {}
        for k, (name, label) in enumerate(LAYOUTS):
            b = QPushButton(label)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setChecked(name == self.layout_name)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(lambda _checked=False, n=name: self.set_layout(n))
            self.layout_buttons[name] = b
            grid.addWidget(b, k // 2, k % 2)
        lay.addLayout(grid)

        beh_head = QLabel("WINDOW BEHAVIOUR")
        beh_head.setObjectName("section")
        lay.addWidget(beh_head)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.behaviour_buttons = {}
        for key, label in (("hover", "Hover"), ("follow", "Follow")):
            b = QPushButton(label)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setChecked((key == "follow") == self.follow)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(lambda _checked=False, k=key: self.set_follow(k == "follow"))
            self.behaviour_buttons[key] = b
            row.addWidget(b)
        lay.addLayout(row)
        hint = QLabel(platform_support.shortcut_label(
            "Hover pins windows in the room. Follow lets them drift after your gaze. "
            "Scroll over a window to pull it closer or push it away. Shift + scroll slides it sideways, Ctrl + scroll resizes it.",
            PROFILE))
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        self.side.setFixedWidth(290)

    def _build_dock(self):
        self.dock = QFrame(self)
        self.dock.setObjectName("dock")
        lay = QHBoxLayout(self.dock)
        lay.setContentsMargins(6, 2, 6, 2)
        lay.setSpacing(10)
        # Hidden holder: controls that are not in the dock still exist for the rest of the app.
        self._parked = QWidget(self)
        self._parked.hide()
        self.btn_add = make_icon_button("grid", self.open_picker, "Launcher: add a window or screen  (A)", tint="#3d8bff")
        self.btn_panel = make_icon_button("windows", self.toggle_panel, "Windows  (P)", checkable=True, tint="#22c3e6")
        self.btn_layout = make_icon_button("layers", self.cycle_layout, "Arrangement  (L)", tint="#8b5cf6")
        self.btn_mode = make_icon_button("3d", self.toggle_mode, "Enter 3D space  (Space)", primary=True)
        self.btn_follow = make_icon_button("hover", self.toggle_follow, "Hover or follow  (H)", checkable=True, tint="#ff9f1a")
        self.btn_recenter = make_icon_button("recenter", self.recenter, "Recenter  (R)", tint="#34c759")
        self.btn_calib = make_icon_button("calibrate", self.open_calibration, "Calibrate glasses", tint="#ff4d6d")
        self.btn_settings = make_icon_button("settings", self.open_settings, "Settings", tint="#8e8e93")
        self.btn_full = make_icon_button("fullscreen", self.toggle_fullscreen, "Full screen  (F11)", tint="#ffcc00")
        self.btn_min = make_icon_button("minimise", self.showMinimized, "Minimise", tint="#ff9f0a")

        self.btn_home = make_icon_button("home", self.toggle_home, "Home  (Home key)", tint="#ff6fd0")
        self.btn_airneo = make_icon_button("shield", self.open_airneo, "Virtual Box: setup and tunnel", tint="#22d3a6")
        self.btn_tunnel = make_icon_button("shield", self._toggle_tunnel, "Tunnel on or off", checkable=True, tint="#22d3a6")
        self._dock_buttons = {"home": self.btn_home, "mode": self.btn_mode, "add": self.btn_add,
                              "airneo": self.btn_airneo, "settings": self.btn_settings, "tunnel": self.btn_tunnel}
        self._dock_profile = None
        self.tunnel_runner = TunnelRunner()
        self.tunnel_runner.done.connect(self._on_tunnel_done)
        self._apply_dock_layout("default")
        for b in (self.btn_panel, self.btn_layout, self.btn_follow, self.btn_recenter,
                  self.btn_calib, self.btn_full, self.btn_min):
            b.setParent(self._parked)
        self._update_layout_button()
        self._update_follow_button()
        self.status_strip = StatusStrip(self)
        self.status_strip.clicked.connect(self.open_quick_settings)
        self.status_strip.cast_clicked.connect(self.open_picker)
        self.status_strip.bell_clicked.connect(self._toggle_notify_from_strip)
        self.status_strip.wifi_clicked.connect(self._open_network_settings)
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self._tick_clock)
        self.clock_timer.start(1000)
        self._profile_timer = QTimer(self)
        self._profile_timer.timeout.connect(self._refresh_dock_profile)
        self._profile_timer.start(700)

    def _apply_dock_layout(self, profile):
        """Shows the dock buttons for a profile, in order. Every other dock button is parked out of sight."""
        lay = self.dock.layout()
        while lay.count():
            item = lay.takeAt(0)
            if item.widget() is not None:
                item.widget().hide()
        for b in self._dock_buttons.values():
            b.setParent(self._parked)
            b.hide()
        for name in dock_profiles.dock_layout(profile):
            b = self._dock_buttons[name]
            b.setParent(self.dock)
            lay.addWidget(b)
            b.show()
        self._dock_profile = profile
        self.dock.adjustSize()
        self.dock.move((self.width() - self.dock.width()) // 2, self.height() - self.dock.height() - 34)

    def _refresh_dock_profile(self):
        """The dock changes for the window you are using: a tunnel window (WireGuard, or Air Neo) gets tunnel controls."""
        if self.sheet_kind == "airneo" and self.sheet.isVisible():
            profile = dock_profiles.profile_for("", "Virtual Box")
        else:
            path, title = "", ""
            focused = getattr(self.scene, "focused", None)
            if focused is not None and focused["grab"].kind == "window":
                path = program_path(focused["grab"].ident) if IS_WIN else ""
                title = focused["name"]
            else:
                path = foreground_program()
            profile = dock_profiles.profile_for(path, title)
        if profile != self._dock_profile:
            self._apply_dock_layout(profile)

    def open_airneo(self):
        """Air Neo: first-run setup, the passcode sign-in and the tunnel panel, inside the desk."""
        if self.sheet_kind == "airneo":
            self._close_airneo()
            return
        self._clear_sheet()
        self.sheet_kind = "airneo"
        self.airneo = AirNeoPanel(DATA_HERE, PROFILE.os, self._airneo_request)
        self.airneo.closed.connect(self._close_airneo)
        self._sheet_frame(bare=True)
        self.sheet_lay.addWidget(self.airneo)
        self.sheet.setFixedHeight(min(640, max(480, self.height() - 80)))
        self._show_sheet(width=720)

    def _sheet_frame(self, bare):
        """bare=True: the sheet draws no frame or margins of its own, so the Virtual Box card is the only border.
        bare=False: the usual sheet frame, for every other sheet."""
        if bare:
            self.sheet.setStyleSheet("QFrame#sheet { background: transparent; border: 0px; border-radius: 0px; }")
            self.sheet_lay.setContentsMargins(0, 0, 0, 0)
            self.sheet_lay.setSpacing(0)
        else:
            self.sheet.setStyleSheet("")
            self.sheet_lay.setContentsMargins(28, 26, 28, 24)
            self.sheet_lay.setSpacing(11)

    def _close_airneo(self):
        self.sheet.hide()
        self._sheet_frame(bare=False)
        self.sheet_kind = None
        self.airneo = None
        self._apply_visibility()

    def _tunnel_command(self, action):
        return airneo_core.tunnel_command(PROFILE.os, airneo_core.data_paths(DATA_HERE)["conf"], action)

    def _airneo_request(self, action):
        """Starts or stops the tunnel on a worker thread; the result comes back to _on_tunnel_done. After 'up', the
        other computer is checked through the tunnel."""
        paths = airneo_core.data_paths(DATA_HERE)
        device = airneo_core.load_state(paths["state"]).get("device", "")
        peer = airneo_core.peer_address(device) if device else ""
        self.tunnel_runner.start(PROFILE.os, paths["conf"], action, peer)

    def _toggle_tunnel(self):
        """The tunnel button in the dock: opens Air Neo until setup is done, then starts or stops the tunnel."""
        state = airneo_core.load_state(airneo_core.data_paths(DATA_HERE)["state"])
        if not state.get("setup_done") or airneo_core.find_wg() is None:
            self.open_airneo()             # setup, or the install of WireGuard, happens in Virtual Box
            return
        self._airneo_request("down" if state.get("tunnel_on") else "up")

    def _on_tunnel_done(self, ok, msg, action, peer_seen=False):
        paths = airneo_core.data_paths(DATA_HERE)
        state = airneo_core.load_state(paths["state"])
        if ok:
            state["tunnel_on"] = action in airneo_core.TUNNEL_ON_ACTIONS
            airneo_core.save_state(paths["state"], state)
        elif action in airneo_core.TUNNEL_ON_ACTIONS:      # a failed start means the tunnel is not up
            state["tunnel_on"] = False
            airneo_core.save_state(paths["state"], state)
        self.btn_tunnel.setChecked(bool(state.get("tunnel_on")))
        self.toast(f"Tunnel {msg}" if ok else f"Tunnel: {msg}")
        if self.sheet_kind == "airneo" and getattr(self, "airneo", None) is not None:
            self.airneo.tunnel_result(ok, msg, action, peer_seen)

    def _launch_app(self, name, exe):
        try:
            os.startfile(exe)
            self.toast(f"Opening {name}")
        except Exception:
            rh.log.exception("could not open %s", exe)
            self.toast(f"Could not open {name}")

    def _tick_clock(self):
        if hasattr(self, "status_strip"):
            if self.status_strip.refresh_power():
                self._place()
            self.status_strip.update()
        text = clock_text()
        if self.clock_lbl.text() != text:
            self.clock_lbl.setText(text)
        self._sync_home()

    def _ai_pill(self):
        """The Claude bar at the top of the home screen: one dark pill, the AI ring and 'Message Claude'."""
        self.home_ai = QPushButton("Message Claude")
        self.home_ai.setIcon(make_ai_icon(22))
        self.home_ai.setIconSize(QSize(22, 22))
        self.home_ai.setToolTip("Open Claude")
        self.home_ai.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.home_ai.setFixedSize(340, 56)
        self.home_ai.setStyleSheet(
            "QPushButton { background: rgba(10,10,12,238); border: 1px solid rgba(255,255,255,26); "
            "border-radius: 28px; color: #f4f4f6; font-size: 14pt; font-weight: 400; "
            "text-align: left; padding-left: 22px; }"
            "QPushButton:hover { background: rgba(26,26,30,242); }"
            "QPushButton:pressed { background: rgba(4,4,6,250); }")
        self.home_ai.clicked.connect(lambda: self._open_web("Claude", "https://claude.ai/"))
        return self.home_ai

    def _build_empty(self):
        """Home screen after the INAIR home reference: a glass widget panel on the left and, on the right,
        two picture cards (3D space, Windows) and four action cards. Every card runs an existing action."""
        self.empty = QFrame(self)
        self.empty.setObjectName("home")
        outer = QVBoxLayout(self.empty)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(20)

        # ----- top toolbar, as in the reference: back, the Liquid Glass Claude pill with three tools, and 3D
        bar = QHBoxLayout()
        bar.setContentsMargins(0, 0, 0, 0)
        bar.addStretch(1)
        bar.addWidget(self._ai_pill())
        bar.addStretch(1)
        outer.addLayout(bar)
        root = QHBoxLayout()
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(36)
        outer.addLayout(root)

        # ----- widget panel (left): calendar, Gmail, Drive, PC status
        wbox = GlassFrame(None, radius=34, soft=True)
        wbox.setObjectName("widgetbox")
        wbox.setFixedSize(354, 360)
        wg = QGridLayout(wbox)
        wg.setContentsMargins(16, 16, 16, 16)
        wg.setSpacing(10)
        self.home_cal = HomeCard("calendar")
        self.home_mail = HomeCard("mail", text={"mark": "M", "label": "Gmail"})
        self.home_drive = HomeCard("drive", text={"mark": "D", "label": "Google Drive"})
        self.home_pc = HomeCard("pc")
        self.home_mail.clicked.connect(lambda: self._open_web("Gmail", "https://mail.google.com/"))
        self.home_drive.clicked.connect(lambda: self._open_web("Google Drive", "https://drive.google.com/"))
        wg.addWidget(self.home_cal, 0, 0, 2, 1)
        wg.addWidget(self.home_mail, 0, 1)
        wg.addWidget(self.home_drive, 1, 1)
        wg.addWidget(self.home_pc, 2, 0, 1, 2)
        root.addWidget(wbox)

        # ----- right side: two picture cards and four action cards
        self.home_room = HomeCard("room")
        self.home_windows = HomeCard("windows")
        self.home_hover = HomeCard("hover")
        self.home_recenter = HomeCard("recenter")
        self.home_layout = HomeCard("layout")
        self.home_calibrate = HomeCard("calibrate")
        self.home_room.clicked.connect(self.toggle_mode)
        self.home_windows.clicked.connect(self.toggle_panel)
        self.home_hover.clicked.connect(self.toggle_follow)
        self.home_recenter.clicked.connect(self.recenter)
        self.home_layout.clicked.connect(self.cycle_layout)
        self.home_calibrate.clicked.connect(self.open_calibration)
        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(24)
        grid.addWidget(self.home_room, 0, 0, 1, 2)
        grid.addWidget(self.home_windows, 1, 0, 1, 2)
        grid.addWidget(self.home_hover, 0, 2)
        grid.addWidget(self.home_recenter, 0, 3)
        grid.addWidget(self.home_layout, 1, 2)
        grid.addWidget(self.home_calibrate, 1, 3)
        root.addLayout(grid)
        self.empty.setFixedSize(934, max(432, outer.sizeHint().height()))   # taller only if the content needs it
        self._sync_home()

    def _sync_home(self):
        """Keep the home widgets in step with the app: today's date, glasses state, windows, 3D space,
        and the state of the action cards and the status-strip bell."""
        if not hasattr(self, "home_cal"):
            return
        now = time.localtime()
        self.home_cal.set_text(week=time.strftime("%a", now), day=str(now.tm_mday))
        n = len(getattr(self, "panels", []))
        spatial = getattr(self, "mode", "") == "spatial"
        track = self.track_lbl.text() if hasattr(self, "track_lbl") else ""
        self.home_pc.set_text(label="PC connection", title=track or "Mouse",
                              sub=f"{n} window{'' if n == 1 else 's'}  \u00b7  {'3D space' if spatial else 'Flat setup'}")
        self.home_room.set_text(title="3D space", sub="Tap to leave" if spatial else "Tap to enter")
        self.home_room.set_wallpaper(getattr(self, "bg_path", ""))
        self.home_windows.set_text(title="Windows", sub=f"{n} open" if n else "None open")
        follow = bool(getattr(self, "follow", False))
        self.home_hover.set_text(title="Hover", sub="On" if follow else "Off", on=follow)
        self.home_recenter.set_text(title="Recenter", sub="Reset the view", on=False)
        self.home_layout.set_text(title="Layout", sub=dict(LAYOUTS).get(getattr(self, "layout_name", ""), ""), on=False)
        self.home_calibrate.set_text(title="Calibrate", sub="Glasses setup", on=False)
        strip = getattr(self, "status_strip", None)
        notify = bool(getattr(self, "notify_on", True))
        if strip is not None and strip.bell_on != notify:
            strip.bell_on = notify
            strip.update()

    def _open_web(self, name, url):
        try:
            webbrowser.open(url)
            self.toast(f"Opening {name}")
        except Exception:
            rh.log.exception("could not open %s", url)
            self.toast(f"Could not open {name}")

    def _toggle_notify_from_strip(self):
        self._set_notify(not self.notify_on)
        self.toast("Notifications on" if self.notify_on else "Notifications off")

    def _open_network_settings(self):
        if IS_MAC:
            QDesktopServices.openUrl(QUrl(PROFILE.wifi_url))
            self.toast("Opening Wi-Fi settings")
            return
        if sys.platform != "win32":
            self.toast("Wi-Fi settings open on Windows")
            return
        try:
            os.startfile("ms-settings:network-wifi")
            self.toast("Opening Wi-Fi settings")
        except OSError:
            rh.log.exception("could not open Wi-Fi settings")
            self.toast("Could not open Wi-Fi settings")

    def _build_sheet(self):
        self.sheet = QFrame(self)
        self.sheet.setObjectName("sheet")
        self._sheet_watch = _SheetWatch(self)
        self.sheet.installEventFilter(self._sheet_watch)
        self.sheet_lay = QVBoxLayout(self.sheet)
        self.sheet_lay.setContentsMargins(28, 26, 28, 24)
        self.sheet_lay.setSpacing(11)
        self.sheet.setFixedWidth(460)
        self.sheet.hide()

    def _update_backdrop(self):
        if not self.isVisible() or self.width() < 2:
            return
        image = self.scene.grabFramebuffer()
        if image.isNull():
            return
        self.backdrop = blur_backdrop(image, self.width(), self.height())
        for w in (self.empty, self.dock, self.side):
            w.update()

    def _refresh_home(self):
        home_ok = self.home_wanted and self.mode != "spatial" and not self.sheet.isVisible()
        self.empty.setVisible(home_ok)

    def _build_toast(self):
        self.toast_frame = self._pill("")
        self.toast_frame.hide()
        self.toast_timer = QTimer(self)
        self.toast_timer.setSingleShot(True)
        self.toast_timer.timeout.connect(self.toast_frame.hide)

    def _build_hint(self):
        self.hint_frame = self._pill("Space or Esc: back to flat")
        self.hint_frame.hide()
        self.hint_timer = QTimer(self)
        self.hint_timer.setSingleShot(True)
        self.hint_timer.timeout.connect(self.hint_frame.hide)

    # ----- placement and visibility
    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.scene.setGeometry(self.rect())
        self._place()

    def showEvent(self, ev):
        super().showEvent(ev)
        if not self._excluded:
            exclude_from_capture(int(self.winId()))
            self._excluded = True

    def _place(self):
        W, H = self.width(), self.height()
        self.brand.move(32, 34)
        self.status.adjustSize()
        self.status.move((W - self.status.width()) // 2, 24)
        self.capsule.adjustSize()
        self.capsule.move(W - self.capsule.width() - 24, 24)
        self.side.setFixedHeight(max(300, H - 190))
        self.side.move(W - self.side.width() - 28, 84)
        self.dock.adjustSize()
        self.dock.move((W - self.dock.width()) // 2, H - self.dock.height() - 34)
        self.status_strip.move((W - self.status_strip.width()) // 2, H - 34 + 12)
        self.empty.adjustSize()
        self.empty.move((W - self.empty.width()) // 2, (H - self.empty.height()) // 2)
        self.sheet.adjustSize()
        self.sheet.move((W - self.sheet.width()) // 2, max(20, (H - self.sheet.height()) // 2))
        above_dock = H - self.dock.height() - 34 - 14
        self.toast_frame.adjustSize()
        self.toast_frame.move((W - self.toast_frame.width()) // 2, above_dock - self.toast_frame.height())
        self.hint_frame.adjustSize()
        self.hint_frame.move((W - self.hint_frame.width()) // 2, above_dock - self.hint_frame.height())

    def _apply_visibility(self):
        """Setup shows the room controls. 3D keeps a calm dock and status bar, and hides what needs the desktop."""
        if self.intro_running:
            for w in (self.brand, self.status, self.dock, self.status_strip, self.capsule, self.side, self.empty):
                w.hide()
            self.sheet.hide()
            return
        spatial = self.mode == "spatial"
        self.brand.setVisible(not spatial)
        self.status.hide()          # no status line at the top (time, glasses, mode): removed on request
        self.capsule.show()
        self.close_btn.setVisible(not spatial)
        self.dock.show()
        self.status_strip.show()
        for b in (self.btn_add, self.btn_calib, self.btn_panel):
            b.setVisible(not spatial)
        self.side.setVisible(self.side_wanted and not spatial)
        self.btn_panel.setChecked(self.side_wanted)
        self.scene.reserved_right = (self.side.width() + 40) if (self.side_wanted and not spatial) else 0
        self.scene.relayout()
        self.empty.setVisible(self.home_wanted and not spatial and not self.sheet.isVisible())
        if spatial and self.sheet_kind != "settings":
            self.sheet.hide()
        if spatial:
            self.toast_frame.hide()
        self._place()

    # ----- actions
    def toast(self, msg):
        if not self.notify_on or self.mode == "spatial":
            return
        self.toast_frame.label.setText(msg)
        self.toast_frame.adjustSize()
        self._place()
        self.toast_frame.show()
        self.toast_frame.raise_()
        self.toast_timer.start(2600)

    def _focus(self, p):
        if self.scene.focused is not p:
            self.scene.focused = p
            self._refresh_list()

    def add_source(self, kind, ident, name):
        if len(self.panels) >= self.max_panels:
            self.toast(f"Up to {self.max_panels} windows (change in Settings)")
            return
        grab = Grabber(kind, ident)
        p = {"grab": grab, "name": name, "dist": DEFAULT_DIST, "expanded": False}
        p["ratio"] = self.shape
        self.panels.append(p)
        self.scene.panels = self.panels
        self.scene.focused = p
        self.scene.relayout()
        self.scene.kick_warp(0.6)
        self._refresh_list()
        self.toast(f"Added {name}")

    def remove_panel(self, index):
        if 0 <= index < len(self.panels):
            self.close_panel(self.panels[index])

    def close_panel(self, p):
        """Closes a window with a short animation. It leaves the list and the layout at once, and is taken out of the
        room when the animation has finished (see _finish_close)."""
        if p.get("closing") is not None:
            return
        p["closing"] = time.monotonic()
        self._close_tuner()
        if self.kb_panel is p:
            self.kb_panel = None
        if self.scene.focused is p:
            live = [q for q in self.panels if q is not p and q.get("closing") is None]
            self.scene.focused = live[-1] if live else None
        self.scene.relayout()
        self.scene.kick_warp(0.5)
        self._refresh_list()
        self.toast(f"Removed {p['name']}")
        QTimer.singleShot(int(CLOSE_MS) + 40, lambda q=p: self._finish_close(q))

    def _finish_close(self, p):
        index = next((i for i, q in enumerate(self.panels) if q is p), None)
        if index is None:
            return
        self.panels.pop(index)
        p["grab"].stop()
        self.scene.drop_panel(p)
        self.scene.panels = self.panels
        if self.scene.focused is None:
            live = [q for q in self.panels if q.get("closing") is None]
            self.scene.focused = live[-1] if live else None
        self._refresh_list()

    def nudge_panel(self, index, delta, warp=0.45):
        """Pull a window closer (negative) or push it further away (positive)."""
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            new = min(MAX_DIST, max(MIN_DIST, p.get("dist", DEFAULT_DIST) + delta))
            if abs(new - p.get("dist", DEFAULT_DIST)) < 1e-6:
                return
            rh.log.info("distance of %s: %.2f m -> %.2f m", p["name"], p.get("dist", DEFAULT_DIST), new)
            p["dist"] = new
            self.scene.relayout()
            self.scene.kick_warp(warp)
            self._refresh_list()

    def resize_panel(self, index, factor):
        """Make a window wider or narrower in the room (Ctrl + scroll over it). The distance does not change."""
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            cur = p.get("size", 1.0)
            new = min(MAX_SIZE, max(MIN_SIZE, cur * factor))
            if abs(new - cur) < 1e-6:
                return
            p["size"] = new
            self.scene.relayout()
            self.scene.kick_warp(0.3)
            self._refresh_list()

    def turn_panel(self, index, delta):
        """Slide a window sideways around you (Shift + scroll over it). The place is kept until the arrangement changes."""
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            cur = p.get("bearing", 0.0)
            new = min(MAX_BEARING, max(-MAX_BEARING, cur + delta))
            if abs(new - cur) < 1e-6:
                return
            p["bearing"] = new
            self.scene.relayout()
            self.scene.kick_warp(0.3)
            self._refresh_list()

    def focus_panel(self, index):
        """Puts a window back in its usual place in front of you, at its default distance, size and turn."""
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            for key in ("bearing", "size"):
                p.pop(key, None)
            p["dist"], p["expanded"], p["hidden"] = DEFAULT_DIST, False, False
            self._focus(p)
            self.scene.relayout()
            self.scene.kick_warp(0.4)
            self._refresh_list()

    def minimise_panel(self, index):
        """Hides a window from the room; its picture keeps updating. The window list has a Show button."""
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            p["hidden"] = not p.get("hidden", False)
            if p["hidden"] and self.kb_panel is p:
                self._release_keys(say=False)
            self.scene.relayout()
            self.scene.kick_warp(0.4)
            self._refresh_list()

    def _capture_keys(self, p):
        """The window was clicked, so it is the active window and the keyboard types into it by itself."""
        if p["grab"].kind != "window" or not IS_WIN:
            self.kb_panel = None
            return
        self.kb_panel = p
        rh.log.info("keys: now typing into %s (window %s)", p["name"], p["grab"].ident)
        self.toast(f"Typing in {p['name']}  ·  click the room to come back")

    def _release_keys(self, say=True):
        if self.kb_panel is None:
            return
        name = self.kb_panel["name"]
        self.kb_panel = None
        if say:
            self.toast(f"Keys back to Spatial Desk ({name})")

    def toggle_expand(self, index):
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            p["expanded"] = not p.get("expanded", False)
            self.scene.relayout()
            self.scene.kick_warp(1.0)       # the starfield rush when a window grows or shrinks
            self._refresh_list()

    def set_mode(self, mode):
        if mode == self.mode:
            return
        self.mode = mode
        self._close_tuner()
        self.target = 1.0 if mode == "spatial" else 0.0
        self.scene.kick_warp(1.5 if mode == "spatial" else 1.0, dur=0.3)
        self.btn_mode.setIcon(make_icon("flat" if mode == "spatial" else "3d", QColor(12, 12, 14)))
        self.btn_mode.setToolTip("Back to flat setup  (Space)" if mode == "spatial" else "Enter 3D space  (Space)")
        if mode == "spatial":
            self.hint_frame.show()
            self.hint_frame.raise_()
            self.hint_timer.start(3500)
        else:
            self.hint_frame.hide()
            self.hint_timer.stop()
        self._apply_visibility()
        self._refresh_chrome()

    def toggle_mode(self):
        self.set_mode("setup" if self.mode == "spatial" else "spatial")

    def cycle_ratio(self):
        p = self.scene.focused
        if p is None:
            self.toast("Pick a window first")
            return
        order = list(RATIOS)
        p["ratio"] = order[(order.index(p.get("ratio", "auto")) + 1) % len(order)]
        self.scene.kick_warp(0.4)
        self.toast(f"Window ratio: {p['ratio'].capitalize()}")

    def toggle_home(self):
        self.home_wanted = not self.home_wanted
        if self.home_wanted and self.mode == "spatial":
            self.set_mode("setup")
        self._apply_visibility()

    def toggle_panel(self):
        self.side_wanted = not self.side_wanted
        self._apply_visibility()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def set_layout(self, name):
        self.layout_name = name
        for p in self.panels:
            p.pop("bearing", None)              # a preset puts every window back in its own place
            p.pop("size", None)                 # ...and its own size
        self.scene.set_layout(name)
        self.scene.kick_warp(0.5)
        for key, b in self.layout_buttons.items():
            b.setChecked(key == name)
        self._update_layout_button()
        self._save()
        self.toast(f"Arrangement: {dict(LAYOUTS)[name]}")

    def cycle_layout(self):
        keys = [k for k, _ in LAYOUTS]
        self.set_layout(keys[(keys.index(self.layout_name) + 1) % len(keys)])

    def _update_layout_button(self):
        self.btn_layout.setToolTip(f"Arrangement: {dict(LAYOUTS)[self.layout_name]}  (L)")

    def set_follow(self, on):
        self.follow = bool(on)
        self.scene.set_follow(self.follow)
        for key, b in self.behaviour_buttons.items():
            b.setChecked((key == "follow") == self.follow)
        self._update_follow_button()
        self._refresh_chrome()
        self._save()
        self.toast("Follow: windows travel with your gaze" if self.follow else "Hover: windows stay where they are")

    def toggle_follow(self):
        self.set_follow(not self.follow)

    def _update_follow_button(self):
        self.btn_follow.setIcon(make_icon("follow" if self.follow else "hover"))
        self.btn_follow.setChecked(self.follow)
        self.btn_follow.setToolTip("Follow: windows travel with your gaze  (H)" if self.follow
                                   else "Hover: windows stay fixed in the room  (H)")

    def recenter(self):
        if self.live:
            self.tracker.recenter()
        else:
            self.mouse_yaw = 0.0
            self.mouse_pitch = 0.0
        self.scene.reset_follow()
        self.toast("Recentered")

    def _end_intro(self):
        self.intro_running = False
        self._apply_visibility()
        self._maybe_first_run_setup()

    def _maybe_first_run_setup(self):
        """On first run, Air Neo's setup opens by itself once the intro is done, so you see it."""
        state = airneo_core.load_state(airneo_core.data_paths(DATA_HERE)["state"])
        if not state.get("setup_done") and self.sheet_kind is None:
            QTimer.singleShot(350, self.open_airneo)

    def _on_click(self, x, y):
        if self._click_busy:
            return                          # a click is already being sent; ignore the room until it is done
        hit = self.scene.pick(x, y)
        if hit is None:
            # A click on the empty room: the room takes the keyboard back and no window stays the focused one.
            self._release_keys(say=False)
            if self.scene.focused is not None:
                self.scene.focused = None
                self._refresh_list()
            self.activateWindow()
            return
        kind, idx, u, v = hit
        if kind == "taskbar":
            self._taskbar_click(u, v)
            return
        if idx >= len(self.panels):
            return
        p = self.panels[idx]
        newly_focused = self.scene.focused is not p
        self._focus(p)
        if kind == "header":
            action = title_hit(u)
            if action == "sidebar":
                self._open_tuner(idx)
            elif action == "apps":
                self.open_picker()
            elif action == "focus":
                self.focus_panel(idx)
            elif action == "min":
                self.minimise_panel(idx)
            elif action == "max":
                self.toggle_expand(idx)
            elif action == "close":
                self.remove_panel(idx)
            return
        # A real click, sent on a worker thread so the desk never waits for it. The click makes the window active, so
        # from now on the keyboard types into it.
        # A window that was not focused before: the real pointer rests in the middle of it afterwards.
        rest = self._window_centre_global(p) if newly_focused else None
        self._click_busy = True
        try:
            threading.Thread(target=self._click_in_background, args=(p["grab"], u, v, rest), daemon=True).start()
        except RuntimeError:                  # no thread could start: do not leave the room ignoring clicks
            self._click_busy = False
            raise
        self._capture_keys(p)

    def _pointer_tick(self):
        """Keeps the room's dot under the real mouse over the 2D screens (home icons, Virtual Box, the dock), which
        cover the 3D view. Over the 3D view itself, the room draws the dot or, over a virtual window, the real arrow."""
        g = QCursor.pos()
        w = QApplication.widgetAt(g)
        # This window's own 2D screens, the window card included: the dot is drawn over them and the system cursor
        # is hidden there, so the room keeps one cursor.
        over_screen = w is not None and w is not self and w is not self.scene and w.window() is self
        if over_screen and self.isVisible():
            if not self._dot_cursor:
                self._dot_cursor = True
                QApplication.setOverrideCursor(Qt.CursorShape.BlankCursor)   # the dot is the only cursor here
                self.scene.set_pointer(None, None, "mouse")                 # the dot inside the 3D view is not drawn
            local = self.mapFromGlobal(g)
            self.pointer_dot.setGeometry(self.rect())
            self.pointer_dot.show_at(local.x(), local.y())
        elif self._dot_cursor:
            self._dot_cursor = False
            QApplication.restoreOverrideCursor()
            self.pointer_dot.hide()

    def _window_centre_global(self, p):
        """Where the real pointer rests when a window is focused: the middle of that window as it appears in the room,
        in physical screen pixels. None when it is not known. The room is full screen, so this is where the window is
        shown, not where the real app is on the desktop."""
        info = p.get("pick")
        if not info:
            return None
        centre = np.asarray(info["place"], dtype=np.float64) @ np.array([0.0, 0.0, 0.0, 1.0])
        spot = self.scene._screen_of(centre[:3])
        if spot is None:
            return None
        g = self.scene.mapToGlobal(QPoint(int(round(spot[0])), int(round(spot[1]))))
        dpr = self.devicePixelRatioF()           # Qt's coordinates are logical; the Win32 calls use physical pixels
        return int(round(g.x() * dpr)), int(round(g.y() * dpr))

    def _click_in_background(self, grab, u, v, rest=None):
        """Runs the real click on a worker thread, and tells you in the room when it could not be sent."""
        try:
            status = click_grab(grab, u, v, desk=int(self.winId()), rest=rest)
            if status not in (True, "ok", None):
                rh.log.info("click not sent to %s: %s", grab.ident, status)
                self.click_status.emit(CLICK_MESSAGES.get(status, "The click was not sent."))
        except Exception:
            rh.log.exception("the click failed")
            self.click_status.emit("The click could not be sent (see helper.log).")
        finally:
            self._click_busy = False

    def _on_wheel(self, x, y, delta, mode="distance"):
        hit = self.scene.pick(x, y)
        rh.log.info("wheel: mode=%s delta=%s hit=%s", mode, delta, hit)
        if hit is None or hit[1] >= len(self.panels):
            return
        self._focus(self.panels[hit[1]])
        if mode == "size":
            self.resize_panel(hit[1], max(0.5, 1.0 + 0.06 * (delta / 120.0)))   # scroll up = bigger
        elif mode == "sideways":
            self.turn_panel(hit[1], -0.05 * (delta / 120.0))                    # scroll up = left
        else:
            self.nudge_panel(hit[1], -0.15 * (delta / 120.0), warp=0.35)

    def _look(self, dx, dy):
        if self.mode == "spatial" and not self.live:
            self.mouse_yaw += dx * 0.003 * self.look_speed
            self.mouse_pitch -= dy * 0.003 * self.look_speed

    def _ensure_flat(self):
        if self.mode == "spatial":
            self.set_mode("setup")

    # ----- launcher
    def open_picker(self):
        self._ensure_flat()
        self._clear_sheet()
        self.sheet_kind = "picker"
        self._sheet_title("Launcher")
        self._sheet_text("Pick a screen or window to bring into your space.")
        own = int(self.winId()) if IS_WIN else 0
        options = []
        try:
            options += [("screen", idx, name) for idx, name in list_screens()]
        except Exception:
            rh.log.exception("could not list screens")
        try:
            options += [("window", hwnd, title) for hwnd, title in list_windows(own)]
        except Exception:
            rh.log.exception("could not list windows")
        if not options:
            self._sheet_text("Nothing to capture yet. Open a window and try again.")
        else:
            holder = QWidget()
            grid = QGridLayout(holder)
            grid.setContentsMargins(0, 0, 0, 0)
            grid.setSpacing(12)
            metrics = QFontMetrics(self.font())
            for n, (kind, ident, name) in enumerate(options):
                tile = QToolButton()
                tile.setObjectName("tile")
                tile.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                tile.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
                tile.setIcon(QIcon(capture_thumbnail(kind, ident, name)))
                tile.setIconSize(QSize(TILE_W, TILE_H))
                tile.setText(metrics.elidedText(name, Qt.TextElideMode.ElideRight, TILE_W - 8))
                tile.setToolTip(name)
                tile.setFixedSize(TILE_W + 18, TILE_H + 46)
                tile.clicked.connect(lambda _c=False, k=kind, i=ident, nm=name: self._pick(k, i, nm))
                grid.addWidget(tile, n // 3, n % 3)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(holder)
            scroll.setFixedHeight(min(460, ((len(options) + 2) // 3) * (TILE_H + 58) + 6))
            self.sheet_lay.addWidget(scroll)
        self._sheet_close_row()
        self._show_sheet(width=820)

    def _pick(self, kind, ident, name):
        self.sheet.hide()
        self.add_source(kind, ident, name)

    def open_calibration(self):
        self._ensure_flat()
        self._clear_sheet()
        self.sheet_kind = "calib"
        self._sheet_title("Calibrate glasses")
        self._sheet_text("Put the glasses on, look straight ahead, and keep your head still for 3 seconds.")
        self.calib_bar = QProgressBar()
        self.calib_bar.setRange(0, 100)
        self.calib_bar.setValue(0)
        self.calib_bar.setTextVisible(False)
        self.sheet_lay.addWidget(self.calib_bar)
        self.calib_msg = QLabel("Not started.")
        self.calib_msg.setObjectName("hint")
        self.sheet_lay.addWidget(self.calib_msg)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(make_button("Close", self.sheet.hide))
        row.addWidget(make_button("Start", self._start_calibration, primary=True))
        self.sheet_lay.addLayout(row)
        self._show_sheet()

    def _start_calibration(self):
        self.tracker.calibrate()
        self.calib_msg.setText("Hold your head still…")

    def _qtile(self, kind, label, action, checked=None, checkable=False):
        """A rounded tile with an icon and a label. Checked tiles go white, as the reference shows."""
        b = QPushButton(label)
        b.setObjectName("qtile")
        b.setCheckable(checkable)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setMinimumHeight(64)
        b.setIconSize(QSize(26, 26))

        def refresh_icon(on=False):
            b.setIcon(make_icon(kind, QColor(12, 12, 14) if on else QColor(236, 242, 250), px=52))
        if checkable:
            b.setChecked(bool(checked))
            refresh_icon(bool(checked))
            b.toggled.connect(lambda on: (refresh_icon(on), action()))
        else:
            refresh_icon(False)
            b.clicked.connect(lambda _c=False: action())
        return b

    def _qround(self, kind, tip, action):
        b = QPushButton()
        b.setObjectName("qround")
        b.setFixedSize(52, 52)
        b.setIcon(make_icon(kind, QColor(236, 242, 250), px=44))
        b.setIconSize(QSize(26, 26))
        b.setToolTip(tip)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.clicked.connect(lambda _c=False: action())
        return b

    def _close_quick(self):
        self.sheet.hide()
        self.sheet_kind = None
        self._apply_visibility()

    def open_quick_settings(self):
        """The control centre: time, quick tiles, immersiveness, and the list of open windows."""
        self._clear_sheet()
        self.sheet_kind = "quick"
        body = QWidget()
        body.setStyleSheet(QUICK_QSS)
        root = QHBoxLayout(body)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(18)

        # Left: header, tiles, round buttons, immersiveness slider
        left = QVBoxLayout()
        left.setSpacing(14)
        head = QHBoxLayout()
        clock = QVBoxLayout()
        clock.setSpacing(0)
        t = QLabel(clock_text())
        t.setObjectName("qtime")
        d = QLabel(time.strftime("%A, %B %d"))
        d.setObjectName("qdate")
        clock.addWidget(t)
        clock.addWidget(d)
        head.addLayout(clock)
        head.addStretch(1)
        battery = read_battery()
        if battery:
            bl = QLabel(f"{battery[0]}%")
            bl.setObjectName("qhint")
            head.addWidget(bl, 0, Qt.AlignmentFlag.AlignTop)
        close = QPushButton()
        close.setObjectName("qx")
        close.setFixedSize(28, 28)
        close.setIcon(make_icon("close", QColor(236, 242, 250), px=28))
        close.setIconSize(QSize(14, 14))
        close.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        close.clicked.connect(self._close_quick)
        head.addWidget(close, 0, Qt.AlignmentFlag.AlignTop)
        left.addLayout(head)

        grid = QGridLayout()
        grid.setSpacing(10)
        layout_tile = self._qtile("layers", f"Arrangement\n{dict(LAYOUTS)[self.layout_name]}", lambda: None)
        def cycle():
            self.cycle_layout()
            layout_tile.setText(f"Arrangement\n{dict(LAYOUTS)[self.layout_name]}")
        layout_tile.clicked.disconnect()
        layout_tile.clicked.connect(lambda _c=False: cycle())
        tiles = [
            self._qtile("3d", "Spatial 3D", self.toggle_mode, checked=self.mode == "spatial", checkable=True),
            self._qtile("follow" if self.follow else "hover", "Follow gaze" if self.follow else "Hover",
                        self.toggle_follow, checked=self.follow, checkable=True),
            layout_tile,
            self._qtile("recenter", "Recenter", self.recenter),
            self._qtile("fullscreen", "Full screen", self.toggle_fullscreen,
                        checked=self.isFullScreen(), checkable=True),
            self._qtile("home", "Home", self.toggle_home, checked=self.home_wanted, checkable=True),
        ]
        for i, b in enumerate(tiles):
            grid.addWidget(b, i // 3, i % 3)
        left.addLayout(grid)

        rounds = QHBoxLayout()
        rounds.setSpacing(12)
        rounds.addWidget(self._qround("calibrate", "Calibrate glasses", self.open_calibration))
        rounds.addWidget(self._qround("settings", "Settings", self.open_settings))
        rounds.addStretch(1)
        left.addLayout(rounds)

        fov = int(self.scene.fov)
        fov_row = QHBoxLayout()
        fov_lbl = QLabel("Immersiveness")
        fov_lbl.setObjectName("qrow")
        fov_val = QLabel(f"{fov}°")
        fov_val.setObjectName("qhint")
        fov_row.addWidget(fov_lbl)
        fov_row.addStretch(1)
        fov_row.addWidget(fov_val)
        left.addLayout(fov_row)
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setObjectName("qslider")
        slider.setRange(int(FOV_MIN), int(FOV_MAX))
        slider.setValue(fov)
        slider.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        def on_fov(v):
            self.scene.set_fov(v)
            fov_val.setText(f"{v}°")
        slider.valueChanged.connect(on_fov)
        slider.sliderReleased.connect(self._save)
        left.addWidget(slider)
        left.addStretch(1)
        root.addLayout(left, 3)

        # Right: the windows that are open, each with a close button, and a clear action
        card = QFrame()
        card.setObjectName("qlist")
        card_lay = QVBoxLayout(card)
        card_lay.setContentsMargins(18, 18, 18, 16)
        card_lay.setSpacing(10)
        head_row = QHBoxLayout()
        title = QLabel("Windows")
        title.setObjectName("qrow")
        head_row.addWidget(title)
        head_row.addStretch(1)
        count = QLabel(str(sum(1 for q in self.panels if q.get("closing") is None)))
        count.setObjectName("qhint")
        head_row.addWidget(count)
        card_lay.addLayout(head_row)
        if not self.panels:
            empty = QLabel("No windows open. Add one from the launcher.")
            empty.setObjectName("qhint")
            empty.setWordWrap(True)
            card_lay.addWidget(empty)
        for i, p in enumerate(self.panels):
            if p.get("closing") is not None:
                continue
            row = QHBoxLayout()
            name = QLabel(str(p.get("name", f"Window {i + 1}")))
            name.setObjectName("qrow")
            name.setMinimumWidth(120)
            name.setWordWrap(False)
            x = QPushButton()
            x.setObjectName("qx")
            x.setFixedSize(28, 28)
            x.setIcon(make_icon("close", QColor(236, 242, 250), px=28))
            x.setIconSize(QSize(12, 12))
            x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            x.setToolTip("Close this window")
            x.clicked.connect(lambda _c=False, idx=i: self._quick_remove(idx))
            row.addWidget(name)
            row.addStretch(1)
            row.addWidget(x)
            card_lay.addLayout(row)
        card_lay.addStretch(1)
        if self.panels:
            clear = QPushButton("Close all")
            clear.setObjectName("qghost")
            clear.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            clear.clicked.connect(self._quick_clear)
            card_lay.addWidget(clear, 0, Qt.AlignmentFlag.AlignRight)
        root.addWidget(card, 2)

        self.sheet_lay.addWidget(body)
        self._show_sheet(width=760)

    def _quick_remove(self, index):
        self.remove_panel(index)
        self.open_quick_settings()

    def _quick_clear(self):
        for p in list(self.panels):
            self.close_panel(p)
        self.open_quick_settings()


    def open_settings(self):
        """Settings in the style of a phone's settings app: grouped rows, detail pages and search."""
        self._clear_sheet()
        self.sheet_kind = "settings"
        self._set_stack = QStackedWidget()
        self._set_stack.setStyleSheet(SETTINGS_QSS)
        self._set_stack.addWidget(self._settings_root())
        self.sheet.setFixedHeight(min(680, max(460, self.height() - 60)))
        self.sheet_lay.addWidget(self._set_stack)
        self._show_sheet(width=780)

    def _close_settings(self):
        self.sheet.hide()
        self.sheet_kind = None
        self._apply_visibility()

    def _settings_scroll(self, holder):
        sc = QScrollArea()
        sc.setObjectName("setscroll")
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.Shape.NoFrame)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        sc.setWidget(holder)
        sc.viewport().setAutoFillBackground(False)
        return sc

    def _settings_group(self, rows):
        box = QFrame()
        box.setObjectName("setgroup")
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        for i, r in enumerate(rows):
            if i:
                inset = QHBoxLayout()
                inset.setContentsMargins(56, 0, 0, 0)
                sep = QFrame()
                sep.setObjectName("setsep")
                sep.setFixedHeight(1)
                inset.addWidget(sep)
                v.addLayout(inset)
            v.addWidget(r)
        return box

    def _switch(self, checked, on_change):
        sw = ToggleSwitch(checked)
        sw.toggled.connect(on_change)
        return sw

    def _spin(self, lo, hi, value, step=1, suffix="", on_change=None):
        sp = QSpinBox()
        sp.setObjectName("setspin")
        sp.setRange(lo, hi)
        sp.setSingleStep(step)
        sp.setValue(value)
        if suffix:
            sp.setSuffix(suffix)
        sp.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        if on_change is not None:
            sp.valueChanged.connect(on_change)
        return sp

    def _slider_row(self, title, lo, hi, value, fmt, on_change, on_release=None):
        box = QFrame()
        box.setObjectName("setrow")
        v = QVBoxLayout(box)
        v.setContentsMargins(14, 10, 14, 12)
        v.setSpacing(8)
        head = QHBoxLayout()
        t = QLabel(title)
        t.setObjectName("setrowtitle")
        val = QLabel(fmt.format(value))
        val.setObjectName("setrowvalue")
        head.addWidget(t)
        head.addStretch(1)
        head.addWidget(val)
        s = QSlider(Qt.Orientation.Horizontal)
        s.setObjectName("qslider")
        s.setRange(int(lo), int(hi))
        s.setValue(int(value))
        s.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        def changed(v_):
            val.setText(fmt.format(v_))
            on_change(v_)
        s.valueChanged.connect(changed)
        if on_release is not None:
            s.sliderReleased.connect(on_release)
        v.addLayout(head)
        v.addWidget(s)
        return box

    def _theme_label(self):
        if self.bg_path:
            return "Custom image"
        return str(self.theme_name).capitalize()

    def _settings_sections(self):
        return [
            ("Glasses", [
                SettingsRow("calibrate", "#3b82f6", "Glasses & calibration",
                            on_click=lambda: self._settings_push(self._settings_glasses_page())),
            ]),
            ("Display", [
                SettingsRow("3d", "#a855f7", "Theme", value=self._theme_label(),
                            on_click=lambda: self._settings_push(self._settings_theme_page())),
                SettingsRow("hover", "#06b6d4", "Immersiveness", value=f"{int(self.scene.fov)}\u00b0",
                            on_click=lambda: self._settings_push(self._settings_fov_page())),
                SettingsRow("layers", "#f97316", "Arrangement", value=dict(LAYOUTS).get(self.layout_name, ""),
                            on_click=lambda: self._settings_push(self._settings_arrangement_page())),
                SettingsRow("layers", "#f97316", "Window shape", value=SHAPE_LABELS[self.shape], chevron=True,
                            on_click=lambda: self._settings_push(self._settings_shape_page())),
                SettingsRow("layers", "#f97316", "Window curve", chevron=False,
                            trailing=self._spin(0, 100, self.curve, 10, "%", on_change=self._set_curve)),
            ]),
            ("2D to 3D", [
                SettingsRow("3d", "#a855f7", "Depth from 2D", chevron=False,
                            trailing=self._switch(self.depth_on, self._set_depth_on)),
                SettingsRow("grid", "#a855f7", "Depth strength", chevron=False,
                            trailing=self._spin(0, 100, self.depth_pct, 5, "%", on_change=self._set_depth_pct)),
                SettingsRow("settings", "#64748b", "Depth model", value="Ready" if self.depth_model_ok else "Not installed",
                            chevron=False),
            ]),
            ("Windows", [
                SettingsRow("grid", "#22c55e", "Maximum windows", chevron=False,
                            trailing=self._spin(1, MAX_PANELS_LIMIT, self.max_panels, on_change=self._set_max_panels)),
                SettingsRow("recenter", "#ec4899", "Transition time", chevron=False,
                            trailing=self._spin(200, 4000, self.fade_ms, 100, " ms", on_change=self._set_fade)),
                SettingsRow("follow", "#14b8a6", "Follow gaze", chevron=False,
                            trailing=self._switch(self.follow, self.set_follow)),
            ]),
            ("Startup & alerts", [
                SettingsRow("home", "#ef4444", "Launch animation", chevron=False,
                            trailing=self._switch(self.show_intro, self._set_intro)),
                SettingsRow("windows", "#eab308", "Notifications", chevron=False,
                            trailing=self._switch(self.notify_on, self._set_notify)),
            ]),
            ("Account", [
                SettingsRow("home", "#64748b", "Signed in as", value=self.account_name or "", chevron=False),
                SettingsRow("home", "#64748b", "Sign out", value="", chevron=True, on_click=self.sign_out_now),
            ]),
            ("Help", [
                SettingsRow("grid", "#64748b", "Desktop shortcut", value="Windows", chevron=False,
                            on_click=self._install_app_shortcuts),
                SettingsRow("grid", "#64748b", "Keyboard shortcuts",
                            on_click=lambda: self._settings_push(self._settings_keys_page())),
                SettingsRow("settings", "#64748b", "About",
                            on_click=lambda: self._settings_push(self._settings_about_page())),
            ]),
        ]

    def _settings_root(self):
        self._set_groups = []
        page = QWidget()
        page.setObjectName("setbody")
        v = QVBoxLayout(page)
        v.setContentsMargins(6, 4, 6, 6)
        v.setSpacing(12)
        top = QHBoxLayout()
        top.addStretch(1)
        done = QPushButton("Done")
        done.setObjectName("setdone")
        done.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        done.clicked.connect(self._close_settings)
        top.addWidget(done)
        v.addLayout(top)
        title = QLabel("Settings")
        title.setObjectName("settitle")
        v.addWidget(title)
        search = QLineEdit()
        search.setObjectName("setsearch")
        search.setPlaceholderText("Search settings")
        search.setClearButtonEnabled(True)
        search.textChanged.connect(self._settings_filter)
        v.addWidget(search)
        content = QVBoxLayout()
        content.setContentsMargins(0, 0, 0, 0)
        content.setSpacing(6)
        for name, rows in self._settings_sections():
            lbl = QLabel(name.upper())
            lbl.setObjectName("setsection")
            group = self._settings_group(rows)
            content.addWidget(lbl)
            content.addWidget(group)
            content.addSpacing(8)
            self._set_groups.append((lbl, group, rows))
        content.addStretch(1)
        holder = QWidget()
        holder.setObjectName("setbody")
        holder.setLayout(content)
        v.addWidget(self._settings_scroll(holder), 1)
        return page

    def _settings_filter(self, text):
        q = text.strip().lower()
        for lbl, group, rows in self._set_groups:
            any_shown = False
            for r in rows:
                show = (not q) or (q in r.title_text.lower())
                r.setVisible(show)
                any_shown = any_shown or show
            group.setVisible(any_shown)
            lbl.setVisible(any_shown)
            for sep in group.findChildren(QFrame, "setsep"):
                sep.setVisible(not q)

    def _settings_push(self, page):
        stack = self._set_stack
        while stack.count() > 1:
            old = stack.widget(1)
            stack.removeWidget(old)
            old.deleteLater()
        stack.addWidget(page)
        stack.setCurrentWidget(page)

    def _settings_back(self):
        stack = self._set_stack
        if stack.count() > 1:
            page = stack.widget(stack.count() - 1)
            stack.setCurrentIndex(0)
            stack.removeWidget(page)
            page.deleteLater()

    def _settings_detail(self, title, build):
        page = QWidget()
        page.setObjectName("setbody")
        v = QVBoxLayout(page)
        v.setContentsMargins(6, 4, 6, 6)
        v.setSpacing(12)
        head = QHBoxLayout()
        back = QPushButton("\u2039  Settings")
        back.setObjectName("setback")
        back.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        back.clicked.connect(self._settings_back)
        head.addWidget(back)
        head.addStretch(1)
        t = QLabel(title)
        t.setObjectName("setpagetitle")
        head.addWidget(t)
        head.addStretch(1)
        balance = QLabel("")
        balance.setFixedWidth(back.sizeHint().width())
        head.addWidget(balance)
        v.addLayout(head)
        content = QVBoxLayout()
        content.setContentsMargins(0, 0, 0, 0)
        content.setSpacing(12)
        build(content)
        content.addStretch(1)
        holder = QWidget()
        holder.setObjectName("setbody")
        holder.setLayout(content)
        v.addWidget(self._settings_scroll(holder), 1)
        return page

    def _settings_glasses_page(self):
        def build(c):
            status = getattr(self.tracker, "message", "") or "Not started"
            c.addWidget(self._settings_group([
                SettingsRow("calibrate", "#3b82f6", "Status", value=status, chevron=False),
                SettingsRow("calibrate", "#3b82f6", "Calibrate glasses", on_click=self.open_calibration),
            ]))
            c.addWidget(self._settings_group([
                SettingsRow("hover", "#64748b", "Camera passthrough and hands", chevron=False,
                            trailing=self._switch(bool(self.cfg.get("camera_on", False)), self._set_camera)),
            ]))
            c.addWidget(self._settings_group([
                self._slider_row("Look sensitivity", 50, 200, int(self.look_speed * 100), "{}%",
                                 self._look_speed_changed, self._save),
            ]))
        return self._settings_detail("Glasses", build)

    def _settings_theme_page(self):
        def build(c):
            rows = []
            for name in THEMES:
                selected = (not self.bg_path) and self.theme_name == name
                rows.append(SettingsRow("3d", "#a855f7", name.capitalize(), value="\u2713" if selected else "",
                                        chevron=False, on_click=lambda n=name: self._choose_theme(n)))
            rows.append(SettingsRow("grid", "#a855f7", "Custom image\u2026", value="\u2713" if self.bg_path else "",
                                    chevron=False, on_click=self._choose_custom_theme))
            c.addWidget(self._settings_group(rows))
        return self._settings_detail("Theme", build)

    def _settings_fov_page(self):
        def build(c):
            c.addWidget(self._settings_group([
                self._slider_row("Field of view", FOV_MIN, FOV_MAX, int(self.scene.fov), "{}\u00b0",
                                 self._fov_changed, self._save),
            ]))
            d = QLabel("Narrower makes everything feel bigger and closer. Wider shows more of the room.")
            d.setObjectName("setdesc")
            d.setWordWrap(True)
            c.addWidget(d)
        return self._settings_detail("Immersiveness", build)

    def _refresh_taskbar(self):
        tb = self.scene.taskbar
        if tb is None:
            return
        apps = list_taskbar_apps()
        room = tuple(p["grab"].ident for p in self.panels if p["grab"].kind == "window")
        key = (tuple((h, t) for h, t, _path in apps), room)
        if key == self._taskbar_key:
            return
        self._taskbar_key = key
        frame, slots = render_taskbar(apps, set(room))
        tb["grab"].set_frame(frame)
        tb["slots"] = slots

    def _taskbar_click(self, u, v):
        """A click on an icon: the app comes into the room. The real app is not brought to the front."""
        tb = self.scene.taskbar
        if tb is None:
            return
        k = taskbar_slot_at([(s[0], s[1]) for s in tb.get("slots", [])], u * TASKBAR_PIC_W)
        if k is None:
            return
        _x0, _x1, hwnd, title, _path = tb["slots"][k]
        self._open_app(hwnd, title)

    def _open_app(self, hwnd, title):
        """Brings an app into the room, or shows its window there again, so you stay in Spatial Desk."""
        for index, p in enumerate(self.panels):
            if p.get("closing") is not None:
                continue
            if p["grab"].kind == "window" and p["grab"].ident == hwnd:
                if p.get("hidden"):
                    self.minimise_panel(index)          # shows a minimised window again
                self.focus_panel(index)
                return
        self.add_source("window", hwnd, title)

    # ----- camera mode: the picture behind the room, the cursor from your finger, and the keyboard
    def _resume_camera_if_on(self):
        """Camera mode comes back on when the desk opens, if it was on when the app last closed."""
        if self.cfg.get("camera_on"):
            QTimer.singleShot(1200, lambda: self._set_camera(True))

    def _set_camera(self, on):
        """Settings: camera passthrough with hand tracking. Off until turned on; needs the camera libraries."""
        on = bool(on)
        if on:
            ok, why = hand_tracking.camera_ready()
            if not ok:
                self.toast(why)
                on = False
        self.cfg["camera_on"] = on
        self._save()
        self.scene.set_camera_on(on)
        if on:
            self._start_camera()
        else:
            self._stop_camera()

    def _start_camera(self):
        if getattr(self, "cam_worker", None) is not None:
            return
        self.pinch = hand_tracking.Pinch()
        self._kb_shift = False
        self._kb_pressed = None
        self._cam_size = None
        worker = camera_view.CameraWorker(app_paths.data_dir(), self)
        worker.frame.connect(self._on_camera_frame)
        worker.hands.connect(self._on_hands)
        worker.status.connect(self.toast)
        self.cam_worker = worker
        worker.start()

    def _stop_camera(self):
        worker, self.cam_worker = getattr(self, "cam_worker", None), None
        if worker is not None:
            worker.requestInterruption()
            worker.wait(4000)
        self.scene.set_pointer(None, None, "mouse")

    def _on_camera_frame(self, rgb):
        self._cam_size = (rgb.shape[1], rgb.shape[0])
        self.scene.set_camera_frame(rgb)

    def _on_hands(self, hands):
        """Each picture from the camera. The cursor follows the index finger; a pinch presses the key under it, or
        clicks the room (a real click) when there is no key."""
        sc = self.scene
        if not sc.cam_on:
            return
        if not hands:
            sc.set_pointer(None, None, "hand")
            self.pinch.down = False
            self._kb_pressed = None
            sc.set_keyboard(hand_tracking.keyboard_rect(sc.width(), sc.height()), None, None)
            return
        hand = hands[0]
        cw, ch = self._cam_size or (1280, 720)
        nx, ny = hand_tracking.index_tip(hand)
        x, y = hand_tracking.cover_map(nx, ny, cw, ch, sc.width(), sc.height())
        sc.set_pointer(x, y, "hand")
        rect = hand_tracking.keyboard_rect(sc.width(), sc.height())
        kx, ky, kw, kh = rect
        hover = hand_tracking.key_at(hand_tracking.keyboard_keys(kw, kh), x - kx, y - ky)
        event = self.pinch.update(hand_tracking.pinch_ratio(hand))
        if event == "down":
            if hover is not None:
                self._kb_pressed = hover
                self._kb_shift = keyboard_input.press_label(hover, self._kb_shift)
            else:
                self._kb_pressed = None
                self._on_click(x, y)
        elif event == "up":
            self._kb_pressed = None
        sc.set_keyboard(rect, hover, self._kb_pressed)

    def _install_app_shortcuts(self):
        """Settings: puts Spatial Desk on the desktop and in the Start menu, with its icon."""
        ok, message = app_install.install_as_windows_app(HERE, ["Desktop", "Programs"])
        rh.log.info("desktop shortcut: %s", message)
        self.toast(message)

    def sign_out_now(self):
        """Settings: sign out. The desk is hidden and the login comes back; nothing is lost."""
        if callable(self.on_sign_out):
            self.on_sign_out()

    def _open_tuner(self, idx):
        """The top bar's button: a small card beside the cursor for this window's curve, shape and size. Not a sidebar.
        The card is a child of this window, drawn with the desk. A press outside it closes it."""
        if not (0 <= idx < len(self.panels)):
            return
        p = self.panels[idx]
        self._close_tuner()
        card = WindowTuner(
            p["name"], not p.get("curve_off", False), p.get("ratio", "auto"), SHAPE_LABELS,
            on_curve=lambda on, q=p: self._set_window_curve(q, on),
            on_shape=lambda k, q=p: self._set_window_shape(q, k),
            on_size=lambda factor, q=p: self._resize_window(q, factor),
            on_reset=lambda q=p: self._reset_window_size(q),
            parent=self)
        self._tuner = card
        spot = self.mapFromGlobal(QCursor.pos())
        card.show_at(spot.x(), spot.y())
        rh.log.info("window card opened for %s", p["name"])

    def _close_tuner(self):
        """Closes the window card and frees it. It is closed whenever the windows or the mode change, so the card never
        acts on a window that has moved or gone."""
        card = self._tuner
        self._tuner = None
        if card is not None:
            card.hide()
            card.deleteLater()

    def _tuner_outside_press(self, obj, ev):
        """A press in this window outside the card closes the card. Presses in other windows do not count."""
        card = self._tuner
        if card is None or not card.isVisible():
            return
        if not isinstance(obj, QWidget) or obj.window() is not self:
            return
        if not card.geometry().contains(self.mapFromGlobal(ev.globalPosition().toPoint())):
            self._close_tuner()

    def _resize_window(self, p, factor):
        """The card's size buttons act on the window it was opened for, found by identity, not by list position."""
        index = next((i for i, q in enumerate(self.panels) if q is p), None)
        if index is not None:
            self.resize_panel(index, factor)

    def _reset_window_size(self, p):
        if any(q is p for q in self.panels):
            p.pop("size", None)
            self.scene.relayout()
            self.scene.kick_warp(0.3)

    def _set_window_curve(self, p, curved):
        p["curve_off"] = not curved
        self.scene.kick_warp(0.3)

    def _set_window_shape(self, p, key):
        p["ratio"] = key
        self.scene.kick_warp(0.3)
        self.toast(f"{p['name']}: {SHAPE_LABELS[key]}")

    def _choose_shape(self, key):
        self.shape = key
        for p in self.panels:
            p["ratio"] = key
        self.scene.kick_warp(0.4)
        self._save()
        self.toast(f"Window shape: {SHAPE_LABELS[key]}")
        self._settings_push(self._settings_shape_page())

    def _settings_shape_page(self):
        def build(c):
            rows = []
            for key in RATIOS:
                rows.append(SettingsRow("layers", "#f97316", SHAPE_LABELS[key],
                                        value="\u2713" if key == self.shape else "", chevron=False,
                                        on_click=lambda k=key: self._choose_shape(k)))
            c.addWidget(self._settings_group(rows))
        return self._settings_detail("Window shape", build)

    def _settings_arrangement_page(self):
        def build(c):
            rows = []
            for key, label in LAYOUTS:
                rows.append(SettingsRow("layers", "#f97316", label,
                                        value="\u2713" if key == self.layout_name else "", chevron=False,
                                        on_click=lambda k=key: self._choose_layout(k)))
            c.addWidget(self._settings_group(rows))
        return self._settings_detail("Arrangement", build)

    def _settings_keys_page(self):
        def build(c):
            rows = []
            for key, what in SHORTCUT_LIST:
                chip = QLabel(platform_support.shortcut_label(key, PROFILE))
                chip.setObjectName("setkey")
                rows.append(SettingsRow("grid", "#64748b", what, chevron=False, trailing=chip))
            c.addWidget(self._settings_group(rows))
        return self._settings_detail("Keyboard shortcuts", build)

    def _settings_about_page(self):
        def build(c):
            c.addWidget(self._settings_group([
                SettingsRow("settings", "#64748b", "App", value="Spatial Desk", chevron=False),
                SettingsRow("grid", "#64748b", "Source", value="AverageDev143/Air-Neo", chevron=False),
            ]))
        return self._settings_detail("About", build)

    def _choose_theme(self, name):
        self._apply_theme(name)
        self._settings_push(self._settings_theme_page())

    def _choose_custom_theme(self):
        self._apply_theme("custom")
        self._settings_push(self._settings_theme_page())

    def _choose_layout(self, key):
        self.set_layout(key)
        self._settings_push(self._settings_arrangement_page())

    def _apply_theme(self, choice):
        if choice == "custom":
            path, _ = QFileDialog.getOpenFileName(self, "Choose a background image", "",
                                                  "Images (*.png *.jpg *.jpeg *.bmp)")
            if path and self.scene.set_background_image(path):
                self.bg_path = path
                self._save()
                self.toast("Background set")
            return
        self.theme_name = choice
        self.bg_path = ""
        self.scene.set_theme(choice)
        self._save()

    def _init_depth(self):
        """Reads whether the depth model is installed, and turns 2D to 3D on if it was on last time."""
        self.depth_pct = int(self.cfg["depth_pct"])
        self.depth_model_ok, self.depth_status = depth_model.model_status()
        self.depth_on = False
        Grabber.depth_on = False
        self._update_depth_amt()
        if self.cfg["depth_on"]:
            self._apply_depth(True, quiet=True)

    def _apply_depth(self, on, quiet=False):
        """Turns depth on or off. The model loads the first time it is switched on, which takes a moment."""
        on = bool(on)
        if on and getattr(Grabber, "depth_worker", None) is None:
            estimator, status = depth_model.load_estimator()
            self.depth_status = status
            self.depth_model_ok = estimator is not None
            if estimator is None:
                if not quiet:
                    self.toast("2D to 3D needs a depth model: " + status)
                on = False
            else:
                Grabber.depth_worker = depth_model.DepthWorker(estimator)
        self.depth_on = on
        Grabber.depth_on = on
        self._update_depth_amt()

    def _set_depth_on(self, on):
        self._apply_depth(on)
        self._save()

    def _set_depth_pct(self, value):
        self.depth_pct = int(value)
        self._update_depth_amt()
        self._save()

    def _update_depth_amt(self):
        self.scene.depth_amt = (self.depth_pct / 100.0) * DEPTH_MAX_M if self.depth_on else 0.0

    def _set_curve(self, value):
        self.curve = int(value)
        self.scene.curve = self.curve / 100.0
        self._save()

    def _set_max_panels(self, value):
        self.max_panels = value
        self._save()
        # Never hide windows that are already open; just stop adding more.
        self.toast(f"Up to {value} windows")

    def _set_fade(self, value):
        self.fade_ms = value
        self._save()

    def _set_intro(self, value):
        self.show_intro = value
        self._save()

    def _look_speed_changed(self, value):
        self.look_speed = value / 100.0
        self.cfg["look_speed"] = self.look_speed

    def _set_notify(self, value):
        self.notify_on = value
        self._save()

    def _fov_changed(self, value):
        self.scene.set_fov(value)

    # ----- sheet helpers
    def _clear_sheet(self):
        self._sheet_frame(bare=False)
        self.sheet.setMinimumHeight(0)
        self.sheet.setMaximumHeight(16777215)
        while self.sheet_lay.count():
            item = self.sheet_lay.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
            lay = item.layout()
            if lay is not None:
                while lay.count():
                    sub = lay.takeAt(0).widget()
                    if sub is not None:
                        sub.deleteLater()

    def _sheet_title(self, text):
        t = QLabel(text)
        t.setObjectName("sheettitle")
        self.sheet_lay.addWidget(t)

    def _sheet_text(self, text):
        t = QLabel(text)
        t.setObjectName("hint")
        t.setWordWrap(True)
        self.sheet_lay.addWidget(t)

    def _sheet_close_row(self):
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(make_button("Close", self.sheet.hide))
        self.sheet_lay.addLayout(row)

    def _show_sheet(self, width=460):
        self.sheet.setFixedWidth(width)
        self.sheet.adjustSize()
        self.sheet.move((self.width() - self.sheet.width()) // 2, max(20, (self.height() - self.sheet.height()) // 2))
        self.sheet.show()
        self.sheet.raise_()

    # ----- window list
    def _clear_layout(self, lay):
        while lay.count():
            item = lay.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _refresh_list(self):
        self._clear_layout(self.list_lay)
        live = [q for q in self.panels if q.get("closing") is None]
        self.side_head.setText(f"WINDOWS  ·  {len(live)}")
        if not live:
            empty = QLabel("No windows yet.")
            empty.setObjectName("hint")
            self.list_lay.addWidget(empty)
        for i, p in enumerate(self.panels):
            if p.get("closing") is not None:
                continue
            row = QFrame()
            row.setObjectName("row")
            row.setProperty("focused", p is self.scene.focused)
            h = QHBoxLayout(row)
            h.setContentsMargins(8, 6, 6, 6)
            h.setSpacing(4)
            grab = p["grab"]
            problem = (not grab.has_picture()) and grab.age() > 4.0
            badge = QLabel((p["name"].strip()[:1] or "?").upper())
            badge.setObjectName("badge")
            badge.setFixedSize(26, 26)
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label = QLabel(self._elide(p["name"] + ("  · minimised" if p.get("hidden") else ("  · no picture" if problem else "")), 96))
            label.setObjectName("warn" if problem else "name")
            label.setToolTip((grab.error or "") if problem else p["name"])
            dist = QLabel(f"{p.get('dist', DEFAULT_DIST):.1f} m")
            dist.setObjectName("dist")
            dist.setFixedWidth(40)
            dist.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            h.addWidget(badge)
            h.addWidget(label, 1)
            h.addWidget(dist)
            pull = make_button("", lambda _c=False, idx=i: self.nudge_panel(idx, -0.3), tool=True)
            pull.setIcon(make_icon("minus", px=32))
            pull.setIconSize(QSize(12, 12))
            pull.setToolTip("Pull closer")
            push = make_button("", lambda _c=False, idx=i: self.nudge_panel(idx, +0.3), tool=True)
            push.setIcon(make_icon("add", px=32))
            push.setIconSize(QSize(12, 12))
            push.setToolTip("Push further away")
            big = make_button("", lambda _c=False, idx=i: self.toggle_expand(idx), tool=True)
            big.setIcon(make_icon("maximise", px=32))
            big.setIconSize(QSize(12, 12))
            big.setCheckable(True)
            big.setChecked(bool(p.get("expanded")))
            big.setToolTip("Make this the main window (large)")
            remove = make_button("", lambda _c=False, idx=i: self.remove_panel(idx))
            remove.setObjectName("remove")
            remove.setIcon(make_icon("close", px=32))
            remove.setIconSize(QSize(12, 12))
            remove.setToolTip("Remove")
            if p.get("hidden"):
                show = make_button("Show", lambda _c=False, idx=i: self.minimise_panel(idx), tool=True)
                h.addWidget(show)
            for b in (pull, push, big, remove):
                h.addWidget(b)
            self.list_lay.addWidget(row)
        self._apply_visibility()

    def _elide(self, text, width):
        return QFontMetrics(self.font()).elidedText(text, Qt.TextElideMode.ElideRight, width)

    def _watch_pictures(self):
        if any(not p["grab"].has_picture() and p["grab"].age() > 4.0 for p in self.panels):
            self._refresh_list()

    # ----- per-frame
    def _tick(self):
        step = 0.016 / max(0.2, self.fade_ms / 1000.0)
        if self.progress < self.target:
            self.progress = min(self.target, self.progress + step)
        elif self.progress > self.target:
            self.progress = max(self.target, self.progress - step)
        e = self.progress * self.progress * (3.0 - 2.0 * self.progress)
        dim = math.sin(math.pi * self.progress) * 0.3     # only a gentle dip: the starfield rush carries the change

        snap = self.tracker.snapshot()
        for ev in snap.get("events", []):
            if ev == "spatial_button":
                self.toggle_mode()
        calibrated = bool(snap.get("calibrated"))
        status = snap.get("status", "none")
        self.live = status in ("ok", "stale") and calibrated

        if self.live:
            yaw, pitch = snap.get("yaw", 0.0) * self.look_speed, snap.get("pitch", 0.0) * self.look_speed
        else:
            yaw, pitch = self.mouse_yaw, self.mouse_pitch
        self.scene.set_view(yaw, pitch, e, dim)

        calib = snap.get("calib", {}) or {}
        self._refresh_chrome(status, calibrated, calib)
        self.btn_full.setToolTip("Windowed  (F11)" if self.isFullScreen() else "Full screen  (F11)")
        if self.sheet_kind == "calib" and self.sheet.isVisible():
            self.calib_bar.setValue(int(calib.get("progress", 0) * 100))
            self.calib_msg.setText(calib.get("message", ""))

    def _refresh_chrome(self, status="none", calibrated=False, calib=None):
        calib = calib or {}
        if not self.tracker.available:
            text, color = "Mouse", "#7d828c"
            self.status.setToolTip(self.tracker.message)
        elif status == "searching" and self.tracker.message.startswith(("Downloading", "SDK ready")):
            text, color = self.tracker.message, "#c9ced8"
        elif calib.get("state") == "calibrating":
            text, color = "Calibrating…", "#c9ced8"
        elif status in ("ok", "stale") and not calibrated:
            text, color = "Calibrate glasses", "#c9ced8"
        elif status == "ok":
            text, color = "Glasses tracking", "#f4f6f9"
        elif status == "stale":
            text, color = "Glasses signal weak", "#c9ced8"
        elif status == "searching":
            text, color = "Looking for glasses", "#c9ced8"
        else:
            text, color = "Mouse", "#7d828c"
        mode = ("Follow" if self.follow else "Hover") if self.mode == "spatial" else "Flat setup"
        if self.kb_panel is not None and not self.sheet.isVisible():
            mode = f"Typing in {self.kb_panel['name']}  ·  Esc"
        changed = False
        if self.track_lbl.text() != text:
            self.track_lbl.setText(text)
            changed = True
        if self.mode_lbl.text() != mode:
            self.mode_lbl.setText(mode)
            changed = True
        style = f"font-size: 9pt; color: {color};"
        if self.dot.styleSheet() != style:
            self.dot.setStyleSheet(style)
        if changed:
            self.status.adjustSize()
            self._place()

    # ----- input
    def keyPressEvent(self, ev):
        if self.kb_panel is not None and not self.sheet.isVisible():
            # The window that was clicked has the keyboard and gets its keys directly. A key that reaches the desk
            # means the room has the keyboard, so that window is no longer the one typing.
            self._release_keys(say=False)
        key = ev.key()
        if key == Qt.Key.Key_Escape:
            if self.sheet.isVisible():
                self.sheet.hide()
            elif self.mode == "spatial":
                self.set_mode("setup")
            elif self.isFullScreen():
                self.showNormal()
        elif key == Qt.Key.Key_Space:
            self.toggle_mode()
        elif key == Qt.Key.Key_R:
            self.recenter()
        elif key == Qt.Key.Key_P:
            self.toggle_panel()
        elif key == Qt.Key.Key_H:
            self.toggle_follow()
        elif key == Qt.Key.Key_L:
            self.cycle_layout()
        elif key == Qt.Key.Key_A:
            self.open_picker()
        elif key == Qt.Key.Key_T:
            self.cycle_ratio()
        elif key == Qt.Key.Key_Home:
            self.toggle_home()
        elif key == Qt.Key.Key_F11:
            self.toggle_fullscreen()
        elif self.mode == "spatial" and not self.live and key in (
                Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            if key == Qt.Key.Key_Left:
                self.mouse_yaw -= 0.05
            elif key == Qt.Key.Key_Right:
                self.mouse_yaw += 0.05
            elif key == Qt.Key.Key_Up:
                self.mouse_pitch += 0.05
            else:
                self.mouse_pitch -= 0.05
        else:
            super().keyPressEvent(ev)

    def closeEvent(self, ev):
        self._save()
        self.shutdown()
        super().closeEvent(ev)

    def shutdown(self):
        self._close_tuner()
        self._stop_camera()
        self.tracker.close()
        if self.scene.taskbar is not None:
            self.scene.taskbar["grab"].stop()
        for p in self.panels:
            p["grab"].stop()


def _keep_shortcuts(here):
    """Checks the desktop and Start menu shortcuts in the background, so a new version or a deleted shortcut is put right."""
    try:
        result = app_install.refresh_shortcuts(here)
        if result is not None:
            rh.log.info("shortcuts: %s", result[1])
    except Exception:
        rh.log.exception("could not check the shortcuts")


def main():
    rh.setup_logging()
    rh.log.info("%s", platform_support.startup_report(PROFILE))
    rh.log.info("saved data (accounts and settings) is kept in %s", app_paths.data_dir())
    app_install.set_app_user_id()           # the taskbar shows this app's icon, not Python's
    threading.Thread(target=_keep_shortcuts, args=(HERE,), daemon=True).start()
    threading.Thread(target=wc.UIA.warm, daemon=True).start()     # PowerShell starts now, not at the first click
    fmt = QSurfaceFormat()
    fmt.setVersion(3, 3)
    fmt.setSamples(4)                     # 4x multisampling smooths edges
    fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CoreProfile)
    QSurfaceFormat.setDefaultFormat(fmt)
    app = QApplication(sys.argv)
    app.setApplicationName("Spatial Desk")
    app.setWindowIcon(spatial_icon.qicon())
    moved = app_paths.migrate_from_program_folder(HERE)   # accounts and settings from older versions, once
    if moved:
        rh.log.info("copied saved data into %s: %s", app_paths.data_dir(), ", ".join(moved))
    area = app.primaryScreen().availableGeometry()   # fill the screen, minus the taskbar

    def install_offer():
        """After the first account: offer the Windows app, on Windows, until it has been added."""
        return os.name == "nt" and not app_install.is_installed()

    gate = LoginGate(app_paths.accounts_file(), install_offer=install_offer,
                     install_now=lambda places: app_install.install_as_windows_app(HERE, places))
    gate.setGeometry(area)
    desk = {"win": None}

    def sign_out():
        if desk["win"] is not None:
            desk["win"].hide()
        gate.reset()
        gate.setGeometry(area)
        gate.show()

    def sign_in(name):
        win = desk["win"]
        if win is None:
            win = MainWindow()            # made once, on the first sign-in; the intro plays then
            desk["win"] = win
            app.aboutToQuit.connect(win.shutdown)
            win.on_sign_out = sign_out
        win.account_name = name
        win.setGeometry(area)
        win.show()
        gate.hide()

    gate.signed_in.connect(sign_in)
    gate.show()                            # the login comes first, every time the app starts
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
