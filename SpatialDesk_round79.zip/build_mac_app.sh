#!/bin/bash
# Builds "Spatial Desk.app" for this Mac, signs it for local use, and makes a zip of it.
# Run it from the project folder in Terminal:   ./build_mac_app.sh
# Output: dist/Spatial Desk.app and dist/SpatialDesk-mac.zip
set -euo pipefail
cd "$(dirname "$0")"

if [ "$(uname -s)" != "Darwin" ]; then
    echo "This has to run on a Mac (it builds a macOS app)."; exit 1
fi

# The packages (PySide6, mediapipe) only have downloads for certain Python versions. Use 3.12 if it is there.
PYTHON_BIN=""
for candidate in python3.12 python3.11 python3; do
    if command -v "$candidate" >/dev/null 2>&1; then PYTHON_BIN="$candidate"; break; fi
done
if [ -z "$PYTHON_BIN" ]; then
    echo "Python 3 was not found. Install it with: brew install python@3.12"; exit 1
fi
VER=$("$PYTHON_BIN" -c 'import sys; print("%d.%d" % sys.version_info[:2])')
case "$VER" in
    3.11|3.12) ;;
    *) echo "Found Python $VER, which the packages may not support."
       echo "Install Python 3.12 with: brew install python@3.12   then run this again."; exit 1 ;;
esac
echo "Using Python $VER ($PYTHON_BIN)"

# A build environment made with a different Python version is replaced.
VENV=".build-venv"
if [ -x "$VENV/bin/python" ]; then
    OLD=$("$VENV/bin/python" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo "unknown")
    if [ "$OLD" != "$VER" ]; then
        echo "Replacing the build environment (it used Python $OLD)..."
        rm -rf "$VENV"
    fi
fi
if [ ! -d "$VENV" ]; then
    echo "Creating the build environment (first run only)..."
    "$PYTHON_BIN" -m venv "$VENV"
fi
PY="$VENV/bin/python"
"$PY" -m pip install -q --upgrade pip

echo "Installing the packages (this can take a few minutes)..."
"$PY" -m pip install -q -r requirements.txt pyinstaller

# Optional parts. If one has no download for this Mac, the app is still built without it.
if ! "$PY" -m pip install -q -r requirements-camera.txt; then
    echo "Camera mode packages could not be installed; building without camera mode."
fi
if ! "$PY" -m pip install -q onnxruntime; then
    echo "onnxruntime could not be installed; building without 2D to 3D depth."
fi

rm -rf build dist
echo "Drawing the icon..."
"$PY" make_icon.py build/icon/SpatialDesk.iconset
iconutil -c icns build/icon/SpatialDesk.iconset -o build/icon/SpatialDesk.icns

echo "Building the app (this takes a while)..."
"$VENV/bin/pyinstaller" --noconfirm --log-level WARN spatial_desk_mac.spec

# Ad-hoc signature: the app runs on this Mac, and on others after the Gatekeeper step in README_MAC.md.
codesign --force --deep --sign - "dist/Spatial Desk.app"
ditto -c -k --keepParent "dist/Spatial Desk.app" "dist/SpatialDesk-mac.zip"

echo
echo "Done."
echo "  App: dist/Spatial Desk.app   (drag it to Applications)"
echo "  Zip: dist/SpatialDesk-mac.zip"
