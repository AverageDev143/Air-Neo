# Spatial Desk: summary of changes

## Clicking into virtual windows
- Problem 1: the first fix posted window messages (PostMessage). Clicks did nothing in most apps.
- Problem 2: the next version moved the real pointer and clicked. The click worked, but Windows
  activated the real app, so the spatial view disappeared.
- Current method (`click_window_at` / `_send_click`):
  1. Converts the clicked point on the virtual window to screen coordinates.
  2. Remembers the Spatial Desk window and the pointer position.
  3. Sends one absolute left click (SendInput, virtual-desktop coordinates) at that spot.
  4. Puts the pointer back where it was.
  5. Re-activates the Spatial Desk window.
- Status: NOT verified on Windows. Known risks:
  - If another window covers the spot, the click lands on that window instead.
  - Apps that ignore synthetic clicks will still not respond.
  - The pointer moves for about 60 ms, which may flicker.

## Interface
- Dark neutral palette (graphite and white), replacing the cyan accent.
- Home screen: widget cards (calendar, Gmail, Drive, PC connection) on the left; coloured icons
  with labels on the right (Launcher, Hover, Recenter, Calibrate, Layout, Windows, 3D space, Settings);
  page dots.
- Dock: hidden on the flat home screen, shown in 3D mode.
- Status: plain text (time, mode, setup), no pill.
- Window controls: plain glyphs, no box.

## Not done
- Glass window cards and the icon-led title bar from the references (need Windows to test).
- Curved multi-screen layout and blurred photo backgrounds from the references.
- Real app logos on the tiles.

## How it was checked
- Rendered the main window on a Linux virtual display (Xvfb + PySide6) and compared screenshots.
- Click behaviour cannot be checked there; it needs Windows.

## Round 12 changes
- Home: vivid gradient app tiles with white glyphs; home panel widened so all four columns fit.
- Dock: glass capsule, shown on the home screen as well as in 3D.
- Arc layout: spread capped by window count (gentle arc for 3 windows); windows shrink when there are 3 or more, so the outer windows stay inside the view. Verified with synthetic windows in 3D mode, not with real captures.

## Round 13 changes
- Liquid glass: GlassFrame paints the dock and the home widget panel (translucent body, thin sheen, lit edge at top-left). This is an approximation; it does not blur or refract the scene behind.
- Dock buttons: glass hover state. Layout is unchanged (one row of icons).

## Round 14 changes
- Liquid glass is real now: the 3D scene is captured about 4 times a second, blurred, and shown behind the glass dock and home widget panel. The glass adds a light tint, a thin specular band, and a lit rim.
- Limitation: the backdrop updates about 4 times a second, so it can lag behind fast motion in 3D mode.
- Test wallpaper: set with Settings > background image. For best results use a large image (the room reference is only 512x335).

## Round 15 changes
- Window title bar: added the reference's left-hand icons (document, ring, up-caret). These are visual only; they do not do anything yet.
- Keyboard shortcuts and Qt-side mouse clicks were tested with synthetic events on Linux; all passed. Win32 clicks into real windows are still untested.

## Round 16 changes (windows)
- Default window width raised to 2.8 m, so a window fills about the same share of the frame as the reference.
- Removed the white glow around the focused window and reduced the rim, to match the reference's plain edge.

## Round 17 changes (window title bar)
- Title bar is now a flat, translucent grey strip with thin icons (was a black capsule with an outline).
- Window rim thinned further.
- Title bar height raised so its proportions are not stretched.
- Known gap: a small gap remains between the title bar and the window; the reference attaches them.

## Round 18 changes (title bar)
- Title bar slimmed, with smaller and lighter icons, for a cleaner look.

## Round 19 changes (title bar)
- Title bar is a centred, rounded pill spanning about 73% of the window width (not end to end), with a gap above the window, as in the reference.
- Icons: document, ring, and caret on the left; pull, push, maximise, and close on the right. Hit testing uses the same positions.

## Round 20 changes (title bar)
- Left icons clustered at the left end; right buttons clustered at the right end, so the bar no longer looks spread out.
- Bar made more transparent (fill alpha 190 focused, 160 unfocused).

## Round 21 changes (title bar)
- Icons smaller and lighter; bar moved closer to the window, to match the reference crop.

## Round 22 changes (title bar)
- Up-caret moved to the centre of the bar.
- Bar made slightly smaller (narrower and shorter).

## Round 23 changes (title bar)
- Bar length reduced to two-thirds, still centred.

## Round 24 changes (dock)
- Dock uses flat "soft" glass: the glossy band and heavy bevel are removed, leaving the blurred backdrop, a dark tint, and a thin light edge.
- INAIR dock images could not be found online; the dock was matched to the crop provided by the user.

## Round 25 changes (dock and status strip)
- Dock icons are coloured per action (blue, cyan, violet, green, red, amber, grey).
- Status strip under the dock: Wi-Fi symbol and clock. No battery icon, because the app has no battery reading.

## Round 26 changes (dock, Windows)
- Dock now uses coloured rounded app tiles (one colour per action, white glyphs, thin sheen), in a tighter glass pill, as in the reference. The 3D button is white, as the main action. Hover and checked states are kept.
- Status line under the dock: Wi-Fi, volume, battery (only when the PC has one, read from GetSystemPowerStatus, refreshed about every 30 s) and the clock.
- Not verified on Windows (rendered code could not be run in this environment). The Wi-Fi and volume symbols are decorative; they do not read the real network or sound state.

## Round 27 changes (dock, closer to the reference)
- Dock has no glass pill: the tiles float on the room, as in the reference.
- Tiles are solid, vivid squircles with a bright rim and a solid white glyph (were gradient tiles with line glyphs).
- Tighter pitch (tile + 4 px, no spacing) and a vivid palette, one colour per action.
- Hover and checked states use a soft wash, no outline.
- Status line is smaller and quieter (8 pt, thinner strokes, lower opacity).
- Not verified on Windows.

## Round 28 changes (dock uses real Microsoft app logos)
- The dock now lists the Microsoft apps found on this PC: Word, Excel, PowerPoint, Outlook, OneNote, Edge, Teams (if installed), File Explorer and Notepad. Each icon is read from the program's own .exe, so the logos are the real ones.
- Clicking an app opens it (os.startfile). Apps that are not installed are left out.
- After the apps, a divider, then 3D, Launcher and Settings. Hover, Recenter, Windows, Arrangement, Calibrate, Full screen and Minimise are still on the home screen and keyboard shortcuts (H, R, P, L, F11).
- Not verified on Windows. Office and Teams paths cover the common installs (Office 2016/2019/365 under Program Files); Microsoft Store versions of apps are not found.

## Round 29 changes (dock)
- Launcher, Settings and the other dock controls are plain white glyphs with no coloured tile, closer to the reference's floating icons. The 3D button stays as the one solid white tile.
- Not verified on Windows. The reference is a visionOS dock; no screenshot of the real window could be taken here.

## Round 30 changes (dock, closer to the reference)
- Dock shows only the real Microsoft app logos from the PC, plus plain white glyphs for the controls (3D, Launcher, Settings). No coloured tiles, letter tiles or divider line.
- An app whose logo Windows cannot read is left out of the dock.
- Not verified on Windows. Earlier mock-ups were placeholders and are not a preview of the real window.
- Fix: restored the make_glyph_icon helper that a Round 30 edit had removed (NameError at start-up).

## Round 31 changes (window size and capture)
- The app window opens filling the screen's work area (was a fixed 1280x800).
- Window captures are kept up to 2560 px wide (was 1920), so text stays sharper.
- Not verified on Windows. Click mapping and window scaling still need the helper.log from a real run.

## Round 32 changes (clicks, edges, sharpness)
- Clicks in virtual windows are posted to the window (WM_LBUTTONDOWN/UP) at the clicked spot. The real pointer no longer moves. Some apps (browsers, Store apps) may ignore posted clicks; for those, tick "Click with the real pointer" in Settings to use the old method.
- Window textures use mipmaps, so small text no longer shimmers or turns to noise when the window is far away.
- Rounded window corners are antialiased (were hard-edged), and the 3D view uses 4x multisampling.
- Not verified on Windows. The glasses' own pixel count still limits how small text can be read; a narrower field of view (Settings) makes text bigger.

## Round 33 changes (home screen, sharpness)
- The home screen no longer appears after the launch animation. Show or hide it with the home button in the dock or the Home key.
- Window captures are shrunk with smooth filtering (was skipping pixels), so text no longer breaks up.
- Windows use anisotropic filtering where the driver supports it, so text at an angle stays sharper.
- Not verified on Windows. Closer matching to INAIR OS is limited: the only reference available is one screenshot.

## Round 34 changes (window ratio, look sensitivity)
- Press T to cycle the focused window through Auto, Landscape, Widescreen and Portrait. The picture is cropped to the new shape, not stretched. The title bar is never cropped.
- Settings > Look sensitivity (50 to 200%) scales how fast the view turns, for both the mouse and the glasses.
- Not verified on Windows.

## Round 35 changes (closer to INAIR: dock, title bar, status, home)
- Dock: larger tiles (46 px) and a little more spacing.
- Title bar: lighter, more see-through glass (size and buttons unchanged).
- Status line at the top: softer text.
- Home screen: roomier grid, larger rounder app tiles, clearer labels.
- Not verified on Windows. Send a new screenshot so the next round can be checked against the references.

## Round 36 changes (title bar, layout, test harness)
- Title bar spans the full window width with dark glass (matches the INAIR references).
- "Code" layout: main window sits at least 3.6 m away and side windows at least 4.0 m, so with three windows all of them stay in view (were off-screen). Side windows are a little narrower.
- Added tools/render_layout.py: renders the app on a virtual display with synthetic window content, so layouts can be checked without capturing real apps.
- Known gaps: with two windows the second sits mostly off the right edge; the home screen and settings window do not yet match the references; not verified on Windows.

## Round 37 changes (status strip)
- Bottom status strip now follows the reference order: AI orb, screen cast, notifications bell, Wi-Fi, battery (when present), clock. The volume speaker was removed to match the reference.
- Known gap: the bell glyph is small and reads more like a cup at the default size.

## Round 38: control centre (after the INAIR control-panel reference)
- Click the bottom status strip to open a control centre: time and date, battery %, six tiles (Spatial 3D, Hover/Follow, Arrangement, Recenter, Full screen, Home), calibrate and settings buttons, an Immersiveness slider (field of view), and a list of open windows with a close button each and "Close all".
- Every tile and control calls an existing app action; nothing is decorative. The reference's Bluetooth, brightness and sound controls are not included because the app has no such features.
- The bell in the status strip is still small. Known gap.
- tools/test_quick.py: 12 functional checks for the control centre (run on the virtual display, see tools/render_layout.py).

## Round 39: home screen restyled toward the references
- App tiles are dark glass squircles with a coloured glyph (each app keeps its colour), replacing the saturated gradient tiles.
- Calendar card is dark glass with the red weekday kept as the accent; mini cards and the PC card are dark glass with thin borders.
- Known gaps: the widget box keeps a light top band; the PC card is still empty; the home screen has no list-style card like the "INAIR Space" panel in the second reference.

## Round 40: settings app, window title bars
- Settings is a full, phone-style app: a large title, search, grouped rows with coloured icon tiles, chevrons, switches and detail pages (Glasses, Theme, Immersiveness, Arrangement, Keyboard shortcuts, About). Every control changes a real setting, and Done closes it.
- Maximum windows, transition time, follow gaze, launch animation and notifications are controls on the root page.
- Window title bars: a gradient glass fill, a hairline edge, a brighter outline when focused, and the window's name beside the icons.
- tools/test_settings.py: 17 functional checks (real mouse clicks through QTest).
- Known gaps: the settings app has no sound or Bluetooth controls (the app doesn't have those features); the window body edges and shadows are still drawn by the 3D shader and haven't changed; not verified on Windows.

## Round 41: sideways placement (closer to INAIR OS window placement)
- Shift + scroll over a window slides it sideways around you (up to about 150 degrees either way). Plain scroll still pulls it closer or pushes it away.
- The place is kept while you work. Choosing an arrangement (Focus, Stage, Arc, Layers) puts every window back in its own place.
- Works in Arc, Focus, Stage and Layers. The setup row is unchanged.
- The keyboard shortcut list and the Behaviour hint mention the gesture.
- Scroll up slides a window to the left. If that feels backwards, flip the sign in `MainWindow._on_wheel`.
- tools/test_sideways.py: 22 checks on the layout and window-control code. Run with `python tools/test_sideways.py`; needs numpy only, not PySide6. A check with the change removed fails, so the tests do exercise it.
- Not verified on Windows or in the running app (PySide6 was not available to the build environment). Wheel handling in `Scene.wheelEvent` is untested.

## Round 42: window size (Ctrl + scroll)
- Ctrl + scroll over a window makes it wider or narrower, from half to one and a half times its normal width. Its distance does not change. Scroll up makes it bigger.
- Works in Arc, Focus, Stage and Layers. Choosing a preset arrangement now resets both the sideways place and the size of every window.
- In the Arc arrangement the total arc is still capped, so a bigger window takes room from its neighbours. Stage and Layers do not have this effect.
- The keyboard shortcut list and the Behaviour hint mention Ctrl + scroll.
- tools/test_sideways.py now has 34 checks. A check with the layers width change removed fails, so the size tests do exercise it.
- Not verified on Windows or in the running app (PySide6 was not available to the build environment).
- Behaviour taken from INAIR OS's public pages, which describe windows that resize and reposition in 3D space with depth control. No INAIR artwork, icons or code were used.

## Round 43: design title bar, edges, clicks and keys
- Title bar is the approved design: a black capsule, 85% opaque when the window is focused and 72% otherwise, with six icons and no text (sidebar, apps on the left; focus in the centre; minimise, maximise, close on the right). Icons are drawn on the design's 24-unit grid.
- Title bar buttons do something: Sidebar shows or hides the window list; Apps opens the window picker; Focus puts the window back in its default place, distance, size and turn; Minimise hides the window from the room (the list has a Show button); Maximise makes it the large main window; Close removes it from the desk (the real app keeps running). Distance is still set with the scroll wheel.
- Edges: the window capture now uses the visible frame (DWM extended frame bounds) instead of the full window rectangle, which included Windows' invisible resize border. That border showed as a dark or see-through fringe around each window. The capture is cut to the visible frame, one more pixel in from each side. Clicks use the same rectangle, so they land where you see them.
- Clicks: the pointer is moved over the spot, then a press and release are posted to the innermost control there, with coordinates relative to that control. Clicks outside the app's content are not sent, and the attempt is logged.
- Keys: clicking a window's picture sends your keys to that window (the control that has keyboard focus inside it). Esc returns keys to the desk, and so does clicking the empty room. The status strip says "Typing in <name>" while keys are going to a window. Keys are posted as messages, so apps that read the keyboard state directly (for example Ctrl+C) or ignore posted input (browsers, Store apps) may not respond.
- tools/test_input.py: checks for key codes, typed characters, the visible-frame crop and the title bar layout. tools/test_sideways.py gained a check for minimised windows. Both run without Windows or Qt.
- Not verified on Windows or in the running app (PySide6 was not available to the build environment). Check helper.log: each posted click records whether Windows accepted the messages.

## Round 44: home screen matches the home reference
- Left: a glass widget panel with the calendar (white card, today's weekday and date), Gmail and Google Drive (open the web apps in the browser), and a PC status card (the glasses or mouse state from the status line, the open window count, and flat or 3D).
- Right: two picture cards over four solid squircles. 3D space shows your wallpaper, or a teal gradient when none is set; clicking it enters or leaves 3D. Windows shows a stack of window icons and the count; clicking it shows or hides the window list.
- The four squircles are Hover, Recenter, Layout and Calibrate, in the dock's colours. Round 39's dark glass tiles are replaced.
- Removed: the three page dots (there is only one home page), the light band across the glass panel (the panel uses soft glass now), and Launcher and Settings from the home grid (both remain in the dock).
- Not added: the assistant pill from the reference, because the app has no assistant. A control that does nothing would break the rule that every control works.
- tools/test_home.py: 19 checks for the cards, wallpaper and status counts. Run with `python tools/test_home.py`.
- Checked on Linux with the offscreen display: test_home 19/19, test_quick 12/12, test_settings 17/17, test_input and test_sideways pass. Not verified on Windows.
- home_preview_round44.png is an offscreen render. The blurred 3D backdrop does not appear there, so the real glass panel will look greyer on the glasses.
- tools/test_quick.py and tools/test_settings.py still point at /home/claude/Air-Neo/src. Point them at this folder to run them.

## Round 45: every button works, and the home cards have textures
- Home: Hover, Recenter, Layout and Calibrate are now cards the same size and style as the others (124 x 168, same corner radius and caption). Hover shows On or Off and Layout shows the current arrangement name, both live.
- Textures: Calendar has paper grain, Gmail has linen, Google Drive has brushed metal, and each action card has its own pattern (halftone, rings, grid, stripes). Textures are drawn once per size and cached.
- Status strip: the AI orb opens claude.ai, the screen-cast icon opens the window picker, the bell turns notifications on and off (and dims when they are off), and the Wi-Fi icon opens Windows Wi-Fi settings (on Windows only; elsewhere it shows a note). The battery and clock still open the control centre.
- tools/test_buttons.py opens every screen (home, picker, settings and its six pages, calibration, control centre) and fails if any visible button has no click, press or toggle handler. It checked 131 buttons with 0 unwired. The calendar and PC cards are display-only and are skipped on purpose.
- tools/test_home.py now has 30 checks, covering the new cards, the status strip and the textures.
- Checked on Linux with the offscreen display: test_buttons, test_home 30/30, test_quick 12/12, test_settings 17/17, test_input and test_sideways clean. Not verified on Windows.
- test_quick.py and test_settings.py still point at /home/claude/Air-Neo/src. Point them at this folder to run them.

## Round 46: gradient backgrounds instead of textures
- Calendar, Gmail and Google Drive cards now have vertical gradient backgrounds: white to cool grey for the calendar, amber for Gmail, pale blue for Drive.
- The four action cards (Hover, Recenter, Layout, Calibrate) keep their dock colour as a gradient and no longer have a pattern drawn over them.
- The texture generator and its cache were removed.
- tools/test_home.py now checks the gradients (32 checks). tools/test_buttons.py still passes with 0 unwired buttons.
- Checked on Linux with the offscreen display. Not verified on Windows.

## Round 47: reference match for the status strip, Claude bar and logos
- Status strip redrawn to match the reference: screen cast, notifications, Wi-Fi, battery (when the PC has one) and clock. The bell arc was drawn the wrong way round and is fixed.
- The AI button moved from the status strip to a "Message Claude" bar at the top of the home screen. Clicking it opens claude.ai.
- Gmail and Google Drive cards now show their logos instead of letters. These are vector drawings that approximate the official marks; swap in the official SVGs if you want exact artwork.
- The home screen is 432 px tall to fit the bar above the widgets.
- tools/test_home.py: 32 checks, with the strip positions and the Claude bar updated. tools/test_buttons.py: 0 unwired buttons.
- Checked on Linux with the offscreen display. Not verified on Windows.

## Round 48: dock, Liquid Glass toolbar and logos from the photos
- Dock: each tile is now a coloured squircle with a white glyph, as in the reference (before, the colours were computed but never drawn). Installed apps show up to six tiles; the rest sit behind a +N tile that opens an app list sheet.
- Home toolbar (top of home): a round back button (hides home), a Liquid Glass pill with "Message Claude" plus windows, recenter and settings buttons, and a round 3D button. Every control is a real action.
- Gmail and Google Drive logos redrawn from the photo of the logos, with the gradients. These are vector drawings that match the photo closely but are not Google's official files.
- tools/test_buttons.py: 137 buttons checked, 0 without a handler. tools/test_home.py: 32 checks.
- Checked on Linux with the offscreen display. Not verified on Windows. The sandbox has no installed apps, so the app tiles and +N overflow were not exercised with real icons.

## Round 49: quieter dock, fixed status strip, single AI pill
- Dock: installed-app icons and the +N tile are removed. The dock is the four controls (Home, 3D, Launcher, Settings) on quiet squircles of one size; 3D is the near-white one.
- Status strip: a fixed-width grid. Screen cast, notifications and Wi-Fi sit on set positions, the battery (when the PC has one) sits after them, and the clock is right-aligned, so nothing shifts when the battery shows or hides.
- Home top: only the "Message Claude" pill remains, in a solid dark style. The Liquid Glass styling and the buttons beside and inside the pill are removed.
- tools/test_home.py: 32 checks. tools/test_buttons.py: all visible buttons wired.
- Checked on Linux with the offscreen display. Not verified on Windows.

## Round 50: tidier dock, status line and AI bar
- Dock glyphs are drawn at four times the display size with one stroke weight, so home, 3D, launcher and menu icons match. The launcher icon has a finer stroke and wider gaps, so it reads as four squares.
- Status line: screen cast, notifications and Wi-Fi sit close together, then the battery (when the PC has one), then the clock, all on one line. The clock no longer sits far to the right.
- AI bar: a black rounded card with a thin light edge and the AI ring, in the style of the Siri reference.
- tools/test_home.py: 32 checks. tools/test_buttons.py: all visible buttons wired.
- Checked on Linux with the offscreen display. Not verified on Windows.

## Round 51: quieter dock tiles and a complete Wi-Fi icon
- Dock tiles are smaller (44 px, down from 52) and use translucent fills instead of bright squares. The 3D button is marked by a lighter fill, and every glyph is white.
- Wi-Fi icon: three larger arcs fanning up from a base dot, centred on the same line as the other status icons. Before, it was drawn low and incomplete.
- The status line sits 12 px under the dock, up from 6 px.
- Checked on Linux with the offscreen display. Not verified on Windows.

## Round 52: merged with the 2D-to-3D and curved-window line (rounds 44-46 there)
- Merged the two lines of work from the common round 43 base: the home screen, dock, status strip and tests from round 51, and the curved windows, settings restyle and depth relief from the other line. The three-way merge had no textual conflicts. Both sides were checked for duplicate definitions and for names that no longer exist.
- Settings: a new "2D to 3D" section (Depth from 2D, Depth strength, Depth model status), and "Window curve" under Display. The root page now has six sections, and tools/test_settings.py checks six (it checked five before).
- Depth is off unless the model file is in models/ and onnxruntime is installed (see models/README.txt).
- The depth texture and the depth switch tolerate the test harness's fake capture object, which has no depth method.
- Depth suits windows and still pictures. It is estimated at most twice a second per window, so it will not keep up with video. Video would need the depth model to run at the frame rate, which a CPU model cannot do.
- tools/screenshots.py saves PNGs of the home screen, the 3D view (copied from the screen), the window picker, the settings root and each of its six pages, calibration, the control centre and both title bar states. Run it on Windows with PySide6 and mss installed.
- Run here (no Qt in the build sandbox): test_input, test_sideways, test_curve, test_depth all pass. test_home, test_buttons, test_quick, test_settings and screenshots.py need PySide6 and were not run. test_quick and test_settings still point at /home/claude/Air-Neo/src.
- Not verified on Windows or in the running app.

## Round 53: runs on macOS too, with platform detection
- platform_support.py works out which computer the app is on at start-up. Windows: glasses, window capture, Ctrl and Alt labels, Windows Wi-Fi page. macOS: screen capture, no glasses and no per-window capture yet, Cmd and Option labels, System Settings for Wi-Fi. Linux runs for testing with glasses and window capture off.
- Remote sessions are detected: a Windows remote desktop session (SESSIONNAME starts with RDP-) and an SSH session on a Mac (SSH_CONNECTION or SSH_TTY). The app cannot tell that a Mac is being viewed through Screen Sharing, so that case is not detected.
- On a Mac the glasses thread does not start, so the app never tries to download or load the Windows RayNeo SDK. The status says glasses need Windows.
- Shortcut labels in Settings and the help text follow the computer: Ctrl becomes Cmd and Alt becomes Option on a Mac. Qt already maps the keys, so the shortcuts themselves are unchanged.
- The Wi-Fi button opens System Settings on a Mac (x-apple.systempreferences:com.apple.wifi-settings-extension, the macOS 13 and later page).
- The start-up log (helper.log) records what was detected, including any remote session.
- run.command starts the app on a Mac (double-click it, or run ./run.command in Terminal). The same requirements.txt works on both systems.
- Mac notes: the first capture asks for Screen Recording permission (System Settings, Privacy and Security). Run the app in a desktop session, for example over Screen Sharing; a plain SSH login has no display for the app.
- tools/test_platform.py: 30 checks on the detection rules, the shortcut labels and the start-up report, with fake inputs. Run with `python tools/test_platform.py`.
- Not verified on a Mac: the app has not been run on macOS, and the Wi-Fi page address has not been checked against a real Mac.

## Round 53 fix: the launchers install into their own environment
- run.command (Mac) and run.bat (Windows) now create a .venv folder next to the app and install the packages there. Homebrew's Python on macOS refuses system-wide installs ("externally-managed-environment"), so the old launcher stopped at that step.
- If pip reports that no version of PySide6 matches your Python, install Python 3.12 (brew install python@3.12), delete the .venv folder, and run the launcher again.
- Tested here: the Mac launcher creates the environment and reaches the install step. The install itself needs internet, which this sandbox does not have.
- Not verified on a Mac or on Windows.

## Round 53 fix 2: one Python launcher for Windows and Mac
- run.bat is removed. Windows blocks .bat files, so the app is started with run.py instead: `py run.py` (or `python run.py`) in a terminal in the app folder.
- run.py creates the .venv folder, installs requirements.txt into it, and runs spatial_desk.py. It works on both systems; the Windows and Mac interpreter paths were checked.
- run.command (Mac) just calls run.py.
- Tested here: both launchers create the environment and stop at the install step, as expected without internet. Not run on Windows or a Mac.

## Round 54: fixes from the first Windows run, window shape, and the taskbar
- Opening text: the title picture was drawn without the crop setting, so it sampled one empty pixel. It now draws the whole picture.
- Home screen: each card's outline is kept half a pixel inside its widget, so it is no longer cut at the edge. The home container grows past 432 px only when its content needs more room. Styling is unchanged.
- Scroll and keyboard: the code sends scroll up to "pull closer" and scroll down to "push away". Log lines now record each wheel event, each distance change, each window that receives keys, and any key that is not delivered (helper.log). Keys are still sent as window messages, which classic Windows apps accept but many modern apps ignore; a reliable fix needs the target window brought to the front briefly.
- Window shape: Settings, Display, Window shape (Match the app, Landscape 16:9, Widescreen 21:9, Portrait 9:16), applied to every window and to new ones. The T key still changes the focused window only. Arc is under Settings, Display, Arrangement.
- Taskbar: the real Windows taskbar is read from the screen under it. Its background is made transparent by colour, so only the icons and text show. It appears in 3D below the windows while you look down, and fades in as you look down. It is one shared strip, not one per window.
- tools/test_taskbar.py: checks for the background removal, the show-when-looking-down rule, and the shape labels. tools/test_sideways.py gained a stub for the new logging.
- Not verified on Windows: the opening text, the home outline, scroll, keys, the window shape page, and the taskbar all need a run on your PC.

## Round 55: clickable taskbar, shape menu, and light animation
- Clicking the 3D taskbar clicks the real taskbar under that spot: the pointer moves there, a click is sent, and the pointer is put back. Clicks only work on Windows, and only while the taskbar is on screen (an auto-hiding taskbar cannot be clicked).
- The Sidebar button on each window's top bar now opens a small menu: Curved window (on or off), and the shape (Match the app, Landscape 16:9, Widescreen 21:9, Portrait 9:16) for that window. The icon is unchanged. The window list is still on the home screen's Windows card.
- Animation, kept light: the curve eases in and out over about a fifth of a second, the shape turns over in about a sixth of a second, and the taskbar rises and fades in as you look down.
- tools/test_taskbar.py: checks for the click mapping, the off-Windows no-op, and the flat-window curve. The flat check was confirmed to fail when removed.
- Not verified on Windows: the taskbar click, the menu, and the animations need a run on your PC.

## Round 56: the taskbar works with auto-hide, and clicks stay in Spatial Desk
- The taskbar no longer copies the real Windows taskbar. It lists the open app windows itself (including minimised ones, skipping tool windows and the desk), draws each app's icon in a row, and puts a small dot under the apps that are in the room. Auto-hide no longer matters, because the real taskbar is not read at all.
- Clicking an icon brings that app into the room: a window already there is focused (or shown again if minimised), and an app that is not there is added. The real app is never brought to the front, so you stay in Spatial Desk.
- Clicks in a room window always use the non-activating path, so the app does not come to the front. The pointer_click setting is no longer used for this.
- The old click on the real taskbar (click_screen_point) is removed.
- Limits: icons come from each program file, so an app running elevated (as administrator) may show a blank icon. Apps with several windows show one icon per window, the way the taskbar groups them only partly. Apps that use a shared host window (some Store apps) are listed under the host's title.
- tools/test_taskbar.py: checks for the icon layout, the click-to-icon mapping, adding or focusing an app (the no-duplicate rule was confirmed to fail when broken), and the off-Windows empty list.
- Not verified on Windows: the window listing, the icons, and the click-to-room behaviour need a run on your PC.

## Round 57: bug scan, and a remote-access kit (separate folder)
- tools/bug_scan.py reads the app's Python files without running them and reports code that can never run, duplicate definitions, undefined names, attributes read but never set, bare excepts and shared mutable defaults. It found no issues in the app's files. Its three early false positives (nested async functions, class-level constants and Qt signals) were fixed in the scanner, not in the app.
- tools/test_bug_scan.py plants one bug of each kind and checks each is caught.
- Limits: a static scan cannot find graphics, runtime or Windows-only bugs. Those still need a run on your PC.
- Remote access is a separate kit (RemoteAccess_home.zip): WireGuard for the tunnel, the Mac's built-in Screen Sharing for the screen. The generator and its tests are in that kit, not in the app. Frame rate: Screen Sharing is not built for 120 Hz at 1440p, and I have not measured it.

## Round 58: Air Neo inside Spatial Desk, and the dock changes for tunnel windows
- Air Neo is a feature inside Spatial Desk for a WireGuard tunnel between this computer and your Mac. It opens from the dock (shield button) and has three parts: an animated first-run setup, a passcode sign-in, and a tunnel panel with a status light and a Connect/Disconnect button. The whole app keeps the name Spatial Desk; say if you want that renamed too.
- First run: pick this computer (PC or Mac), make its own key pair (the private key never leaves it), paste the other computer's public key (and, on the PC, the Mac's address and port), set a passcode, and open the panel. Each step fades in, the progress ring fills while the keys are made, and the sign-in card shakes on a wrong passcode.
- Encryption is WireGuard's. Air Neo writes WireGuard configs and runs WireGuard's own tools (wireguard.exe on Windows, wg-quick on a Mac). The only crypto Air Neo runs itself is passcode hashing with the standard library's PBKDF2 (200,000 rounds).
- The passcode is a local lock, not an account. There is no server, so nothing is signed in to anywhere.
- The dock changes for tunnel windows: when the window you are using is WireGuard (matched by program file name), or the Air Neo panel is open, the dock shows tunnel controls. On Windows the program file of the focused window is read to decide; the Air Neo panel decides on any system.
- Limits: installing the Windows tunnel needs an administrator (a UAC prompt). On a Mac, wg-quick needs sudo, which the app cannot give itself, so starting the tunnel from the app is likely to fail there with a message; start it from Terminal instead. The saved private key is a file in airneo_data, protected by file permissions on macOS and Linux; on Windows those permissions do not restrict other users in the same way.
- tools/test_airneo.py: checks for saved state, the passcode (the right one passes, a wrong one fails, nothing is stored in clear), the per-device configs (each holds only its own private key), tunnel commands, and dock profiles. The passcode check and the dock rule were each confirmed to fail when broken.
- Not verified: the screens, the animation, the dock change, the Windows tunnel install and the Mac tunnel start have not been run.

## Round 59: Air Neo first-run crash fixed
- The Air Neo folder (airneo_data) was never created, so the first save failed on Windows with "No such file or directory" and the error repeated on every click. Saving and writing private files now create the folder first. Save and write errors appear as a message in the panel instead of failing silently.
- The RayNeo message "An Application Control policy has blocked this file" comes from Windows (Smart App Control, Windows Security, or a managed PC's policy), not from the app. The app falls back to mouse and keyboard, as designed.
- tools/test_airneo.py: checks that saving creates a missing folder and that private files are created with owner-only permissions where the system supports it.

## Round 60: 3D view crash fixed (curve flag name clash)
- The per-window curve toggle was stored under the key "flat", which the window layout already uses for each window's flat position (an array). The curve check then got an array, the 3D view failed, and the view was disabled. The toggle is now stored as "curve_off", and the layout keeps "flat".
- A test now passes a real layout position through the curve check, which would have caught this.
- The deprecated mss.mss() calls are now mss.MSS() (the Windows warnings).
- The Qt line "SetProcessDpiAwarenessContext() failed: Access is denied" is harmless: the app has already set DPI awareness at start-up, and Qt reports that its own attempt was refused.

## Round 61: cut-off pictures, responsive clicks, the window tuner, the intro title, first-run setup
- Cut-off pictures: the crop had the wrong direction, so a shape taller than the picture zoomed in and lost the top and bottom. A new fit_scale() keeps the whole picture in view. Where the shape does not match the picture, the empty space around it is transparent (the fragment shader drops pixels outside the picture). The picture is never zoomed in.
- Responsive clicks: the Win32 click (with its 30 ms wait) runs on a worker thread, so the desk no longer waits for it. Clicks still never move your real pointer.
- The top-bar button (the sidebar glyph, unchanged) opens a small card at the cursor, not a sidebar: Curved window on or off, the shape, and the size (smaller, bigger, reset). The card closes when you click away.
- Intro: the title is now Segoe UI Variable Display DemiBold, and its letters rise and fade in one after another. The subtitle (RAYNEO AIR 3S PRO) fades in last. The intro texture is redrawn as it plays.
- First run: Air Neo's setup opens by itself after the intro, until setup is done. The dock button still opens it at any time.
- Resolution: windows were already captured at their own size up to 2560 pixels wide (1440p-class), and nothing in that pipeline changed in this round. The gain in sharpness comes from no longer zooming in. The sharpness on your monitor depends on your display scale, and I can't measure it from here.
- tools/test_view.py: checks for the fit (including a case that fails when the old crop is put back), the letter timing, and the wiring of the clicks, the tuner button and the first-run setup. Nothing here has been run on Windows.

## Round 62: Spatial Desk accounts, the login, and Virtual Box
- Spatial Desk has a login. It is shown before the desk every time the app starts. The first time, you create an account: a name, a password (at least 8 characters, typed twice), and one of eight pre-made profile icons. After that you pick your account and enter its password. A wrong password shakes the card. The desk is made on the first sign-in, so the intro plays once per launch.
- The accounts are local. They are stored in accounts_data/accounts.json, which only this user can read on macOS and Linux. Passwords are stored only as PBKDF2 hashes (the same hashing Virtual Box uses). There is no online account, no server and no sync. Deleting that file resets the accounts, so this is a lock on the desk, not protection against someone with access to the folder.
- The eight profile icons are drawn in code (gradient discs with an emblem). None is a copied picture.
- Settings has an Account section: "Signed in as" and "Sign out", which returns to the login without losing anything.
- The tunnel feature is called Virtual Box everywhere you see it: the dock tooltip, the setup screens, and the tunnel-window detection. Its own passcode screens are gone, since the account now locks the app. Internal names (the airneo modules and the airneo_data folder) are unchanged, so existing setups keep working; renaming them can be done later with a migration.
- tools/test_accounts.py: 26 account checks, plus checks that no "Air Neo" is shown to you, that the login comes first, that Settings has sign-out, and that the login draws the same eight icons the accounts use. Breaking the password check was confirmed to fail the tests.
- tools/test_settings.py: the root page now has seven sections.
- Not verified on Windows: the login screen, its animation and the icons have not been run.

## Round 63: click and typing fixes, the intro title, window open and close, the Windows app, saved accounts
Round 63 covers two sessions. The first fixed the in-room issues below; the second, the Windows app and the accounts.

Room and windows
- The intro title was never drawn. Its texture was re-rendered only after the title phase had returned, so it stayed transparent. It is now re-rendered from the first frame, and it fades in quickly so each letter shows as it arrives.
- Typing sent each character twice: a key-down and a character, and Windows made a second character from the key-down. Ordinary text now sends one character per keystroke. Backspace, Tab and Enter send only a key-down, since Windows makes their character from it.
- Keys go to the control you last clicked, or to the focused control when it is inside the same window. A second window of the same program no longer receives keys meant for another.
- Clicks on a window whose picture does not match its shape were mapped to the whole shape, so they landed in the wrong place. They now land on the picture, and clicks on the empty margin pass to the window behind.
- Settings > "Click with the real pointer" was stored but never read. It now works: the window is raised without activating it, the click is sent, the pointer goes back, and Spatial Desk is brought to the front.
- The window card (the top bar button) was a popup, which closes when the app loses focus. It is now a tool window that floats above the desk and closes when you click outside it.
- Windows open with a fade and grow, and close with a fade and shrink. A closing window takes no clicks and no place in the layout, and is removed when its animation ends. Close-all no longer loops.

Windows app and saved accounts
- Accounts and settings are kept in a per-user folder: %LOCALAPPDATA%\Spatial Desk on Windows, ~/Library/Application Support/Spatial Desk on macOS, ~/.local/share/Spatial Desk elsewhere. They no longer depend on where the program is or how it was started. The old files beside the program are copied across once, and never overwritten.
- A damaged accounts file used to read as empty, and creating an account then overwrote it. It is now moved aside as accounts.json.damaged-<time> and the screen says so. If it cannot be moved, the app refuses to save over it.
- Saving accounts is atomic: the new file replaces the old one in one step, and the previous version is kept as accounts.json.bak.
- Saving settings now creates the data folder first, and writes via a temporary file.
- The picker's subtitle is kept up to date: after the first account exists it says "Who is using the desk?" rather than the first-run wording.
- The big "New account" tile is gone. "Add account" is a small button at the bottom of the account page. The first-run form is shown straight away when there are no accounts, with Back hidden.
- After the first account is created (Windows only, until installed), a step offers "Add Spatial Desk to Windows": a desktop shortcut and a Start menu entry, both ticked by default, with the app icon. Settings > Help > Desktop shortcut does the same later.
- The app icon is drawn in code (graphite tile, a glass window in front of a dimmer one) and packed into a real .ico with sizes 16 to 256. The taskbar shows this icon rather than Python's, through an explicit app user model ID.
- Shortcuts are made with WScript.Shell through PowerShell. Every value reaches PowerShell through environment variables and the script runs -EncodedCommand, so folders with spaces, quotes or non-ASCII letters cannot break it. The shortcut runs pythonw.exe on spatial_desk.py from the project folder.
- Bugs found while testing: the existing tests test_home and test_settings failed because the first-run Virtual Box sheet covers the page under test; the "Maximum windows" check picked the wrong spin box; both tests now isolate the first-run sheet, and test_settings exits non-zero on a failure.

Tests (all run with: xvfb-run -a -s "-screen 0 1920x1080x24" python3 tools/test_<name>.py)
- tools/test_input.py: 48 checks: one character per keystroke, control keys, key-up, the click mapping on letterboxed pictures, the window animation curve, and the intro reveal.
- tools/test_install.py: 36 checks: the .ico format (read back by Pillow), the shortcut plan, the PowerShell step and its safety, the install record, and the icon's pixels.
- tools/test_login_flow.py: 52 checks, driven with real clicks and typing against a scratch file: first account, relaunch, wrong and right passwords, adding a second account, mismatched passwords, Back, sign-out and sign-in again, the subtitle, a damaged file (kept, and read-only when it cannot be moved), a failed save, and the install step (accepted, failed, and skipped).
- tools/test_launch.py: 22 checks: the same accounts path from any folder, settings saved in one process and read in another, migration once and never overwriting, and a full launch through the app's entry point that reaches the desk signed in as the saved account. A negative control (the login pointed back at the old folder) makes the launch checks fail as the bug report describes.
- Existing suites run under the virtual display: test_accounts, test_airneo, test_bug_scan, test_buttons, test_curve, test_depth, test_home (32), test_platform, test_quick (12), test_settings (17), test_sideways, test_taskbar, test_view. All pass.

Not verified on Windows
- The shortcuts themselves: the .lnk files, their icon in Explorer, and the taskbar identity. These need a run on Windows.
- The Start menu and desktop locations on machines where they are redirected (OneDrive folders).
- The click behaviour and typing into browsers and Store apps (see Round 63 room notes).

Decisions to confirm
- Preferences are shared by all accounts. Per-account preferences would be a separate change.
- Virtual Box keys stay beside the program in airneo_data. Moving them is separate.
- Real clicks as the default (apps come forward briefly) is still a choice, not a default.

## Round 64: real clicks and real typing, and nothing posted
- Clicks on virtual windows are real clicks only. The posted-message path (PostMessage to the control under the spot) is gone, along with the Settings switch "Click with the real pointer", which chose between the two.
- A click runs as a plan (click_plan): raise the window above the room without activating it, send the click with the same input a mouse makes, wait a moment, put the pointer back, and raise the room again without activating it. The click itself makes the window active, so the keyboard types into it, the way it does on any screen.
- Typing is not forwarded any more. The keyboard goes to the active window directly, so text cannot be sent twice. A key that reaches the desk (you clicked the room) means the room has the keyboard, and the typing hint is cleared.
- The typing hint now says "click the room to come back" (Esc goes to the window, because the window has the keyboard).
- Removed: key_messages, send_key, click_window_message, key_target, bring_to_front, typed-character helpers and their Win32 bindings. The process-id binding stays, because other code still uses it.
- Trade-offs to know: a clicked window becomes the active window, so the desk's own shortcuts wait until you click the room again. The real pointer moves for a moment and goes back. Apps that need two clicks to activate (the usual Windows behaviour for a first click) will need the second click.
- Tests: tools/test_input.py now checks the click plan (35 checks); tools/test_view.py checks that the posted path, the key forwarding and the switch are gone. The full suite passes under Xvfb.
- Not verified on Windows: the real clicks and typing themselves. The check to run: click a window in the room, type, and confirm the text appears once; click the room and confirm the desk responds to keys; confirm the pointer returns to where it was.

## Round 65: click off a window, the white-dot cursor, camera passthrough with hand tracking
Click off
- A click on a rounded-off corner of a window falls through to whatever is behind it. Hit-testing uses the same rounded-rectangle rule as the shader (inside_rounded).
- A click on the empty room gives the keyboard back, unfocuses the window (no window stays focused), and activates the desk.

Cursor
- Over empty room the system pointer is hidden and the cursor is a white dot with a soft white aura (pointer_art.dot_image), drawn in the room.
- Over a window, with the mouse, the normal arrow shows. With a fingertip as the cursor, a thin ring shows that the finger is over a window.
- The scene remembers which cursor shape it last set, so it does not reset it on every mouse move.

Camera mode (Settings, Glasses page: "Camera passthrough and hands"; off by default)
- The camera picture fills the room behind the windows, cropped to fill the screen, never stretched, and mirrored as a mirror shows it.
- Hand tracking (MediaPipe Tasks, the hand model downloaded once into the data folder) runs on a worker thread. The index fingertip is the cursor.
- A pinch over a key of the virtual keyboard sends that key with real key input (SendInput, Unicode packets, one per character). A pinch anywhere else makes a real click on the room. Holding a pinch does not repeat the key; the next pinch does.
- The virtual keyboard is drawn in the lower middle of the view, where a desk usually is. This is an automatic placement, not detection of the desk's surface: the keyboard does not follow the desk in the picture. A calibration step (tap the four corners of the desk) would make it sit on the desk; that is the next step if you want it.
- Camera mode needs OpenCV and MediaPipe, which are optional: pip install -r requirements-camera.txt. Without them the app says so and runs as before. It stops when the app closes and starts again at launch if it was on.
- The picture, the keyboard and the cursor are drawn with the panel shader (sprites), so there is no new GL code. Overlays are drawn after the windows, and only after the intro.

Tests (all under Xvfb: xvfb-run -a -s "-screen 0 1920x1080x24" python3 tools/test_<name>.py)
- tools/test_camera.py: 37 checks: screen mapping (mirror and cover), the picture's visible part, the pinch and its thresholds, the keyboard (40 keys, no overlaps, key text, Shift and Back and Enter), key events (one down and one up per character; surrogate pairs), a missing camera and a missing model fail with a clear message, and the MediaPipe Tasks setup is reached (a non-model file fails inside the model loader, not on a wrong name).
- tools/test_pointer.py: 25 checks that read real pixels from the rendered desk: the dot's aura, the ring, the keyboard's hovered key, the camera picture covering the room, the keyboard drawn in the room, and the click-off (focus and keyboard given back).
- tools/test_hands.py: 17 end-to-end checks with a fake camera and a fake hand tracker: the worker thread, the cursor following the fingertip, a pinch on a key pressing it once, a pinch in the room clicking it, camera mode off stopping the worker, and a missing library refused with what to install.
- tools/test_input.py now has 41 checks (the rounded corners are included); tools/test_view.py checks the wiring.
- Bugs found by these tests and fixed: the cursor's textures were reset to None because the default state was inserted inside initializeGL (moved to the scene's constructor); the first version of the keyboard check sampled key centres, where the labels are.

Not verified here (needs a PC with a webcam)
- A real webcam opening (CAP_DSHOW on Windows) and real hand detection. The model's download address (MODEL_URL in hand_tracking.py) could not be checked from this machine; if the download fails, the message says where to place hand_landmarker.task by hand.
- The real click and the real key presses on Windows (SendInput). The end-to-end test replaces the room click with a recorder for this reason.
- Whether the picture is mirrored the way you expect, and how the keyboard's size and place look in your room.

## Round 66: cursor, top status line, 12-hour clock, taskbar height, Virtual Box look, SDK load check
Cursor
- The cursor dot is 22 px across on screen (texture 64 px), a solid white core with a thin dark rim. It was drawn at 128 px with a large glow, which looked wrong.
- The system cursor stays hidden in the room, and the dot is the cursor everywhere, over windows too. The arrow used to switch on and off at window edges, which made the cursor flicker. Only a fingertip over a window (camera mode) shows the ring.
- tools/test_pointer.py checks the new dot and ring pixels (needs PySide6; not run here).

Top status line and clock
- The line at the top (time, glasses state, mode) is hidden. Its labels stay in the code because the home PC card reads one of them.
- Every clock shows 12-hour time (8:33 PM), through clock_text(). The bottom clock slot is wider to fit it.
- tools/test_clock.py checks the times, including midnight, noon and 8:33 PM.

Taskbar
- Moved up: sits about 19.5 degrees below your eye (was about 22). It starts to fade in at about 10 degrees and is fully shown by about 17.5 degrees, so a smaller look-down is enough.
- tools/test_taskbar.py checks the new angle and range.

Virtual Box screens
- A header with a mark, a step bar on the setup pages ("Step 2 of 4 · Keys"), icons drawn in code, and a clearer welcome page with three feature rows.
- The welcome text no longer says "Nothing leaves your home network": traffic can cross the internet when a public address or a DDNS name is used.
- Setup logic is unchanged. Not rendered here (PySide6 not installed in the build environment); please check the look on the PC.

Windows: the RayNeo SDK DLL
- The error dialog ("... is either not designed to run on Windows or it contains an error") appears when Windows is asked to load a file that is not a valid DLL for this computer. The reading is that a bad or wrong-architecture RayNeoSDK.dll is loaded when the app starts, and the screen behind it is the sign-in page. This is not confirmed: the full error text and the shortcut's Target were not available.
- New tools/pe_check.py reads the DLL header first. A 32-bit DLL in 64-bit Python, a Mac library saved as .dll, an HTML page saved as .dll, or a truncated file is refused with a reason, and Windows is not asked to load it.
- find_library() skips such a file, so the next start downloads a fresh copy. The download only saves DLLs that pass the check.
- tools/test_pe_check.py: 22 checks, including the lookup, the loader message and a fake download. With the checker disabled, 14 of them fail.

Tests (Qt-free, all pass): test_taskbar 42, test_view 61, test_input 41, test_sideways 34, test_curve 12, test_depth 16, test_airneo 49, test_accounts 35, test_platform 29, test_bug_scan 8, test_camera 37, test_pe_check 22, test_clock 9. bug_scan: 0 findings in 13 files.
Qt tests not run here (need PySide6): test_pointer (pixel values updated by hand), test_home, test_buttons, test_settings, test_quick, test_login_flow, test_launch, test_install, test_hands.

## Round 67: window shapes no longer stretch, and picture edges are soft
Stretching (the main fault)
- fit_scale() returned its two values in the wrong order. A window whose shape did not match its app (Landscape, Widescreen or Portrait on an app of another shape) squashed or stretched the picture, and cut off its top and bottom. "Match the app" was not affected, so it looked fine. Measured before the fix: a 0.9-proportion app in a 16:9 window showed at 0.35 (about 40% of its proportions); a 16:9 app in a portrait window showed at 5.6.
- Now the picture always keeps its own proportions: the limiting side fills the shape, and the other side is letterboxed with transparent space. Nothing is cut off. The same crop is used for curved windows, so curved windows are fixed too.
- The existing tests only checked that one side fills, which is why this got through. tools/test_view.py now checks the shown proportions for 42 shape combinations (max error about 1e-16), and two specific cases from the bug.
- The click mapping uses the same crop, so clicks stay on the picture.

Soft edges
- The window shader used to drop pixels outside the picture with a hard cut, which left jagged edges on letterboxed or cropped pictures. It now softens the picture's edge over one pixel. Edge pixels of a picture that matches the shape stay fully opaque.
- Not compiled here: there is no GL context or GLSL compiler in the build environment. Check the window's shader compiles on the PC (the 3D view falls back to a flat message if it does not).

Curve
- The curve maps the picture along its arc length, so the picture is not stretched along the curve. Its 32 vertex columns keep the error under about 0.4 mm at the default curve.

Not changed (and why)
- A non-matching shape shows a smaller picture inside the frame, because the frame size is fixed. That keeps everything visible and undistorted, but the picture is smaller than in "Match the app", so it can look less sharp. Making the frame grow to keep the picture at full size would fix that, but it changes the window layout; it is a separate change.
- Sharpness on the glasses is limited by their display resolution. The capture is at the window's native size (up to 2560 px wide) with mipmaps and 8x anisotropic filtering, which I did not change.

Tests (Qt-free, all pass): test_view 65, test_input 41, test_taskbar 42, test_sideways 34, test_curve 12, test_depth 16, test_airneo 49, test_accounts 35, test_platform 29, test_bug_scan 8, test_camera 37, test_pe_check 22, test_clock 9. bug_scan: 0 findings.

## Round 68: two cursors, clicks without the drag, windows kept inside the view
Cursor
- Outside the windows: the room's own dot, a small solid core (about 9 px) with a soft glow. Its full size on screen is 30 px.
- Over a window (mouse): the system arrow, so the cursor is the real one where a click lands. The room's dot is hidden there.
- The state is checked every frame, and it holds for 0.15 s after the pointer leaves a window, so the cursor does not flicker on an edge.
- Camera mode (fingertip): the dot stays, and a ring marks a window under the fingertip.

Clicks
- The cause of the drag: a real click moves the real pointer onto the real window to click it. The system cursor was visible during that move (about 80 ms), so it looked as if it was dragged away from the virtual window.
- Now the system cursor is hidden for the whole click (ShowCursor, balanced in a finally block), and the pointer returns to where it was. The click order is unchanged (tests/test_input checks it).
- NOT verified on Windows: whether every app accepts the click. If one does not respond, check helper.log.

Windows filling the screen
- The flat row was fitted to the view's width only, and the height of a window follows its shape. A Portrait window, or a tall or square app, ran past the top and bottom of the view. That is why it filled the screen until 3D mode, where the windows sit further back.
- Now a window's width is also limited so its frame stays inside 82% of the visible height at its distance (VIEW_FILL). Landscape windows at the default size are unchanged. Tall windows are narrower.
- With the frame no longer stretched past the screen, the picture is drawn at a larger on-screen share of pixels per texel. This is the likely cause of the "worse" resolution on tall windows, but it has not been measured.

Tests (Qt-free, all pass): test_view 67, test_sideways 39 (3 new height checks), test_input 41, test_taskbar 42, test_curve 12, test_depth 16, test_airneo 49, test_accounts 35, test_platform 29, test_bug_scan 8, test_camera 37, test_pe_check 22, test_clock 9. bug_scan: 0 findings.
Qt tests not run here (need PySide6): test_pointer (dot pixel values updated by hand for the new dot).

## Round 69: Virtual Box border, thinner type, and installing WireGuard automatically
Border
- The Virtual Box card was drawn inside the sheet, and the sheet had its own frame (a 1px border and rounded corners) with margins. That was the big border that followed the card. While Virtual Box is open the sheet is now bare (no frame, no margins); every other sheet gets its frame back, including when Virtual Box closes.

Text
- Every weight in Virtual Box's style sheet is lighter: titles and the large status 300 (Light), headings, labels and buttons 400 (Regular). No 600 weights are left in it.

Installing WireGuard (Virtual Box runs on it)
- Virtual Box checks for WireGuard when it opens. If it is missing, the install starts in the background, and progress shows under the header.
- Windows: the newest official installer is taken from download.wireguard.com (the index lists every release; the newest for this computer's processor is picked). The file must be at least a few MB, and its digital signature must be valid and signed by WireGuard LLC before it runs. It is then installed silently (DO_NOT_LAUNCH=1 /qn) with administrator permission: Windows shows its own prompt, and if you click No, nothing is installed.
- Mac: wireguard-tools is installed with Homebrew, if Homebrew is present. Homebrew is not installed automatically.
- Setup's keys step and the Connect button wait for the install instead of stopping with a message. If it fails, the reason is shown and the step can be retried.
- The dock's tunnel button also starts the install when WireGuard is missing.
- The tunnel command uses WireGuard's full path (C:\Program Files\WireGuard\wireguard.exe) when it is installed, so it works without a restart.
- The install starts when Virtual Box is opened, not at app start. Starting it at app start would show a permission prompt on every launch on a computer that never uses Virtual Box.
- NOT verified here (no network, no Windows): the download, the signature check, the UAC prompt and the install itself.

Tests (Qt-free, all pass): test_wg_install 29 (new: installer choice, signature gate, download and install results, Homebrew path, single-run guard), test_view 73, test_airneo 49, test_sideways 39, test_input 41, test_taskbar 42, test_curve 12, test_depth 16, test_camera 37, test_pe_check 22, test_clock 9, test_accounts 35, test_platform 29, test_bug_scan 8. bug_scan: 0 findings in 14 files.
Qt tests not run here (need PySide6): the Virtual Box screens and the sheet frame.

## Round 71: window glitch, clicks that check first, black window card
Glitch: a window that took the whole view
- Cause: a window's height is its width times its shape. When the real app changed shape (for example, turned tall), the capture's aspect changed, but the width was only fitted again on the next relayout, which happens on a mode switch. The height ran off the screen until 3D mode. This is now fixed at draw time: a window is never taller than the view allows (_fit_width), and a change of shape re-fits the layout before the next frame (_layout_dirty), not inside the paint.
- The setup row is also always fitted (_fit_row): the gap shrinks before the windows do. Before, a row that was already too wide was left alone. This is a guard for rare cases (many windows with the first one pulled close); it is not the cause of the glitch above.

Clicks on virtual windows
- Before each click, the target must be the top window at the click spot (WindowFromPoint). If something else is on top, the target is raised again, up to three times. If it still is not on top, the click is not sent, so it cannot land on the room or on another window.
- A minimised window is reported instead of clicked.
- If Windows refuses the click (SendInput returns 0), the reason is reported. This is what happens when the program runs as administrator.
- Each case shows a message in the room (CLICK_MESSAGES) and is written to helper.log, so a click that does not work says why.
- Not verified on Windows: whether the click now reaches every app. The log line says which case happened.

Window card (the top-bar sidebar button)
- It is painted solid black with rounded corners in paintEvent. The old card set its background only in the style sheet, and the margins came out transparent (alpha 0 when rendered), so it showed whatever was behind it.
- Text is Light (weight 300) throughout.

Tests (Qt-free, all pass): test_sideways (new: row fit, close first window, very tall window, layout re-fit wiring), test_view (click wiring checks updated), test_input, test_taskbar, test_curve, test_airneo, test_wg_install, test_accounts, test_platform, test_bug_scan.
Qt tests run headless (QT_QPA_PLATFORM=offscreen): the same results as before; test_pointer fails the same way it did before. The card render was checked by reading its pixels: black, fully opaque.
Not verified on Windows: the click behaviour, the glitch fix in the 3D view, and the card on your display.

Shortcuts on every start (Windows)
- APP_VERSION (app_install.py) is "71". Bump it each round.
- On every start, in the background, the desktop and Start menu shortcuts are checked. They are made again when one is missing, when the record is from another version (including round 69's), when the app's folder changed, or when the Python changed. Nothing is made if the app was never installed: the install offer still asks for that.
- The record (windows_app.json) now keeps the version, the app's folder, the Python and the places the shortcuts are in. Records from before this round are read with places_from_paths().
- Tests: test_install.py checks each case (current, deleted, older version, moved folder, changed Python, never installed, old record).
- Not verified on Windows: that PowerShell makes the shortcuts again on your PC, and that Windows shows them.

Cursor during a click: not changed in this round. Real clicks move the real pointer to the real app, which is raised above the room for a moment, so the pointer appears outside the virtual window. Changing that needs a choice (see the round notes in the reply).

## Round 72: the dot everywhere, the real pointer in the window you focus
- APP_VERSION is "72" (the shortcuts are checked once on this version).
- The room's dot was drawn inside the 3D view, so the 2D screens (home icons, Virtual Box, the dock) covered it. The dot is now also drawn by PointerDot, a layer above the 2D screens that takes no mouse input. It follows the real mouse wherever it is over a 2D screen (_pointer_tick, every 30 ms), and hides over a virtual window, where the real arrow shows.
- Over the 2D screens the system cursor is blanked with an override cursor while the dot is shown, and restored when the pointer goes back to the 3D view or leaves the app. This keeps one cursor, not two.
- When a window is focused by a click, the real pointer rests in the middle of that window as it appears in the room (_window_centre_global, using _screen_of, the inverse of pick()), not at the click spot. Windows that were already focused keep the old behaviour (the pointer returns to where it was).
- The room coordinates are converted to physical pixels for SetCursorPos (devicePixelRatioF).
- Tests: test_sideways checks that _screen_of undoes pick()'s mapping (within a pixel) and that points behind the camera are refused; test_view checks the wiring; the dot was rendered offscreen and its pixels checked (white core, glow, dark background).
- Not changed: the real click still moves the real pointer to the real app while the click is sent, and the real app is raised above the room for that moment.
- Not verified on Windows: the override cursor over the home screen and Virtual Box, and whether the rest point is in the expected place on your display (including scaling).

## Round 73: clicks for more apps (real input, done more carefully)
Why not every app works yet: a click is real input, so it has to reach the real program. That needs the program's window to be on top at the spot, and the pointer to move there. Two cases cannot be clicked from a normal program at all: a program running as administrator (Windows blocks input from a lower-privilege program; see "blocked" in CLICK_MESSAGES), and a program with its own input layer (some games). Running Spatial Desk as administrator lets it click administrator programs; that is a choice to make, not done here.

What changed
- Activation: before a click, the clicked window is made the foreground window (_activate, with AttachThreadInput). Programs that ignore a click on an inactive window now get an active one. The room itself is never activated (checked in test_view).
- Hover: the pointer moves, waits 50 ms, then the button goes down and up with a 50 ms gap. Programs that show hover states or act on hover now see the pointer on the control first.
- Screen clicks (the desktop, and any screen-kind source): the room covers the screen, so the room is lowered behind the desktop for the click and raised again after. Before, a click on the desktop landed on the room.
- One click at a time: while a click is being sent, further room clicks are ignored. A click made by us can no longer start another.
- A click that raises an error is reported in the room and in helper.log, and the busy flag is always cleared.
- APP_VERSION is "73".

Tests: test_view (the room is never activated; the clicked window is activated before the click), test_input (click order unchanged), all other Qt-free and headless Qt tests as before. test_pointer fails the same way it did before.
Not verified on Windows: whether every ordinary program now accepts the click; the pointer still moves to the real program for the moment of the click.

## Round 74: clicks through three routes, as other Windows automation tools do it
Research (what others do)
- trycua/cua (Cua Driver, May 2026) routes each click: UI Automation invoke first, then PostMessage, then SendInput only when the caller allows it. Its PostMessage route is dropped by Chromium content; its SendInput route needs the foreground. The same article notes that UIA is the right tree API for most apps.
- bgautogui (PyPI) and winput (Go) use PostMessage for background clicks and say some apps ignore posted messages.
- The C++ forum thread notes that SendMessage is more reliable than PostMessage for buttons (not used here: SendMessage waits for the target thread, which can hang the room).

What the app does now (window_clicks.py, spatial_desk.click_window_at)
1. "post": if a control is under the spot and it is a classic Win32 control (button, list, tab, etc.) and the window is not a browser: a mouse message is posted to that control. No pointer movement, no focus change, and it works while the room covers the window.
2. "uia": the top-most window is raised for the moment (not activated), a helper PowerShell process asks the control under the spot to act (InvokePattern, TogglePattern or SelectionItemPattern). Text fields are reported as "edit" and go to the real click. The room is raised back afterwards. No pointer movement.
3. "send": the real click, as before: the window is activated, the pointer moves there and back, and the room is raised again. Text fields always use this, because typing needs real focus.
- Desktop clicks: unchanged (the room is lowered behind the desktop for the click).
- The UI Automation helper stays running; it is stopped when the app exits. After three failures it is turned off, and clicks use the other routes.
- APP_VERSION is "74".

Tests
- tools/test_clicks.py: the route order for text fields, classic controls, browsers, WPF or WinUI windows, a click on the window itself, unknown controls; every route list ends with the real click; the helper script's rules; the off-Windows behaviour.
- test_pointer fails exactly as it did in round 69 (the 3D view does not draw headless here); the other tests pass.
Not verified on Windows: UIA invoke on real apps, the posted-message route on real controls, and the fallback timing. A click that does nothing now has three places to fail; the log (helper.log) records which route was tried.

## Round 75: faster clicks
Where the time went (counted from the code; not measured on Windows)
- Real click (before): 40 ms activation wait, 15 ms after each of the three input events (45 ms), and an 80 ms pause before the pointer went back. About 165 ms of fixed waiting.
- Posted click (before): 40 ms after the pointer move, 50 ms after the press. About 90 ms.
- Accessibility click (before): 40 ms wait after raising the window, and PowerShell started on the first click (one to two seconds).

What changed
- Real click: 8 ms after the pointer move, 12 ms after the press, a 20 ms pause before the pointer goes back (the position is carried in each input event; the pause is kept as a margin). About 40 ms.
- Activation: waits only until Windows reports the window in front (checked every 4 ms, at most 100 ms). Usually a few ms.
- Posted click: 5 ms after the move, 12 ms after the press. About 17 ms.
- Accessibility click: checks every 4 ms, at most 80 ms, that the window is on top.
- The top-window check retries every 10 ms (was 40 ms).
- The accessibility helper starts when the app starts (UIA.warm), so the first click does not wait for PowerShell.
- The room's dot follows the mouse every 10 ms (was 30 ms).
- Screen clicks: 20 ms wait removed.
- APP_VERSION is "75".

Tests: test_clicks checks there is no fixed wait of 40 ms or more on the click path, the step waits, the warm-up and the dot timer. test_input now expects the 20 ms pause. The wait helper was checked directly: it returns at once when the condition is already true, and stops at its limit when it never is.
Not verified on Windows: the actual times. The estimates above come from the code; a timing check on your PC would show the real numbers.

## Round 76: bug hunt
Method: pyflakes over every module (only unused imports and one redefinition; none is a runtime error), the project's bug scanner (0 findings), review of the code added in rounds 71 to 75, a check that worker threads never touch widgets (they only emit signals or write logs), and a check that every test file reports its failures (see the last item below). Each bug below was first reproduced by a test that failed on the previous code.

Confirmed bugs, fixed
1. The accessibility helper answered "error" for a single request it could not finish. That was treated as a broken helper: it was killed and started again, and three such answers in a session switched accessibility off until the app was restarted. Now "error" is one failed request; the helper is kept.
2. A helper stopped by the watchdog during a request cleared the process reference, and the next line of the request then raised an error that was not caught. The request now keeps its own process reference, so a stopped helper gives "error", not a crash.
3. Text the helper printed by mistake (start-up noise, for example) was read as its answer, which started it again. The helper now says "ready" when it can take requests, start-up text is skipped, and replies that are not answer words are skipped (up to five lines).
4. A click on a button inside a group box landed on the group box. The control lookup returned only the direct child. It now goes down to the deepest control, which is the one a real click would reach.
5. The dot and blank cursor applied over the tuner card and other popups, because they are separate windows. The pointer disappeared over them. The 2D-screen cursor now applies only to this window's own screens.
6. If the click thread could not start, the room ignored every later click until restart. The busy flag is reset in that case.
7. The shortcut check recorded every line PowerShell printed as a shortcut path. A stray line would have been reported as a missing shortcut on every start, and the shortcuts would have been made again on every start. Only lines that are shortcut paths are recorded now.
8. The accessibility helper's start-up limit was the same 6 seconds as one request. Starting it compiles a little C# on the first run, which can be slow on some PCs. Start-up now has 15 seconds.
9. Test hygiene: in test_view (the round 72 checks) and test_install (the round 76 checks), checks were placed after the summary, so they were never counted. Moved the summaries to the end. The view checks that were not counted all pass.

Checked and found fine
- Shortcut paths are passed to PowerShell in environment variables, so an apostrophe in a user name does not break the script.
- Worker threads only emit signals or write logs. The icon drawing uses no text, so it can run before the application object exists.

Still open
- test_pointer fails headless because the 3D view does not draw without a display. It fails the same way on the round 69 code.
- The unused imports pyflakes reports are harmless and are left for a tidy-up pass.
- Everything Windows-specific is unverified: the helper's replies on a real PC, the posted messages, and the cursor over the tuner card.
- APP_VERSION is "76".

## Round 70: Mac app with Virtual Box
Packaging
- build_mac_app.sh builds "Spatial Desk.app" with PyInstaller (spatial_desk_mac.spec), draws the icon (make_icon.py, into .icns with iconutil), signs it ad hoc, and makes dist/SpatialDesk-mac.zip. See README_MAC.md.
- mac_entry.py is the bundle's entry point. It puts Homebrew's folders on PATH first, because an app started from Finder does not get them.
- The bundle's Info.plist carries the Screen Recording and Camera usage text.

Virtual Box on a Mac
- wg-quick needs an administrator. tunnel_command("macos") now runs it through osascript with "with administrator privileges", so macOS shows its own password box. Closing that box is reported as "the administrator password was not given".
- find_wg() also checks /opt/homebrew/bin, /usr/local/bin and MacPorts' /opt/local/bin. The Mac command's PATH and mac_entry.py's PATH include the same folders.
- The Mac install now also installs wireguard-go, which wg-quick uses on macOS.

Where files go
- When frozen (bundled), Virtual Box's files (airneo_data) and the depth model go to ~/Library/Application Support/Spatial Desk/, not into the app bundle. Running from source is unchanged.

Tests (Qt-free, all pass): test_airneo (new checks: Mac command, quoting round trip, cancelled prompt), test_wg_install, test_accounts, test_platform, test_view, test_sideways, test_input, test_taskbar, test_curve, test_depth, test_camera, test_pe_check, test_clock, test_bug_scan. bug_scan: 0 findings.
Qt tests run headless (QT_QPA_PLATFORM=offscreen): test_hands, test_launch, test_login_flow, test_settings, test_quick, test_home, test_buttons pass. test_pointer fails the same way before and after this round.
NOT verified (no Mac here): the PyInstaller build, the signed bundle, the Screen Recording prompt, the osascript password box, and wg-quick itself.

## Round 77: Virtual Box, and the Mac build in the same package
This package now has the Mac changes from round 70 (the Mac build files, the Mac tunnel through the administrator box, and the Mac paths) as well as the Windows changes from rounds 71 to 76.

Why Virtual Box kept failing (found in the code, then reproduced)
1. Windows: starting and stopping the tunnel ran WireGuard's tunnel command without administrator rights, so the tunnel service was never installed. The screen showed only the last line of the output, which did not say why. Now the command runs through Windows' own prompt (ShellExecuteEx "runas"), and a declined prompt says so.
2. "Connected" was shown as soon as the command succeeded, even when the other computer never answered. Now, after Connect, the other computer is pinged through the tunnel. Connected means it answers. Until then the panel says "Waiting for your Mac" (or PC), explains what to check, and keeps checking every 15 seconds.
3. Every time setup ran, new keys were made and the old private key was overwritten. The other computer kept the old public key, so the two never matched. Now an existing key is kept, and the public key is worked out from it.
4. Pasting this computer's own public key, or its private key, into the other computer's field was accepted. Both are refused now, with the reason.
5. Reset while connected left the tunnel running with the old keys. Reset now asks you to disconnect first.
6. A failed start left the tunnel marked as connected. A failed start now marks it as off.
7. The start command did not remove an old tunnel of the same name first, so an old config could keep running. The Windows start now removes it first, in the same administrator run.
8. The Mac's firewall step was missing from the instructions. The done page and the waiting message now say to allow incoming connections for wireguard-go, and the PC's address step explains the Mac's local address and port forwarding.
9. The background commands (ping, sc, wg) could open console windows in front of the app. They are started without one now.

Checks
- tools/test_airneo.py: the key checks, the ping reading (English and any language, through TTL=), the waiting loop, the Windows start with a declined prompt, an error code, a service that did not start, and the stop; the macOS start and a cancelled administrator box.
- tools/test_airneo_panel.py (headless): keys are kept, own keys are refused, Reset is refused while connected, waiting and connected states, a failed start, and reopening with the tunnel on.
- tools/test_tunnel_live.py: a real WireGuard connection between two network namespaces, with the configs the app writes and the app's own peer check. Correct keys connect both ways. A wrong key does not connect, and neither does a key made again on one side only. This test runs only where Linux, root and wireguard-go are present, and skips elsewhere.
- Not verified on Windows: the administrator prompt itself, the sc output on your PC, and WireGuard's command-line behaviour there. Not verified on a Mac: the administrator box and wg-quick on a real Mac.
- APP_VERSION is "77".

## Round 78: change the other computer's key without a full reset
- Virtual Box's main page has a Change key button, next to Reset. It opens the key page, which shows this computer's public key (to give to the other computer) and asks for the other computer's new key, with its address on the PC.
- Saving rewrites the tunnel config with the new key. If the tunnel is on, it is restarted with the new config in the same action: on Windows, the old tunnel service is removed and the new one installed in one administrator run; on a Mac, the old tunnel is taken down and the new one brought up in one password-box run. The key page then returns to the main page and says whether it is connected.
- While the restart runs, Change key and Reset are unavailable. A failed restart means the tunnel is not up, and says why.
- The key page shows this computer's public key, so it can be copied to the other computer.
- core: the 'restart' action (TUNNEL_ACTIONS, TUNNEL_ON_ACTIONS); mac_shell() builds the macOS shell line, shared by the password-box command and the tests.
- Tests: test_airneo (the restart commands, one administrator run on a Mac, the Windows replacement, unknown actions refused); test_airneo_panel (the whole key change, the tunnel off and on, a failed restart); test_tunnel_live (a restart on a real WireGuard interface picks up the new key, and the Mac answers).
- APP_VERSION is "78".
- Not verified on Windows or on a Mac, as in round 77.


## Round 79: the window card is part of the desk
Symptoms reported
- The top-bar card (Curved window, Shape, Size) did not appear when its button was clicked. It showed only after the desk lost focus (Windows key).
- After the app was closed, the card stayed on top of the screen. Clicks made the screen flash and did nothing on virtual windows.

Cause
- The card was a separate top-level window (Tool, frameless, translucent, stays on top), with the desk as its parent. Windows gave it its own layer, and it was not painted until the desk lost focus.
- It was not hidden when the desk closed, so it outlived the desk window.
- Its click-away filter was installed on the whole application.
- Likely, though not verified here: a window that was never painted still takes mouse input, so presses over the room landed on the card. That would explain the clicks that did nothing, and the flash when the card closed.

Fix
- The card is a child widget of the desk, placed in the desk's own 2D layer, like the Virtual Box sheet and the toast. It appears at once, is drawn with the desk, and is removed with it. It is no longer a window of its own, and it has no application-wide filter.
- A press in the desk outside the card closes it. Presses in other windows do not count.
- The card closes when its window closes, when the mode changes (Space), and on shutdown.
- Size and Reset now act on the window the card was opened for. They used to hold a list index, which moves when a window closes, so the card could resize a different window.
- The card is kept inside the desk by card_origin() in tuner_ui.py, a function that needs no Qt.
- The card now inherits the desk's stylesheet. Its own rules use object names, which take precedence over the generic QWidget, QLabel and QPushButton rules, so the look should not change. Checked by reading the rules, not on screen.
- APP_VERSION is "79".

Tests
- tools/test_tuner.py: 24 checks. The placement grid, the structure of the card and the desk, and every path that must close the card. Three deliberately broken copies each fail it (card not parented, close missing from close_panel, size button by index).
- tools/test_view.py and tools/test_clicks.py: the checks that described the old separate window now describe the child card.
- Qt-free suites pass, as before. The Qt suites need PySide6, which is not installed in the build sandbox, so they fail the same way on the round 78 code.
- bug_scan: 0 findings in 14 files.

Not verified on Windows or in the running app
- Check on the PC: click the top-bar button on a window; the card should appear at once. Click outside it; it should close. Close the app (Alt+F4); nothing should be left on screen. Curved, Shape and Size should change that window.
