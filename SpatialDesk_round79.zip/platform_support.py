"""Works out which computer the app is running on, and picks the matching behaviour.

Windows: window capture, RayNeo glasses, Windows Wi-Fi settings, Ctrl and Alt shortcut labels.
macOS:   screen capture (macOS asks for Screen Recording permission the first time), no glasses and no
         per-window capture yet, Cmd and Option labels, and System Settings for Wi-Fi. Use it for testing,
         and for working on the Mac over a remote desktop.
Linux:   runs for testing; glasses and window capture are off.

Detection reads only the operating system name and a few environment variables, so it can be tested with fake inputs.
"""
import os
import platform
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Profile:
    os: str               # "windows", "macos", "linux" or "other"
    name: str             # the name shown to you, e.g. "macOS"
    glasses: bool         # RayNeo glasses tracking can run here
    window_capture: bool  # individual app windows can be captured (not only whole screens)
    mod_label: str        # the key used with scroll: Ctrl on Windows, Cmd on a Mac
    alt_label: str        # Alt on Windows, Option on a Mac
    wifi_url: str         # what the Wi-Fi button opens, or "" when there is nothing to open
    ui_fonts: tuple       # font families to try, in order
    remote: str           # "" when local, otherwise how the session is remote: "RDP" or "SSH"


def detect(system=None, env=None):
    """The profile for this computer. Pass system ("Windows", "Darwin", "Linux") and env to test other cases."""
    system = platform.system() if system is None else system
    env = os.environ if env is None else env
    if system == "Windows":
        remote = "RDP" if str(env.get("SESSIONNAME", "")).upper().startswith("RDP-") else ""
        return Profile("windows", "Windows", True, True, "Ctrl", "Alt", "ms-settings:network-wifi",
                       ("Segoe UI Variable Text", "Segoe UI"), remote)
    if system == "Darwin":
        remote = "SSH" if (env.get("SSH_CONNECTION") or env.get("SSH_TTY")) else ""
        return Profile("macos", "macOS", False, False, "Cmd", "Option",
                       "x-apple.systempreferences:com.apple.wifi-settings-extension",
                       ("SF Pro Text", "Helvetica Neue"), remote)
    if system == "Linux":
        return Profile("linux", "Linux", False, False, "Ctrl", "Alt", "", ("DejaVu Sans", "Arial"), "")
    return Profile("other", str(system or "unknown"), False, False, "Ctrl", "Alt", "", ("Arial",), "")


def shortcut_label(text, profile):
    """Writes a shortcut for this computer: 'Ctrl + scroll' becomes 'Cmd + scroll' on a Mac."""
    text = re.sub(r"\bCtrl\b", profile.mod_label, text)
    return re.sub(r"\bAlt\b", profile.alt_label, text)


def startup_report(profile):
    """A few lines for the log, so a remote check shows what the app decided."""
    lines = [f"Platform: {profile.name}",
             "Glasses tracking: " + ("on" if profile.glasses else f"off ({profile.name} has no RayNeo support here)"),
             "Window capture: " + ("on" if profile.window_capture else "screens only"),
             f"Shortcuts are labelled with {profile.mod_label} and {profile.alt_label}"]
    if profile.remote:
        lines.append(f"Remote session detected ({profile.remote}); drawing may be slower than on the computer itself")
    return "\n".join(lines)
