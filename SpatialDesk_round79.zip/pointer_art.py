"""The pictures the desk draws on top of the room: the cursor dot, the ring that shows a fingertip is over a window,
and the virtual keyboard. Each is an image with transparent edges, drawn as a sprite.
"""
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QImage, QPainter, QPen, QRadialGradient

from hand_tracking import keyboard_keys

DOT_TEX = 64                   # the texture the dot and ring are drawn in, in pixels (sharp when shown small)
DOT_PX = 30                    # the dot's full size on screen, in logical pixels: a small core and a soft glow


def _blank(size):
    img = QImage(size, size, QImage.Format.Format_RGBA8888)
    img.fill(Qt.GlobalColor.transparent)
    return img


def image_bytes(img):
    """The pixels of an image as RGBA bytes, ready for a texture."""
    img = img.convertToFormat(QImage.Format.Format_RGBA8888)
    return bytes(img.constBits())[: img.sizeInBytes()]


def dot_image(size=DOT_TEX):
    """The cursor dot, for outside the windows: a small solid white core (about 9 px across on screen) with a little
    soft glow round it that fades out. The stops are fractions of the radius, and the glow ends at the picture's edge.
    """
    img = _blank(size)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    radius = size / 2.0
    c = QPointF(radius, radius)
    grad = QRadialGradient(c, radius)
    grad.setColorAt(0.0, QColor(255, 255, 255, 255))
    grad.setColorAt(0.30, QColor(255, 255, 255, 255))     # solid core
    grad.setColorAt(0.36, QColor(255, 255, 255, 150))     # the glow starts bright...
    grad.setColorAt(0.55, QColor(255, 255, 255, 55))
    grad.setColorAt(0.80, QColor(255, 255, 255, 14))
    grad.setColorAt(1.0, QColor(255, 255, 255, 0))        # ...and fades to nothing
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(grad))
    p.drawEllipse(c, radius, radius)
    p.end()
    return img


def ring_image(size=DOT_TEX):
    """The ring shown while a fingertip is over a window: a thin white ring with a faint dark edge, so it reads on
    both dark and light pictures. Its line is about 2 px on screen."""
    img = _blank(size)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    c = QPointF(size / 2.0, size / 2.0)
    r = 0.78 * size / 2.0
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(QPen(QColor(0, 0, 0, 70), 0.14 * size))
    p.drawEllipse(c, r, r)
    p.setPen(QPen(QColor(255, 255, 255, 240), 0.086 * size))
    p.drawEllipse(c, r, r)
    p.end()
    return img


def keyboard_image(width, height, hover=None, pressed=None, scale=1.0):
    """The virtual keyboard, width x height in logical units (drawn at scale for sharp keys). The hovered key is
    lighter; a pressed key takes the accent colour for a moment."""
    img = QImage(max(1, int(width * scale)), max(1, int(height * scale)), QImage.Format.Format_RGBA8888)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.scale(scale, scale)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(12, 14, 20, 150))
    p.drawRoundedRect(QRectF(0, 0, width, height), 0.035 * width, 0.035 * width)
    row_h = height / 5.0
    for label, x0, y0, x1, y1 in keyboard_keys(width, height):
        if label == pressed:
            fill = QColor(110, 190, 255, 210)
        elif label == hover:
            fill = QColor(255, 255, 255, 120)
        else:
            fill = QColor(255, 255, 255, 30)
        p.setBrush(fill)
        p.drawRoundedRect(QRectF(x0, y0, x1 - x0, y1 - y0), 0.25 * row_h, 0.25 * row_h)
        font = QFont("Segoe UI")
        font.setPixelSize(max(6, int(0.36 * (y1 - y0))))
        p.setFont(font)
        p.setPen(QColor(255, 255, 255, 235))
        p.drawText(QRectF(x0, y0, x1 - x0, y1 - y0), Qt.AlignmentFlag.AlignCenter, label)
        p.setPen(Qt.PenStyle.NoPen)
    p.end()
    return img
