"""Functional checks for the settings app (run on the virtual display)."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from PySide6.QtWidgets import QApplication, QPushButton, QSlider, QLineEdit, QFrame
from PySide6.QtCore import QCoreApplication, QEvent
import numpy as np
app = QApplication(sys.argv[:1])
import spatial_desk as sd

class FG:
    def __init__(self, kind, ident, fps=24):
        self.kind, self.ident, self.error = kind, ident, None
    def latest(self): return 1, np.zeros((800, 1280, 4), np.uint8)
    def has_picture(self): return True
    def age(self): return 10.0
    def stop(self): pass
sd.Grabber = FG
sd.MainWindow._maybe_first_run_setup = lambda self: None  # the first-run sheet would cover the page under test

w = sd.MainWindow(); w.resize(1280, 800); w.show()
def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        app.processEvents(); time.sleep(0.02)
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
pump(3)
for k in range(2):
    w.add_source("screen", k, f"App {k+1}")
pump(0.5)

results = []
def check(name, cond):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name)

def rows_titled(text):
    return [r for r in w.sheet.findChildren(QFrame, "setrow") if getattr(r, "title_text", "") == text]

from PySide6.QtTest import QTest
from PySide6.QtCore import Qt
def click_row(title):
    r = rows_titled(title)
    if not r: return False
    QTest.mouseClick(r[0], Qt.MouseButton.LeftButton, pos=r[0].rect().center())
    return True

# 1) open from the control centre's Settings button path
w.open_settings(); pump(0.5)
check("settings opens", w.sheet.isVisible() and w.sheet_kind == "settings")
check("root has seven sections", len(w._set_groups) == 7)

# 2) search filters rows
search = w.sheet.findChild(QLineEdit, "setsearch")
search.setText("follow"); pump(0.2)
visible = [r.title_text for g in w._set_groups for r in g[2] if r.isVisible()]
check("search for 'follow' leaves only Follow gaze", visible == ["Follow gaze"])
search.setText(""); pump(0.2)
visible = [r.title_text for g in w._set_groups for r in g[2] if r.isVisible()]
check("clearing search shows all rows", len(visible) >= 9)

# 3) switch rows change real settings
before = w.follow
click_row("Follow gaze"); pump(0.3)
check("Follow gaze switch changes follow", w.follow != before)
click_row("Follow gaze"); pump(0.3)
check("Follow gaze switch changes back", w.follow == before)

before = w.show_intro
click_row("Launch animation"); pump(0.2)
check("Launch animation switch changes setting", w.show_intro != before)
click_row("Launch animation"); pump(0.2)

before = w.notify_on
click_row("Notifications"); pump(0.2)
check("Notifications switch changes setting", w.notify_on != before)
click_row("Notifications"); pump(0.2)

# 4) push and go back
click_row("Theme"); pump(0.4)
check("Theme page pushes", w._set_stack.count() == 2)
check("back returns to root", (w._settings_back() or True) and w._set_stack.count() == 1)

# 5) theme choice applies to the scene
click_row("Theme"); pump(0.4)
t = list(sd.THEMES)[-1]
choice = [r for r in w.sheet.findChildren(QFrame, "setrow") if getattr(r, "title_text", "") == t.capitalize()]
QTest.mouseClick(choice[0], Qt.MouseButton.LeftButton, pos=choice[0].rect().center()); pump(0.4)
check("choosing a theme row sets it", w.theme_name == t and not w.bg_path)
w._settings_back(); pump(0.2)

# 6) arrangement choice
click_row("Arrangement"); pump(0.4)
w._choose_layout("wide"); pump(0.4)
check("choosing an arrangement sets it", w.layout_name == "wide")
w._settings_back(); pump(0.2)

# 7) immersiveness slider sets the field of view
click_row("Immersiveness"); pump(0.4)
sl = w.sheet.findChildren(QSlider, "qslider")
check("immersiveness page has a slider", len(sl) == 1)
sl[0].setValue(75); pump(0.3)
check("slider changes the field of view", abs(w.scene.fov - 75) < 0.5)
w._settings_back(); pump(0.2)

# 8) maximum windows spin box: the one on the row called "Maximum windows"
w.open_settings(); pump(0.3)
mx_rows = rows_titled("Maximum windows")
spin = mx_rows[0].findChild(sd.QSpinBox) if mx_rows else None
if spin is not None:
    spin.setValue(3); pump(0.2)
    check("maximum windows spin sets the limit", w.max_panels == 3)
else:
    check("maximum windows spin sets the limit", False)
# 9) Done closes the settings, and another sheet still opens at its natural height
done = [b for b in w.sheet.findChildren(QPushButton) if b.text() == "Done"]
done[0].click(); pump(0.3)
check("Done closes settings", (not w.sheet.isVisible()) and w.sheet_kind is None)
w.open_quick_settings(); pump(0.3)
check("control centre opens after settings (height reset)", w.sheet.maximumHeight() > 10000)

print("RESULT", sum(ok for _, ok in results), "/", len(results))
os._exit(0 if all(ok for _, ok in results) else 1)
