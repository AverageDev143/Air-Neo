"""Checks for Air Neo's logic and the dock profiles: saved state, the passcode, the WireGuard configs and commands,
and which dock shows for which window. Needs no Qt and no network. usage: python tools/test_airneo.py
"""
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
import airneo_core as core  # noqa: E402
import dock_profiles as dock  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# saved state, including a folder that does not exist yet (this was the first-run crash on Windows)
with tempfile.TemporaryDirectory() as d:
    nested = os.path.join(d, "airneo_data")
    core.save_state(os.path.join(nested, "state.json"), dict(core.DEFAULT_STATE, setup_done=True))
    check("saving creates a missing folder", os.path.isfile(os.path.join(nested, "state.json")))
    core.write_private(os.path.join(d, "other", "device.key"), "secret\n")
    check("a private file is written, creating its folder",
          open(os.path.join(d, "other", "device.key"), encoding="utf-8").read() == "secret\n")
    if os.name == "posix":
        mode = os.stat(os.path.join(d, "other", "device.key")).st_mode & 0o777
        check("a private file is readable by its owner only", mode == 0o600, oct(mode))
# saved state
with tempfile.TemporaryDirectory() as d:
    path = os.path.join(d, "state.json")
    check("a missing state file gives the defaults", core.load_state(path) == core.DEFAULT_STATE)
    state = dict(core.DEFAULT_STATE, setup_done=True, host="home.example.net", port=51820)
    core.save_state(path, state)
    check("the state round-trips", core.load_state(path) == state)
    with open(path, "w", encoding="utf-8") as f:
        f.write("{not json")
    check("a damaged state file gives the defaults", core.load_state(path) == core.DEFAULT_STATE)
    with open(path, "w", encoding="utf-8") as f:
        f.write('{"setup_done": true, "unknown": 1}')
    check("unknown keys are ignored", core.load_state(path)["setup_done"] is True and "unknown" not in core.load_state(path))

check("the setup steps run in order", core.next_step("welcome") == "device" and core.next_step("peer") == "done")
check("the last step stays on the last step", core.next_step("done") == "done")

# the passcode: stored as a salted hash, checked in constant time
record = core.make_passcode_record("correct horse", salt=b"0123456789abcdef", iterations=1000)
check("the right passcode is accepted", core.check_passcode("correct horse", record))
check("a wrong passcode is refused", not core.check_passcode("correct hors", record))
check("the passcode itself is not stored", "correct horse" not in repr(record))
check("a record with the same passcode but another salt differs",
      core.make_passcode_record("correct horse", salt=b"x" * 16, iterations=1000)["hash"] != record["hash"])
try:
    core.make_passcode_record("abc")
    check("a short passcode is refused", False, "no error")
except ValueError:
    check("a short passcode is refused", True)
check("no record means no sign-in", not core.check_passcode("anything", None))

# WireGuard configs: which key each file holds, and what the tunnel carries
def key(ch):
    return ch * 43 + "="


MP, MU, WP, WU = key("M"), key("N"), key("W"), key("X")
mac, win = core.build_configs(MP, MU, WP, WU, "home.example.net", 51820)
check("the Mac file holds only the Mac's private key", f"PrivateKey = {MP}" in mac and WP not in mac)
check("the PC file holds only the PC's private key", f"PrivateKey = {WP}" in win and MP not in win)
check("the PC sends only the tunnel's subnet through the Mac", "AllowedIPs = 10.66.0.0/24\n" in win)
check("the PC uses the Mac's endpoint", "Endpoint = home.example.net:51820" in win)
mac2, win2 = core.build_configs(MP, MU, WP, WU, "203.0.113.7", 40000, lan="192.168.1.0/24")
check("a home network is added to the PC's allowed list", "AllowedIPs = 10.66.0.0/24, 192.168.1.0/24" in win2)
for label, args in (("a host with a newline", ("a.example\nPrivateKey = x", 51820)),
                    ("a port of zero", ("home.example.net", 0))):
    try:
        core.build_configs(MP, MU, WP, WU, args[0], args[1])
        check(f"{label} is refused", False, "no error")
    except ValueError:
        check(f"{label} is refused", True)
try:
    core.check_lan("10.66.0.0/24")
    check("a home network that overlaps the tunnel is refused", False)
except ValueError:
    check("a home network that overlaps the tunnel is refused", True)

class _Done:
    def __init__(self, out):
        self.stdout = out


def fake_wg(args, input=None, **kw):
    return _Done(key("P") + "\n") if args[1] == "genkey" else _Done(key("Q") + "\n")


check("a key pair comes back as private then public", core.generate_keypair(run=fake_wg) == (key("P"), key("Q")))
check("the setup asks for the other device's key before finishing",
      core.next_step("keys") == "peer" and core.next_step("peer") == "done")
pc_cfg = core.build_device_config("pc", WP, WU, MU, "home.example.net", 51820)
mac_cfg = core.build_device_config("mac", MP, MU, WU, "unused")
check("the PC's own config holds only its private key", f"PrivateKey = {WP}" in pc_cfg and MP not in pc_cfg)
check("the PC trusts the Mac's public key and uses its endpoint",
      f"PublicKey = {MU}" in pc_cfg and "Endpoint = home.example.net:51820" in pc_cfg)
check("the Mac's own config holds only its private key", f"PrivateKey = {MP}" in mac_cfg and WP not in mac_cfg)
check("the Mac trusts the PC's public key", f"PublicKey = {WU}" in mac_cfg and "Endpoint" not in mac_cfg)
try:
    core.build_device_config("tv", WP, WU, MU, "x")
    check("an unknown device is refused", False)
except ValueError:
    check("an unknown device is refused", True)
paths = core.data_paths("/base")
check("Air Neo keeps its files in one folder next to the app",
      paths["folder"] == os.path.join("/base", "airneo_data") and paths["key"].startswith(paths["folder"]))
check("the saved state keeps the public keys and the peer details",
      set(["public_key", "peer_public"]) <= set(core.DEFAULT_STATE))
check("finding WireGuard's tool returns a path or nothing", core.find_wg() is None or isinstance(core.find_wg(), str))

# tunnel commands: lists, one per system, and the install needs the right system
check("Windows brings the tunnel up as a service",
      core.tunnel_command("windows", r"C:\wg\pc.conf", "up") == ["wireguard.exe", "/installtunnelservice", r"C:\wg\pc.conf"])
check("Windows takes it down by tunnel name",
      core.tunnel_command("windows", r"C:\wg\pc.conf", "down") == ["wireguard.exe", "/uninstalltunnelservice", "pc"])
mac_up = core.tunnel_command("macos", "/x/mac.conf", "up")
check("the Mac asks for an administrator through macOS and runs wg-quick up",
      mac_up[0] == "osascript" and "wg-quick up" in mac_up[-1] and mac_up[-1].endswith("with administrator privileges"))
check("the Mac command puts Homebrew's folders on PATH first", "export PATH=/opt/homebrew/bin:" in mac_up[-1])
check("MacPorts' folder is searched for WireGuard", "/opt/local/bin" in core.MAC_TOOL_DIRS and "/opt/local/bin" in core.MAC_PATH)
# the script must survive two layers of quoting: the shell's and AppleScript's
import shlex as _shlex
_odd = '/x/My "Mac" $HOME.conf'
_script = core.tunnel_command("macos", _odd, "down")[-1]
_inner = _script[len('do shell script "'):_script.index('" with administrator')].replace('\\"', '"').replace("\\\\", "\\")
_argv = _shlex.split(_inner.split("; ", 1)[1])
check("a path with spaces, quotes and $ reaches wg-quick unchanged",
      _argv == ["wg-quick", "down", _odd])
check("Linux still runs wg-quick directly", core.tunnel_command("linux", "/x/l.conf", "down") == ["wg-quick", "down", "/x/l.conf"])
try:
    core.tunnel_command("macos", "/x/mac.conf", "sideways")
    check("an unknown action is refused", False)
except ValueError:
    check("an unknown action is refused", True)

class _Proc:
    def __init__(self, code, err=""):
        self.returncode, self.stderr, self.stdout = code, err, ""


check("a successful 'up' reports connected",
      core.run_tunnel_command(["x"], "up", run=lambda c, **k: _Proc(0)) == (True, "connected"))
check("a successful 'down' reports disconnected",
      core.run_tunnel_command(["x"], "down", run=lambda c, **k: _Proc(0)) == (True, "disconnected"))
ok, msg = core.run_tunnel_command(["x"], "up", run=lambda c, **k: _Proc(1, "access denied\nneeds admin"))
check("a failed command shows its last message", (ok, msg) == (False, "needs admin"))

def missing(c, **k):
    raise FileNotFoundError
ok, msg = core.run_tunnel_command(["wg-quick"], "up", run=missing)
check("a missing tool says so, and does not crash", ok is False and "not found" in msg)

class _Cancelled:
    returncode, stdout = 1, ""
    stderr = "execution error: User canceled. (-128)"
ok, msg = core.run_tunnel_command(["osascript"], "up", run=lambda c, **k: _Cancelled())
check("closing the administrator box is reported as not given, not as a crash", ok is False and "not given" in msg)

# dock profiles: the dock changes for tunnel windows, and only for them
check("a WireGuard window selects the tunnel dock", dock.profile_for(r"C:\Program Files\WireGuard\wireguard.exe") == "tunnel")
check("the program name is matched without case", dock.profile_for(r"C:\X\WIREGUARD.EXE") == "tunnel")
check("a window titled Virtual Box selects the tunnel dock", dock.profile_for("", "Virtual Box setup") == "tunnel")
check("any other program keeps the normal dock", dock.profile_for(r"C:\Apps\chrome.exe", "Mail") == "default")
check("nothing known keeps the normal dock", dock.profile_for("", "") == "default")
check("the tunnel dock shows the tunnel button", "tunnel" in dock.dock_layout("tunnel"))
check("the normal dock keeps its buttons and adds Air Neo", dock.dock_layout("default")[:3] == ("home", "mode", "add")
      and "airneo" in dock.dock_layout("default"))
check("an unknown profile gets the normal dock", dock.dock_layout("nope") == dock.dock_layout("default"))

print()

# ---- round 77: Virtual Box connects only when the other computer answers
class Done:
    def __init__(self, returncode=0, stdout="", stderr=""):
        self.returncode, self.stdout, self.stderr = returncode, stdout, stderr


def fake_run(answers):
    """A run() that answers each command from a list of (command starts with, Done)."""
    calls = []
    def run(cmd, **kwargs):
        calls.append(list(cmd))
        for prefix, done in answers:
            if list(cmd[:len(prefix)]) == list(prefix):
                return done
        return Done(1, "", "no answer")
    run.calls = calls
    return run


OWN_PUB = "A" * 42 + "B="
OWN_PRIV = "C" * 42 + "D="
OTHER_PUB = "E" * 42 + "F="
try:
    core.check_peer_key(OWN_PUB, OWN_PUB, OWN_PRIV)
    refused_own = False
except ValueError as e:
    refused_own = "this computer's own public key" in str(e)
check("pasting this computer's own public key is refused with the reason", refused_own)
try:
    core.check_peer_key(OWN_PRIV, OWN_PUB, OWN_PRIV)
    refused_priv = False
except ValueError as e:
    refused_priv = "private key" in str(e)
check("pasting a private key is refused, and the reason says so", refused_priv)
check("pasting the other computer's public key is accepted",
      core.check_peer_key(OTHER_PUB, OWN_PUB, OWN_PRIV) == OTHER_PUB)
try:
    core.check_peer_key("not a key", OWN_PUB, OWN_PRIV)
    refused_bad = False
except ValueError:
    refused_bad = True
check("text that is not a key is refused", refused_bad)

run_pub = fake_run([(["wg", "pubkey"], Done(0, OTHER_PUB + "\n"))])
check("the public key is worked out from the private key (kept, not regenerated)",
      core.public_from_private(OWN_PRIV, run=run_pub) == OTHER_PUB)

check("the PC reaches the Mac's tunnel address, and the Mac reaches the PC's",
      core.peer_address("pc") == core.MAC_IP and core.peer_address("mac") == core.WIN_IP)

check("a Windows ping that got a reply (any language keeps TTL=) counts as answered",
      core.peer_answers("windows", core.MAC_IP, run=fake_run([(["ping"], Done(0, "Reply from 10.66.0.1: bytes=32 time=3ms TTL=128"))])))
check("a Windows ping that only got 'destination unreachable' does not count",
      not core.peer_answers("windows", core.MAC_IP, run=fake_run([(["ping"], Done(0, "Reply from 10.66.0.1: Destination host unreachable."))])))
check("a macOS ping that got a reply counts as answered",
      core.peer_answers("macos", core.WIN_IP, run=fake_run([(["ping"], Done(0, "64 bytes from 10.66.0.2: icmp_seq=0 ttl=64 time=1.2 ms"))])))
check("a macOS ping with no reply does not count",
      not core.peer_answers("macos", core.WIN_IP, run=fake_run([(["ping"], Done(2, "", "timeout"))])))

sleeps = []
replies = iter([Done(2), Done(2), Done(0, "64 bytes from 10.66.0.2: icmp_seq=0 ttl=64")])
def scripted_run(cmd, **kwargs):
    return next(replies)
check("waiting for the other computer keeps trying, and stops when it answers",
      core.wait_for_peer("macos", core.WIN_IP, attempts=10, delay_s=2.0, run=scripted_run, sleep=sleeps.append)
      and sleeps == [2.0, 2.0])

script_up = core.windows_tunnel_script("up", r"C:\SpatialDesk\airneo_data\airneo.conf")
script_down = core.windows_tunnel_script("down", r"C:\SpatialDesk\airneo_data\airneo.conf")
check("starting the Windows tunnel removes an old tunnel of the same name first, then installs the new config",
      script_up.index("/uninstalltunnelservice airneo") < script_up.index("/installtunnelservice")
      and "&" in script_up and "&&" not in script_up)
check("stopping the Windows tunnel only removes it", "/uninstalltunnelservice airneo" in script_down
      and "/installtunnelservice" not in script_down)

class FakeWindowsElevate:
    def __init__(self, code=0, declined=False):
        self.code, self.declined, self.params = code, declined, []
    def __call__(self, program, parameters):
        self.params.append((program, parameters))
        if self.declined:
            raise core.ElevationDeclined()
        return self.code

conf = r"C:\SpatialDesk\airneo_data\airneo.conf"
ok, msg, seen = core.tunnel_action("windows", conf, "up", core.MAC_IP,
                                   run=fake_run([(["sc"], Done(0, "STATE : 4  RUNNING")),
                                                 (["ping"], Done(0, "Reply from 10.66.0.1: bytes=32 time=3ms TTL=128"))]),
                                   elevate=FakeWindowsElevate(0), sleep=lambda s: None)
check("Windows: connected when the tunnel runs and the Mac answers", ok and seen and msg == "connected", msg)
ok, msg, seen = core.tunnel_action("windows", conf, "up", core.MAC_IP,
                                   run=fake_run([(["sc"], Done(0, "STATE : 4  RUNNING")), (["ping"], Done(1, "", "no"))]),
                                   elevate=FakeWindowsElevate(0), sleep=lambda s: None)
check("Windows: the tunnel is up but the Mac has not answered: says waiting, and is still ok",
      ok and not seen and "waiting" in msg, msg)
ok, msg, seen = core.tunnel_action("windows", conf, "up", core.MAC_IP,
                                   run=fake_run([(["sc"], Done(0, "STATE : 1  STOPPED"))]),
                                   elevate=FakeWindowsElevate(0), sleep=lambda s: None)
check("Windows: a tunnel service that did not start is reported, not called connected",
      not ok and "did not start" in msg, msg)
ok, msg, seen = core.tunnel_action("windows", conf, "up", core.MAC_IP, run=fake_run([]),
                                   elevate=FakeWindowsElevate(declined=True), sleep=lambda s: None)
check("Windows: a declined prompt says what to do, and the tunnel is not marked connected",
      not ok and "permission" in msg and not seen, msg)
ok, msg, seen = core.tunnel_action("windows", conf, "up", core.MAC_IP, run=fake_run([]),
                                   elevate=FakeWindowsElevate(code=5), sleep=lambda s: None)
check("Windows: a failed WireGuard command gives its code", not ok and "code 5" in msg, msg)

fake_elevate = FakeWindowsElevate(0)
core.tunnel_action("windows", conf, "down", "", run=fake_run([]), elevate=fake_elevate, sleep=lambda s: None)
check("Windows: the stop runs as administrator, through cmd, with the removal",
      fake_elevate.params and fake_elevate.params[0][0] == "cmd.exe" and fake_elevate.params[0][1].startswith('/d /c "')
      and "/uninstalltunnelservice airneo" in fake_elevate.params[0][1])

mac_ok, mac_msg, mac_seen = core.tunnel_action(
    "macos", "/x/airneo.conf", "up", core.WIN_IP,
    run=fake_run([(["osascript"], Done(0, "")), (["ping"], Done(0, "64 bytes from 10.66.0.2: icmp_seq=0 ttl=64"))]))
check("macOS: connected through the administrator box, and the PC answers", mac_ok and mac_seen and mac_msg == "connected", mac_msg)
mac_ok, mac_msg, mac_seen = core.tunnel_action(
    "macos", "/x/airneo.conf", "up", core.WIN_IP,
    run=fake_run([(["osascript"], Done(1, "", "execution error: User canceled. (-128)")) ]))
check("macOS: a cancelled administrator box is reported as not given", not mac_ok and "not given" in mac_msg, mac_msg)



# ---- round 78: changing the other computer's key restarts the tunnel with the new config
check("the tunnel accepts 'restart', and treats it as a tunnel that is left running",
      "restart" in core.TUNNEL_ACTIONS and core.TUNNEL_ON_ACTIONS == ("up", "restart"))
shell_restart = core.mac_shell("restart", "/x/y z.conf")
check("the macOS restart takes the old tunnel down first, ignoring that it may not be up, then brings the new one up",
      shell_restart.index("wg-quick down") < shell_restart.index("wg-quick up")
      and ">/dev/null 2>&1; wg-quick up" in shell_restart and "'/x/y z.conf'" in shell_restart, shell_restart)
mac_restart_cmd = core.tunnel_command("macos", "/x/airneo.conf", "restart")
check("macOS restart is one administrator run (one password box), not two",
      mac_restart_cmd[0] == "osascript" and mac_restart_cmd[-1].count("with administrator privileges") == 1
      and "wg-quick down" in mac_restart_cmd[-1] and "wg-quick up" in mac_restart_cmd[-1])
restart_elevate = FakeWindowsElevate(0)
ok, msg, seen = core.tunnel_action("windows", conf, "restart", core.MAC_IP,
                                   run=fake_run([(["sc"], Done(0, "STATE : 4  RUNNING")),
                                                 (["ping"], Done(0, "Reply from 10.66.0.1: bytes=32 time=3ms TTL=128"))]),
                                   elevate=restart_elevate, sleep=lambda s: None)
check("Windows restart replaces the tunnel: removes the old one, installs the new config, and reports connected",
      ok and msg == "connected" and "/uninstalltunnelservice" in restart_elevate.params[0][1]
      and "/installtunnelservice" in restart_elevate.params[0][1], msg)
restart_calls = []
def counting_run(cmd, **kwargs):
    restart_calls.append(list(cmd)[:1])
    if list(cmd)[:1] == ["osascript"]:
        return Done(0, "")
    return Done(0, "64 bytes from 10.66.0.2: icmp_seq=0 ttl=64")
ok, msg, seen = core.tunnel_action("macos", "/x/airneo.conf", "restart", core.WIN_IP, run=counting_run)
check("macOS restart: one administrator run, then the PC is checked; connected",
      ok and seen and restart_calls.count(["osascript"]) == 1, f"{msg} {restart_calls}")
try:
    core.tunnel_action("macos", "/x/airneo.conf", "sideways", "", run=counting_run)
    rejected = False
except ValueError:
    rejected = True
check("an unknown tunnel action is refused", rejected)


if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all Air Neo and dock checks passed")
