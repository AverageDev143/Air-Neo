"""Checks for the 2D to 3D depth module: image maths, the worker thread and the missing-model path.
Needs numpy only (no model file, no onnxruntime). usage: python tools/test_depth.py
"""
import os
import sys
import threading
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import depth_model as dm  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# resize: a flat picture stays flat, and the output has the asked-for size
flat = np.full((50, 80, 3), 120.0, np.float32)
out = dm.resize_bilinear(flat, 31, 17)
check("resize gives the asked-for shape", out.shape == (17, 31, 3), str(out.shape))
check("resize keeps a flat picture flat", np.allclose(out, 120.0))

ramp = np.tile(np.linspace(0, 255, 80, dtype=np.float32), (50, 1))
r = dm.resize_bilinear(ramp, 40, 10)
check("resize keeps a left-to-right ramp rising", np.all(np.diff(r[0]) >= -1e-4))
check("resize keeps the ends of the ramp", abs(r[0, 0] - 0.0) < 1e-3 and abs(r[0, -1] - 255.0) < 1e-3)

# model input: the right layout and normalisation
white = np.full((30, 60, 3), 255, np.uint8)
x = dm.to_model_input(white)
check("model input is 1 x 3 x H x W", x.shape == (1, 3, dm.INPUT_H, dm.INPUT_W), str(x.shape))
expect = (1.0 - dm.MEAN) / dm.STD
check("white normalises to the ImageNet values",
      all(np.allclose(x[0, c], expect[c], atol=1e-5) for c in range(3)))

# depth normalisation: 0..1, order kept, extremes clipped, flat input stays at zero
raw = np.linspace(-3.0, 9.0, 200, dtype=np.float32).reshape(10, 20)
d = dm.normalise_depth(raw)
check("normalised depth is within 0..1", d.min() >= 0.0 and d.max() <= 1.0)
check("normalised depth keeps the order", np.all(np.diff(np.sort(d.ravel())) >= 0))
spiky = np.ones((20, 20), np.float32)
spiky[0, 0] = 1e6
dn = dm.normalise_depth(spiky)
check("one bright spot does not flatten the rest", np.percentile(dn, 50) == 0.0 and dn.max() <= 1.0)
check("a flat map gives zeros", np.all(dm.normalise_depth(np.full((4, 4), 2.0)) == 0.0))

# smoothing: the first map is taken as it is, later ones move part of the way
sm = dm.Smoother(0.5)
a = sm(np.zeros((3, 3), np.float32))
b = sm(np.ones((3, 3), np.float32))
check("first map is taken as it is", np.all(a == 0.0))
check("next map moves halfway", np.allclose(b, 0.5))


# the worker: hands each result to the window it came from
class FakeEstimator:
    def estimate(self, rgb):
        return np.full((4, 6), rgb.mean() / 255.0, np.float32)


class FakeOwner:
    def __init__(self):
        self.depth = None
        self.got = threading.Event()

    def set_depth(self, depth):
        self.depth = depth
        self.got.set()


worker = dm.DepthWorker(FakeEstimator())
owner = FakeOwner()
worker.submit(owner, np.full((8, 8, 3), 51, np.uint8))
got = owner.got.wait(2.0)
check("worker returns a depth map to its window", got and owner.depth is not None)
check("the depth map comes from the picture", got and abs(owner.depth.mean() - 0.2) < 1e-3,
      str(None if owner.depth is None else owner.depth.mean()))

# missing model and missing onnxruntime both leave the app flat, with a reason
ready, message = dm.model_status()
check("without the model file the status is not ready", ready is False and "model file not found" in message
      or ready is False and "onnxruntime" in message, message)
est, msg = dm.load_estimator()
check("without the model there is no estimator", est is None and msg, msg)

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all depth checks passed")
