"""Checks for the cursor, the camera picture behind the room, the virtual keyboard, and clicking off a window.
usage: python tools/test_pointer.py   (needs PySide6 and a display, or QT_QPA_PLATFORM=offscreen)

The pictures are read back from the rendered desk, pixel by pixel, so a check fails if nothing is drawn.
"""
import os
import sys
import tempfile
import time

import numpy as np

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
os.environ["SPATIAL_DESK_DATA"] = tempfile.mkdtemp(prefix="sd-pointer-test-")

from PySide6.QtWidgets import QApplication   # noqa: E402
from PySide6.QtCore import Qt                # noqa: E402
from PySide6.QtTest import QTest             # noqa: E402

app = QApplication.instance() or QApplication(sys.argv[:1])
import hand_tracking as ht                   # noqa: E402
import pointer_art                           # noqa: E402
import spatial_desk as sd                    # noqa: E402

failures = 0
results = []


def check(name, ok, detail=""):
    global failures
    results.append((name, bool(ok)))
    if not ok:
        failures += 1
    print(("PASS  " if ok else "FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""))


def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        QTest.qWait(20)


def pixel(img, x, y):
    c = img.pixelColor(int(round(x)), int(round(y)))
    return c.red(), c.green(), c.blue(), c.alpha()


# ---- the pictures themselves (no window needed). The texture is 64 px and is drawn 30 px across on screen: the solid
# core has a radius of 30% of the picture's radius (about 4.5 px), and the soft glow fades out by the edge.
dot = pointer_art.dot_image()
check("the dot is a 64 pixel picture", dot.width() == 64 and dot.height() == 64)
check("the dot's core is solid white", pixel(dot, 32, 32)[3] == 255 and pixel(dot, 32, 32)[0] == 255)
check("the solid core reaches about 30% of the radius", pixel(dot, 32 + 8, 32)[3] == 255, str(pixel(dot, 32 + 8, 32)))
check("a soft glow sits just outside the core", 0 < pixel(dot, 32 + 12, 32)[3] < 255
      and pixel(dot, 32 + 12, 32)[0] == 255, str(pixel(dot, 32 + 12, 32)))
check("the glow is brighter near the core than near the edge", pixel(dot, 32 + 12, 32)[3]
      > pixel(dot, 32 + 24, 32)[3], f"{pixel(dot, 32 + 12, 32)} vs {pixel(dot, 32 + 24, 32)}")
check("the glow is gone at the picture's edge", pixel(dot, 32 + 31, 32)[3] < 6, str(pixel(dot, 32 + 31, 32)))
check("the corners of the dot's picture are transparent", pixel(dot, 0, 0)[3] == 0)
data = pointer_art.image_bytes(dot)
check("the dot's pixels are the right size for a texture", len(data) == 64 * 64 * 4, str(len(data)))

ring = pointer_art.ring_image()
check("the ring is open in the middle", pixel(ring, 32, 32)[3] < 10, str(pixel(ring, 32, 32)))
check("the ring has a white line around it", max(pixel(ring, 32 + r, 32)[3] for r in range(20, 30)) > 150)

kb = pointer_art.keyboard_image(300, 120, hover="Q", pressed=None)
check("the keyboard picture is the size asked for", kb.width() == 300 and kb.height() == 120)
def probe(key):
    """A point in the key's fill, away from its label, which is drawn in the middle of the key."""
    return key[1] + 0.22 * (key[3] - key[1]), key[2] + 0.2 * (key[4] - key[2])


q = [k for k in ht.keyboard_keys(300, 120) if k[0] == "Q"][0]
a = [k for k in ht.keyboard_keys(300, 120) if k[0] == "A"][0]
qc, ac = probe(q), probe(a)
check("the hovered key is lighter than the others", pixel(kb, *qc)[3] > pixel(kb, *ac)[3]
      or pixel(kb, *qc)[0] > pixel(kb, *ac)[0], f"{pixel(kb, *qc)} vs {pixel(kb, *ac)}")
kb_pressed = pointer_art.keyboard_image(300, 120, hover=None, pressed="Q")
check("a pressed key takes the accent colour", pixel(kb_pressed, *qc)[2] > pixel(kb_pressed, *qc)[0])

# ---- the desk itself, rendered
import unittest.mock as mock   # noqa: E402

with mock.patch.object(sd, "Grabber", mock.MagicMock()), mock.patch.object(sd.MainWindow, "_maybe_first_run_setup",
                                                                             lambda self: None):
    w = sd.MainWindow()
w.resize(1280, 720)
w.show()
w.scene.skip_intro = True
pump(1.2)
check("the scene has drawn at least once", w.scene.width() > 0 and w.scene.intro_ended)

# the cursor is the white dot over empty room, and the system pointer is hidden there
w.scene.set_pointer(640, 360, "mouse")
pump(0.4)
check("over empty room the system pointer is hidden", w.scene.cursor().shape() == Qt.CursorShape.BlankCursor,
      str(w.scene.cursor().shape()))
img = w.scene.grabFramebuffer()
core = pixel(img, 640, 360)
away = pixel(img, 640 + 120, 360 + 120)
check("the dot is drawn at the cursor: bright white in the middle", core[0] > 220 and core[1] > 220 and core[2] > 220,
      str(core))
check("the room is dark away from the dot", away[0] < 120 and away[1] < 120, str(away))
check("the dot is small: 4 px out from the middle is still the white core (its radius is about 11 px)",
      pixel(img, 640 + 4, 360)[0] > 220, str(pixel(img, 640 + 4, 360)))
check("the dot is gone 14 px from the middle (no large glow)", pixel(img, 640 + 14, 360)[0] < away[0] + 30,
      f"{pixel(img, 640 + 14, 360)} vs {away}")

# the camera picture fills the room behind the windows
frame = np.zeros((720, 1280, 3), dtype=np.uint8)
frame[:, :] = (30, 160, 40)
w.scene.set_camera_on(True)
w.scene.set_camera_frame(frame)
pump(0.5)
img = w.scene.grabFramebuffer()
top_left = pixel(img, 4, 4)
bottom_right = pixel(img, 1275, 715)
check("the camera picture covers the room: its colour shows in the corner",
      abs(top_left[0] - 30) < 14 and abs(top_left[1] - 160) < 14 and abs(top_left[2] - 40) < 14, str(top_left))
check("the camera picture covers the far corner too", abs(bottom_right[1] - 160) < 14, str(bottom_right))

# the virtual keyboard sits in the room, and the key under the finger is lighter
rect = ht.keyboard_rect(w.scene.width(), w.scene.height())
kx, ky, kw, kh = rect
keys = ht.keyboard_keys(kw, kh)
qk = [k for k in keys if k[0] == "Q"][0]
ak = [k for k in keys if k[0] == "A"][0]
w.scene.set_keyboard(rect, hover="Q", pressed=None)
pump(0.5)
img = w.scene.grabFramebuffer()
qx, qy = kx + probe(qk)[0], ky + probe(qk)[1]
ax, ay = kx + probe(ak)[0], ky + probe(ak)[1]
check("the keyboard is drawn in the room", pixel(img, qx, qy)[0] > 0 or pixel(img, qx, qy)[1] > 0
      or pixel(img, qx, qy)[2] > 0, str(pixel(img, qx, qy)))
check("the key under the finger is lighter than the key beside it", sum(pixel(img, qx, qy)[:3])
      > sum(pixel(img, ax, ay)[:3]), f"{pixel(img, qx, qy)} vs {pixel(img, ax, ay)}")

# over the keyboard the dot still follows the finger (hand mode), and it is not the system pointer
w.scene.set_pointer(qx, qy, "hand")
pump(0.4)
check("with a finger in the room the system pointer stays hidden",
      w.scene.cursor().shape() == Qt.CursorShape.BlankCursor)

# turning camera mode off puts the room back
w.scene.set_camera_on(False)
pump(0.5)
img = w.scene.grabFramebuffer()
check("with camera mode off the camera picture is gone", abs(pixel(img, 4, 4)[1] - 160) > 30, str(pixel(img, 4, 4)))

# ---- clicking off a window: the room takes the keyboard back and no window stays focused
w.scene.pick = lambda x, y: None                         # the click lands on empty room
w.kb_panel = {"name": "Notepad", "grab": None}
w.scene.focused = {"name": "Notepad", "grab": None}
w._on_click(100, 100)
check("a click on the empty room gives the keyboard back to the room", w.kb_panel is None)
check("a click on the empty room leaves no window focused", w.scene.focused is None, str(w.scene.focused))

w.close()
print()
print(f"RESULT {sum(ok for _, ok in results)} / {len(results)}")
if failures:
    print(f"{failures} check(s) failed")
    os._exit(1)
print("all pointer, camera and click-off checks passed")
os._exit(0)
