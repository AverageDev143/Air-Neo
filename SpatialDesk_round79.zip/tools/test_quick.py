import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.argv = ["x"]
from PySide6.QtWidgets import QApplication, QPushButton
from PySide6.QtCore import Qt
app = QApplication(sys.argv[:1])
import numpy as np
import spatial_desk as sd
def fake_frame(k, W=1280, H=800):
    return np.zeros((H, W, 4), np.uint8)
class FG:
    def __init__(self, kind, ident, fps=24):
        self.kind, self.ident, self.error = kind, ident, None
    def latest(self): return 1, fake_frame(0)
    def has_picture(self): return True
    def age(self): return 10.0
    def stop(self): pass
sd.Grabber = FG
w = sd.MainWindow(); w.resize(1280, 800); w.show()
from PySide6.QtCore import QCoreApplication, QEvent
def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        app.processEvents(); time.sleep(0.02)
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
pump(4)
for k in range(3):
    w.add_source("screen", k, f"App {k+1}")
pump(1)
results = []
def check(name, cond):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name)

# 1) status strip click opens the control centre
w.status_strip.clicked.emit()
pump(0.5)
check("status strip opens control centre", w.sheet.isVisible() and w.sheet_kind == "quick")

# 2) window list: close the middle window
btns = [b for b in w.sheet.findChildren(QPushButton) if b.objectName() == "qx" and b.toolTip() == "Close this window"]
check("three close buttons listed", len(btns) == 3)
btns[1].click(); pump(0.5)
check("closing one window removes it", len(w.panels) == 2)
check("list rebuilt after close", w.sheet.isVisible() and w.sheet_kind == "quick")

# 3) tiles
tiles = {b.text().split("\n")[0]: b for b in w.sheet.findChildren(QPushButton) if b.objectName() == "qtile"}
check("six tiles present", len(tiles) == 6)
tiles["Recenter"].click(); pump(0.3)
check("recenter tile runs without error", True)
before = w.layout_name
tiles["Arrangement"].click(); pump(0.3)
check("arrangement tile cycles layout", w.layout_name != before)

# 4) immersiveness slider sets field of view
from PySide6.QtWidgets import QSlider
sl = w.sheet.findChild(QSlider, "qslider")
sl.setValue(75); pump(0.3)
check("slider changes field of view", abs(w.scene.fov - 75) < 0.5)

# 5) Spatial 3D tile switches mode
tiles["Spatial 3D"].click(); pump(1.0)
check("spatial tile switches to 3D", w.mode == "spatial")

# 6) Close all empties the windows and closes nothing else
w.open_quick_settings(); pump(0.3)
clear = [b for b in w.sheet.findChildren(QPushButton) if b.text() == "Close all"]
check("close all button present", len(clear) == 1)
clear[0].click(); pump(0.5)
check("close all removes every window", len(w.panels) == 0)

# 7) the sheet's own X closes the control centre
w.open_quick_settings(); pump(0.2)
xs = [b for b in w.sheet.findChildren(QPushButton) if b.objectName() == "qx" and b.toolTip() == ""]
xs[0].click(); pump(0.3)
check("header X closes the control centre", (not w.sheet.isVisible()) and w.sheet_kind is None)

print("RESULT", sum(ok for _, ok in results), "/", len(results))
os._exit(0)
