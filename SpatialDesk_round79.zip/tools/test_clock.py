"""Checks that every clock in the app shows 12-hour time (8:33 PM), not 24-hour time (20:33). The function is read from
spatial_desk.py with ast, so the test runs the code the app runs, without Qt.
usage: python tools/test_clock.py
"""
import ast
import os
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(HERE, "..", "spatial_desk.py")
with open(SRC_PATH, encoding="utf-8") as f:
    SRC = f.read()
TREE = ast.parse(SRC)

ns = {"time": time}
for node in TREE.body:
    if isinstance(node, ast.FunctionDef) and node.name == "clock_text":
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)
clock_text = ns["clock_text"]

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


def at(hour, minute):
    return time.struct_time((2026, 11, 12, hour, minute, 0, 3, 316, -1))


cases = {
    (0, 5): "12:05 AM",       # just after midnight
    (0, 0): "12:00 AM",       # midnight
    (8, 33): "8:33 AM",       # morning, no leading zero
    (12, 0): "12:00 PM",      # noon
    (13, 30): "1:30 PM",
    (20, 33): "8:33 PM",      # the case in the screenshot
    (23, 59): "11:59 PM",
}
for (h, m), want in cases.items():
    got = clock_text(at(h, m))
    check(f"{h:02d}:{m:02d} shows as {want}", got == want, f"got {got!r}")

check("the live clock (no argument) gives a 12-hour time",
      clock_text().split(" ")[-1] in ("AM", "PM") and ":" in clock_text())

check("no clock in the app still uses 24-hour time", '"%H:%M"' not in SRC)
print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all clock checks passed")
