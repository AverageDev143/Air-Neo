"""Launching Spatial Desk the way the desktop shortcut does. Run: python tools/test_launch.py  (needs PySide6)

What this proves:
  - the accounts and settings file is the same whichever folder the app starts from (the shortcut starts it from
    its own working folder, not the project folder);
  - accounts and settings saved by one run are found by the next run, in a new process;
  - saved data from the older layout (beside the program) is copied into the data folder once, never overwritten;
  - a real launch of the app reaches the desk with the saved account, without asking for a new one.
The last check runs the app's own entry point, and drives its login screen with clicks and typing.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable
failures = 0
results = []


def check(name, ok, detail=""):
    global failures
    results.append((name, bool(ok)))
    if not ok:
        failures += 1
    print(("PASS  " if ok else "FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""))


def run_python(code, cwd, data_dir, extra_env=None, timeout=240):
    env = dict(os.environ)
    env["SPATIAL_DESK_DATA"] = data_dir
    env.pop("XDG_DATA_HOME", None)
    env.update(extra_env or {})
    return subprocess.run([PY, "-c", code], cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)


# ---- 1. the same file from any working folder
data = tempfile.mkdtemp(prefix="sd-launch-data-")
probe = ("import sys; sys.path.insert(0, %r)\n"
         "import app_paths; print(app_paths.accounts_file()); print(app_paths.settings_file())")
probe = probe % HERE
from_project = run_python(probe, HERE, data)
from_elsewhere = run_python(probe, tempfile.gettempdir(), data)
check("the probe runs from the project folder", from_project.returncode == 0, from_project.stderr[-300:])
check("the probe runs from another folder too", from_elsewhere.returncode == 0, from_elsewhere.stderr[-300:])
check("the accounts path is the same from either folder",
      from_project.stdout == from_elsewhere.stdout and from_project.stdout != "",
      f"{from_project.stdout!r} vs {from_elsewhere.stdout!r}")
check("the accounts file is in the data folder, not in the project folder",
      from_project.stdout.splitlines()[0].startswith(data))
check("the project folder gets no accounts folder of its own", not os.path.exists(os.path.join(HERE, "accounts_data")))

# ---- 2. the settings saved by one run are loaded by the next, in a new process
save_code = (
    "import sys; sys.path.insert(0, %r)\n"
    "import spatial_desk as sd\n"
    "data = sd.load_settings(); data['fov'] = 73; data['theme'] = 'dusk'\n"
    "sd.save_settings(data); print('saved', sd.SETTINGS_PATH)\n") % HERE
load_code = (
    "import sys; sys.path.insert(0, %r)\n"
    "import spatial_desk as sd\n"
    "d = sd.load_settings(); print(d['fov'], d['theme'])\n") % HERE
data2 = tempfile.mkdtemp(prefix="sd-settings-data-")
s1 = run_python(save_code, tempfile.gettempdir(), data2)
check("a settings save runs in its own process", s1.returncode == 0 and "saved" in s1.stdout, s1.stderr[-400:])
s2 = run_python(load_code, HERE, data2)
check("a new process reads the same settings back", s2.stdout.strip() == "73 dusk", s2.stdout + s2.stderr[-300:])
check("the settings file is in the data folder", os.path.exists(os.path.join(data2, "settings.json")))

# ---- 3. saved data from the older layout is copied across once, and never overwritten
old_root = tempfile.mkdtemp(prefix="sd-old-layout-")
os.makedirs(os.path.join(old_root, "accounts_data"))
old_accounts = {"accounts": {"oldtimer": {"name": "OldTimer", "avatar": "orbit", "salt": "x", "hash": "y"}},
                "last": "oldtimer"}
with open(os.path.join(old_root, "accounts_data", "accounts.json"), "w", encoding="utf-8") as f:
    json.dump(old_accounts, f)
with open(os.path.join(old_root, "settings.json"), "w", encoding="utf-8") as f:
    json.dump({"fov": 61}, f)
migrate_code = (
    "import sys; sys.path.insert(0, %r)\n"
    "import app_paths; print(','.join(app_paths.migrate_from_program_folder(%r)))\n") % (HERE, old_root)
data3 = tempfile.mkdtemp(prefix="sd-migrate-data-")
m1 = run_python(migrate_code, HERE, data3)
check("the first run copies the older accounts and settings", m1.returncode == 0 and "accounts.json" in m1.stdout
      and "settings.json" in m1.stdout, m1.stdout + m1.stderr[-300:])
copied = json.load(open(os.path.join(data3, "accounts.json"), encoding="utf-8"))
check("the copied accounts are the same accounts", copied == old_accounts)
check("the older files are left where they were",
      os.path.exists(os.path.join(old_root, "accounts_data", "accounts.json")))
with open(os.path.join(data3, "accounts.json"), "w", encoding="utf-8") as f:
    json.dump({"accounts": {"newer": {"name": "Newer", "avatar": "orbit", "salt": "a", "hash": "b"}}}, f)
m2 = run_python(migrate_code, HERE, data3)
check("a second run copies nothing", m2.stdout.strip() == "", m2.stdout + m2.stderr[-200:])
check("a second run does not overwrite the newer accounts",
      json.load(open(os.path.join(data3, "accounts.json"), encoding="utf-8"))["accounts"].keys() == {"newer"})

# ---- 4. a real launch: the desk opens with the saved account, and nothing asks for a new one
launch_data = tempfile.mkdtemp(prefix="sd-launch-full-")
log_path = os.path.join(HERE, "helper.log")
log_existed_before = os.path.exists(log_path)
seed = (
    "import sys; sys.path.insert(0, %r)\n"
    "import accounts_core as ac, app_paths, os\n"
    "p = app_paths.accounts_file()\n"
    "data = ac.create(ac.empty(), 'Mira', 'correct horse battery', 'orbit')\n"
    "ac.save(p, data); print('seeded', p)\n") % HERE
seeded = run_python(seed, HERE, launch_data)
check("the saved account exists before the launch", seeded.returncode == 0 and "seeded" in seeded.stdout,
      seeded.stderr[-300:])

driver = r'''
import json, os, sys, time
sys.path.insert(0, %(here)r)
os.environ["SPATIAL_DESK_DATA"] = %(data)r
from PySide6.QtWidgets import QApplication, QLabel, QPushButton
from PySide6.QtCore import QCoreApplication
from PySide6.QtTest import QTest
from PySide6.QtCore import Qt

REPORT = {}

def scenario(app):
    """Runs in place of app.exec(): drives the login screen, then looks at the desk."""
    import spatial_desk as sd
    from login_ui import LoginGate, AccountCard

    def pump(ms=40):
        QTest.qWait(ms); QCoreApplication.processEvents()

    def wait_for(fn, tries=200):
        for _ in range(tries):
            pump(25)
            got = fn()
            if got:
                return got
        return None

    gates = [w for w in app.topLevelWidgets() if isinstance(w, LoginGate)]
    REPORT["gate_found"] = len(gates) == 1
    if not gates:
        return
    gate = gates[0]
    wait_for(lambda: gate.isVisible())
    REPORT["starts_on_picker"] = gate.stack.currentWidget() is gate.pages["pick"]
    REPORT["subtitle"] = gate.pick_sub.text()
    cards = gate.cards_host.findChildren(AccountCard)
    names = []
    for c in cards:
        names += [l.text() for l in c.findChildren(QLabel) if l.objectName() == "gateName"]
    REPORT["cards"] = names
    card = [c for c in cards if "Mira" in [l.text() for l in c.findChildren(QLabel) if l.objectName() == "gateName"]]
    if not card:
        return
    QTest.mouseClick(card[0], Qt.MouseButton.LeftButton); pump(120)
    gate.password_field.setFocus(); QTest.keyClicks(gate.password_field, "correct horse battery"); pump(40)
    QTest.mouseClick(gate.pages["password"].findChildren(QPushButton)[-1], Qt.MouseButton.LeftButton)
    desks = wait_for(lambda: [w for w in app.topLevelWidgets() if type(w).__name__ == "MainWindow"] or None)
    REPORT["desk_opened"] = bool(desks)
    if desks:
        REPORT["signed_in_as"] = getattr(desks[0], "account_name", None)
        REPORT["gate_hidden"] = not gate.isVisible()
    REPORT["accounts_file_present"] = os.path.exists(os.path.join(%(data)r, "accounts.json"))
    return 0

import PySide6.QtWidgets as W
W.QApplication.exec = lambda self, *a: (scenario(self), 0)[1]
import spatial_desk as sd
try:
    sd.main()
except SystemExit as e:
    REPORT["exit_code"] = e.code
print("REPORT " + json.dumps(REPORT))
os._exit(0)
''' % {"here": HERE, "data": launch_data}
driver_path = os.path.join(tempfile.mkdtemp(prefix="sd-driver-"), "driver.py")
with open(driver_path, "w", encoding="utf-8") as f:
    f.write(driver)
launch = subprocess.run([PY, driver_path], cwd=tempfile.gettempdir(),
                        env=dict(os.environ, SPATIAL_DESK_DATA=launch_data), capture_output=True, text=True,
                        timeout=300)
report_line = [ln for ln in launch.stdout.splitlines() if ln.startswith("REPORT ")]
report = json.loads(report_line[-1][7:]) if report_line else {}
check("the launch runs to the end without crashing", bool(report_line), launch.stderr[-600:])
check("the entry point finds the login screen", report.get("gate_found") is True, str(report))
check("the login screen opens on the account picker", report.get("starts_on_picker") is True, str(report))
check("the picker asks who is using the desk, not for a new account",
      report.get("subtitle") == "Who is using the desk?", str(report.get("subtitle")))
check("the saved account is offered as a card", report.get("cards") == ["Mira"], str(report.get("cards")))
check("signing in opens the desk", report.get("desk_opened") is True, str(report))
check("the desk is signed in as the saved account", report.get("signed_in_as") == "Mira", str(report))
check("the login screen goes away once the desk is open", report.get("gate_hidden") is True, str(report))

# the app writes helper.log beside the program; remove it only if these runs were what created it
if not log_existed_before and os.path.exists(log_path):
    os.remove(log_path)

for d in (data, data2, data3, launch_data, old_root):
    shutil.rmtree(d, ignore_errors=True)

print()
print(f"RESULT {sum(ok for _, ok in results)} / {len(results)}")
if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all launch checks passed")
