"""Checks for the pure parts of the window input, edge and title bar code: no Windows and no Qt needed.

The functions are read from spatial_desk.py with `ast` and run with numpy.
usage: python tools/test_input.py
"""
import ast
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(HERE, "..", "spatial_desk.py")
with open(SRC_PATH, encoding="utf-8") as f:
    SRC = f.read()
TREE = ast.parse(SRC)

CONSTS = {"HDR_W", "HDR_H", "BAR_W", "BAR_X0", "BAR_X1", "BAR_TOP", "BAR_H", "BAR_ICON_SIZE",
          "HDR_BTN_HALF", "HDR_BTNS", "BAR_ICON", "OPEN_MS", "CLOSE_MS", "INTRO_REVEAL"}
FUNCS = {"visible_crop", "crop_picture", "title_hit", "click_plan", "visible_point", "window_motion",
         "intro_progress", "_smooth", "fit_scale", "inside_rounded"}
ns = {"np": np, "math": math}


def _names(node):
    out = []
    for t in node.targets:
        if isinstance(t, ast.Name):
            out.append(t.id)
        elif isinstance(t, ast.Tuple):
            out += [e.id for e in t.elts if isinstance(e, ast.Name)]
    return out


for node in TREE.body:
    if isinstance(node, ast.Assign) and set(_names(node)) & CONSTS:
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)
    if isinstance(node, ast.FunctionDef) and node.name in FUNCS:
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)

click_plan = ns["click_plan"]
inside_rounded = ns["inside_rounded"]
visible_point, window_motion = ns["visible_point"], ns["window_motion"]
intro_progress, fit_scale = ns["intro_progress"], ns["fit_scale"]
OPEN_MS, CLOSE_MS = ns["OPEN_MS"], ns["CLOSE_MS"]
visible_crop, crop_picture, title_hit = ns["visible_crop"], ns["crop_picture"], ns["title_hit"]
HDR_W, HDR_BTNS, HDR_BTN_HALF = ns["HDR_W"], ns["HDR_BTNS"], ns["HDR_BTN_HALF"]

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# Key messages
# Visible frame inside the full window rectangle
check("visible frame inside the full rectangle",
      visible_crop((0, 0, 100, 50), (8, 8, 92, 42)) == (8, 8, 84, 34))
check("identical rectangles give the whole capture",
      visible_crop((0, 0, 100, 50), (0, 0, 100, 50)) == (0, 0, 100, 50))
check("a visible frame outside the capture is rejected", visible_crop((0, 0, 100, 50), (-5, 0, 60, 50)) is None)

pic = np.zeros((50, 100, 4), np.uint8)
cut = crop_picture(pic, (0, 0, 100, 50), (8, 8, 92, 42))
check("crop removes the border and one more pixel each side", cut.shape == (32, 82, 4), str(cut.shape))
check("crop returns the picture unchanged when the frame is unknown",
      crop_picture(pic, (0, 0, 100, 50), (-5, 0, 60, 50)) is pic)

# Title bar layout: six buttons, none overlapping, each reachable by a click
centres = [cx for _key, cx in HDR_BTNS]
check("six title bar buttons", len(HDR_BTNS) == 6, str(len(HDR_BTNS)))
check("buttons sit inside the capsule",
      all(ns["BAR_X0"] <= cx <= ns["BAR_X1"] for cx in centres))
gaps = [b - a for a, b in zip(sorted(centres), sorted(centres)[1:])]
check("buttons do not overlap", min(gaps) > 2 * HDR_BTN_HALF, str(min(gaps)))
check("capsule is about 36% of the window width", abs(ns["BAR_W"] / HDR_W - 0.36) < 0.01)
check("every button is found by a click at its centre",
      all(title_hit(cx / HDR_W) == key for key, cx in HDR_BTNS),
      str([(key, title_hit(cx / HDR_W)) for key, cx in HDR_BTNS]))
check("a click left of the buttons hits nothing", title_hit(0.02) is None)
check("the icons are the approved set",
      set(ns["BAR_ICON"].values()) == {"sidebar", "apps", "focus", "minimise", "maximise", "close"},
      str(ns["BAR_ICON"]))


# Clicks on a letterboxed picture: the point is mapped onto the picture, and the empty margin is not a hit
check("a click at the centre of the shape is the centre of the picture",
      visible_point(0.5, 0.5, (1.0, 2.0)) == (0.5, 0.5))
check("a plain shape maps a click to the same place on the picture", visible_point(0.3, 0.6, (1.0, 1.0)) == (0.3, 0.6))
check("a click in the empty band above a shorter picture is not a hit", visible_point(0.5, 0.2, (1.0, 2.0)) is None)
check("a click inside a shorter picture is scaled onto it",
      visible_point(0.5, 0.3, (1.0, 2.0)) is not None and abs(visible_point(0.5, 0.3, (1.0, 2.0))[1] - 0.1) < 1e-9)
for quad, content in ((0.5625, 1.0), (1.0, 0.5625), (0.5, 0.75)):
    fx, fy = fit_scale(quad, content)
    lo_u, hi_u = 0.5 - 0.5 / fx, 0.5 + 0.5 / fx
    lo_v, hi_v = 0.5 - 0.5 / fy, 0.5 + 0.5 / fy
    edges = [visible_point(lo_u + 1e-9, lo_v + 1e-9, (fx, fy)), visible_point(hi_u - 1e-9, hi_v - 1e-9, (fx, fy))]
    check(f"quad {quad} for picture {content}: the visible part maps exactly onto the whole picture",
          all(e is not None and min(e) >= -1e-6 and max(e) <= 1 + 1e-6 for e in edges)
          and abs(edges[0][0]) < 1e-6 and abs(edges[1][0] - 1.0) < 1e-6, str(edges))

# Window open and close animation
check("a window that is opening starts invisible and slightly small", window_motion(10.0, 10.0, None) == (0.0, 0.9))
check("an open window settles to full size and full visibility", window_motion(99.0, 10.0, None) == (1.0, 1.0))
steps = [window_motion(10.0 + i * OPEN_MS / 1000.0 / 20, 10.0, None)[0] for i in range(21)]
check("an opening window only ever gets more visible", all(b >= a - 1e-12 for a, b in zip(steps, steps[1:])))
check("a closing window starts fully visible", window_motion(5.0, 0.0, 5.0) == (1.0, 1.0))
check("a closed window is gone and a little small", window_motion(5.0 + CLOSE_MS / 1000.0, 0.0, 5.0)[0] == 0.0
      and abs(window_motion(5.0 + CLOSE_MS / 1000.0, 0.0, 5.0)[1] - 0.9) < 1e-9)
csteps = [window_motion(5.0 + i * CLOSE_MS / 1000.0 / 20, 0.0, 5.0)[0] for i in range(21)]
check("a closing window only ever gets less visible", all(b <= a + 1e-12 for a, b in zip(csteps, csteps[1:])))

# Intro title: the reveal runs from 0 to 1 and reaches 1 by the end of the reveal
check("the title reveal starts at 0", intro_progress(0.0) == 0.0)
check("the title reveal is complete by the end of the reveal", intro_progress(ns["INTRO_REVEAL"]) == 1.0
      and intro_progress(10.0) == 1.0)
check("the title reveal skips straight to complete when the intro is skipped", intro_progress(0.0, skip=True) == 1.0)
rise = [intro_progress(i * 0.05) for i in range(80)]
check("the title reveal never goes back", all(b >= a for a, b in zip(rise, rise[1:])))

# Clicks are real: the window is raised, clicked, and the room raised again, with the pointer back where it was
plan = click_plan(10, 20, 100, 200, (5, 6))
check("a click raises the window above the room first", plan[0] == ("raise", 10), str(plan))
check("the click is a real click at the spot", ("click", 100, 200) in plan)
check("the window gets a moment to take the click before the pointer moves back",
      ("pause", 0.02) in plan and plan.index(("pause", 0.02)) > plan.index(("click", 100, 200)))
check("the pointer goes back where it was, after the click",
      plan.index(("cursor", 5, 6)) > plan.index(("pause", 0.02)))
check("the room is raised again after the pointer goes back",
      plan[-1] == ("raise", 20) and plan.index(("raise", 20)) > plan.index(("cursor", 5, 6)), str(plan))
check("the plan never activates anything itself: the click does that, as with a mouse",
      all(step[0] in ("raise", "click", "pause", "cursor") for step in plan))

# Clicks off a window: a click on a rounded-off corner is not a click on the window
W_M, H_M, R_M = 1.0, 0.6, 0.07
check("the middle of a window is inside its rounded shape", inside_rounded(0.5, 0.5, W_M, H_M, R_M))
check("the very corner of a rounded window is outside it", not inside_rounded(0.005, 0.005, W_M, H_M, R_M))
check("the middle of an edge is inside a rounded window", inside_rounded(0.5, 0.001, W_M, H_M, R_M))
check("just past the top edge is outside", not inside_rounded(0.5, -0.01, W_M, H_M, R_M))
arc_cx, arc_cy = W_M / 2 - R_M, H_M / 2 - R_M          # centre of the top-right corner's arc, metres from the middle
def corner_point(radius):
    angle = math.radians(45)
    x = arc_cx + radius * math.cos(angle)
    y = arc_cy + radius * math.sin(angle)
    return 0.5 + x / W_M, 0.5 + y / H_M
check("a point just inside the rounded corner is inside", inside_rounded(*corner_point(R_M - 0.01), W_M, H_M, R_M))
check("a point just outside the rounded corner is outside", not inside_rounded(*corner_point(R_M + 0.01), W_M, H_M, R_M))

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all input, click, animation and intro checks passed")
