"""Checks for camera and hand tracking. Run: python tools/test_camera.py

The geometry, pinch, keyboard layout, key text and key events are checked directly. The camera and the hand model
need a real camera and the model file; here the checks cover what can be checked without them: that a missing camera
or a missing model fails with a clear message, and that the MediaPipe calls are set up the way they are used.
"""
import math
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

import hand_tracking as ht            # noqa: E402
import keyboard_input as ki           # noqa: E402

failures = 0
results = []


def check(name, ok, detail=""):
    global failures
    results.append((name, bool(ok)))
    if not ok:
        failures += 1
    print(("PASS  " if ok else "FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""))


def close(a, b, tol=1e-6):
    return abs(a - b) <= tol


# ---- where the picture sits on the screen
fw, fh, sw, sh = 1920, 1080, 1000, 1000
check("the centre of the picture is the centre of the screen when it covers a square screen",
      all(close(v, 500.0, 1e-6) for v in ht.cover_map(0.5, 0.5, fw, fh, sw, sh, mirror=False)))
x_m, _ = ht.cover_map(0.25, 0.5, fw, fh, sw, sh, mirror=True)
x_u, _ = ht.cover_map(0.75, 0.5, fw, fh, sw, sh, mirror=False)
check("the picture is mirrored: a point on the left of the raw frame lands on the right of the screen",
      close(x_m, x_u), f"{x_m} vs {x_u}")
check("a hand moved to the right of the raw frame moves to the left of the screen (mirror)",
      ht.cover_map(0.9, 0.5, fw, fh, sw, sh)[0] < ht.cover_map(0.1, 0.5, fw, fh, sw, sh)[0])
crop = ht.cover_crop(1920, 1080, 1000, 1000)
check("a wide picture covering a square screen shows the middle part of its width",
      close(crop[0], 1080 / 1920 * 1920 / 1080 / (1920 / 1080)) and close(crop[0], 1 / (1920 / 1080), 1e-9)
      and crop[1] == 1.0, str(crop))
same = ht.cover_crop(1600, 900, 1920, 1080)
check("a picture of the same shape as the screen is shown whole", close(same[0], 1.0, 1e-9)
      and close(same[1], 1.0, 1e-9), str(same))
cx, cy = ht.cover_crop(1080, 1920, 1000, 1000)
check("a tall picture covering a square screen shows the middle part of its height", cx == 1.0 and close(cy, 1080 / 1920))


# ---- hands: a hand is 21 landmarks; build one from a few points
def hand_with(thumb, index, wrist=(0.5, 0.8), mcp=(0.5, 0.5)):
    pts = [(0.5, 0.5, 0.0)] * 21
    pts[ht.WRIST] = (wrist[0], wrist[1], 0.0)
    pts[ht.MIDDLE_MCP] = (mcp[0], mcp[1], 0.0)
    pts[ht.THUMB_TIP] = (thumb[0], thumb[1], 0.0)
    pts[ht.INDEX_TIP] = (index[0], index[1], 0.0)
    return pts


touching = hand_with((0.40, 0.50), (0.40, 0.50))
open_hand = hand_with((0.30, 0.60), (0.60, 0.15))
check("the index fingertip is landmark 8", ht.index_tip(open_hand) == (0.60, 0.15))
check("a touching thumb and index give a ratio of zero", ht.pinch_ratio(touching) == 0.0)
check("an open hand gives a large ratio", ht.pinch_ratio(open_hand) > 1.0, str(ht.pinch_ratio(open_hand)))
def scaled(hand, s, centre=(0.5, 0.5)):
    return [(centre[0] + s * (x - centre[0]), centre[1] + s * (y - centre[1]), z) for x, y, z in hand]


pinched_small = hand_with((0.45, 0.5), (0.40, 0.5))
check("the ratio does not depend on how big the hand is in the picture",
      close(ht.pinch_ratio(pinched_small), ht.pinch_ratio(scaled(pinched_small, 2.0)), 1e-9),
      f"{ht.pinch_ratio(pinched_small)} vs {ht.pinch_ratio(scaled(pinched_small, 2.0))}")

pinch = ht.Pinch()
seq = [pinch.update(r) for r in (0.8, 0.30, 0.45, 0.45, 0.60, 0.20, 0.10)]
check("a pinch starts once, when the ratio drops below the first threshold",
      seq == [None, "down", None, None, "up", "down", None], str(seq))
check("a pinch does not flicker while the ratio sits between the thresholds",
      seq[2] is None and seq[3] is None)

# ---- the keyboard: where it sits, what keys there are, and what they send
kx, ky, kw, kh = ht.keyboard_rect(1920, 1080)
check("the keyboard sits in the lower middle of the screen", kw == 960 and abs((kx + kw / 2) - 960) < 1e-9
      and ky + kh <= 1080 * 0.9 + 1e-9 and ky > 1080 * 0.4, str((kx, ky, kw, kh)))
keys = ht.keyboard_keys(960, 400)
check("the keyboard has 40 keys", len(keys) == 40, str(len(keys)))
check("every key lies inside the keyboard", all(0 <= x0 < x1 <= 960 and 0 <= y0 < y1 <= 400
                                                 for _l, x0, y0, x1, y1 in keys))
check("the keys do not overlap", all(not (a[1] < b[3] and b[1] < a[3] and a[2] < b[4] and b[2] < a[4])
                                     for i, a in enumerate(keys) for b in keys[i + 1:]))
q = [k for k in keys if k[0] == "Q"][0]
check("the centre of a key is that key", ht.key_at(keys, (q[1] + q[3]) / 2, (q[2] + q[4]) / 2) == "Q")
check("a point outside every key is no key", ht.key_at(keys, -5, -5) is None)
space = [k for k in keys if k[0] == "Space"][0]
check("the space bar is the widest key", max(k[3] - k[1] for k in keys) == space[3] - space[1])

check("a letter sends the letter in lower case", ht.label_text("A", False) == ("a", None, False))
check("Shift makes the next letter a capital and then turns off", ht.label_text("A", True) == ("A", None, False))
check("Shift toggles the capitals on and off", ht.label_text("Shift", False) == (None, None, True)
      and ht.label_text("Shift", True) == (None, None, False))
check("digits are typed as they are", ht.label_text("7", True) == ("7", None, False))
check("Space types a space", ht.label_text("Space", False) == (" ", None, False))
check("Back sends the Backspace key", ht.label_text("Back", False) == (None, 0x08, False))
check("Enter sends the Enter key and turns off capitals", ht.label_text("Enter", True) == (None, 0x0D, False))

# ---- key events: one down and one up per character, so a key arrives once
ev = ki.key_events(text="a")
check("a letter is one key-down and one key-up", len(ev) == 2 and ev[0][2] == ki.KEYEVENTF_UNICODE
      and ev[1][2] == (ki.KEYEVENTF_UNICODE | ki.KEYEVENTF_KEYUP) and ev[0][1] == ord("a"))
check("two letters are four events, in order", [e[1] for e in ki.key_events(text="ab")] == [97, 97, 98, 98])
emoji = ki.key_events(text="\U0001F600")
check("a character outside the basic plane is sent as a surrogate pair",
      [e[1] for e in emoji if not e[2] & ki.KEYEVENTF_KEYUP] == [0xD83D, 0xDE00], str([e[1] for e in emoji]))
check("a virtual key is a key-down and a key-up of its code",
      ki.key_events(vk=0x0D) == [(0x0D, 0, 0), (0x0D, 0, ki.KEYEVENTF_KEYUP)])
check("sending on a machine without Windows sends nothing and says so", ki.send(ki.key_events(text="a")) is False)

# ---- the optional libraries: missing ones fail with a clear message, present ones are set up as they are used
ok, message = ht.camera_ready()
check("camera_ready says whether the camera libraries are installed", isinstance(ok, bool) and isinstance(message, str))
if not ok:
    check("a missing library says what to install", "requirements-camera.txt" in message, message)
else:
    check("with the libraries installed, camera_ready says so", message == "Camera ready", message)

cam = ht.Camera(index=97)                       # no such camera on this machine
started = cam.start()
check("with no camera, start() says so and does not pretend", started is False and cam.error is not None,
      str(cam.error))
check("the message for a missing camera tells you what to do",
      cam.error is not None and ("No camera" in cam.error or "OpenCV" in cam.error), str(cam.error))
cam.stop()

model_dir = tempfile.mkdtemp(prefix="sd-model-")
try:
    path = ht.ensure_model(model_dir)
    check("a model that is already there is used without a download", path.endswith(ht.MODEL_FILE))
except RuntimeError as e:
    check("with no model and no network, the message says where to put the file",
          ht.MODEL_FILE in str(e) and model_dir in str(e), str(e))
fake = os.path.join(model_dir, "fake.task")
with open(fake, "wb") as f:
    f.write(b"not a model")
try:
    ht.HandTracker(fake)
    check("a file that is not a model is refused", False)
except Exception as e:
    check("a file that is not a model is refused with an error, not a crash", True, type(e).__name__)

print()
print(f"RESULT {sum(ok for _, ok in results)} / {len(results)}")
if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all camera and hand checks passed")
