"""Checks for the taskbar: background removal, when it shows, the icon layout and clicks, the window shape
settings, and the window curve. Needs numpy only. The functions are read from spatial_desk.py with ast.
usage: python tools/test_taskbar.py
"""
import ast
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(HERE, "..", "spatial_desk.py")
with open(SRC_PATH, encoding="utf-8") as f:
    SRC = f.read()
TREE = ast.parse(SRC)

FUNCS = {"_smooth", "taskbar_visibility", "key_background", "taskbar_slots", "taskbar_slot_at", "list_taskbar_apps"}
CONSTS = {"TASKBAR_KEY_LO", "TASKBAR_KEY_HI", "DEFAULT_DIST", "TASKBAR_DIST", "TASKBAR_Y", "TASKBAR_ANGLE", "TASKBAR_PIC_W", "TASKBAR_PIC_H",
          "TASKBAR_ICON", "TASKBAR_GAP", "WS_EX_TOOLWINDOW", "GWL_EXSTYLE", "_NOT_APPS", "SHAPE_LABELS", "RATIOS"}
ns = {"np": np, "os": os, "math": math, "IS_WIN": False}


def _names(node):
    out = []
    for t in node.targets:
        if isinstance(t, ast.Name):
            out.append(t.id)
        elif isinstance(t, ast.Tuple):
            out += [e.id for e in t.elts if isinstance(e, ast.Name)]
    return out


for node in TREE.body:
    if isinstance(node, ast.FunctionDef) and node.name in FUNCS:
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)
    if isinstance(node, ast.Assign) and set(_names(node)) & CONSTS:
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)
    if isinstance(node, ast.ClassDef) and node.name == "StaticPicture":
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)

taskbar_visibility, key_background = ns["taskbar_visibility"], ns["key_background"]
taskbar_slots, taskbar_slot_at, list_taskbar_apps = ns["taskbar_slots"], ns["taskbar_slot_at"], ns["list_taskbar_apps"]
StaticPicture = ns["StaticPicture"]
W = ns["TASKBAR_PIC_W"]

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# visibility: hidden while you look ahead, shown when you look well down
check("looking ahead hides the taskbar", taskbar_visibility(0.0) == 0.0)
check("looking up hides the taskbar", taskbar_visibility(0.3) == 0.0)
check("looking well down shows it fully", taskbar_visibility(-0.6) == 1.0)
vals = np.array([taskbar_visibility(float(q)) for q in np.linspace(0.0, -0.6, 61)])
check("visibility rises as you look down", np.all(np.diff(vals) >= -1e-9))
# the taskbar sits about 19 degrees below the eye, is fully shown by the time you look at it, and starts to show
# well before that (about 10 degrees), so a small look down is enough (it used to need about 22 degrees)
angle = ns["TASKBAR_ANGLE"]
check("the taskbar sits about 19 degrees below the eye", abs(math.degrees(angle) - 19.5) < 1.0,
      f"{math.degrees(angle):.1f} degrees")
check("looking straight at the taskbar shows it fully", taskbar_visibility(-angle) == 1.0)
check("it is already showing before you look straight at it", 0.0 < taskbar_visibility(-angle * 0.7) < 1.0)
check("a small look down (6 degrees) does not show it yet", taskbar_visibility(-math.radians(6)) == 0.0)

# background removal on a synthetic picture: flat grey background, one bright icon, one soft edge
frame = np.zeros((40, 120, 4), np.uint8)
frame[..., :3] = 40
frame[..., 3] = 255
frame[12:28, 20:36, :3] = 230
frame[12:28, 36, :3] = 60
keyed = key_background(frame)
check("keying keeps the picture's size", keyed.shape == frame.shape)
check("the background becomes transparent", np.all(keyed[0:5, 0:5, 3] == 0))
check("the icon stays opaque", np.all(keyed[14:26, 22:34, 3] == 255))
check("the edge between them is part-transparent", 0 < int(keyed[20, 36, 3]) < 255, str(keyed[20, 36, 3]))
check("the input picture is not changed", frame[0, 0, 3] == 255)

# icon layout: centred, inside the picture, no overlaps, and the same spacing for any count
check("no apps, no icons", taskbar_slots(0) == [])
for n in (1, 3, 8):
    slots = taskbar_slots(n)
    check(f"{n} app(s): one slot each", len(slots) == n)
    check(f"{n} app(s): every icon is inside the picture",
          all(0 <= x0 and x1 <= W for x0, x1 in slots), str(slots))
    check(f"{n} app(s): icons are centred", abs((slots[0][0] + slots[-1][1]) / 2.0 - W / 2.0) < 1e-6)
    check(f"{n} app(s): icons do not overlap",
          all(b[0] >= a[1] for a, b in zip(slots, slots[1:])))

# clicks: a point on an icon finds that icon; a point between icons finds none
slots = taskbar_slots(4)
check("the middle of each icon finds that icon",
      all(taskbar_slot_at(slots, (x0 + x1) / 2.0) == k for k, (x0, x1) in enumerate(slots)))
check("empty picture margin finds no icon", taskbar_slot_at(slots, 2.0) is None)
check("a little beside an icon still finds it", taskbar_slot_at(slots, slots[1][1] + 3) == 1)

# the taskbar picture object: the texture code reads it like a window capture
pic = StaticPicture(np.zeros((4, 4, 4), np.uint8))
v0, _ = pic.latest()
pic.set_frame(np.ones((4, 4, 4), np.uint8))
v1, f1 = pic.latest()
check("setting a new picture bumps its version", v1 == v0 + 1)
check("the new picture is the one returned", int(f1[0, 0, 0]) == 1)
check("a picture the app draws has no depth", pic.latest_depth() == (0, None))

# off Windows there are no windows to list, so the taskbar is empty
check("off Windows the app list is empty", list_taskbar_apps() == [])

# the window shape settings match the ratios the app knows
labels = ratios = None
for node in TREE.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id == "SHAPE_LABELS":
            labels = [k.value for k in node.value.keys]
        if node.targets[0].id == "RATIOS":
            ratios = [k.value for k in node.value.keys]
check("every window shape has a label", labels is not None and set(labels) == set(ratios), f"{labels} vs {ratios}")

# MainWindow's taskbar actions, run against a stub: an icon click brings the app into the room, never a duplicate
main_cls = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == "MainWindow")
for name in ("_taskbar_click", "_open_app"):
    fn = next(n for n in main_cls.body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module([fn], []), SRC_PATH, "exec"), ns)


class _Grab:
    def __init__(self, kind, ident):
        self.kind = kind
        self.ident = ident


class _Stub:
    def __init__(self, room):
        self.panels = [{"grab": _Grab("window", h), "name": f"w{h}", "hidden": False} for h in room]
        self.calls = []
        self.scene = type("S", (), {})()
        self.scene.taskbar = {"slots": [(x0, x1, hwnd, f"app{hwnd}", "") for (x0, x1), hwnd in zip(taskbar_slots(3), (101, 202, 303))]}

    def focus_panel(self, index):
        self.calls.append(("focus", index))

    def minimise_panel(self, index):
        self.calls.append(("show", index))

    def add_source(self, kind, ident, name):
        self.calls.append(("add", kind, ident, name))


_Stub._taskbar_click = ns["_taskbar_click"]
_Stub._open_app = ns["_open_app"]

s = _Stub(room=[202])
s._taskbar_click(((taskbar_slots(3)[0][0] + taskbar_slots(3)[0][1]) / 2.0) / W, 0.5)
check("clicking an icon of an app that is not in the room adds it", s.calls == [("add", "window", 101, "app101")], str(s.calls))

s = _Stub(room=[202])
s._taskbar_click(((taskbar_slots(3)[1][0] + taskbar_slots(3)[1][1]) / 2.0) / W, 0.5)
check("clicking an app already in the room focuses its window, without a second copy",
      s.calls == [("focus", 0)], str(s.calls))

s = _Stub(room=[])
s.panels = [{"grab": _Grab("window", 303), "name": "w303", "hidden": True}]
s._taskbar_click(((taskbar_slots(3)[2][0] + taskbar_slots(3)[2][1]) / 2.0) / W, 0.5)
check("clicking a minimised app shows it again", s.calls == [("show", 0), ("focus", 0)], str(s.calls))

s = _Stub(room=[])
s._taskbar_click(2.0 / W, 0.5)
check("a click in the empty part of the taskbar does nothing", s.calls == [], str(s.calls))

# the window curve: flat windows have none, and the setting is followed otherwise
scene_cls = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == "Scene")
kappa_fn = next(n for n in scene_cls.body if isinstance(n, ast.FunctionDef) and n.name == "_kappa")
exec(compile(ast.Module([kappa_fn], []), SRC_PATH, "exec"), ns)


class _SceneStub:
    curve = 1.0


apos = np.array([0.0, 0.0, -2.6])
check("a window with its curve turned off has no curve", ns["_kappa"](_SceneStub(), {"apos": apos, "curve_off": True}, 1.0) == 0.0)
# the setup row keeps a flat position as an array under "flat"; that must not switch the curve off
check("a real layout position does not switch the curve off (the round 59 crash)",
      ns["_kappa"](_SceneStub(), {"apos": apos, "flat": np.array([0.0, 0.0, -2.6])}, 1.0) > 0.0)
check("a curved window follows the setting", abs(ns["_kappa"](_SceneStub(), {"apos": apos}, 1.0) - 1.0 / 2.6) < 1e-9)
check("the curve fades with the 3D view", ns["_kappa"](_SceneStub(), {"apos": apos}, 0.0) == 0.0)

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all taskbar and shape checks passed")
