"""Checks for the Windows library check (pe_check.py) and how the RayNeo SDK loader uses it. Needs no Windows, no Qt
and no network: the files are built in memory, and the download is replaced by a fake that serves a tar archive.
usage: python tools/test_pe_check.py
"""
import io
import os
import platform
import shutil
import struct
import sys
import tarfile
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import pe_check  # noqa: E402
import rayneo_helper as rh  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


def make_pe(machine=0x8664, dll=True, pe_at=0x80):
    """A minimal Windows program header: 'MZ', the PE offset, 'PE\\0\\0' and the 20-byte COFF header."""
    data = bytearray(pe_at + 24 + 0x40)
    data[0:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, pe_at)
    data[pe_at:pe_at + 4] = b"PE\x00\x00"
    characteristics = 0x2022 if dll else 0x0022          # 0x2000 is the DLL bit
    struct.pack_into("<HHIIIHH", data, pe_at + 4, machine, 3, 0, 0, 0, 0xF0, characteristics)
    return bytes(data)


def write(path, data):
    with open(path, "wb") as f:
        f.write(data)


def _check(folder, name, data, bits):
    """Writes data to a file in folder and returns what pe_check says about it (None when it is good)."""
    path = os.path.join(folder, name)
    write(path, data)
    return pe_check.check_library(path, bits)


tmp = tempfile.mkdtemp(prefix="sd_pe_")
try:
    x64 = make_pe(0x8664)
    arm = make_pe(0xAA64)
    x86 = make_pe(0x014C)
    exe = make_pe(0x8664, dll=False)
    html = b"<html><body>404 Not Found</body></html>" + b" " * 60
    macho = b"\xcf\xfa\xed\xfe" + b"\x00" * 120                  # a Mac library's magic number
    cut = bytearray(b"MZ" + b"\x00" * 120)
    struct.pack_into("<I", cut, 0x3C, 10000)                      # the PE header would be past the end

    # ---- what the checker says about each kind of file
    check("a 64-bit DLL is accepted by 64-bit Python", _check(tmp, "x64.dll", x64, 64) is None)
    check("an ARM64 DLL is accepted by 64-bit Python", _check(tmp, "arm.dll", arm, 64) is None)
    why = _check(tmp, "x86.dll", x86, 64)
    check("a 32-bit DLL is refused by 64-bit Python, with the reason",
          why is not None and "32-bit (x86)" in why and "this Python is 64-bit" in why, str(why))
    check("a 32-bit DLL is accepted by 32-bit Python", _check(tmp, "x86b.dll", x86, 32) is None)
    why = _check(tmp, "app.dll", exe, 64)
    check("a program that is not a library is refused", why is not None and "not a library" in why, str(why))
    why = _check(tmp, "page.dll", html, 64)
    check("an HTML page saved as a .dll is refused", why is not None and "not a Windows library" in why, str(why))
    why = _check(tmp, "mac.dll", macho, 64)
    check("a Mac library saved as a .dll is refused", why is not None and "does not start like" in why, str(why))
    why = _check(tmp, "empty.dll", b"", 64)
    check("an empty file is refused", why is not None and "too small" in why, str(why))
    why = _check(tmp, "cut.dll", bytes(cut), 64)
    check("a file cut short is refused", why is not None and "cut short" in why, str(why))
    why = pe_check.check_library(os.path.join(tmp, "nothere.dll"), 64)
    check("a missing file says it is missing", why == "is missing", str(why))

    # ---- saving: only a good library is written, and a good one replaces a bad one
    target = os.path.join(tmp, "saved", "RayNeoSDK.dll")
    os.makedirs(os.path.dirname(target))
    check("save_checked writes a good DLL and reports success",
          pe_check.save_checked(x64, target, 64) is None and open(target, "rb").read() == x64)
    check("save_checked leaves no temporary file behind", not os.path.exists(target + ".part"))
    bad_target = os.path.join(tmp, "saved", "Bad.dll")
    reason = pe_check.save_checked(x86, bad_target, 64)
    check("save_checked refuses a bad DLL and writes nothing",
          reason is not None and not os.path.exists(bad_target) and not os.path.exists(bad_target + ".part"),
          str(reason))
    write(bad_target, html)
    check("save_checked replaces a bad copy with a good one", pe_check.save_checked(x64, bad_target, 64) is None
          and open(bad_target, "rb").read() == x64)

    # ---- the lookup skips a bad copy (Windows is pretended, so the check applies here)
    real_system = platform.system
    real_env = os.environ.get("RAYNEO_SDK_DIR")
    platform.system = lambda: "Windows"
    try:
        sdk = os.path.join(tmp, "lookup")
        os.makedirs(sdk)
        os.environ["RAYNEO_SDK_DIR"] = sdk
        write(os.path.join(sdk, "RayNeoSDK.dll"), x86)
        found = rh.find_library()
        check("the lookup does not return a 32-bit copy on 64-bit Python", found is None, str(found))
        check("the lookup keeps the reason it refused the copy",
              "32-bit (x86)" in rh.LAST_PROBLEM["text"], rh.LAST_PROBLEM["text"])
        write(os.path.join(sdk, "RayNeoSDK.dll"), x64)
        check("the lookup returns a good copy", rh.find_library() == os.path.join(sdk, "RayNeoSDK.dll"))

        # ---- the loader refuses a bad file before Windows is asked to load it (nothing is loaded here)
        write(os.path.join(sdk, "RayNeoSDK.dll"), x86)
        try:
            rh.RayNeoSdk(os.path.join(sdk, "RayNeoSDK.dll"))
            check("the loader refuses a 32-bit DLL", False, "it did not raise")
        except OSError as e:
            check("the loader refuses a 32-bit DLL with a message that says what to do",
                  "32-bit (x86)" in str(e) and "Delete that file" in str(e), str(e))

        # ---- the download keeps only good DLLs (fake download: a tar archive written where urlretrieve would write it)
        def fake_archive(members):
            buf = io.BytesIO()
            with tarfile.open(fileobj=buf, mode="w:gz") as t:
                for name, data in members:
                    info = tarfile.TarInfo(name=f"rayneo-sdk/{name}")
                    info.size = len(data)
                    t.addfile(info, io.BytesIO(data))
            return buf.getvalue()

        real_urlretrieve = rh.urllib.request.urlretrieve

        def serve(payload):
            def fake(url, dest):
                write(dest, payload)
                return dest, None
            rh.urllib.request.urlretrieve = fake

        try:
            dest_dir = os.path.join(tmp, "download")
            os.makedirs(dest_dir)
            os.environ["RAYNEO_SDK_DIR"] = os.path.join(dest_dir, "sdk")
            serve(fake_archive([("RayNeoSDK.dll", x86), ("libusb-1.0.dll", x64)]))
            messages = []
            ok = rh.ensure_sdk(dest_dir, report=messages.append)
            check("a download with only a 32-bit RayNeoSDK.dll does not count as installed", ok is False, str(ok))
            check("the download says which file it skipped and why",
                  any("Skipped RayNeoSDK.dll" in m and "32-bit (x86)" in m for m in messages), str(messages))
            check("the bad file is not left in the sdk folder",
                  not os.path.exists(os.path.join(dest_dir, "sdk", "RayNeoSDK.dll")))

            serve(fake_archive([("RayNeoSDK.dll", x64), ("libusb-1.0.dll", x64)]))
            messages = []
            ok = rh.ensure_sdk(dest_dir, report=messages.append)
            check("a download with a good RayNeoSDK.dll installs it", ok is True
                  and os.path.isfile(os.path.join(dest_dir, "sdk", "RayNeoSDK.dll")), str(messages))
        finally:
            rh.urllib.request.urlretrieve = real_urlretrieve
    finally:
        platform.system = real_system
        if real_env is None:
            os.environ.pop("RAYNEO_SDK_DIR", None)
        else:
            os.environ["RAYNEO_SDK_DIR"] = real_env
finally:
    shutil.rmtree(tmp, ignore_errors=True)

print()
if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all library checks passed")
