"""Every button on every screen must do something. Opens the home screen, the window picker, the settings
pages, the calibration sheet and the control centre, and fails if a visible button has no click, press
or toggle handler. The calendar and PC cards are display-only and are skipped on purpose.
usage: python tools/test_buttons.py   (needs PySide6 and a display, or QT_QPA_PLATFORM=offscreen)"""
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from PySide6.QtWidgets import QApplication, QAbstractButton
app = QApplication(sys.argv[:1])
import spatial_desk as sd


class FakeGrab:
    def __init__(self, kind, ident, fps=24):
        self.kind, self.ident, self.error = kind, ident, None
    def latest(self): return 1, np.zeros((400, 640, 4), np.uint8)
    def has_picture(self): return True
    def age(self): return 10.0
    def stop(self): pass


sd.Grabber = FakeGrab
DISPLAY_ONLY = {"calendar", "pc"}
failures = []
checked = 0


def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        app.processEvents()
        time.sleep(0.02)


def handled(b):
    return any(b.receivers(sig) for sig in ("2clicked(bool)", "2pressed()", "2toggled(bool)"))


def audit(w, screen):
    global checked
    for b in w.findChildren(QAbstractButton):
        if not b.isVisible():
            continue
        if getattr(b, "kind", None) in DISPLAY_ONLY:
            continue
        checked += 1
        if not handled(b):
            label = b.text() or b.toolTip() or type(b).__name__
            failures.append(f"{screen}: '{label}' has no handler")


w = sd.MainWindow()
w.resize(1280, 800)
w.show()
end = time.time() + 20
while w.intro_running and time.time() < end:
    pump(0.1)
pump(0.5)
w.add_source("screen", 0, "App 1")
w.add_source("screen", 1, "App 2")
pump(0.5)

audit(w, "home")
w.toggle_home(); pump(0.5)
audit(w, "home (on)")
w.open_picker(); pump(0.5)
audit(w, "window picker")
w.sheet.hide(); pump(0.3)
w.open_settings(); pump(0.5)
audit(w, "settings")
for name, page in (("glasses", w._settings_glasses_page), ("theme", w._settings_theme_page),
                   ("immersiveness", w._settings_fov_page), ("arrangement", w._settings_arrangement_page),
                   ("keyboard shortcuts", w._settings_keys_page), ("about", w._settings_about_page)):
    w._settings_push(page()); pump(0.4)
    audit(w, f"settings > {name}")
w.sheet.hide(); pump(0.3)
w.open_calibration(); pump(0.5)
audit(w, "calibration")
w.sheet.hide(); pump(0.3)
w.open_quick_settings(); pump(0.5)
audit(w, "control centre")

for f in failures:
    print("FAIL", f)
print(f"checked {checked} buttons, {len(failures)} without a handler")
print(f"RESULT {'PASS' if not failures else 'FAIL'}")
os._exit(0 if not failures else 1)
