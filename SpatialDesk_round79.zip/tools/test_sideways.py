"""Checks for sliding a window sideways around you (Shift + scroll over it).

Needs only numpy, not PySide6. The real functions are read from spatial_desk.py with `ast`
and run against small stand-ins for the parts that need Qt or OpenGL.

usage: python tools/test_sideways.py
"""
import ast
import math
import os
import textwrap

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(HERE, "..", "spatial_desk.py")
with open(SRC_PATH, encoding="utf-8") as f:
    SRC = f.read()
TREE = ast.parse(SRC)

CONST_NAMES = {"PANEL_W", "DEFAULT_DIST", "EXPAND_FACTOR", "LAYOUT_GAP", "LAYOUTS",
               "CODE_MAIN_MIN_DIST", "CODE_SIDE_MIN_DIST", "MAX_BEARING", "MIN_DIST", "MAX_DIST",
               "MIN_SIZE", "MAX_SIZE", "VIEW_FILL", "RATIOS"}
SCENE_METHODS = {"relayout", "_half_width_at", "_angle_for", "_set_space", "_panel_width", "_max_width_for",
                 "_fit_width", "_fit_row", "_screen_of"}
MAIN_METHODS = {"turn_panel", "resize_panel", "set_layout", "_on_wheel"}

class _FakeLog:
    def info(self, *args, **kwargs):
        pass


class _FakeRH:
    log = _FakeLog()


ns = {"math": math, "np": np, "rh": _FakeRH()}


def _target_names(node):
    names = []
    for t in node.targets:
        if isinstance(t, ast.Name):
            names.append(t.id)
        elif isinstance(t, ast.Tuple):
            names += [e.id for e in t.elts if isinstance(e, ast.Name)]
    return names


# Module-level constants used by the functions under test.
for node in TREE.body:
    if isinstance(node, ast.Assign) and set(_target_names(node)) & CONST_NAMES:
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)


def _class_from(class_name, wanted):
    """Build a plain Python class holding the named methods, copied from spatial_desk.py."""
    cls_node = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == class_name)
    parts = []
    for fn in cls_node.body:
        if isinstance(fn, ast.FunctionDef) and fn.name in wanted:
            decs = ["@" + ast.get_source_segment(SRC, d) for d in fn.decorator_list]
            seg = ast.get_source_segment(SRC, fn)
            parts.append(textwrap.indent("\n".join(decs + [seg]), "    "))
    code = f"class Stub{class_name}:\n" + "\n\n".join(parts) + "\n"
    exec(compile(code, f"<{class_name} extract>", "exec"), ns)
    return ns[f"Stub{class_name}"]


SceneStub = _class_from("Scene", SCENE_METHODS)
SceneStub.width = lambda self: 1600
SceneStub.height = lambda self: 900
SceneStub.update = lambda self: None

MainStub = _class_from("MainWindow", MAIN_METHODS)


class RecordingScene(SceneStub):
    def __init__(self, layout):
        self.panels = []
        self.layout_name = layout
        self.fov = 62.0
        self.reserved_right = 0
        self.relayouts = 0
        self.warps = []

    def relayout(self):
        self.relayouts += 1
        SceneStub.relayout(self)

    def kick_warp(self, amount, dur=0.2):
        self.warps.append(amount)

    def set_layout(self, name):
        self.layout_name = name
        self.relayout()


def make_scene(layout, n=3):
    s = RecordingScene(layout)
    for k in range(n):
        s.panels.append({"name": f"App {k + 1}", "dist": ns["DEFAULT_DIST"], "expanded": False})
    s.relayout()
    return s


def centre_of(p):
    x, _y, z = p["space"]
    return math.atan2(float(x), -float(z))


def centres(s):
    return [centre_of(p) for p in s.panels]


failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# 1. Arc (ring) layout: one window slides, the others stay put, and the moved window still faces you.
for layout in ("wide", "focus"):
    s = make_scene(layout)
    base = centres(s)
    s.panels[1]["bearing"] = 0.3
    s.relayout()
    now = centres(s)
    moved = now[1] - base[1]
    others = max(abs(now[0] - base[0]), abs(now[2] - base[2]))
    check(f"{layout}: middle window moves by the bearing", abs(moved - 0.3) < 1e-6, f"moved {moved:.6f}")
    check(f"{layout}: other windows stay where they were", others < 1e-6, f"max change {others:.6f}")
    facing = max(abs(p["rot_space"] + centre_of(p)) for p in s.panels)
    check(f"{layout}: every window still turns to face you", facing < 1e-6, f"off by {facing:.6f}")

# 2. Stage layout: a side window slides; the main window does not move.
s = make_scene("code")
s.panels[0]["expanded"] = True
s.relayout()
base = centres(s)
s.panels[2]["bearing"] = -0.4
s.relayout()
now = centres(s)
check("stage: side window slides by the bearing", abs((now[2] - base[2]) + 0.4) < 1e-6,
      f"moved {now[2] - base[2]:.6f}")
check("stage: main window does not move", abs(now[0] - base[0]) < 1e-6)
check("stage: the other side window does not move", abs(now[1] - base[1]) < 1e-6)

# 3. Layers: the bearing shifts the window sideways without changing its depth.
s = make_scene("layers")
base_d = [float(np.linalg.norm([p["space"][0], p["space"][2]])) for p in s.panels]
base = centres(s)
s.panels[1]["bearing"] = 0.25
s.relayout()
now = centres(s)
depth = [float(np.linalg.norm([p["space"][0], p["space"][2]])) for p in s.panels]
check("layers: window slides by the bearing", abs((now[1] - base[1]) - 0.25) < 1e-6,
      f"moved {now[1] - base[1]:.6f}")
check("layers: depth of every window is unchanged", max(abs(a - b) for a, b in zip(base_d, depth)) < 1e-6)

# 4. The setup row (flat, before 3D mode) ignores the bearing.
s = make_scene("wide")
flat_before = [p["flat"].copy() for p in s.panels]
s.panels[0]["bearing"] = 1.0
s.relayout()
flat_after = [p["flat"] for p in s.panels]
check("setup row ignores the sideways place",
      all(np.allclose(a, b) for a, b in zip(flat_before, flat_after)))

# 4b. Size: a window's width follows its size, in every arrangement, and the rest keep their size.
def widths_of(s):
    return [float(p["w_space"]) for p in s.panels]


s = make_scene("layers")
base = widths_of(s)
s.panels[1]["size"] = 1.3
s.relayout()
now = widths_of(s)
check("layers: sized window is 1.3 times wider", abs(now[1] / base[1] - 1.3) < 1e-6, f"ratio {now[1] / base[1]:.6f}")
check("layers: other windows keep their width", abs(now[0] - base[0]) < 1e-6 and abs(now[2] - base[2]) < 1e-6)

s = make_scene("wide")
before = widths_of(s)
s.panels[1]["size"] = 1.3
s.relayout()
after = widths_of(s)
check("arc: sized window is 1.3 times wider than its neighbour",
      abs((after[1] / after[0]) / (before[1] / before[0]) - 1.3) < 1e-6)

s = make_scene("code")
s.panels[0]["expanded"] = True
s.relayout()
before = widths_of(s)
s.panels[2]["size"] = 1.3
s.relayout()
after = widths_of(s)
check("stage: sized side window is 1.3 times wider than the other side window",
      abs((after[2] / after[1]) / (before[2] / before[1]) - 1.3) < 1e-6)

s = make_scene("focus")
before = [float(p["w_flat"]) for p in s.panels]
s.panels[1]["size"] = 1.3
s.relayout()
after = [float(p["w_flat"]) for p in s.panels]
check("setup row: sized window is 1.3 times wider than its neighbour",
      abs((after[1] / after[0]) / (before[1] / before[0]) - 1.3) < 1e-6)

# 4c. resize_panel: clamps at both ends and does nothing once at a limit.
m = MainStub()
m.scene = make_scene("layers")
m.panels = m.scene.panels
m._refresh_list = lambda: None
m.resize_panel(0, 10.0)
check("resize_panel clamps at MAX_SIZE", abs(m.panels[0]["size"] - ns["MAX_SIZE"]) < 1e-9,
      f"got {m.panels[0]['size']}")
warps = len(m.scene.warps)
m.resize_panel(0, 1.2)
check("resize_panel does nothing once at the largest size", len(m.scene.warps) == warps)
m.resize_panel(0, 1e-6)
check("resize_panel clamps at MIN_SIZE", abs(m.panels[0]["size"] - ns["MIN_SIZE"]) < 1e-9)
m.resize_panel(9, 2.0)  # no such window: must not raise
check("resize_panel ignores a missing window", True)

# 5. turn_panel: moves, clamps at both ends, ignores tiny moves, and checks the index.
m = MainStub()
m.panels = []
m.scene = make_scene("wide")
m.panels = m.scene.panels
m._refresh_list = lambda: None
m.turn_panel(0, 0.2)
check("turn_panel moves the window", abs(m.panels[0]["bearing"] - 0.2) < 1e-9)
m.turn_panel(0, 100.0)
check("turn_panel clamps at +MAX_BEARING", abs(m.panels[0]["bearing"] - ns["MAX_BEARING"]) < 1e-9,
      f"got {m.panels[0]['bearing']}")
before = len(m.scene.warps)
m.turn_panel(0, 0.5)
check("turn_panel does nothing once at the limit", len(m.scene.warps) == before)
m.turn_panel(0, -100.0)
check("turn_panel clamps at -MAX_BEARING", abs(m.panels[0]["bearing"] + ns["MAX_BEARING"]) < 1e-9)
m.turn_panel(7, 0.1)  # no such window: must not raise
check("turn_panel ignores a missing window", True)

# 6. Choosing a preset arrangement puts every window back in its own place.
m.layout_name = "wide"
m.layout_buttons = {}
m._update_layout_button = lambda: None
m._save = lambda: None
m.toast = lambda msg: None
for p in m.panels:
    p["bearing"] = 0.7
    p["size"] = 1.3
m.set_layout("code")
check("choosing an arrangement clears the sideways places",
      all("bearing" not in p for p in m.panels))
check("choosing an arrangement also resets each window's size",
      all("size" not in p for p in m.panels))
check("choosing an arrangement still changes the layout", m.scene.layout_name == "code")

# 7. Shift + scroll is routed to the sideways move; a plain scroll still pulls or pushes.
class Routed(MainStub):
    def __init__(self):
        self.calls = []
        self.panels = [{"name": "A"}, {"name": "B"}]
        self.scene = type("S", (), {"pick": lambda _s, x, y: ("body", 1, 0.5, 0.5)})()

    def _focus(self, p):
        self.calls.append(("focus", p["name"]))

    def turn_panel(self, index, delta):
        self.calls.append(("turn", index, round(delta, 6)))

    def resize_panel(self, index, factor):
        self.calls.append(("resize", index, round(factor, 6)))

    def nudge_panel(self, index, delta, warp=0.45):
        self.calls.append(("nudge", index, round(delta, 6)))


r = Routed()
r._on_wheel(10, 10, 120, "sideways")
check("Shift + scroll slides the window", ("turn", 1, -0.05) in r.calls, str(r.calls))
r3 = Routed()
r3._on_wheel(10, 10, 120, "size")
check("Ctrl + scroll resizes the window", ("resize", 1, 1.06) in r3.calls, str(r3.calls))
r4 = Routed()
r4._on_wheel(10, 10, -120, "size")
check("Ctrl + scroll down makes it smaller", ("resize", 1, 0.94) in r4.calls, str(r4.calls))
r2 = Routed()
r2._on_wheel(10, 10, 120)
check("plain scroll still pulls the window closer", ("nudge", 1, -0.15) in r2.calls, str(r2.calls))

# 8. A minimised window takes no place: the others are laid out as if it were not there.
s3 = make_scene("wide", 3)
s3.panels[1]["hidden"] = True
s3.relayout()
s2 = make_scene("wide", 2)
two = centres(s2)
check("minimised window leaves the others where two windows would put them",
      abs(centre_of(s3.panels[0]) - two[0]) < 1e-6 and abs(centre_of(s3.panels[2]) - two[1]) < 1e-6)

# ---- windows stay inside the view's height: a tall shape (Portrait, or a tall app) is narrowed, not run off the screen
# The room's vertical view: half the height at distance d is tan(fov / 2) * d. A frame may use VIEW_FILL of that height.
def frame_limit(fov, dist):
    return ns["VIEW_FILL"] * 2.0 * math.tan(math.radians(fov) / 2.0) * dist

fov = 62.0
scene = RecordingScene("focus")
land = scene._panel_width({"ratio": "landscape", "dist": ns["DEFAULT_DIST"]})
check("a default landscape window keeps its normal width", abs(land - ns["PANEL_W"]) < 1e-9, str(land))
por = scene._panel_width({"ratio": "portrait", "dist": ns["DEFAULT_DIST"]})
check("a Portrait window is narrowed so it fits the view's height (it used to fill the whole screen)",
      por < ns["PANEL_W"] and por * (16 / 9) <= frame_limit(fov, ns["DEFAULT_DIST"]) + 1e-9, f"width {por}")
sq = scene._panel_width({"ratio": "auto", "aspect": 1.0, "dist": ns["DEFAULT_DIST"]})
check("a square app is narrowed to fit the view's height too", sq * 1.0 <= frame_limit(fov, ns["DEFAULT_DIST"]) + 1e-9,
      f"width {sq}")
check("a window is never wider than its normal width", all(
    scene._panel_width({"ratio": r, "aspect": a, "dist": 2.0}) <= ns["PANEL_W"] + 1e-9
    for r in ("auto", "landscape", "widescreen", "portrait") for a in (0.3, 0.56, 1.0, 1.8)))
# every window in a row stays inside the view, whatever its shape
tall = RecordingScene("focus")
tall.panels = [{"name": f"P{k}", "dist": ns["DEFAULT_DIST"], "expanded": False, "ratio": r}
               for k, r in enumerate(("portrait", "landscape", "portrait"))]
tall.relayout()
inside = True
for p in tall.panels:
    hr = {"portrait": 16 / 9, "landscape": 9 / 16}[p["ratio"]]
    inside = inside and p["w_flat"] * hr <= frame_limit(fov, ns["DEFAULT_DIST"]) + 1e-9
check("a row with tall windows keeps every frame inside the view's height", inside)

# ---- round 70: the window that filled the view (a row that was too wide was left alone)
fit = RecordingScene("focus")
row_w, row_gap = fit._fit_row([2.8] * 8, 1.2, 0.18)
check("a row of eight windows always fits the usable width",
      sum(row_w) + row_gap * 7 <= 1.2 + 1e-9, f"{sum(row_w) + row_gap * 7:.3f}")
one_w, _ = fit._fit_row([4.5], 1.7, 0.18)
check("one window wider than the space is shrunk to it", one_w[0] <= 1.7 + 1e-9, f"{one_w[0]:.3f}")
norm_w, norm_gap = fit._fit_row([2.8, 2.8, 2.8], 20.0, 0.18)
check("a normal row keeps its widths and its gap", norm_w == [2.8, 2.8, 2.8] and abs(norm_gap - 0.18) < 1e-12)

close = RecordingScene("focus")
close.panels = [{"name": f"C{k}", "dist": ns["MIN_DIST"], "expanded": False} for k in range(6)]
close.panels[0]["expanded"] = True
close.relayout()
half_close = close._half_width_at(ns["MIN_DIST"])
edge = max(abs(p["flat"][0]) + p["w_flat"] / 2.0 for p in close.panels)
check("six windows with the first pulled close stay inside the row's width",
      edge <= half_close + 1e-9, f"edge {edge:.3f} half {half_close:.3f}")
check("no window is wider than the whole row when the first is pulled close",
      max(p["w_flat"] for p in close.panels) <= 2.0 * half_close + 1e-9)

tallish = fit._fit_width(6.0, ns["DEFAULT_DIST"])
check("a window whose app turned very tall is kept inside the view's height",
      tallish * 6.0 <= frame_limit(fov, ns["DEFAULT_DIST"]) + 1e-9, f"{tallish * 6.0:.3f}")
src_now = open(SRC_PATH, encoding="utf-8").read()
check("the draw step clamps each window to the view's height (_fit_width)", "_fit_width(hr, view_dist)" in src_now)
check("a change of capture shape re-fits the layout before the next frame",
      "self._layout_dirty = True" in src_now and "self.relayout()" in src_now)

# ---- round 72: the focus rest point is where pick() would find the same spot in the room
cam = RecordingScene("focus")
cam._last_view = np.eye(4)
mid = cam._screen_of((0.0, 0.0, -2.6))
check("the middle of a window straight ahead is the middle of the view", mid is not None and abs(mid[0] - 800) < 1e-6 and abs(mid[1] - 450) < 1e-6, str(mid))
roundtrip_ok = True
worst = 0.0
for px, py in ((100, 80), (1500, 120), (640, 700), (1200, 450)):
    W, H, tan_h = 1600.0, 900.0, math.tan(math.radians(62.0) / 2.0)
    d = np.array([(2.0 * px / W - 1.0) * tan_h * (W / H), (1.0 - 2.0 * py / H) * tan_h, -1.0])
    spot = cam._screen_of(d * 2.6)
    worst = max(worst, abs(spot[0] - px), abs(spot[1] - py))
check("the room-to-screen mapping undoes the pick mapping (within a pixel)", worst < 1.0, f"worst {worst:.4f}")
behind = cam._screen_of((0.0, 0.0, 1.0))
check("a point behind the camera has no place on the screen", behind is None)

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all sideways checks passed")
