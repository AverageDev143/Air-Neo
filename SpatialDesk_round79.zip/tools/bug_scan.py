"""Static bug scan for the app's Python files. Reads the code only; nothing is run.

Checks:
  unreachable   statements that can never run (after return, raise, continue or break in the same block)
  duplicate     a function or method defined twice in the same scope (the later one silently wins)
  undefined     a name that is used but never bound anywhere in the file and is not a builtin
  unset-attr    self.NAME is read but never assigned, and is not a method (Qt base-class methods are listed separately)
  bare-except   'except:' with no exception type (hides errors such as KeyboardInterrupt)
  mutable-default  a list, dict or set used as a default argument (shared between calls)

usage: python tools/bug_scan.py [files...]     (default: the app's Python files)
exit code 1 when any finding is reported.
"""
import ast
import builtins
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
DEFAULT = ["spatial_desk.py", "depth_model.py", "platform_support.py", "rayneo_helper.py", "run.py",
           "airneo_core.py", "airneo_ui.py", "dock_profiles.py", "tuner_ui.py", "login_ui.py", "accounts_core.py",
           "pointer_art.py", "pe_check.py", "wg_install.py"]
TERMINAL = (ast.Return, ast.Raise, ast.Continue, ast.Break)
QT_BASE_METHODS = {
    "destroyed", "showMinimized", "showMaximized", "raise_", "activateWindow", "update", "width", "height", "rect", "size", "resize", "move", "show", "hide", "close", "raise_", "setGeometry",
    "geometry", "isVisible", "setVisible", "setStyleSheet", "setFixedSize", "setFixedHeight", "setFixedWidth",
    "setMinimumSize", "setMinimumHeight", "setMinimumWidth", "setMaximumSize", "setLayout", "layout", "setObjectName",
    "setAttribute", "setCursor", "setFocusPolicy", "setFocus", "grab", "mapTo", "mapFrom", "window", "palette",
    "setPalette", "font", "setFont", "setToolTip", "setText", "text", "setChecked", "isChecked", "setCheckable",
    "setEnabled", "isEnabled", "setWindowTitle", "setWindowFlags", "winId", "devicePixelRatioF", "isFullScreen",
    "showNormal", "showFullScreen", "showMaximized", "setAutoFillBackground", "setSizePolicy", "sizeHint", "parent",
    "findChildren", "findChild", "installEventFilter", "removeEventFilter", "deleteLater", "setWindowOpacity",
    "setProperty", "property", "style", "setContentsMargins", "setSpacing", "addWidget", "addLayout", "addStretch",
    "setWordWrap", "setAlignment", "setPixmap", "setIcon", "setIconSize", "setChecked", "setValue", "value", "setRange",
    "setSingleStep", "setSuffix", "setPlaceholderText", "setCursorPosition", "setTabOrder", "setDefault", "isDown",
    "underMouse", "hasFocus", "clearFocus", "repaint", "adjustSize", "mapToGlobal", "mapFromGlobal", "setWindowModality",
    "setMask", "clearMask", "setSelectionMode", "setDragEnabled", "setItemDelegate", "setModel", "setSortingEnabled",
    "setClearButtonEnabled", "setFrame", "setTextFormat", "setScaledContents", "setSizeAdjustPolicy", "setDuration",
    "setEasingCurve", "setStartValue", "setEndValue", "start", "stop", "setInterval", "setSingleShot", "isActive",
    "setCurrentIndex", "currentIndex", "setCurrentText", "setOpenExternalLinks", "setTextInteractionFlags",
    "setHorizontalScrollBarPolicy", "setVerticalScrollBarPolicy", "setWidgetResizable", "setWidget", "ensureVisible",
    "setDirection", "setStretch", "setAccessibleName", "setTabletTracking", "setMouseTracking", "setAcceptDrops",
    "addAction", "addSeparator", "exec", "popup", "close", "setTitle", "setModal", "setWindowIcon", "keyPressEvent",
    "keyReleaseEvent", "mousePressEvent", "mouseMoveEvent", "mouseReleaseEvent", "wheelEvent", "paintEvent",
    "resizeEvent", "showEvent", "hideEvent", "closeEvent", "moveEvent", "changeEvent", "eventFilter", "event",
    "initializeGL", "paintGL", "resizeGL", "makeCurrent", "doneCurrent", "context", "format", "setFormat",
    "isValid", "isNull", "isEmpty", "ensurePolished", "unpolish", "polish", "lower", "activateWindow", "setFocusProxy",
    "setFrameShape", "setFrameShadow", "setLineWidth", "setStyle", "setTabsClosable", "setDocumentMode",
    "setUsesScrollButtons", "setMovable", "setTabPosition", "setCurrentWidget", "currentWidget", "addTab", "insertTab",
    "count", "widget", "indexOf", "setItemText", "setItemIcon", "addItem", "addItems", "clear", "setPlainText",
    "toPlainText", "setReadOnly", "setLineWrapMode", "setPlaceholder", "setHtml", "setEchoMode", "selectAll", "insert",
    "setSelection", "setCompleter", "setValidator", "setInputMask", "setAcceptRichText", "setTabStopDistance",
    "setDisabled", "setHidden", "setStatusTip", "setShortcut", "setShortcutContext", "setMenuRole", "setData", "data",
    "setPos", "setTransform", "setRotation", "setScale", "setOpacity", "setZValue", "setFlag", "setFlags", "setCursor",
    "setBrush", "setPen", "brush", "pen", "setRenderHint", "drawText", "fillRect", "begin", "end", "save", "restore",
    "translate", "rotate", "scale", "setTransformationMode", "setTimeoutDuration", "requestActivate", "setHeaderHidden",
    "setColumnWidth", "setRowHeight", "setAlternatingRowColors", "setRootIsDecorated", "setIndentation", "setUniformRowHeights",
    "setFocusPolicy", "setSpan", "setHorizontalHeaderLabels", "setVerticalHeaderLabels", "horizontalHeader", "verticalHeader",
    "setCellWidget", "setItem", "setRowCount", "setColumnCount", "setDragDropMode", "setDefaultDropAction",
    "setTextVisible", "setEditable", "setModelColumn", "setView", "view", "setMaxVisibleItems", "setFrame", "setLabel",
    "setSpacing", "setStretchFactor", "setBackgroundRole", "setForegroundRole", "setAutoScroll", "setAnimated", "setSection",
    "rowCount", "columnCount", "model", "selectionModel", "setContextMenuPolicy", "customContextMenuRequested", "emit",
    "connect", "disconnect", "blockSignals", "objectName", "setCheckState", "checkState", "setTristate", "isTristate",
    "setFileMode", "setNameFilter", "setDirectory", "selectedFiles", "setAcceptMode", "setLabelText", "setCancelButtonText",
    "setOkButtonText", "setDefaultButton", "addButton", "buttonRole", "setStandardButtons", "standardButtons", "button",
    "setHorizontalPolicy", "setVerticalPolicy", "setHorizontalStretch", "setVerticalStretch", "setScrollable", "setStepType",
    "setWrapping", "setKeyboardTracking", "setButtonSymbols", "setAccelerated", "setDecimals", "setDisplayIntegerBase",
    "setTickPosition", "setTickInterval", "setOrientation", "setPageStep", "setSliderPosition", "sliderPosition",
    "setTrackingEnabled", "setSubControls", "setLocale", "setTimeSpec", "setDisplayFormat", "setDate", "setTime",
    "setMinimumDate", "setMaximumDate", "setCalendarPopup", "setSpecialValueText", "setStepEnabled", "setWordWrap",
    "setDropDuplicates", "setInsertPolicy", "setModelColumn", "setMaxLength", "setMaxCount", "addItemWithData", "findText",
    "findData", "setCurrentIndexChanged", "setCurrentTextChanged", "setTextChanged", "setGroupName", "setExclusive",
    "setAutoExclusive", "setAutoRepeat", "setAutoRepeatDelay", "setAutoRepeatInterval", "setDown", "setArrowType",
    "setPopupMode", "setMenu", "showMenu", "setDefaultAction", "setToolButtonStyle", "setCheckedState", "setStatus",
    "setSeparatorsCollapsible", "setChildrenCollapsible", "setOpaqueResize", "setHandleWidth", "sizes", "setSizes",
    "setStretchFactor", "indexAt", "setScrollBarPolicy", "setStyleStrategy", "setPointSize", "setPointSizeF",
    "setFamily", "setBold", "setItalic", "setWeight", "setLetterSpacing", "setCapitalization", "setKerning",
}
BUILTIN_NAMES = set(dir(builtins)) | {"__file__", "__name__"}


def scan_file(path):
    findings = []
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src, filename=path)
    rel = os.path.relpath(path, ROOT)

    def report(kind, lineno, msg):
        findings.append((rel, lineno, kind, msg))

    # unreachable statements and bare excepts
    for node in ast.walk(tree):
        for field in ("body", "orelse", "finalbody"):
            block = getattr(node, field, None)
            if not isinstance(block, list):
                continue
            for k, stmt in enumerate(block[:-1]):
                if isinstance(stmt, TERMINAL):
                    nxt = block[k + 1]
                    report("unreachable", nxt.lineno, f"code after {type(stmt).__name__.lower()} on line {stmt.lineno} can never run")
                    break
        if isinstance(node, ast.ExceptHandler) and node.type is None:
            report("bare-except", node.lineno, "bare 'except:' hides every error, including Ctrl+C")

    # duplicate definitions in one scope
    def check_scope(body, owner):
        seen = {}
        for stmt in body:
            if isinstance(stmt, (ast.FunctionDef, ast.ClassDef)):
                if stmt.name in seen:
                    report("duplicate", stmt.lineno, f"'{stmt.name}' is defined again in {owner} (first on line {seen[stmt.name]}); the later one wins")
                seen[stmt.name] = stmt.lineno
    check_scope(tree.body, "the module")
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            check_scope(node.body, f"class {node.name}")

    # mutable default arguments
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.Lambda)):
            defaults = node.args.defaults + [d for d in node.args.kw_defaults if d is not None]
            for d in defaults:
                if isinstance(d, (ast.List, ast.Dict, ast.Set)):
                    report("mutable-default", d.lineno, "a mutable default argument is shared between calls")

    # undefined names: loaded somewhere, bound nowhere in the file, not a builtin
    bound, loaded = set(), {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Name):
            if isinstance(n.ctx, (ast.Store, ast.Del)):
                bound.add(n.id)
            else:
                loaded.setdefault(n.id, n.lineno)
        elif isinstance(n, ast.arg):
            bound.add(n.arg)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound.add(n.name)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                bound.add((a.asname or a.name).split(".")[0])
        elif isinstance(n, ast.ExceptHandler) and n.name:
            bound.add(n.name)
    for name, lineno in loaded.items():
        if name not in bound and name not in BUILTIN_NAMES:
            report("undefined", lineno, f"'{name}' is used but never defined in this file")

    # self attributes read but never set (methods and Qt base-class calls are excluded)
    for cls in (n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)):
        methods = {f.name for f in cls.body if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))}
        # class-level names (constants, signals) are attributes too
        for f in cls.body:
            if isinstance(f, ast.Assign):
                methods |= {t.id for t in f.targets if isinstance(t, ast.Name)}
            elif isinstance(f, ast.AnnAssign) and isinstance(f.target, ast.Name):
                methods.add(f.target.id)
        assigned, reads = set(), {}
        for n in ast.walk(cls):
            if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == "self":
                if isinstance(n.ctx, ast.Store):
                    assigned.add(n.attr)
                else:
                    reads.setdefault(n.attr, n.lineno)
        for name, lineno in reads.items():
            if name in assigned or name in methods:
                continue
            if name in QT_BASE_METHODS:
                continue
            report("unset-attr", lineno, f"self.{name} is read in class {cls.name} but never assigned (check it is set before use)")
    return findings


def main(argv):
    files = argv[1:] or [os.path.join(ROOT, f) for f in DEFAULT]
    findings = []
    for path in files:
        findings += scan_file(path)
    for rel, lineno, kind, msg in sorted(findings):
        print(f"{rel}:{lineno}: [{kind}] {msg}")
    print()
    print(f"{len(findings)} finding(s) in {len(files)} file(s)")
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
