"""Checks for the WireGuard installer (wg_install.py): which installer is picked, the signature gate, the download and
install results, the Homebrew path on a Mac, and the single-run guard. No network and no PowerShell are used: the
download and the PowerShell calls are replaced by fakes.
usage: python tools/test_wg_install.py
"""
import base64
import os
import sys
import threading

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import wg_install as wg  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


INDEX = """
<a href="wireguard-amd64-0.5.3.msi">wireguard-amd64-0.5.3.msi</a>
<a href="wireguard-amd64-0.10.0.msi">wireguard-amd64-0.10.0.msi</a>
<a href="wireguard-amd64-0.9.1.msi">wireguard-amd64-0.9.1.msi</a>
<a href="wireguard-arm64-1.0.1.msi">wireguard-arm64-1.0.1.msi</a>
<a href="wireguard-x86-2.0.0.msi">wireguard-x86-2.0.0.msi</a>
<a href="wireguard-installer.exe">wireguard-installer.exe</a>
"""

# ---- which installer is picked
check("64-bit Intel and AMD get the amd64 installer", wg.msi_arch("AMD64") == "amd64")
check("ARM Windows gets the arm64 installer", wg.msi_arch("ARM64") == "arm64")
check("anything else gets the 32-bit installer", wg.msi_arch("x86") == "x86")
check("an unknown processor falls back to 32-bit, never to a wrong 64-bit file", wg.msi_arch("") == "x86")
picked = wg.latest_msi(INDEX, "amd64")
check("the newest amd64 version is picked, comparing numbers (0.10.0 beats 0.9.1)",
      picked == ("wireguard-amd64-0.10.0.msi", "0.10.0"), str(picked))
check("an ARM computer never gets an amd64 file", wg.latest_msi(INDEX, "arm64")[0] == "wireguard-arm64-1.0.1.msi")
check("the setup .exe is never picked as the installer", "installer" not in str(wg.latest_msi(INDEX, "amd64")))
check("an index without an installer for this computer gives None", wg.latest_msi("nothing here", "amd64") is None)

# ---- the signature gate: only a valid WireGuard LLC signature is run
check("a valid WireGuard LLC signature is accepted",
      wg.is_wireguard_signature("Valid", "CN=WireGuard LLC, O=WireGuard LLC, L=Austin"))
check("an unsigned installer is refused", not wg.is_wireguard_signature("NotSigned", "CN=WireGuard LLC"))
check("a signature from someone else is refused", not wg.is_wireguard_signature("Valid", "CN=Some Other Company"))
check("a tampered signature is refused", not wg.is_wireguard_signature("HashMismatch", "CN=WireGuard LLC"))
check("no signature information is refused", not wg.is_wireguard_signature("", ""))

# ---- the PowerShell commands: the file path arrives in an environment variable, never in the script text
install_text = base64.b64decode(wg.powershell_args(wg.INSTALL_SCRIPT)[-1]).decode("utf-16-le")
check("the install script reads the installer path from the environment", "$env:SD_MSI" in install_text)
check("the install script asks for administrator permission (RunAs)", "-Verb RunAs" in install_text)
check("the install script installs silently without starting WireGuard",
      "DO_NOT_LAUNCH=1" in install_text and "/qn" in install_text)
check("the install script has no path written into it", "C:\\" not in install_text and ".msi'" not in install_text)
args = wg.powershell_args("exit 0")
check("PowerShell gets the script encoded, so nothing is re-parsed",
      args[0] == "powershell.exe" and "-EncodedCommand" in args)

# ---- the install flow, with fakes
calls = {"powershell": []}
real_fetch, real_ps, real_sig, real_brew = wg.fetch, wg.run_powershell, wg._windows_signature_ok, wg._brew_path


def fake_powershell(script, env):
    calls["powershell"].append(script)
    return calls.get("exit", 0), calls.get("output", "")


def run_windows(fetch_bytes, sig_ok=True, exit_code=0, output=""):
    """Runs the Windows install with a fake download. Returns (ok, the messages, the PowerShell scripts run)."""
    messages = []
    calls["powershell"] = []
    calls["exit"] = exit_code
    calls["output"] = output

    def fake_fetch(url, timeout=60):
        return INDEX.encode() if url == wg.INDEX_URL else fetch_bytes

    wg.fetch = fake_fetch
    wg.run_powershell = fake_powershell
    wg._windows_signature_ok = lambda path: (sig_ok, "Valid" if sig_ok else "NotSigned")
    try:
        ok = wg.install("windows", messages.append, machine="AMD64")
    finally:
        wg.fetch, wg.run_powershell, wg._windows_signature_ok = real_fetch, real_ps, real_sig
    return ok, messages, list(calls["powershell"])


big = b"M" * (wg.MIN_MSI_BYTES + 10)
ok, messages, scripts = run_windows(b"<html>not found</html>")
check("a download too small to be an installer is not run", ok is False and not scripts
      and any("too small" in m for m in messages), str(messages))
ok, messages, scripts = run_windows(big, sig_ok=False)
check("an installer that is not signed by WireGuard LLC is not run",
      ok is False and not any(s == wg.INSTALL_SCRIPT for s in scripts) and any("not signed" in m for m in messages),
      str(messages))
ok, messages, scripts = run_windows(big, sig_ok=True, exit_code=0)
check("a signed installer that finishes is reported as installed", ok is True
      and any(s == wg.INSTALL_SCRIPT for s in scripts) and any("installed" in m for m in messages), str(messages))
ok, messages, scripts = run_windows(big, sig_ok=True, exit_code=3010)
check("an install that asks for a restart still counts as installed", ok is True)
ok, messages, scripts = run_windows(big, sig_ok=True, exit_code=1602, output="The user cancelled the install")
check("an install the user cancelled at the permission prompt is reported, not hidden",
      ok is False and any("did not finish" in m and "1602" in m for m in messages), str(messages))
wg.fetch = lambda url, timeout=60: (_ for _ in ()).throw(OSError("no route"))
messages = []
ok = wg.install("windows", messages.append, machine="AMD64")
wg.fetch = real_fetch
check("the download site being unreachable is reported and nothing is run",
      ok is False and any("Could not reach" in m for m in messages), str(messages))

# ---- other systems
messages = []
check("Linux is told plainly that it cannot install this automatically",
      wg.install("linux", messages.append) is False and "cannot install" in messages[0].lower())
wg._brew_path = lambda: None
messages = []
check("a Mac without Homebrew is told to install Homebrew, and nothing is run",
      wg.install("macos", messages.append) is False and "Homebrew" in messages[0])
wg._brew_path = real_brew

# ---- the single-run guard: a second install request while one runs does nothing
gate = threading.Event()
finished = []


def slow_install(os_name, report, machine=None):
    report("working")
    gate.wait(5)
    return True


real_install = wg.install
wg.install = slow_install
try:
    started = wg.start("windows", lambda t: None, lambda ok, last: finished.append((ok, last)))
    second = wg.start("windows", lambda t: None, lambda ok, last: None)
    check("a second install request does not start a second install", started is True and second is False
          and wg.is_running())
    gate.set()
    for _ in range(200):
        if finished:
            break
        threading.Event().wait(0.01)
    check("the finished install reports back once", finished == [(True, "working")], str(finished))
    check("the guard is released when the install ends", not wg.is_running())
finally:
    wg.install = real_install

print()
if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all WireGuard installer checks passed")
