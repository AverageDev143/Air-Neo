"""Checks for the platform detection: which computer, what it can do, and the shortcut labels.
Needs no Qt and no Windows or Mac. usage: python tools/test_platform.py
"""
import os
import platform
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
import platform_support as ps  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


win = ps.detect("Windows", {})
check("Windows: glasses and window capture on", win.glasses and win.window_capture)
check("Windows: shortcuts use Ctrl and Alt", (win.mod_label, win.alt_label) == ("Ctrl", "Alt"))
check("Windows: Wi-Fi opens the Windows page", win.wifi_url == "ms-settings:network-wifi")
check("Windows: local session when not remote", win.remote == "")
check("Windows: remote desktop is detected",
      ps.detect("Windows", {"SESSIONNAME": "RDP-Tcp#3"}).remote == "RDP")
check("Windows: the console is not a remote session",
      ps.detect("Windows", {"SESSIONNAME": "Console"}).remote == "")

mac = ps.detect("Darwin", {})
check("macOS: named macOS", mac.os == "macos" and mac.name == "macOS")
check("macOS: no glasses and no per-window capture yet", not mac.glasses and not mac.window_capture)
check("macOS: shortcuts use Cmd and Option", (mac.mod_label, mac.alt_label) == ("Cmd", "Option"))
check("macOS: Wi-Fi opens System Settings", mac.wifi_url.startswith("x-apple.systempreferences:"))
check("macOS: fonts start with the system font", mac.ui_fonts[0] == "SF Pro Text")
check("macOS: SSH session is detected (SSH_CONNECTION)",
      ps.detect("Darwin", {"SSH_CONNECTION": "10.0.0.2 51000 10.0.0.9 22"}).remote == "SSH")
check("macOS: SSH session is detected (SSH_TTY)", ps.detect("Darwin", {"SSH_TTY": "/dev/ttys001"}).remote == "SSH")
check("macOS: screen sharing alone is not guessed", ps.detect("Darwin", {"DISPLAY": ":0"}).remote == "")

lin = ps.detect("Linux", {})
check("Linux: runs for testing, glasses off", lin.os == "linux" and not lin.glasses and not lin.window_capture)
other = ps.detect("FreeBSD", {})
check("other systems are named and get safe defaults",
      other.os == "other" and other.name == "FreeBSD" and not other.glasses)

auto = ps.detect()
expected = {"Windows": "windows", "Darwin": "macos", "Linux": "linux"}.get(platform.system(), "other")
check("detect() with no arguments reads this computer", auto.os == expected, f"{auto.os} vs {expected}")

# shortcut labels
check("Ctrl becomes Cmd on a Mac", ps.shortcut_label("Ctrl + scroll resizes it", mac) == "Cmd + scroll resizes it")
check("Alt becomes Option on a Mac", ps.shortcut_label("Alt + drag", mac) == "Option + drag")
check("Windows labels are unchanged", ps.shortcut_label("Ctrl + scroll, Alt + drag", win) == "Ctrl + scroll, Alt + drag")
check("Shift and plain keys are unchanged", ps.shortcut_label("Shift + scroll", mac) == "Shift + scroll")
check("words that only contain Ctrl or Alt are left alone",
      ps.shortcut_label("Controller and Altitude", mac) == "Controller and Altitude")
check("every Ctrl in a sentence is replaced",
      ps.shortcut_label("Ctrl + a, then Ctrl + c", mac) == "Cmd + a, then Cmd + c")

# the start-up report
report = ps.startup_report(mac)
check("report names the computer", "Platform: macOS" in report)
check("report says glasses are off on a Mac", "Glasses tracking: off" in report)
check("report says only screens are captured", "Window capture: screens only" in report)
check("report says no remote session when local", "Remote session" not in report)
check("report flags a remote session",
      "Remote session detected (SSH)" in ps.startup_report(ps.detect("Darwin", {"SSH_TTY": "/dev/ttys001"})))
check("Windows report says glasses are on", "Glasses tracking: on" in ps.startup_report(win))

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all platform checks passed")
