"""A real WireGuard connection between two network namespaces, using the configs the app writes.

Needs Linux, root, the 'ip' tool, wireguard-tools and wireguard-go. Without them it prints SKIP and passes, so the
normal checks still run on Windows and macOS. The two namespaces stand in for the Mac and the PC:
  mac  10.66.0.1  listens on UDP 51820
  pc   10.66.0.2  connects to the Mac's address on the virtual cable

What it proves: the configs the app builds connect when the keys match, and do not connect when a key is wrong or
was made again on one side only. It uses the app's own peer check (peer_answers) inside each namespace.

usage: sudo python3 tools/test_tunnel_live.py
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
import airneo_core as core  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


def missing_tools():
    if not sys.platform.startswith("linux") or os.geteuid() != 0:
        return "needs Linux and root"
    for tool in ("ip", "wg", "wg-quick", "wireguard-go", "ping"):
        if shutil.which(tool) is None:
            return f"{tool} is not installed"
    if not os.path.exists("/dev/net/tun"):
        return "no TUN device"
    return None


def ns_run(ns):
    """The app's own run(): the same command, run inside one of the test computers."""
    def run(cmd, **kwargs):
        kwargs.pop("creationflags", None)
        return subprocess.run(["ip", "netns", "exec", ns] + list(cmd), **kwargs)
    return run


ENV = dict(os.environ, WG_QUICK_USERSPACE_IMPLEMENTATION="/usr/bin/wireguard-go")


def sh(*cmd, check_it=True):
    return subprocess.run(list(cmd), check=check_it, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def build_namespaces():
    for ns in ("vbmac", "vbpc"):
        subprocess.run(["ip", "netns", "del", ns], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    sh("ip", "netns", "add", "vbmac")
    sh("ip", "netns", "add", "vbpc")
    sh("ip", "link", "add", "veth-mac", "type", "veth", "peer", "name", "veth-pc")
    sh("ip", "link", "set", "veth-mac", "netns", "vbmac")
    sh("ip", "link", "set", "veth-pc", "netns", "vbpc")
    for ns, dev, addr in (("vbmac", "veth-mac", "192.0.2.1/24"), ("vbpc", "veth-pc", "192.0.2.2/24")):
        sh("ip", "netns", "exec", ns, "ip", "addr", "add", addr, "dev", dev)
        sh("ip", "netns", "exec", ns, "ip", "link", "set", dev, "up")
        sh("ip", "netns", "exec", ns, "ip", "link", "set", "lo", "up")


def remove_namespaces():
    for ns in ("vbmac", "vbpc"):
        subprocess.run(["ip", "netns", "del", ns], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-x", "wireguard-go"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run("rm -f /var/run/wireguard/*.sock", shell=True, stderr=subprocess.DEVNULL)


def bring_up(mac_conf, pc_conf):
    """Writes the two configs as the app does (named airneo.conf on each computer; the test names them apart,
    because both computers share one socket folder here) and brings each side up with wg-quick."""
    folder = tempfile.mkdtemp(prefix="vb_live_")
    os.makedirs(f"{folder}/mac")
    os.makedirs(f"{folder}/pc")
    mac_path, pc_path = f"{folder}/mac/airmac.conf", f"{folder}/pc/airpc.conf"
    open(mac_path, "w").write(mac_conf)
    open(pc_path, "w").write(pc_conf)
    os.chmod(mac_path, 0o600)
    os.chmod(pc_path, 0o600)
    subprocess.run("rm -f /var/run/wireguard/*.sock", shell=True, stderr=subprocess.DEVNULL)
    subprocess.run(["ip", "netns", "exec", "vbmac", "wg-quick", "up", mac_path], env=ENV,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["ip", "netns", "exec", "vbpc", "wg-quick", "up", pc_path], env=ENV,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return mac_path, pc_path


def tear_down(mac_path, pc_path):
    subprocess.run(["ip", "netns", "exec", "vbpc", "wg-quick", "down", pc_path], env=ENV,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["ip", "netns", "exec", "vbmac", "wg-quick", "down", mac_path], env=ENV,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-x", "wireguard-go"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run("rm -f /var/run/wireguard/*.sock", shell=True, stderr=subprocess.DEVNULL)


def main():
    reason = missing_tools()
    if reason:
        print(f"SKIP  live tunnel test: {reason}")
        return 0
    mac_priv, mac_pub = core.generate_keypair(wg="wg")
    pc_priv, pc_pub = core.generate_keypair(wg="wg")

    def mac_conf(peer_pub):
        return core.build_device_config("mac", mac_priv, mac_pub, peer_pub, "", core.DEFAULT_PORT, None)

    def pc_conf(priv, pub):
        return core.build_device_config("pc", priv, pub, mac_pub, "192.0.2.1", core.DEFAULT_PORT, None)

    try:
        build_namespaces()

        paths = bring_up(mac_conf(pc_pub), pc_conf(pc_priv, pc_pub))
        time.sleep(2)
        check("correct keys: the PC sees the Mac through the tunnel",
              core.peer_answers("macos", core.MAC_IP, run=ns_run("vbpc")))
        check("correct keys: the Mac sees the PC through the tunnel",
              core.peer_answers("macos", core.WIN_IP, run=ns_run("vbmac")))
        tear_down(*paths)

        paths = bring_up(mac_conf(mac_pub), pc_conf(pc_priv, pc_pub))
        time.sleep(2)
        check("the Mac has the wrong key for the PC: no answer, so the app reports waiting",
              not core.peer_answers("macos", core.MAC_IP, run=ns_run("vbpc")))
        tear_down(*paths)

        new_priv, new_pub = core.generate_keypair(wg="wg")
        paths = bring_up(mac_conf(pc_pub), pc_conf(new_priv, new_pub))
        time.sleep(2)
        check("keys made again on the PC but not on the Mac: no answer (the reason this round keeps the key)",
              not core.peer_answers("macos", core.MAC_IP, run=ns_run("vbpc")))
        tear_down(*paths)

        paths = bring_up(mac_conf(new_pub), pc_conf(new_priv, new_pub))
        time.sleep(2)
        check("the Mac is given the new PC key: connected again",
              core.peer_answers("macos", core.MAC_IP, run=ns_run("vbpc")))
        tear_down(*paths)
        # the key is changed on the Mac while the tunnel is up: a restart with the new config connects
        paths = bring_up(mac_conf(mac_pub), pc_conf(pc_priv, pc_pub))
        time.sleep(2)
        check("before the key change: the Mac has the wrong key, so no answer",
              not core.peer_answers("macos", core.WIN_IP, run=ns_run("vbmac")))
        open(paths[0], "w").write(mac_conf(pc_pub))
        os.chmod(paths[0], 0o600)
        subprocess.run(["ip", "netns", "exec", "vbmac", "sh", "-c", core.mac_shell("restart", paths[0]).split("; ", 1)[1]],
                       env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        check("the restart with the new key: the Mac answers the PC through the tunnel",
              core.peer_answers("macos", core.WIN_IP, run=ns_run("vbmac")))
        tear_down(*paths)
    finally:
        remove_namespaces()

    print()
    if failures:
        print(f"{failures} check(s) failed")
        return 1
    print("all live tunnel checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
