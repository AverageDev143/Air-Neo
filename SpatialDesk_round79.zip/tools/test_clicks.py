"""Checks for the routes a click takes into a window (window_clicks.py). Needs only Python, not PySide6 or Windows:
the routing rules are plain functions, and the Windows parts are checked by reading their text.

usage: python tools/test_clicks.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
import window_clicks as wc  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# ---- the route order
check("a text field gets only the real click (it needs real focus)",
      wc.choose_routes("Notepad", "Edit", True) == ["send"])
check("a rich text field gets only the real click",
      wc.choose_routes("WordPad", "RICHEDIT50W", True) == ["send"])
check("a classic button tries a posted message first, then UI Automation, then the real click",
      wc.choose_routes("#32770", "Button", True) == ["post", "uia", "send"])
check("a list in a classic window tries a posted message first",
      wc.choose_routes("CabinetWClass", "SysListView32", True) == ["post", "uia", "send"])
check("a browser never gets posted messages (they are dropped there)",
      wc.choose_routes("Chrome_WidgetWin_1", "Chrome_RenderWidgetHostHWND", True) == ["uia", "send"])
check("a browser's classic-looking child still does not get posted messages",
      wc.choose_routes("Chrome_WidgetWin_1", "Button", True) == ["uia", "send"])
check("a custom-drawn WPF or WinUI window uses UI Automation, then the real click",
      wc.choose_routes("HwndWrapper[App;;abc]", "HwndWrapper[App;;def]", True) == ["uia", "send"])
check("a click on the window itself (no control under the spot) uses UI Automation, then the real click",
      wc.choose_routes("Notepad", "", False) == ["uia", "send"])
check("an unknown control gets UI Automation before the real click",
      wc.choose_routes("Foo", "SomeControl", True) == ["uia", "send"])


# every combination ends with the real click, so a click is always attempted
names = ["", "Edit", "Button", "SysListView32", "Chrome_RenderWidgetHostHWND", "Foo", "RICHEDIT50W"]
ends_ok = True
for w in ("", "Notepad", "Chrome_WidgetWin_1", "#32770"):
    for c in names:
        for has in (False, True):
            routes = wc.choose_routes(w, c, has)
            if not routes or routes[-1] != "send" or any(r not in ("post", "uia", "send") for r in routes):
                ends_ok = False
check("every route list ends with the real click and uses only known routes", ends_ok)
check("the posted-message route is never used without a control under the spot",
      all("post" not in wc.choose_routes("#32770", "Button", False) for _ in range(1)))

# ---- the UI Automation helper script
S = wc.UIA_SCRIPT
check("the helper reads one request per line and answers one word per line",
      "[Console]::In.ReadLine()" in S and "[Console]::Out.WriteLine($answer)" in S)
check("the helper asks the control to act with Invoke, Toggle or Select",
      "InvokePattern" in S and "TogglePattern" in S and "SelectionItemPattern" in S)
check("text fields are reported as 'edit', so the caller uses a real click",
      "ControlType.Edit" in S and "'edit'" in S)
check("the helper stops at the target window, so it never acts outside it",
      "NativeWindowHandle" in S and "ProcessId -ne $owner" in S)
check("the helper sets DPI awareness, so its coordinates match the screen",
      "SetProcessDPIAware" in S)
check("the helper runs with no console window",
      wc.CREATE_NO_WINDOW == 0x08000000)


# ---- speed: no fixed waits on the click path (waits end as soon as Windows has done its part)
import re
spatial = open(os.path.join(HERE, "..", "spatial_desk.py"), encoding="utf-8").read()
window_src = open(os.path.join(HERE, "..", "window_clicks.py"), encoding="utf-8").read()
def body(src, name):
    m = re.search(r"^def " + name + r"\(.*?(?=^def |^class |\Z)", src, re.S | re.M)
    return m.group(0) if m else ""
click_path = body(spatial, "_real_click") + body(spatial, "_uia_click") + body(spatial, "click_window_at")
check("the click path has no fixed wait of 40 ms or more", not re.search(r"sleep\((0\.0[4-9]|0\.[1-9])", click_path + body(spatial, "_activate")))
check("the real click waits 15 ms or less between its steps", "0.012" in body(spatial, "_send_click") and "0.008" in body(spatial, "_send_click"))
check("the posted click waits 15 ms or less between its steps", "sleep(0.005)" in window_src and "sleep(0.012)" in window_src)
check("the helper starts with the app, so the first click does not wait for PowerShell",
      "UIA.warm" in spatial and "def warm" in window_src)
check("the dot follows the mouse every 10 ms", "_dot_timer.start(10)" in spatial)

# ---- bug hunt (round 76): the helper's replies, a stopped helper, and nested controls
class FakeStream:
    def __init__(self, lines=None, on_write=None):
        self.lines = list(lines or [])
        self.written = []
        self.on_write = on_write

    def write(self, text):
        self.written.append(text)
        if self.on_write:
            self.on_write()
        return len(text)

    def flush(self):
        pass

    def readline(self):
        return self.lines.pop(0) if self.lines else ""


class FakeProc:
    def __init__(self, lines=None, on_write=None):
        self.stdin = FakeStream(on_write=on_write)
        self.stdout = FakeStream(lines=lines)
        self.killed = False

    def poll(self):
        return 1 if self.killed else None

    def kill(self):
        self.killed = True


def clicker_with(proc, on_start=None):
    c = wc.UiaClicker()
    c._disabled = False

    def start():
        c._proc = proc
        if on_start:
            on_start(c)
    c._start = start
    return c


proc = FakeProc(lines=["error\n"])
c = clicker_with(proc)
answer = c.invoke(1, 2, 3, 4)
check("a request the helper could not finish is 'error', and the helper is kept (not restarted)",
      answer == "error" and not proc.killed and c._failures == 0, f"answer {answer!r} killed {proc.killed}")

proc = FakeProc(lines=["Warning: something printed first\n", "invoked\n"])
c = clicker_with(proc)
answer = c.invoke(1, 2, 3, 4)
check("text printed before the answer is skipped, not taken as the answer", answer == "invoked", f"answer {answer!r}")

def stop_while_writing(clk):
    clk._proc = None                 # the watchdog clears the helper while the request is being written
    proc2.stdout.lines.clear()       # and the helper's answer never comes (end of output)

proc2 = FakeProc(lines=["invoked\n"], on_write=lambda: stop_while_writing(c2))
c2 = clicker_with(proc2)
try:
    answer = c2.invoke(1, 2, 3, 4)
    crashed = False
except AttributeError:
    answer, crashed = None, True
check("a helper stopped by the watchdog mid-request gives 'error', not a crash",
      not crashed and answer == "error", f"crashed {crashed} answer {answer!r}")

check("the helper announces when it is ready, so start-up noise is not read as an answer",
      "WriteLine('ready')" in wc.UIA_SCRIPT)

# nested controls: a group box holds a button; the click must reach the button, not the box
class FakeUser32:
    def __init__(self, origins, children):
        self.origins = origins          # hwnd -> (left, top) of its client area on screen
        self.children = children        # parent hwnd -> [(child hwnd, (l, t, r, b) on screen)]

    def ScreenToClient(self, hwnd, byref_pt):
        pt = byref_pt._obj
        ox, oy = self.origins[hwnd]
        pt.x -= ox
        pt.y -= oy
        return True

    def ChildWindowFromPointEx(self, parent, pt, flags):
        ox, oy = self.origins[parent]
        sx, sy = pt.x + ox, pt.y + oy
        for child, (l, t, r, b) in self.children.get(parent, []):
            if l <= sx < r and t <= sy < b:
                return child
        return parent                    # no child there: the parent itself, as Windows does

real_flag, real_user32 = wc.IS_WIN, getattr(wc, "user32", None)
wc.IS_WIN = True
wc.user32 = FakeUser32(origins={1: (0, 0), 2: (100, 100), 3: (150, 150)},
                       children={1: [(2, (100, 100, 300, 300))], 2: [(3, (150, 150, 250, 250))]})
try:
    nested = wc.child_at(1, 200, 200)
finally:
    wc.IS_WIN, wc.user32 = real_flag, real_user32
check("a click on a button inside a group box finds the button (the deepest control), not the box",
      nested == 3, f"found {nested}")

# the 2D-screen cursor applies only to the main window's own screens, not to the tuner card or other top-level windows
spatial_text = open(os.path.join(HERE, "..", "spatial_desk.py"), encoding="utf-8").read()
def method_body(src, name):
    i = src.find(f"def {name}(")
    if i < 0:
        return ""
    j = src.find("\n    def ", i + 1)
    return src[i:j if j > 0 else i + 3000]

tick = method_body(spatial_text, "_pointer_tick")
check("the dot and blank cursor apply only to this window's own 2D screens (the window card is one of them)",
      "w.window() is self" in tick, "the tick does not check which window the pointer is over")
check("a click that cannot start its thread does not leave the room ignoring clicks for good",
      "except RuntimeError" in method_body(spatial_text, "_on_click") and "self._click_busy = False" in method_body(spatial_text, "_on_click"))

check("the helper gets longer to start than to answer one request (its first run compiles a little C#)",
      wc.UiaClicker.START_TIMEOUT_S > wc.UiaClicker.TIMEOUT_S >= 3.0)
# ---- off Windows nothing is attempted, and the reason is clear
check("off Windows, the UI Automation helper is not started and answers 'none'",
      (not wc.IS_WIN) and wc.UIA.invoke(1, 1, 10, 10) == "none")
check("off Windows, there is no child window and no class name",
      wc.child_at(1, 10, 10) == 0 and wc.class_name(1) == "" and wc.process_id(1) == 0)
check("off Windows, a posted click is not sent", wc.post_click(1, 1, 10, 10) is False)

print()
if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all click route checks passed")
