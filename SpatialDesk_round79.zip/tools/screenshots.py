"""Saves screenshots of Spatial Desk's screens, so you can check the look.

usage (Windows, with PySide6 and mss installed):   python tools/screenshots.py
The PNG files go in a screenshots folder next to this project.

Widget screens (home, picker, settings and its pages, calibration, control centre, title bar) are grabbed from Qt.
The 3D view is OpenGL, which Qt's grab does not capture reliably, so it is copied from the screen instead: keep the
Spatial Desk window visible and uncovered while the script runs.
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtGui import QColor, QImage, QPainter  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

app = QApplication(sys.argv[:1])
import spatial_desk as sd  # noqa: E402
import mss  # noqa: E402
import mss.tools  # noqa: E402

OUT = os.path.join(HERE, "screenshots")
os.makedirs(OUT, exist_ok=True)
saved = []


def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        app.processEvents()
        time.sleep(0.02)


def save_widget(widget, name):
    path = os.path.join(OUT, name + ".png")
    widget.grab().save(path)
    saved.append(name)


def save_title_bar(name, focused):
    tex = sd.make_title_bar("App", True, focused, sd.DEFAULT_DIST, False)     # the app's own title bar texture
    h, w = tex.shape[:2]
    bar = QImage(tex.data, w, h, 4 * w, QImage.Format.Format_RGBA8888).copy()
    out = QImage(w, h, QImage.Format.Format_ARGB32)
    out.fill(QColor(12, 13, 16))                                               # on a dark background, as in the room
    p = QPainter(out)
    p.drawImage(0, 0, bar)
    p.end()
    out.save(os.path.join(OUT, name + ".png"))
    saved.append(name)


w = sd.MainWindow()
w.resize(1280, 800)
w.show()
end = time.time() + 20
while w.intro_running and time.time() < end:
    pump(0.1)
pump(0.5)
w.add_source("screen", 0, "App 1")
pump(0.8)

save_widget(w, "01_home")
g = w.geometry()
with mss.MSS() as sct:                                                          # the 3D view, from the screen
    shot = sct.grab({"left": g.x(), "top": g.y(), "width": g.width(), "height": g.height()})
    mss.tools.to_png(shot.rgb, shot.size, output=os.path.join(OUT, "02_window_screen.png"))
    saved.append("02_window_screen")

w.open_picker()
pump(0.6)
save_widget(w.sheet, "03_window_picker")
w.sheet.hide()
pump(0.3)

w.open_settings()
pump(0.6)
save_widget(w.sheet, "04_settings")
pages = (("05_settings_glasses", w._settings_glasses_page), ("06_settings_theme", w._settings_theme_page),
         ("07_settings_immersiveness", w._settings_fov_page), ("08_settings_arrangement", w._settings_arrangement_page),
         ("09_settings_shortcuts", w._settings_keys_page), ("10_settings_about", w._settings_about_page))
for name, page in pages:
    w._settings_push(page())
    pump(0.5)
    save_widget(w.sheet, name)
w.sheet.hide()
pump(0.3)

w.open_calibration()
pump(0.6)
save_widget(w.sheet, "11_calibration")
w.sheet.hide()
pump(0.3)

w.open_quick_settings()
pump(0.6)
save_widget(w.sheet, "12_control_centre")
w.sheet.hide()

save_title_bar("13_title_bar_focused", True)
save_title_bar("14_title_bar_unfocused", False)

print("saved to", OUT)
for name in saved:
    print("  ", name + ".png")
os._exit(0)
