"""The login screen, driven the way a person drives it. Run: python tools/test_login_flow.py  (needs PySide6)

Every step uses real clicks and typing on the widgets, against a scratch accounts file. A relaunch is a new LoginGate
on the same file, which is what starting the app again does. Nothing here touches your real accounts.
"""
import json
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
os.environ.setdefault("SPATIAL_DESK_DATA", tempfile.mkdtemp(prefix="sd-login-test-"))

from PySide6.QtCore import Qt, QCoreApplication   # noqa: E402
from PySide6.QtTest import QTest                  # noqa: E402
from PySide6.QtWidgets import QApplication, QLabel, QPushButton   # noqa: E402

import accounts_core as ac                        # noqa: E402
import login_ui                                   # noqa: E402
from login_ui import AccountCard, LoginGate       # noqa: E402

app = QApplication.instance() or QApplication([])
failures = 0
results = []


def check(name, ok, detail=""):
    global failures
    results.append((name, bool(ok)))
    if not ok:
        failures += 1
    print(("PASS  " if ok else "FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""))


def pump(ms=30):
    QTest.qWait(ms)
    QCoreApplication.processEvents()


def show(gate):
    gate.resize(1000, 760)
    gate.show()
    QTest.qWaitForWindowExposed(gate)
    pump(150)


def click(widget):
    QTest.mouseClick(widget, Qt.MouseButton.LeftButton)
    pump(60)


def type_into(field, text):
    field.setFocus()
    field.clear()
    QTest.keyClicks(field, text)
    pump(20)


def cards(gate):
    return gate.cards_host.findChildren(AccountCard)


def card_name(card):
    """The name shown on a card: it is in a child label, not in the button's own text."""
    labels = [lab.text() for lab in card.findChildren(QLabel) if lab.objectName() == "gateName"]
    return labels[0] if labels else ""


def card_named(gate, name):
    for c in cards(gate):
        if card_name(c) == name:
            return c
    return None


def page(gate):
    for name, widget in gate.pages.items():
        if gate.stack.currentWidget() is widget:
            return name
    return None


class Recorder:
    """Records what the gate says when an account is signed in."""

    def __init__(self, gate):
        self.names = []
        gate.signed_in.connect(self.names.append)


def fresh_path(label):
    folder = tempfile.mkdtemp(prefix=f"sd-login-{label}-")
    return os.path.join(folder, "accounts.json")


def read_accounts(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ---- 1. a brand-new computer: the first account is made, and the app remembers it
path = fresh_path("first")
gate = LoginGate(path)
show(gate)
check("with no accounts, the first screen is the create form", page(gate) == "create", str(page(gate)))
check("with no accounts, Back is hidden (there is nowhere to go back to)", not gate.create_back.isVisible())
check("with no accounts, the picker's small button is still there at the bottom", gate.add_button is not None)
rec = Recorder(gate)
type_into(gate.new_name, "Mira")
type_into(gate.new_pass, "correct horse battery")
type_into(gate.new_pass2, "correct horse battery")
click(gate.create_make)
check("creating the first account signs it in", rec.names == ["Mira"], str(rec.names))
check("the account is written to the accounts file", os.path.exists(path))
check("the file holds the account under its lowercase key",
      "mira" in read_accounts(path).get("accounts", {}), str(read_accounts(path)))
check("the file never stores the password in plain text",
      "correct horse battery" not in open(path, encoding="utf-8").read())

# ---- 2. starting the app again: the account is there, and nothing asks for a new one
gate2 = LoginGate(path)
show(gate2)
check("on relaunch the picker is the first screen", page(gate2) == "pick", str(page(gate2)))
check("on relaunch the subtitle asks who is using the desk", gate2.pick_sub.text() == "Who is using the desk?",
      gate2.pick_sub.text())
check("on relaunch the account is shown as a card", card_named(gate2, "Mira") is not None,
      str([card_name(c) for c in cards(gate2)]))
check("on relaunch there is no create-only screen in front", page(gate2) != "create")
check("the small Add account button is at the bottom, enabled", gate2.add_button.isEnabled())
check("the Add account button is small (not a big tile)", gate2.add_button.objectName() == "gateSmall")

# wrong password first
rec2 = Recorder(gate2)
click(card_named(gate2, "Mira"))
check("choosing the card opens the password screen", page(gate2) == "password", str(page(gate2)))
type_into(gate2.password_field, "not the password")
click(gate2.pages["password"].findChildren(QPushButton)[-1])
check("a wrong password does not sign in", rec2.names == [], str(rec2.names))
check("a wrong password says so", gate2.password_error.text() == "That password is not right.",
      gate2.password_error.text())
check("a wrong password leaves the saved accounts as they were", "mira" in read_accounts(path)["accounts"])

# right password
type_into(gate2.password_field, "correct horse battery")
click(gate2.pages["password"].findChildren(QPushButton)[-1])
check("the right password signs in", rec2.names == ["Mira"], str(rec2.names))
check("signing in remembers the account as the last one used", read_accounts(path).get("last") == "mira")

# ---- 3. add a second account from the small button at the bottom
gate3 = LoginGate(path)
show(gate3)
click(gate3.add_button)
check("the Add account button opens the create form", page(gate3) == "create", str(page(gate3)))
check("with accounts already there, Back is shown on the create form", gate3.create_back.isVisible())
rec3 = Recorder(gate3)
type_into(gate3.new_name, "Kai")
type_into(gate3.new_pass, "a second long password")
type_into(gate3.new_pass2, "a second long password")
click(gate3.create_make)
check("the second account signs in", rec3.names == ["Kai"], str(rec3.names))
saved = read_accounts(path)["accounts"]
check("both accounts are in the file", set(saved) == {"mira", "kai"}, str(sorted(saved)))
check("the first account still works after adding the second", ac.sign_in(read_accounts(path), "Mira",
                                                                             "correct horse battery"))

# passwords that do not match
gate3b = LoginGate(path)
show(gate3b)
click(gate3b.add_button)
type_into(gate3b.new_name, "Ren")
type_into(gate3b.new_pass, "first try of it")
type_into(gate3b.new_pass2, "second try of it")
click(gate3b.create_make)
check("mismatched passwords are refused", "do not match" in gate3b.create_error.text(), gate3b.create_error.text())
check("a refused create adds no account", "ren" not in read_accounts(path)["accounts"])

# Back returns to the picker without creating anything
click(gate3b.create_back)
check("Back on the create form returns to the accounts", page(gate3b) == "pick", str(page(gate3b)))

# ---- 4. sign out and sign back in to the account made first
gate4 = LoginGate(path)
show(gate4)
rec4 = Recorder(gate4)
check("both accounts are offered after a relaunch", len(cards(gate4)) == 2, str(len(cards(gate4))))
gate4.reset()
pump(100)
check("after a sign-out the picker still lists both accounts", len(cards(gate4)) == 2, str(len(cards(gate4))))
click(card_named(gate4, "Kai"))
type_into(gate4.password_field, "a second long password")
click(gate4.pages["password"].findChildren(QPushButton)[-1])
check("signing back in to the second account works", rec4.names == ["Kai"], str(rec4.names))

# the subtitle follows the accounts after a reset (it used to stay on the first-run wording)
empty_path = fresh_path("subtitle")
g5 = LoginGate(empty_path)
show(g5)
type_into(g5.new_name, "Ola")
type_into(g5.new_pass, "subtitle password")
type_into(g5.new_pass2, "subtitle password")
click(g5.create_make)
g5.reset()
pump(100)
check("after the first account exists, the subtitle no longer says to create one",
      g5.pick_sub.text() == "Who is using the desk?", g5.pick_sub.text())

# ---- 5. a damaged accounts file is kept, never overwritten
bad_path = fresh_path("damaged")
with open(bad_path, "w", encoding="utf-8") as f:
    f.write("{this is not json")
gate6 = LoginGate(bad_path)
show(gate6)
kept = [n for n in os.listdir(os.path.dirname(bad_path)) if ".damaged-" in n]
check("a damaged file is moved aside, not deleted", len(kept) == 1, str(kept))
check("the damaged file keeps its original contents",
      open(os.path.join(os.path.dirname(bad_path), kept[0]), encoding="utf-8").read() == "{this is not json")
check("the screen says the file was kept", "could not be read" in gate6.pick_notice.text()
      or "could not be read" in gate6.notice, gate6.notice)
check("with the file moved aside, the create form is shown", page(gate6) == "create", str(page(gate6)))
type_into(gate6.new_name, "Ren")
type_into(gate6.new_pass, "recovered password")
type_into(gate6.new_pass2, "recovered password")
click(gate6.create_make)
check("a new account can still be made after a damaged file", "ren" in read_accounts(bad_path)["accounts"])
check("the damaged copy is still on disk after that", any(".damaged-" in n for n in
                                                          os.listdir(os.path.dirname(bad_path))))

# a damaged file that cannot be moved aside: the app refuses to save over it
ro_path = fresh_path("readonly")
with open(ro_path, "w", encoding="utf-8") as f:
    f.write("[[broken")
real_set_aside = ac.set_aside


def refuse_move(path):
    raise OSError("the file is locked")


ac.set_aside = refuse_move
try:
    gate7 = LoginGate(ro_path)
    show(gate7)
    check("a damaged file that cannot be moved puts the gate into read-only", gate7.read_only)
    check("read-only: the create button is disabled", not gate7.create_make.isEnabled())
    check("read-only: the damaged file is left exactly as it was",
          open(ro_path, encoding="utf-8").read() == "[[broken")
finally:
    ac.set_aside = real_set_aside

# ---- 6. a save that fails: the account is not added and the user is told
save_path = fresh_path("savefail")
g8 = LoginGate(save_path)
show(g8)
real_save = ac.save


def failing_save(path, data):
    raise OSError("disk is full")


ac.save = failing_save
try:
    rec8 = Recorder(g8)
    type_into(g8.new_name, "Vee")
    type_into(g8.new_pass, "a password here")
    type_into(g8.new_pass2, "a password here")
    click(g8.create_make)
    check("a save that fails does not sign the account in", rec8.names == [], str(rec8.names))
    check("a save that fails tells you why", "disk is full" in g8.create_error.text(), g8.create_error.text())
    check("a save that fails leaves the in-memory accounts without the new one", "vee" not in g8.data["accounts"])
finally:
    ac.save = real_save

# ---- 7. after the first account, the Windows app step is offered, and both outcomes lead on
installed_calls = []


def offer_yes():
    return True


def install_ok(places):
    installed_calls.append(list(places))
    return True, "Spatial Desk is on your desktop and the Start menu."


def install_fails(places):
    return False, "The shortcuts could not be made."


offer_path = fresh_path("offer")
g9 = LoginGate(offer_path, install_offer=offer_yes, install_now=install_ok)
show(g9)
rec9 = Recorder(g9)
type_into(g9.new_name, "Pia")
type_into(g9.new_pass, "install password")
type_into(g9.new_pass2, "install password")
click(g9.create_make)
check("the install step comes after the first account", page(g9) == "install", str(page(g9)))
check("the account is not signed in until the install step is done", rec9.names == [], str(rec9.names))
check("both shortcut boxes start ticked", g9.install_desktop.isChecked() and g9.install_start.isChecked())
click(g9.install_add)
check("adding it calls the install with the desktop and the Start menu",
      installed_calls == [["Desktop", "Programs"]], str(installed_calls))
check("success is reported", g9.install_ok.isVisible() or "desktop" in g9.install_ok.text(), g9.install_ok.text())
click(g9.install_skip)
check("Continue then signs the account in", rec9.names == ["Pia"], str(rec9.names))

fail_path = fresh_path("offerfail")
g10 = LoginGate(fail_path, install_offer=offer_yes, install_now=install_fails)
show(g10)
rec10 = Recorder(g10)
type_into(g10.new_name, "Lou")
type_into(g10.new_pass, "install password")
type_into(g10.new_pass2, "install password")
click(g10.create_make)
click(g10.install_add)
check("a failed install says so and does not sign in", "could not be made" in g10.install_error.text()
      and rec10.names == [], g10.install_error.text())
click(g10.install_skip)
check("Not now still signs the account in", rec10.names == ["Lou"], str(rec10.names))

no_offer = LoginGate(fresh_path("nooffer"), install_offer=lambda: False, install_now=install_ok)
show(no_offer)
rec11 = Recorder(no_offer)
type_into(no_offer.new_name, "Sam")
type_into(no_offer.new_pass, "no offer password")
type_into(no_offer.new_pass2, "no offer password")
click(no_offer.create_make)
check("when the app is already installed, no install step is shown, and sign-in is direct",
      rec11.names == ["Sam"] and page(no_offer) != "install", str(page(no_offer)))

print()
print(f"RESULT {sum(ok for _, ok in results)} / {len(results)}")
if failures:
    print(f"{failures} check(s) failed")
    os._exit(1)
print("all login flow checks passed")
os._exit(0)
