"""Checks for the window fit, the intro letter timing, and the wiring of the new behaviour: no cut-off pictures,
letters that arrive in order, a click that never waits, and a top-bar button that opens the tuner card.
Needs numpy only. usage: python tools/test_view.py
"""
import ast
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(HERE, "..", "spatial_desk.py")
with open(SRC_PATH, encoding="utf-8") as f:
    SRC = f.read()
TREE = ast.parse(SRC)
ns = {"np": np}
for node in TREE.body:
    if isinstance(node, ast.FunctionDef) and node.name in ("fit_scale", "letter_reveal", "_smooth"):
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)
fit_scale, letter_reveal = ns["fit_scale"], ns["letter_reveal"]

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# the proportions: whatever shape a window is put in, the picture is shown at its own proportions (never squashed or
# stretched). quad * fx / fy is the proportion the picture is drawn at, and it must equal the picture's own.
worst = 0.0
for quad in (0.3, 0.5625, 0.75, 0.9, 1.0, 1.78, 2.0):
    for content in (0.3, 0.5625, 0.75, 0.9, 1.0, 1.78):
        fx, fy = fit_scale(quad, content)
        worst = max(worst, abs(quad * fx / fy - content))
check("every shape shows the picture at its own proportions (max error < 1e-9)", worst < 1e-9, f"error {worst}")
check("a 0.9 picture in a 16:9 window is not squashed (the old fit showed it at 0.35)",
      abs(0.5625 * fit_scale(0.5625, 0.9)[0] / fit_scale(0.5625, 0.9)[1] - 0.9) < 1e-9)
check("a 16:9 picture in a portrait window is not stretched (the old fit showed it at 5.6)",
      abs(1.78 * fit_scale(1.78, 0.5625)[0] / fit_scale(1.78, 0.5625)[1] - 0.5625) < 1e-9)
# the fit: the picture always covers the whole of the shape on one side, and is never zoomed in (cut off)
check("the same shape as the picture fills it", fit_scale(0.5625, 0.5625) == (1.0, 1.0))
for quad, content in ((0.5625, 1.0), (1.0, 0.5625), (1.78, 0.5625), (0.5, 0.75), (2.0, 1.0)):
    fx, fy = fit_scale(quad, content)
    check(f"quad {quad} for picture {content}: never zoomed in (both scales >= 1)", fx >= 1.0 and fy >= 1.0,
          f"{fx}, {fy}")
    check(f"quad {quad} for picture {content}: one side fills the shape", min(fx, fy) == 1.0)
    # the sampled range of the picture spans all of it: 0 to 1 is covered when scaled
    lo, hi = 0.5 - 0.5 * fy, 0.5 + 0.5 * fy
    check(f"quad {quad} for picture {content}: the picture's full height is shown or letterboxed",
          lo <= 0.5 and hi >= 0.5 and (fy == 1.0 or (lo < 0.0 and hi > 1.0)))

# the intro: letters arrive one after another, never backwards, and all are in place at the end
check("nothing is shown before the intro starts", all(letter_reveal(0.0, i, 12) == 0.0 for i in range(12)))
check("every letter is in place at the end", all(letter_reveal(1.0, i, 12) == 1.0 for i in range(12)))
check("the first letter arrives before the last", letter_reveal(0.3, 0, 12) > letter_reveal(0.3, 11, 12))
steps = [letter_reveal(p, 5, 12) for p in np.linspace(0.0, 1.0, 40)]
check("a letter only ever rises as the intro goes on", np.all(np.diff(steps) >= -1e-9))

# the wiring: the picture is never zoomed in, clicks do not wait, and the top-bar button opens the tuner card
check("the shader drops pixels outside the picture instead of stretching it", "discard" in SRC and "if (pic <= 0.0) discard;" in SRC)
check("the window crop uses the fit", "crop = fit_scale(hr, cap)" in SRC)
check("a click runs on a worker thread", "threading.Thread(target=self._click_in_background" in SRC)
check("the top-bar button opens the window tuner card", 'self._open_tuner(idx)' in SRC and "WindowTuner(" in SRC)
check("the old menu and the sidebar are no longer the button's action", "self._shape_menu(idx)" not in SRC)
check("first run opens Air Neo's setup after the intro", "self._maybe_first_run_setup()" in SRC
      and "self.open_airneo" in SRC)

# Intro title: the texture is re-drawn in the title phase. It used to be drawn only after that phase had returned,
# so the title stayed transparent the whole time (the old check passed because it only tested the letter timing).
paint = SRC[SRC.index("    def _paint(self):"):SRC.index("    def _kappa(self, p, e):")]
check("the intro title is re-drawn before the title phase returns",
      paint.index("self._sync_intro(t)") < paint.index("title = _smooth(0.0, 0.3, t)"))
check("the title is drawn from the first frame, not from 0.9 seconds",
      "_smooth(0.9, 1.6, t)" not in SRC and "_smooth(0.0, 0.3, t)" in SRC)
check("the intro texture is only uploaded from one place", SRC.count("self._upload_intro(") == 1)

# Clicks: mapped onto the picture the window shows, so a letterboxed window is clicked where you see it
check("clicks are mapped onto the visible picture", "visible_point(u, v, info.get(\"crop\"" in SRC)
check("the picking uses the crop the window is drawn with", '"crop": crop}' in SRC)
check("a window that is closing takes no clicks", 'p.get("closing") is not None' in SRC)

# Pointer setting: it used to be stored but never read, so turning it on did nothing
# Clicks and typing are real: no posted messages, no key forwarding, no switch to choose between them
for gone in ("PostMessageW", "send_key", "click_window_message", "bring_to_front", "pointer_click",
             "_set_pointer_click", "key_messages", "CHAR_FROM_KEYDOWN"):
    check(f"{gone} is gone: clicks and typing are real", gone not in SRC)
check("a click hands the room's window to the click, so the room is raised again afterwards",
      'click_grab(grab, u, v, desk=int(self.winId()), rest=rest)' in SRC)
check("a click is sent only when the target is the top window at that spot",
      "_click_when_top(hwnd, step[1], step[2])" in SRC and "WindowFromPoint" in SRC)
check("a click that cannot be sent says why, in the room", "click_status.emit(" in SRC and "CLICK_MESSAGES" in SRC)
check("a minimised window is reported instead of clicked", '"minimised"' in SRC and "IsIconic(hwnd)" in SRC)
check("a click raises the window, clicks, then raises the room (the sequence is click_plan)",
      "click_plan(" in SRC and "_raise_window(step[1])" in SRC)
check("the room itself is never activated, so the clicked window keeps the keyboard",
      "SetForegroundWindow(own)" not in SRC and "SetForegroundWindow(desk)" not in SRC)
check("the click activates the clicked window (not the room) before it is sent",
      "_activate(target)" in SRC and "SetForegroundWindow(hwnd)" in SRC)

# Open and close: a window is taken out only once its close animation has finished, and close-all cannot loop
check("closing a window animates it, and it is removed later", "def close_panel(self, p):" in SRC
      and "QTimer.singleShot(int(CLOSE_MS) + 40" in SRC and "def _finish_close(self, p):" in SRC)
check("close-all does not loop on a window that is still closing", "while self.panels" not in SRC
      and "for p in list(self.panels):" in SRC)
check("windows fade and grow in with a scale, from the window's centre",
      "window_motion(now, p[\"opened\"], p.get(\"closing\"))" in SRC and "scale(sc, sc, sc)" in SRC)

# The window card: a child of the desk (not a window of its own), closed by a press outside it, opened at the cursor
tuner_src = open(os.path.join(HERE, "..", "tuner_ui.py"), encoding="utf-8").read()
check("the window card is a child of the desk, not a window of its own (no tool, popup or topmost flags)",
      "WindowType.Tool" not in tuner_src and "WindowType.Popup" not in tuner_src
      and "WindowStaysOnTopHint" not in tuner_src)
check("the window card is created as a child of the desk (parent=self)", "parent=self)" in SRC
      and "self._tuner = card" in SRC)
check("a press outside the window card closes it, and only in this window",
      "_tuner_outside_press" in SRC and "geometry().contains" in SRC and "obj.window() is not self" in SRC)
check("the window card opens beside the cursor, mapped into the desk",
      "card.show_at(spot.x(), spot.y())" in SRC and "self.mapFromGlobal(QCursor.pos())" in SRC)

# Camera mode and the cursor: wired into the scene, the desk, and the settings
check("the camera picture is drawn behind the windows, the cursor and keyboard over everything",
      "self._draw_camera()\n        self._draw_windows(proj, view, dt, alpha)" in SRC
      and "self._draw_taskbar(proj, view, alpha)\n        self._draw_overlays()" in SRC)
check("the picture's edge is soft over one pixel (no jagged cut at a letterbox or crop)",
      "float pic = clamp(inside / max(fwidth(inside), 1e-6) + 1.0, 0.0, 1.0);" in SRC
      and "t.a * uAlpha * aa * pic" in SRC)
check("camera mode is off by default", '"camera_on": False' in SRC)
check("camera mode checks its libraries before it starts", "hand_tracking.camera_ready()" in SRC)
check("the cursor is the white dot over empty room (the system pointer is hidden there)",
      "Qt.CursorShape.BlankCursor" in SRC and "pointer_art.dot_image()" in SRC)
check("a click on a rounded-off corner falls through to the window behind",
      'inside_rounded(u, v, info["w"], info["h"], PANEL_CORNER)' in SRC)
check("a click on the empty room unfocuses the window", "self.scene.focused = None" in SRC and
      "self.activateWindow()" in SRC)
check("the hand's pinch presses keys with real key input", "keyboard_input.press_label(" in SRC)
check("the camera stops when the app closes", "self._stop_camera()" in SRC)
airneo_core_src = open(os.path.join(HERE, "..", "airneo_core.py"), encoding="utf-8").read()
check("Virtual Box has no second frame round its card (the sheet is bare while it is open)",
      '_sheet_frame(bare=True)' in SRC and 'self.sheet.setStyleSheet("QFrame#sheet { background: transparent; border: 0px;' in SRC
      and "_sheet_frame(bare=False)" in SRC.split("def _close_airneo")[1].split("def ")[0])
check("the sheet frame is put back for every other sheet and when Virtual Box closes",
      "self._sheet_frame(bare=False)\n        self.sheet_kind = None" in SRC and "def _clear_sheet(self):\n        self._sheet_frame(bare=False)" in SRC)
check("the dock tunnel button installs WireGuard (through Virtual Box) when it is missing",
      'airneo_core.find_wg() is None' in SRC.split("def _toggle_tunnel")[1].split("def _on_tunnel_done")[0])
check("the tunnel uses WireGuard's full path when it is installed", "windows_tunnel_exe()" in airneo_core_src)
airneo_src = open(os.path.join(HERE, "..", "airneo_ui.py"), encoding="utf-8").read()
check("Virtual Box's type is thin: no bold (600) weights left in its style sheet",
      "font-weight: 600" not in airneo_src)
check("Virtual Box starts the WireGuard install when it is missing, and Connect and the keys step wait for it",
      "if core.find_wg() is None:\n            self._start_install()" in airneo_src
      and "self._after_install = self._finish_keys" in airneo_src and "self._start_install()\n            return" in airneo_src)
check("two cursors: the system arrow only over a window, the room's dot everywhere else",
      "shape = Qt.CursorShape.ArrowCursor if arrow else Qt.CursorShape.BlankCursor" in SRC
      and "self.setCursor(Qt.CursorShape.BlankCursor)" in SRC)
check("the cursor does not flicker on a window's edge (it holds for a moment after the pointer leaves)",
      "POINTER_HOLD_S" in SRC and "self._update_pointer_state()" in SRC)
check("the system cursor is hidden for the whole real click (no jump to the real window)",
      "_hide_system_cursor()\n    try:" in SRC and "finally:\n        _show_system_cursor()" in SRC)
check("the top status line is never shown (time, glasses and mode are removed from the top)",
      "self.status.show()" not in SRC and "self.status.hide()" in SRC)
check("the taskbar's look-down range is set from its own angle, not fixed numbers",
      "TASKBAR_ANGLE * 0.5, TASKBAR_ANGLE * 0.9" in SRC)
airneo_src = open(os.path.join(HERE, "..", "airneo_ui.py"), encoding="utf-8").read()
check("Virtual Box does not claim that nothing leaves the home network (a DDNS or public address can be used)",
      "Nothing leaves your home network" not in airneo_src)

print()

# ---- round 72: the dot above the 2D screens, and the real pointer resting in a focused window
check("the dot is drawn above the 2D screens too (PointerDot)", "class PointerDot(QWidget)" in SRC and "PointerDot(self)" in SRC)
check("the dot takes no mouse input", "WA_TransparentForMouseEvents" in SRC.split("class PointerDot")[1][:600])
check("over a 2D screen the cursor is the dot (override cursor, then restored)",
      "setOverrideCursor(Qt.CursorShape.BlankCursor)" in SRC and "restoreOverrideCursor()" in SRC)
check("a newly focused window rests the real pointer in its middle", "newly_focused" in SRC and "_window_centre_global(p)" in SRC)
check("the rest point is converted to physical pixels", "devicePixelRatioF()" in SRC)

if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all view checks passed")
