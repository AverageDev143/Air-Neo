"""Checks for the home screen: the calendar, Gmail and Drive cards, 3D space and Windows cards,
the four app squircles, the PC status card and the wallpaper picture.
usage: python tools/test_home.py   (needs PySide6 and a display, or QT_QPA_PLATFORM=offscreen)"""
import os
import sys
import tempfile
import time

import numpy as np

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from PySide6.QtWidgets import QApplication, QToolButton
from PySide6.QtCore import Qt, QPoint
from PySide6.QtTest import QTest
from PySide6.QtGui import QImage, QColor

app = QApplication(sys.argv[:1])
import spatial_desk as sd


def fake_frame(W=640, H=400):
    img = np.zeros((H, W, 4), np.uint8)
    img[:, :] = (30, 28, 24, 255)
    img[60:H, 0:160] = (40, 44, 52, 255)
    return img


class FakeGrab:
    def __init__(self, kind, ident, fps=24):
        self.kind, self.ident, self.error = kind, ident, None
    def latest(self): return 1, fake_frame()
    def has_picture(self): return True
    def age(self): return 10.0
    def stop(self): pass


sd.Grabber = FakeGrab
sd.MainWindow._maybe_first_run_setup = lambda self: None  # the first-run sheet would cover the page under test
results = []


def check(name, cond):
    results.append(bool(cond))
    print("PASS " if cond else "FAIL ", name)


def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        app.processEvents()
        time.sleep(0.02)


def click(widget):
    QTest.mouseClick(widget, Qt.MouseButton.LeftButton)
    pump(0.15)


w = sd.MainWindow()
w.resize(1280, 800)
w.show()
end = time.time() + 20          # the launch intro hides every widget until it finishes
while w.intro_running and time.time() < end:
    pump(0.1)
pump(0.5)
w.add_source("screen", 0, "App 1")
w.add_source("screen", 1, "App 2")
w.toggle_home()
pump(1.2)

# calendar: today's weekday and day of the month
now = time.localtime()
check("home screen shows when turned on", w.empty.isVisible())
check("calendar shows today's day", w.home_cal._text.get("day") == str(now.tm_mday))
check("calendar shows today's weekday", w.home_cal._text.get("week") == time.strftime("%a", now))

# Gmail and Drive open their web apps
opened = []
sd.webbrowser.open = lambda url, *a, **k: opened.append(url) or True
click(w.home_mail)
check("Gmail card opens Gmail", opened[-1:] == ["https://mail.google.com/"])
click(w.home_drive)
check("Drive card opens Google Drive", opened[-1:] == ["https://drive.google.com/"])

# Windows card toggles the window list
side = w.side_wanted
click(w.home_windows)
check("Windows card toggles the window list", w.side_wanted != side)
click(w.home_windows)
check("Windows card toggles back", w.side_wanted == side)
check("Windows card counts two open windows", w.home_windows._text.get("sub") == "2 open")

# 3D space card: enters 3D, home hides, leaving brings it back
click(w.home_room)
check("3D space card switches to 3D", w.mode == "spatial")
check("home hides in 3D space", not w.empty.isVisible())
w.toggle_mode()
pump(1.2)
check("leaving 3D space shows home again", w.empty.isVisible())

# the four action cards: Hover, Recenter, Layout, Calibrate
follow = w.follow
click(w.home_hover)
check("Hover card toggles hover and follow", w.follow != follow)
pump(1.2)   # the card text refreshes on the one-second tick
check("Hover card shows its new state", w.home_hover._text.get("sub") == ("On" if w.follow else "Off"))
click(w.home_hover)
check("Hover card toggles back", w.follow == follow)
layout = w.layout_name
click(w.home_layout)
check("Layout card changes the arrangement", w.layout_name != layout)
pump(1.2)
check("Layout card shows the arrangement's name", w.home_layout._text.get("sub") == dict(sd.LAYOUTS)[w.layout_name])
click(w.home_recenter)
check("Recenter card runs without error", w.isVisible())
click(w.home_calibrate)
check("Calibrate card opens the calibration sheet", w.sheet.isVisible())
w.sheet.hide()
pump(0.3)

# the Message Claude bar at the top of the home screen opens claude.ai
opened.clear()
click(w.home_ai)
check("Message Claude bar opens Claude", opened[-1:] == ["https://claude.ai/"])

# the status strip: screen cast, bell and Wi-Fi each do something; battery and clock open the control centre
strip = w.status_strip
mid = strip.height() // 2
def strip_click(x):
    QTest.mouseClick(strip, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier, QPoint(x, mid))
    pump(0.15)
strip_click(11)
check("screen cast opens the window picker", w.sheet.isVisible())
w.sheet.hide()
pump(0.3)
notify = w.notify_on
strip_click(35)
pump(1.2)
check("bell switches notifications", w.notify_on != notify)
check("bell icon dims when notifications are off", strip.bell_on == w.notify_on)
strip_click(35)
check("bell switches back", w.notify_on == notify)
strip_click(57)
check("Wi-Fi icon runs without error", w.isVisible())
strip_click(strip.width() - 12)
check("the clock opens the control centre", w.sheet.isVisible())
w.sheet.hide()
pump(0.3)

# gradient backgrounds on the calendar, Gmail and Drive cards and on the four action cards
check("calendar, Gmail and Drive have gradient backgrounds", set(sd.HOME_GRADIENT) == {"calendar", "mail", "drive"})
check("action cards have gradient backgrounds", set(sd.HOME_ACTIONS) == {"hover", "recenter", "layout", "calibrate"})
check("no textures are left on the cards", not hasattr(sd, "_home_texture"))

# PC status card follows the window count
check("PC card shows the glasses or mouse state", w.home_pc._text.get("title") == w.track_lbl.text())
w.add_source("screen", 2, "App 3")
pump(1.2)
check("PC card counts three windows after adding one", "3 windows" in w.home_pc._text.get("sub", ""))

# wallpaper: a picture fills the 3D space card, and the gradient returns when it is removed
tmp = os.path.join(tempfile.gettempdir(), "sd_home_test_bg.png")
img = QImage(320, 200, QImage.Format.Format_RGB32)
img.fill(QColor(200, 80, 40))
img.save(tmp)
w.bg_path = tmp
pump(1.2)
check("3D space card picks up the wallpaper", w.home_room.wallpaper is not None)
w.bg_path = ""
pump(1.2)
check("no wallpaper falls back to the gradient", w.home_room.wallpaper is None)

ok = all(results)
print(f"RESULT {sum(results)} / {len(results)}")
os._exit(0 if ok else 1)
