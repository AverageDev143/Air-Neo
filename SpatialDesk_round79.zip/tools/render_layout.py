"""Render Spatial Desk with synthetic app windows (no capture, no recursion).
usage: render_layout.py <src_dir> <out.png> [n_windows] [mode]"""
import os, sys, time
import numpy as np
src, out = sys.argv[1], sys.argv[2]
n = int(sys.argv[3]) if len(sys.argv) > 3 else 3
mode = sys.argv[4] if len(sys.argv) > 4 else "spatial"
sys.path.insert(0, src)
from PySide6.QtWidgets import QApplication
app = QApplication(sys.argv[:1])
import spatial_desk as sd

def fake_frame(k, W=1280, H=800):
    img = np.zeros((H, W, 4), np.uint8)
    base = [(22, 24, 30), (28, 36, 30), (34, 26, 36), (30, 30, 40)][k % 4]
    img[:, :] = (base[2], base[1], base[0], 255)          # BGRA
    img[0:60, :] = (40, 42, 48, 255)                       # app toolbar
    img[60:H, 0:220] = (30, 32, 38, 255)                   # sidebar
    for r in range(6):                                     # list rows
        y = 90 + r * 70
        img[y:y + 52, 240:W - 40] = (46, 48, 56, 255)
        img[y + 18:y + 26, 262:262 + 360 - 60 * (r % 3)] = (200, 205, 215, 255)
    for c in range(3):                                     # accent blocks
        x = 240 + c * 300
        img[520:700, x:x + 260] = (70 + 40 * c, 120, 220 - 50 * c, 255)
    return img

class FakeGrab:
    def __init__(self, kind, ident, fps=24):
        self.kind, self.ident, self.error = kind, ident, None
        self._f = fake_frame(int(ident) if str(ident).isdigit() else 0)
    def latest(self): return 1, self._f
    def has_picture(self): return True
    def age(self): return 10.0
    def stop(self): pass

sd.Grabber = FakeGrab
w = sd.MainWindow(); w.resize(1280, 800); w.show()
def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        app.processEvents(); time.sleep(0.02)
pump(4)
for k in range(n):
    w.add_source("screen", k, f"App {k + 1}")
if mode == "spatial":
    w.set_mode("spatial")
pump(5)
if len(sys.argv) > 5 and sys.argv[5] == "quick":
    w.open_quick_settings()
    pump(3)
if len(sys.argv) > 5 and sys.argv[5] == "home":
    w.toggle_home()
    pump(3)
if len(sys.argv) > 5 and sys.argv[5].startswith("settings"):
    w.open_settings()
    pump(1)
    page = sys.argv[5].split(":")[1] if ":" in sys.argv[5] else ""
    pages = {"glasses": w._settings_glasses_page, "theme": w._settings_theme_page,
             "fov": w._settings_fov_page, "arrange": w._settings_arrangement_page,
             "keys": w._settings_keys_page, "about": w._settings_about_page}
    if page in pages:
        w._settings_push(pages[page]())
    pump(3)
import subprocess
w.grab().save(out)
print("saved", out, "panels", len(w.panels), "mode", w.mode, "layout", w.scene.layout_name)
os._exit(0)
