"""Checks that the bug scanner catches each kind of bug it claims to catch, and that the app's files are clean.
usage: python tools/test_bug_scan.py
"""
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SCAN = os.path.join(HERE, "bug_scan.py")
sys.path.insert(0, HERE)
import bug_scan  # noqa: E402

PLANTED = '''
import os

class Thing:
    LIMIT = 3

    def run(self, items=[]):
        try:
            self.start()
        except:
            pass
        return self.total
        print("never")

    def run(self):
        return self.LIMIT + missing_name

def helper():
    return os.sep
'''

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


with tempfile.TemporaryDirectory() as d:
    path = os.path.join(d, "planted.py")
    with open(path, "w", encoding="utf-8") as f:
        f.write(PLANTED)
    found = {kind for _rel, _ln, kind, _msg in bug_scan.scan_file(path)}
    for kind in ("unreachable", "duplicate", "undefined", "unset-attr", "bare-except", "mutable-default"):
        check(f"catches '{kind}'", kind in found, f"found {sorted(found)}")

    clean = os.path.join(d, "clean.py")
    with open(clean, "w", encoding="utf-8") as f:
        f.write("class A:\n    LIMIT = 2\n\n    def go(self):\n        return self.LIMIT\n")
    check("passes clean code", bug_scan.scan_file(clean) == [])

r = subprocess.run([sys.executable, SCAN], capture_output=True, text=True)
check("the app's own files have no findings", r.returncode == 0, r.stdout[-400:])

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all bug scanner checks passed")
