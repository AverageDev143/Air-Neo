"""Draws previews of the title bar, the curved windows and the settings page.

This is a picture, not a screenshot of the app. It is drawn with Pillow from the app's own numbers: the title bar
texture positions, the window bend (same formula as the vertex shader) and the camera field of view. Qt's
antialiasing, text rendering and the real GPU output will differ a little.

usage: python tools/render_preview.py <out_dir>
"""
import ast
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(HERE, "..", "spatial_desk.py")
with open(SRC_PATH, encoding="utf-8") as f:
    SRC = f.read()
TREE = ast.parse(SRC)

NAMES = {"FOV_DEFAULT", "PANEL_CORNER", "HDR_W", "HDR_H", "BAR_W", "BAR_X0", "BAR_X1", "BAR_TOP", "BAR_H",
         "BAR_ICON_SIZE", "HDR_BTNS", "BAR_ICON"}
ns = {"np": np, "math": math}
for node in TREE.body:
    if isinstance(node, ast.Assign):
        names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        names += [e.id for t in node.targets if isinstance(t, ast.Tuple) for e in t.elts if isinstance(e, ast.Name)]
        if set(names) & NAMES:
            exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)
    if isinstance(node, ast.FunctionDef) and node.name in ("rot_y", "translate"):
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)

rot_y, translate = ns["rot_y"], ns["translate"]
HDR_W, HDR_H, BAR_X0, BAR_X1, BAR_TOP, BAR_H = (ns[k] for k in ("HDR_W", "HDR_H", "BAR_X0", "BAR_X1", "BAR_TOP", "BAR_H"))
BAR_ICON_SIZE, HDR_BTNS, BAR_ICON, PANEL_CORNER = ns["BAR_ICON_SIZE"], ns["HDR_BTNS"], ns["BAR_ICON"], ns["PANEL_CORNER"]
FOV = math.radians(ns["FOV_DEFAULT"])

W, H = 1600, 900           # output size in pixels
SS = 2                     # supersampling, for smooth edges
CURVE = 1.0                # the app's default curve (Scene.curve): 100% = the window wraps fully round you
DIST = 2.6                 # the default distance of a window, metres
WIN_W = 2.8                # the default width of a window, metres
WIN_H = WIN_W * 9.0 / 16.0
F = (H / 2.0) / math.tan(FOV / 2.0)   # focal length in pixels for the vertical field of view

FONT_REG = "/usr/share/fonts/opentype/inter/Inter-Regular.otf"
FONT_SEMI = "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf"
FONT_DISP = "/usr/share/fonts/opentype/inter/InterDisplay-SemiBold.otf"


def font(path, size):
    try:
        return ImageFont.truetype(path, size * SS)
    except OSError:
        return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size * SS)


def bend(x, y, kappa):
    """The local point of a window's surface, bent round you (the same formula as the vertex shader)."""
    if kappa <= 1e-9:
        return np.array([x, y, 0.0, 1.0])
    R = 1.0 / kappa
    phi = x / R
    return np.array([R * math.sin(phi), y, R * (1.0 - math.cos(phi)), 1.0])


def project(world):
    """World point to pixels on the 1600 x 900 canvas. The viewer is at the origin looking down -z."""
    x, y, z = world[:3]
    s = F / (-z)
    return W / 2.0 + x * s, H / 2.0 - y * s


def to_screen(placement, local_pts):
    return [project((placement @ p)[:3]) for p in local_pts]


def rounded_rect(x0, y0, x1, y1, r, n=10):
    """Outline points of a rounded rectangle, going round once."""
    pts = []
    corners = ((x1 - r, y0 + r, -90, 0), (x1 - r, y1 - r, 0, 90), (x0 + r, y1 - r, 90, 180), (x0 + r, y0 + r, 180, 270))
    for cx, cy, a0, a1 in corners:
        for k in range(n + 1):
            a = math.radians(a0 + (a1 - a0) * k / n)
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def densify(pts, step, closed=True):
    """Adds points along each straight edge, so bending the points also bends the edges (as the GPU grid does)."""
    out = []
    n = len(pts)
    last = n if closed else n - 1
    for i in range(last):
        ax, ay = pts[i]
        bx, by = pts[(i + 1) % n]
        length = math.hypot(bx - ax, by - ay)
        k = max(1, int(math.ceil(length / step)))
        for j in range(k):
            out.append((ax + (bx - ax) * j / k, ay + (by - ay) * j / k))
    if not closed:
        out.append(pts[-1])
    return out


def polyline_local(pts_xy, kappa):
    return [bend(x, y, kappa) for x, y in pts_xy]


def draw_window(layer, c, focused):
    """One window at angle c on the ring, with its title bar. Drawn onto an RGBA layer."""
    d = ImageDraw.Draw(layer)
    apos = np.array([math.sin(c) * DIST, 0.0, -math.cos(c) * DIST])
    placement = translate(*apos) @ rot_y(-c)
    kappa = CURVE / DIST

    # The window body: a rounded rectangle, bent round you.
    body = densify(rounded_rect(-WIN_W / 2, -WIN_H / 2, WIN_W / 2, WIN_H / 2, PANEL_CORNER * 1.0, 6), 0.02)
    d.polygon([(v[0] * SS, v[1] * SS) for v in to_screen(placement, polyline_local(body, kappa))], fill=(25, 27, 33, 255))
    rim = to_screen(placement, polyline_local(body, kappa))
    d.line([(v[0] * SS, v[1] * SS) for v in rim + rim[:1]], fill=(255, 255, 255, 70), width=2 * SS)

    # The title bar: the approved capsule, in the same texture positions the app uses.
    hh = WIN_W * HDR_H / HDR_W
    y0 = WIN_H / 2 + hh / 2 + 0.03

    def tex_to_local(tx, ty):
        return ((tx / HDR_W - 0.5) * WIN_W, y0 + (0.5 - ty / HDR_H) * hh)

    cap = densify(rounded_rect(BAR_X0, BAR_TOP, BAR_X1, BAR_TOP + BAR_H, BAR_H / 2.0, 8), 3.0)
    cap_local = [bend(*tex_to_local(tx, ty), kappa) for tx, ty in cap]
    d.polygon([(v[0] * SS, v[1] * SS) for v in to_screen(placement, cap_local)],
              fill=(0, 0, 0, 217 if focused else 184))

    # Icons, drawn on the same 24-unit grid as the app's paint_bar_icon.
    ink = (236, 239, 244, 214 if focused else 150)
    screen_per_tex = (project((placement @ bend(*tex_to_local(BAR_X1, 0), kappa))[:3])[0]
                      - project((placement @ bend(*tex_to_local(BAR_X0, 0), kappa))[:3])[0]) / (BAR_X1 - BAR_X0)
    stroke = max(1.0, 1.6 * (BAR_ICON_SIZE / 24.0) * screen_per_tex) * SS
    mid = BAR_TOP + BAR_H / 2.0
    for key, cx in HDR_BTNS:
        kind = BAR_ICON[key]
        k = BAR_ICON_SIZE / 24.0
        ox, oy = cx - BAR_ICON_SIZE / 2.0, mid - BAR_ICON_SIZE / 2.0

        def at(ux, uy):
            return (ox + ux * k, oy + uy * k)

        if kind == "sidebar":
            outline = rounded_rect(*at(4, 5), *at(20, 19), 3 * k, 6)
            strokes = [[at(10, 5), at(10, 19)]]
            shapes = [outline]
        elif kind == "apps":
            shapes = [rounded_rect(*at(x, y), *at(x + 5, y + 5), 1.2 * k, 4) for x, y in ((5, 5), (14, 5), (5, 14), (14, 14))]
            strokes = []
        elif kind == "focus":
            shapes = [[(at(12 + 6 * math.cos(a), 12 + 6 * math.sin(a))) for a in np.linspace(0, 2 * math.pi, 40)]]
            strokes = []
        elif kind == "minimise":
            shapes, strokes = [], [[at(6, 12), at(18, 12)]]
        elif kind == "maximise":
            shapes, strokes = [rounded_rect(*at(6, 6), *at(18, 18), 2 * k, 4)], []
        else:  # close
            shapes, strokes = [], [[at(7, 7), at(17, 17)], [at(17, 7), at(7, 17)]]
        for shape in shapes:
            pts = [(v[0] * SS, v[1] * SS) for v in to_screen(placement, [bend(*tex_to_local(x, y), kappa) for x, y in densify(shape, 1.0)])]
            d.line(pts + pts[:1], fill=ink, width=int(round(stroke)), joint="curve")
        for seg in strokes:
            pts = [(v[0] * SS, v[1] * SS) for v in to_screen(placement, [bend(*tex_to_local(x, y), kappa) for x, y in densify(seg, 1.0, closed=False)])]
            d.line(pts, fill=ink, width=int(round(stroke)), joint="curve")


def background():
    """A plain dark room: the app's own 'space' theme colours, with a faint field of stars."""
    top, bottom = np.array([20, 21, 23.0]), np.array([3, 3, 4.0])
    t = np.linspace(0, 1, H)[:, None]
    col = top * (1 - t) + bottom * t
    img = np.repeat(col[:, None, :], W, axis=1)
    rng = np.random.default_rng(7)
    for _ in range(260):
        x, y = rng.integers(0, W), rng.integers(0, H)
        img[y, x] = np.minimum(255, img[y, x] + rng.integers(40, 120))
    return Image.fromarray(img.astype(np.uint8)).convert("RGBA").resize((W * SS, H * SS))


def windows_preview(path):
    base = background()
    layer = Image.new("RGBA", (W * SS, H * SS), (0, 0, 0, 0))
    draw_window(layer, 0.0, focused=True)          # one window, straight in front of you
    out = Image.alpha_composite(base, layer).convert("RGB").resize((W, H), Image.LANCZOS)
    d = ImageDraw.Draw(out)
    d.text((40, H - 46), f"One curved window  ·  curve {int(CURVE * 100)}%  ·  drawn from the app's geometry, not a screenshot",
           font=ImageFont.truetype(FONT_REG, 15), fill=(138, 146, 163))
    out.save(path)


def settings_preview(path):
    """The settings sheet with the new palette: near-black, soft cards, one neutral tile per row, white switches."""
    w, h = 820, 860
    img = Image.new("RGB", (w * SS, h * SS), (9, 10, 12))
    d = ImageDraw.Draw(img, "RGBA")
    d.rounded_rectangle((0, 0, w * SS - 1, h * SS - 1), radius=30 * SS, fill=(12, 12, 14, 246), outline=(255, 255, 255, 20), width=SS)
    S = lambda v: int(v * SS)
    ft = lambda sz: font(FONT_DISP, sz)
    fr = lambda sz: font(FONT_REG, sz)
    fs = lambda sz: font(FONT_SEMI, sz)

    d.rounded_rectangle((S(w - 120), S(24), S(w - 28), S(64)), radius=S(15), fill=(238, 240, 244, 255))
    d.text((S(w - 74), S(44)), "Done", font=fs(15), fill=(11, 12, 15, 255), anchor="mm")
    d.text((S(30), S(26)), "Settings", font=ft(32), fill=(245, 246, 248, 255))
    d.rounded_rectangle((S(30), S(92), S(w - 30), S(136)), radius=S(14), fill=(255, 255, 255, 13), outline=(255, 255, 255, 18), width=SS)
    d.text((S(54), S(114)), "Search settings", font=fr(16), fill=(120, 127, 140, 255), anchor="lm")

    sections = [
        ("GLASSES", [("Glasses and calibration", "", "chev")]),
        ("DISPLAY", [("Theme", "Space", "chev"), ("Immersiveness", "62\u00b0", "chev"), ("Arrangement", "Stage", "chev"), ("Window curve", "100%", "spin")]),
        ("WINDOWS", [("Maximum windows", "4", "spin"), ("Transition time", "1200 ms", "spin"), ("Follow gaze", None, "switch")]),
    ]
    y = 158
    for name, rows in sections:
        d.text((S(38), S(y)), name, font=fs(12), fill=(123, 130, 148, 255), anchor="lm")
        y += 26
        top = y
        row_h = 52
        bottom = top + row_h * len(rows)
        d.rounded_rectangle((S(30), S(top), S(w - 30), S(bottom)), radius=S(18), fill=(255, 255, 255, 9), outline=(255, 255, 255, 15), width=SS)
        for i, (title, value, kind) in enumerate(rows):
            cy = top + row_h * i + row_h / 2.0
            d.rounded_rectangle((S(46), S(cy - 16), S(78), S(cy + 16)), radius=S(9), fill=(255, 255, 255, 20))
            d.ellipse((S(56), S(cy - 6), S(68), S(cy + 6)), outline=(226, 230, 238, 255), width=SS * 2)
            d.text((S(94), S(cy)), title, font=fr(16), fill=(238, 240, 244, 255), anchor="lm")
            if kind == "switch":
                tx0, ty0 = S(w - 104), S(cy - 14)
                d.rounded_rectangle((tx0, ty0, tx0 + S(48), ty0 + S(28)), radius=S(14), fill=(255, 255, 255, 36))
                d.ellipse((tx0 + S(3), ty0 + S(3), tx0 + S(25), ty0 + S(25)), fill=(236, 238, 244, 255))
            elif kind == "spin":
                d.rounded_rectangle((S(w - 170), S(cy - 15), S(w - 46), S(cy + 15)), radius=S(10), fill=(255, 255, 255, 15))
                d.text((S(w - 60), S(cy)), value, font=fr(15), fill=(238, 240, 244, 255), anchor="rm")
            else:
                d.text((S(w - 60), S(cy)), value, font=fr(15), fill=(138, 146, 163, 255), anchor="rm")
                d.text((S(w - 40), S(cy)), "\u203a", font=fr(20), fill=(79, 86, 103, 255), anchor="rm")
            if i < len(rows) - 1:
                d.line([(S(94), S(top + row_h * (i + 1))), (S(w - 46), S(top + row_h * (i + 1)))], fill=(255, 255, 255, 15), width=SS)
        y = bottom + 18

    d.text((S(30), S(h - 34)), "Approximate preview drawn with Pillow, not a screenshot of the app",
           font=fr(13), fill=(96, 103, 118, 255), anchor="lm")
    img.resize((w, h), Image.LANCZOS).save(path)


if __name__ == "__main__":
    out_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "previews")
    os.makedirs(out_dir, exist_ok=True)
    windows_preview(os.path.join(out_dir, "curved_windows_preview.png"))
    settings_preview(os.path.join(out_dir, "settings_preview.png"))
    print("previews written to", os.path.abspath(out_dir))
