"""Checks for Virtual Box's panel (airneo_ui.py) that run without a screen: keys are kept, pasted keys are checked,
Reset waits for a disconnect, and the panel says when the other computer has not answered.

usage: QT_QPA_PLATFORM=offscreen python tools/test_airneo_panel.py
"""
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

app = QApplication(sys.argv)
import airneo_core as core  # noqa: E402
import airneo_ui as ui  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


OWN_PUB = "A" * 42 + "B="
OWN_PRIV = "C" * 42 + "D="
OTHER_PUB = "E" * 42 + "F="

# The panel must not start a WireGuard install while it is tested, and must not make new keys by surprise.
core.find_wg = lambda: "wg"
generated = []
core.generate_keypair = lambda wg="wg": generated.append(wg) or (OWN_PRIV, OWN_PUB)
core.public_from_private = lambda private, run=None, wg="wg": OWN_PUB if private == OWN_PRIV else None

base = tempfile.mkdtemp()
panel = ui.AirNeoPanel(base, "windows", lambda action: None)
panel.state.update({"device": "pc", "setup_done": True, "public_key": OWN_PUB, "port": 51820, "host": "192.168.1.20"})
panel._save()

# 1. an existing key is kept: the public key is worked out from it, and nothing is generated
with open(panel.paths["key"], "w", encoding="utf-8") as f:
    f.write(OWN_PRIV + "\n")
check("an existing private key is found", panel._existing_private() == OWN_PRIV)
panel._finish_keys()
check("setting up again keeps the key this computer already has (nothing is generated)", generated == [])
check("and the public key shown is the one that goes with it", panel.state.get("public_key") == OWN_PUB)

# 2. pasting this computer's own public key into the peer field is refused, with the reason
panel.peer_key.setText(OWN_PUB)
panel.peer_host.setText("192.168.1.30")
panel._save_peer()
check("pasting this computer's own public key is refused on the screen",
      "own public key" in panel.peer_error.text(), panel.peer_error.text())
panel.peer_key.setText(OWN_PRIV)
panel._save_peer()
check("pasting a private key is refused on the screen", "private key" in panel.peer_error.text(), panel.peer_error.text())

# 3. Reset is not allowed while connected
panel.state["tunnel_on"] = True
panel._reset()
check("Reset is refused while connected, and says to disconnect first",
      "Disconnect first" in panel.main_error.text(), panel.main_error.text())
panel.state["tunnel_on"] = False

# 4. connected but the other computer has not answered: waiting, and the status says so
panel.tunnel_result(True, "connected, waiting for the other computer", "up", False)
check("while the other computer has not answered, the status says waiting",
      panel.status_line.text() == "Waiting for your Mac", panel.status_line.text())
check("and the panel explains what to check", "has not answered" in panel.main_error.text())
check("and it keeps checking on a timer while it waits", panel._peer_timer.isActive())

# 5. the other computer answers: Connected, and the timer stops
panel.tunnel_result(True, "connected", "up", True)
check("once the other computer answers, the status says Connected", panel.status_line.text() == "Connected",
      panel.status_line.text())
check("and the waiting message is cleared", panel.main_error.text() == "")
check("and the checking stops", not panel._peer_timer.isActive())

# 6. a failed start shows the reason, and the tunnel is not marked connected
panel.tunnel_result(False, "Windows needs your permission to change the tunnel.", "up", False)
check("a failed start shows its reason and is not marked connected",
      "permission" in panel.main_error.text() and panel.status_line.text() == "Not connected",
      panel.status_line.text())

# 7. reopening the panel while the tunnel is on: it checks again, and does not assume the other computer answers
import time as _time
core.peer_answers = lambda os_name, ip, run=None: False
reopened_state = dict(panel.state, tunnel_on=True, setup_done=True, device="pc")
core.load_state = lambda path: dict(reopened_state)
panel2 = ui.AirNeoPanel(base, "windows", lambda action: None)
app.processEvents()
check("reopening with the tunnel on, before the Mac answers, says waiting (not Connected)",
      panel2.status_line.text() == "Waiting for your Mac", panel2.status_line.text())
core.peer_answers = lambda os_name, ip, run=None: True
panel2._check_peer()
for _ in range(100):
    app.processEvents()
    if panel2.status_line.text() == "Connected":
        break
    _time.sleep(0.02)
check("and it says Connected once the Mac answers on the check", panel2.status_line.text() == "Connected",
      panel2.status_line.text())


# 8. changing the other computer's key: the new key is saved, the config rewritten, and the tunnel restarted if it is on
NEW_OTHER = "G" * 42 + "H="
panel_requests = []
core.peer_answers = lambda os_name, ip, run=None: True
KEYED_STATE = {"device": "pc", "setup_done": True, "public_key": OWN_PUB, "peer_public": OTHER_PUB,
               "host": "192.168.1.20", "port": 51820, "lan": None, "tunnel_on": False}
core.load_state = lambda path: dict(KEYED_STATE)
keyed = ui.AirNeoPanel(base, "windows", lambda action: panel_requests.append(action))
keyed.state.update({"device": "pc", "setup_done": True, "public_key": OWN_PUB, "peer_public": OTHER_PUB,
                    "host": "192.168.1.20", "port": 51820, "lan": None, "tunnel_on": False})
keyed._save()
with open(keyed.paths["key"], "w", encoding="utf-8") as f:
    f.write(OWN_PRIV + "\n")
keyed._open_peer_editor()
check("opening the key change shows this computer's own public key, to give to the other computer",
      keyed.own_key.text() == OWN_PUB, keyed.own_key.text())
check("and fills in the address the PC already uses", keyed.peer_host.text() == "192.168.1.20")
keyed.peer_key.setText(NEW_OTHER)
keyed._save_peer()
check("the new key is saved", keyed.state.get("peer_public") == NEW_OTHER)
written = open(keyed.paths["conf"], encoding="utf-8").read() if os.path.exists(keyed.paths["conf"]) else ""
check("the tunnel config is rewritten with the new key", NEW_OTHER in written and OTHER_PUB not in written)
check("with the tunnel off, nothing is restarted, and the panel says to connect", panel_requests == []
      and "Connect to use it" in keyed.main_error.text(), keyed.main_error.text())
keyed.state["tunnel_on"] = True
keyed._open_peer_editor()
keyed.peer_key.setText(OTHER_PUB)
keyed._save_peer()
check("with the tunnel on, the change restarts it", panel_requests == ["restart"], str(panel_requests))
check("and Change key is unavailable until the restart is done", not keyed.key_btn.isEnabled())
keyed.tunnel_result(True, "connected", "restart", True)
check("when the restart finishes, the tunnel is still on and Change key is available again",
      keyed.state.get("tunnel_on") is True and keyed.key_btn.isEnabled() and keyed.status_line.text() == "Connected",
      keyed.status_line.text())
keyed.tunnel_result(False, "WireGuard could not start the tunnel (code 5).", "restart", False)
check("a failed restart means the tunnel is not up, and says why",
      keyed.state.get("tunnel_on") is False and "code 5" in keyed.main_error.text())


print()
if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all Virtual Box panel checks passed")
