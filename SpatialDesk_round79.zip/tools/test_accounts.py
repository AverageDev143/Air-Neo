"""Checks for Spatial Desk accounts: creating, signing in, names, icons, saving, and deleting. No Qt needed.
usage: python tools/test_accounts.py
"""
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
import accounts_core as ac  # noqa: E402

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


def refused(fn):
    try:
        fn()
        return False
    except ValueError:
        return True


data = ac.empty()
data = ac.create(data, "Vayden", "correct horse battery", "orbit")
check("an account can be created", "vayden" in data["accounts"])
check("the right password signs in", ac.sign_in(data, "Vayden", "correct horse battery"))
check("the wrong password is refused", not ac.sign_in(data, "Vayden", "correct horse batter"))
check("an unknown account is refused", not ac.sign_in(data, "Nobody", "correct horse battery"))
check("the name is found whatever its capitals", ac.sign_in(data, "VAYDEN", "correct horse battery"))
check("a missing password is refused", not ac.sign_in(data, "Vayden", None))
check("signing in remembers the account", data["last"] == "vayden")
check("the name cannot be taken again, whatever its capitals",
      refused(lambda: ac.create(data, "vayDEN", "another password", "leaf")))
check("a short password is refused", refused(lambda: ac.create(data, "Kai", "short", "leaf")))
check("a name that is too short is refused", refused(lambda: ac.create(data, "K", "long enough pass", "leaf")))
check("a name with symbols is refused", refused(lambda: ac.create(data, "bad;name", "long enough pass", "leaf")))
check("a name with a line break is refused", refused(lambda: ac.create(data, "bad\nname", "long enough pass", "leaf")))
check("an icon that is not in the set is refused", refused(lambda: ac.create(data, "Kai", "long enough pass", "dragon")))
check("there are eight pre-made icons", len(ac.AVATARS) == 8 and len(set(ac.AVATARS)) == 8)

data = ac.create(data, "Mira", "another good password", "moon")
check("the picker lists accounts oldest first", [n for n, _a in ac.accounts_list(data)] == ["Vayden", "Mira"])
check("each account keeps its icon", dict(ac.accounts_list(data))["Mira"] == "moon")
data = ac.set_avatar(data, "Mira", "sun")
check("an icon can be changed", dict(ac.accounts_list(data))["Mira"] == "sun")

with tempfile.TemporaryDirectory() as d:
    path = os.path.join(d, "accounts_data", "accounts.json")
    ac.save(path, data)
    loaded = ac.load(path)
    check("accounts survive a save and load", ac.sign_in(loaded, "Vayden", "correct horse battery"))
    text = open(path, encoding="utf-8").read()
    check("the password itself is not in the file", "correct horse battery" not in text
          and "another good password" not in text)
    if os.name == "posix":
        check("the accounts file is readable by its owner only", (os.stat(path).st_mode & 0o077) == 0)
    with open(path, "w", encoding="utf-8") as f:
        f.write("{broken")
    check("a damaged accounts file gives an empty list", ac.load(path) == ac.empty())

data = ac.delete(data, "Mira", "another good password")
check("an account is deleted with its password", "mira" not in data["accounts"])
check("deleting without the password is refused", refused(lambda: ac.delete(data, "Vayden", "wrong password")))
data = ac.create(data, "Temp", "temporary password", "bolt")
ac.sign_in(data, "Temp", "temporary password")
data = ac.delete(data, "Temp", "temporary password")
check("deleting the last-used account clears it", data["last"] == "")

# the wiring: the login comes first, sign-out is in Settings, the icons match, and no "Air Neo" is shown to you
import ast  # noqa: E402
import re  # noqa: E402

SRC = {name: open(os.path.join(HERE, "..", name), encoding="utf-8").read()
       for name in ("spatial_desk.py", "airneo_ui.py", "dock_profiles.py", "login_ui.py", "accounts_core.py")}


def shown_strings(src):
    """The text that can appear on screen: string literals, minus docstrings and comments."""
    tree = ast.parse(src)
    doc_ids = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant):
                doc_ids.add(id(first.value))
    out = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in doc_ids:
            out.append(node.value)
        if isinstance(node, ast.JoinedStr):
            out += [v.value for v in node.values if isinstance(v, ast.Constant) and isinstance(v.value, str)]
    return out


for name, src in SRC.items():
    hits = [t for t in shown_strings(src) if "Air Neo" in t]
    check(f"no 'Air Neo' is shown to you in {name}", not hits, str(hits[:2]))

main_src = SRC["spatial_desk.py"][SRC["spatial_desk.py"].index("def main():"):]
check("the login is created before the desk window", main_src.index("LoginGate(") < main_src.index("MainWindow()"))
check("the login is shown first, every time the app starts", "gate.show()                            # the login comes first" in main_src)
check("the desk is made once, on the first sign-in", "if win is None:" in main_src)
check("Settings has the account and a sign-out row", '"Signed in as"' in SRC["spatial_desk.py"] and '"Sign out"' in SRC["spatial_desk.py"])
check("the window knows the signed-in account and how to sign out",
      "self.account_name = " in SRC["spatial_desk.py"] and "self.on_sign_out = None" in SRC["spatial_desk.py"])
avatars_in_login = re.findall(r'"(\w+)": \("#', SRC["login_ui.py"])
check("the login draws the same eight icons the accounts use", sorted(avatars_in_login) == sorted(ac.AVATARS),
      f"{sorted(avatars_in_login)} vs {sorted(ac.AVATARS)}")

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all account checks passed")
