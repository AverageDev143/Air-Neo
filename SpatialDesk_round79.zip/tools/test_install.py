"""Checks for installing Spatial Desk as a Windows app. Run: python tools/test_install.py

The parts that do not need Windows are checked directly: the .ico file format, the shortcut plan, the PowerShell
script and how values reach it, and the record of what was installed. The icon itself is drawn with Qt, so those
checks need PySide6 and are skipped without it.
"""
import base64
import os
import struct
import sys
import tempfile

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
os.environ["SPATIAL_DESK_DATA"] = tempfile.mkdtemp(prefix="sd-install-test-")

import app_install as ai          # noqa: E402
import app_paths                  # noqa: E402

failures = 0
results = []


def check(name, ok, detail=""):
    global failures
    results.append((name, bool(ok)))
    if not ok:
        failures += 1
    print(("PASS  " if ok else "FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""))


# ---- the .ico file format
fake_png = {size: b"\x89PNG\r\n\x1a\n" + bytes([size % 256]) * (size * 3) for size in ai.ICON_SIZES}
ico = ai.make_ico(fake_png)
reserved, kind, count = struct.unpack("<HHH", ico[:6])
check("the icon file starts with the .ico header (reserved 0, type 1)", reserved == 0 and kind == 1)
check("the icon file holds one entry per size", count == len(ai.ICON_SIZES), str(count))
entries = [struct.unpack("<BBBBHHII", ico[6 + 16 * i: 22 + 16 * i]) for i in range(count)]
widths = [e[0] if e[0] else 256 for e in entries]
check("the entries are the sizes asked for, 256 stored as 0", widths == list(ai.ICON_SIZES), str(widths))
check("every entry is 32 bits per pixel", all(e[5] == 32 for e in entries))
# entry fields: width, height, colours, reserved, planes, bits, data size, data offset
check("each entry records the size of its PNG data", all(e[6] == len(fake_png[s])
                                                         for e, s in zip(entries, ai.ICON_SIZES)))
check("each entry points at its own PNG data", all(e[7] == len(ico) - sum(len(fake_png[t]) for t in ai.ICON_SIZES[i:])
                                                   for i, e in enumerate(entries)))
check("the stored PNG bytes are copied unchanged", all(ico[e[7]: e[7] + e[6]] == fake_png[s]
                                                      for e, s in zip(entries, ai.ICON_SIZES)))

try:
    from PIL import Image
    import io
    real = {}
    for size in ai.ICON_SIZES:
        buf = io.BytesIO()
        Image.new("RGBA", (size, size), (200, 40, 40, 255)).save(buf, "PNG")
        real[size] = buf.getvalue()
    pil = Image.open(io.BytesIO(ai.make_ico(real)))
    got = set(pil.info.get("sizes", set()))
    check("an independent decoder (Pillow) reads all the sizes back",
          got == {(s, s) for s in ai.ICON_SIZES}, str(sorted(got)))
except ImportError:
    check("Pillow not installed: independent decoder check skipped", True)

# ---- which Python the shortcut starts
folder = tempfile.mkdtemp(prefix="sd-venv-")
exe = os.path.join(folder, "python.exe")
open(exe, "w").close()
open(os.path.join(folder, "pythonw.exe"), "w").close()
check("pythonw.exe beside the Python is used, so no console window opens",
      ai.python_for_shortcut(exe) == os.path.join(folder, "pythonw.exe"))
os.remove(os.path.join(folder, "pythonw.exe"))
check("without pythonw.exe, the Python that is running is used", ai.python_for_shortcut(exe) == exe)

# ---- the shortcut plan
here = r"C:\Users\Test User\Projects\Spatial Desk"
plan = ai.shortcut_plan(here, r"C:\Users\Test User\Projects\Spatial Desk\.venv\Scripts\pythonw.exe",
                        r"C:\Users\Test User\AppData\Local\Spatial Desk\spatial_desk.ico")
check("the shortcut runs spatial_desk.py from the project folder",
      plan["arguments"] == '"' + os.path.join(here, "spatial_desk.py") + '"', plan["arguments"])
check("a folder with spaces is quoted, so the path survives", plan["arguments"].startswith('"')
      and plan["arguments"].endswith('spatial_desk.py"'))
check("the shortcut starts in the project folder", plan["workdir"] == here)
check("the shortcut is named Spatial Desk", plan["name"] == "Spatial Desk")
check("the shortcut carries the app's own icon file", plan["icon"].endswith("spatial_desk.ico"))

# ---- the PowerShell step: values travel in the environment, never in the script text
nasty = "C:\\Users\\O'Brien \"Dev\"; Remove-Item -Recurse C:\\"
env = ai.shortcut_environment(ai.shortcut_plan(nasty, nasty + "\\pythonw.exe", nasty + "\\spatial_desk.ico"),
                              ["Desktop", "Programs"])
check("values with quotes and semicolons go in the environment", env["SD_WORKDIR"] == nasty)
check("the places are passed as one list", env["SD_WHERE"] == "Desktop;Programs")
check("the PowerShell script never contains the path", nasty not in ai.PS_SCRIPT)
check("the script reads every value from the environment", all(f"$env:{k}" in ai.PS_SCRIPT for k in
      ("SD_WHERE", "SD_NAME", "SD_TARGET", "SD_ARGS", "SD_WORKDIR", "SD_ICON", "SD_DESC")))
check("the script asks Windows for the Desktop and the Start menu folders",
      "GetFolderPath($where)" in ai.PS_SCRIPT and "'Desktop'" not in ai.PS_SCRIPT)
check("the script stops at the first error", "$ErrorActionPreference = 'Stop'" in ai.PS_SCRIPT)
check("the script is sent encoded, so the command line cannot re-parse it",
      base64.b64decode(base64.b64encode(ai.PS_SCRIPT.encode("utf-16-le"))).decode("utf-16-le") == ai.PS_SCRIPT)

# On Windows this file would be run; here we only check how it is called and what it says on other systems.
if os.name != "nt":
    ok, msg, paths = ai.create_shortcuts(plan, ["Desktop"])
    check("off Windows, no shortcut is attempted and the reason is given", not ok and "Windows" in msg
          and paths == [], msg)
    ok, msg = ai.install_as_windows_app(HERE, ["Desktop"])
    check("off Windows, the install reports that it needs Windows", not ok and "Windows" in msg, msg)
else:
    ok, msg, paths = ai.create_shortcuts(plan, [])
    check("with no place chosen, nothing is created", not ok and paths == [])

# ---- the record of what was installed
check("nothing is recorded as installed on a fresh data folder", not ai.is_installed())
ai.record_install([os.path.join(folder, "Spatial Desk.lnk")], os.path.join(folder, "spatial_desk.ico"))
check("once recorded, the install is remembered", ai.is_installed())
check("the record lives in the user's data folder", os.path.dirname(ai.record_path()) == app_paths.data_dir())
ai.record_install([], "")
check("a record with no shortcuts does not count as installed", not ai.is_installed())

# ---- the icon itself (drawn with Qt)
try:
    from PySide6.QtWidgets import QApplication
    qapp = QApplication.instance() or QApplication([])
    import app_icon as spatial_icon
    from PySide6.QtGui import QColor
    img = spatial_icon.render(256)
    check("the icon renders at the size asked for", img.width() == 256 and img.height() == 256)
    check("the corners of the icon are transparent (rounded tile)", img.pixelColor(0, 0).alpha() == 0)
    check("the middle of the icon is solid", img.pixelColor(128, 200).alpha() == 255)
    bar = img.pixelColor(128, 100)
    check("the front window's title bar is dark (regression: it was white before)", bar.red() < 80 and bar.green() < 80,
          bar.name())
    check("the icon has its three title-bar dots", QColor(img.pixelColor(66, 103)).lightness() > 200)
    small = spatial_icon.render(16)
    check("the 16 pixel icon has no title bar to clip", small.width() == 16)
    tmp = tempfile.mkdtemp(prefix="sd-icon-")
    path = spatial_icon.write_icon(tmp)
    data = open(path, "rb").read()
    check("write_icon writes an .ico with all seven sizes",
          struct.unpack("<HHH", data[:6])[2] == len(ai.ICON_SIZES) and path.endswith("spatial_desk.ico"))
    check("the icon file on disk matches the builder", data == ai.make_ico({s: spatial_icon.png_bytes(s)
                                                                             for s in ai.ICON_SIZES}))
except ImportError as e:
    check("PySide6 not installed: icon checks skipped", True, str(e))

print()
print(f"RESULT {sum(ok for _, ok in results)} / {len(results)}")

# ---- every start: the shortcuts are checked, and made again when needed
rec = {"shortcuts": [r"C:\\Users\\u\\Desktop\\Spatial Desk.lnk",
                     r"C:\\Users\\u\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Spatial Desk.lnk"],
       "version": ai.APP_VERSION, "here": "H", "python": "P", "places": ["Desktop", "Programs"]}
make, reason, places = ai.shortcut_check(rec, "H", "P", exists=lambda p: True)
check("a current install with both shortcuts present is left alone", not make and reason == "")
make, reason, _ = ai.shortcut_check(rec, "H", "P", exists=lambda p: "Desktop" not in p)
check("a deleted desktop shortcut is made again", make and "missing" in reason, reason)
make, reason, places = ai.shortcut_check(dict(rec, version="70"), "H", "P", exists=lambda p: True)
check("a shortcut from an older version is made again with the new one", make and "new version" in reason)
make, reason, _ = ai.shortcut_check(rec, "OTHER", "P", exists=lambda p: True)
check("an app moved to another folder gets shortcuts that point at it", make and "folder changed" in reason)
make, reason, _ = ai.shortcut_check(dict(rec, python="OLD"), "H", "P", exists=lambda p: True)
check("a changed Python gets its shortcuts made again", make and "Python changed" in reason)
check("an app that was never installed gets no shortcuts (the install offer asks)",
      ai.shortcut_check({}, "H", "P") == (False, "", []))
check("a record from before places were kept still works out where the shortcuts are",
      ai.places_from_paths(rec["shortcuts"]) == ["Desktop", "Programs"]
      and ai.places_from_paths([r"C:\\Users\\u\\Desktop\\x.lnk"]) == ["Desktop"])
old_rec = {"shortcuts": rec["shortcuts"]}
make, reason, places = ai.shortcut_check(old_rec, "H", "P", exists=lambda p: True)
check("a round 69 record (no version) is checked and made again once", make and places == ["Desktop", "Programs"])
# ---- bug hunt (round 76): only real shortcut paths are recorded
check("a warning printed by PowerShell is not recorded as a shortcut",
      ai.shortcut_paths_from(["WARNING: x", r"C:\\Users\\u\\Desktop\\Spatial Desk.lnk", "", "junk"]) ==
      [r"C:\\Users\\u\\Desktop\\Spatial Desk.lnk"])
check("the same shortcut printed twice is recorded once",
      ai.shortcut_paths_from([r"C:\\a\\Spatial Desk.lnk", r"C:\\a\\Spatial Desk.lnk"]) == [r"C:\\a\\Spatial Desk.lnk"])
check("a path that is not a shortcut file is not recorded",
      ai.shortcut_paths_from([r"C:\\Users\\u\\Desktop", r"relative\\Spatial Desk.lnk"]) == [])

if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all Windows app install checks passed")
