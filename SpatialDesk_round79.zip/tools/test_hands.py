"""Camera mode end to end, with a fake camera and a fake hand tracker in place of the real ones.
usage: python tools/test_hands.py   (needs PySide6 and a display, or QT_QPA_PLATFORM=offscreen)

The worker thread, its signals, the cursor, the pinch, the key press and the room click all run for real. Only the
camera and the hand model are stand-ins, since this machine has neither. On a PC with a camera, the same code runs
with the real ones; the steps that need them (the model download, the camera itself) are checked on that machine.
"""
import os
import sys
import tempfile
import time
import unittest.mock as mock

import numpy as np

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
os.environ["SPATIAL_DESK_DATA"] = tempfile.mkdtemp(prefix="sd-hands-test-")

from PySide6.QtWidgets import QApplication   # noqa: E402
from PySide6.QtTest import QTest             # noqa: E402

app = QApplication.instance() or QApplication(sys.argv[:1])
import hand_tracking as ht                   # noqa: E402
import keyboard_input                        # noqa: E402
import spatial_desk as sd                    # noqa: E402

failures = 0
results = []


def check(name, ok, detail=""):
    global failures
    results.append((name, bool(ok)))
    if not ok:
        failures += 1
    print(("PASS  " if ok else "FAIL  ") + name + (f"   [{detail}]" if detail and not ok else ""))


def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        QTest.qWait(20)


FRAME_W, FRAME_H = 1280, 720


class FakeCamera:
    """Stands in for the webcam: a picture every time it is read."""

    def __init__(self, index=0):
        self.error = None

    def start(self):
        return True

    def latest(self):
        return np.full((FRAME_H, FRAME_W, 3), (40, 90, 160), dtype=np.uint8)

    def stop(self):
        pass


class Script:
    """What the fake hand does next: "key" (a pinch on the key K), "open", "room" (a pinch in the empty room)."""
    state = "open"
    key = "K"
    key_xy = None
    room_xy = (120.0, 110.0)


def hand_at(nx, ny, pinched):
    """A hand whose index fingertip is at (nx, ny) of the frame; a pinch closes the thumb onto it."""
    pts = [(0.5, 0.5, 0.0)] * 21
    pts[ht.WRIST] = (0.5, 0.85, 0.0)
    pts[ht.MIDDLE_MCP] = (0.5, 0.55, 0.0)
    pts[ht.INDEX_TIP] = (nx, ny, 0.0)
    pts[ht.THUMB_TIP] = (nx + 0.001, ny, 0.0) if pinched else (max(0.0, nx - 0.25), ny + 0.2, 0.0)
    return pts


class FakeTracker:
    def __init__(self, model_path):
        self.model_path = model_path

    def detect(self, rgb):
        if Script.state == "key":
            sx, sy = Script.key_xy
            return [hand_at(1.0 - sx / FRAME_W, sy / FRAME_H, pinched=True)]
        if Script.state == "room":
            sx, sy = Script.room_xy
            return [hand_at(1.0 - sx / FRAME_W, sy / FRAME_H, pinched=True)]
        return [hand_at(0.5, 0.5, pinched=False)]

    def close(self):
        pass


# ---- the desk, with the stand-ins in place of the camera and the hand model
pressed = []
clicked = []
with mock.patch.object(sd, "Grabber", mock.MagicMock()), \
        mock.patch.object(sd.MainWindow, "_maybe_first_run_setup", lambda self: None), \
        mock.patch.object(ht, "Camera", FakeCamera), \
        mock.patch.object(ht, "HandTracker", FakeTracker), \
        mock.patch.object(ht, "ensure_model", lambda folder, report=None: "fake-model.task"), \
        mock.patch.object(keyboard_input, "press_label", lambda label, shift: (pressed.append(label), shift)[1]):
    w = sd.MainWindow()
    w.resize(FRAME_W, FRAME_H)
    w.show()
    w.scene.skip_intro = True
    pump(1.0)
    w._on_click_real = w._on_click
    w._on_click = lambda x, y: clicked.append((round(x), round(y)))   # records the room click, as a real click would go

    ok, _ = ht.camera_ready()
    check("the camera libraries are present for this check", ok)
    w._set_camera(True)
    pump(0.8)
    check("camera mode turns on", w.cfg.get("camera_on") is True and w.scene.cam_on)
    check("the camera worker is running", getattr(w, "cam_worker", None) is not None and w.cam_worker.isRunning())

    # the picture reaches the desk
    check("the picture from the camera reaches the desk", w._cam_size == (FRAME_W, FRAME_H), str(w._cam_size))

    # the cursor follows the index finger across the screen
    kx, ky, kw, kh = ht.keyboard_rect(w.scene.width(), w.scene.height())
    keys = ht.keyboard_keys(kw, kh)
    k = [key for key in keys if key[0] == Script.key][0]
    key_screen = (kx + (k[1] + k[3]) / 2.0, ky + (k[2] + k[4]) / 2.0)
    Script.key_xy = key_screen
    Script.state = "key"
    pump(0.6)
    check("the cursor is the fingertip: it moves onto the key", w.scene.pointer_kind == "hand"
          and w.scene.pointer is not None and abs(w.scene.pointer[0] - key_screen[0]) < 3
          and abs(w.scene.pointer[1] - key_screen[1]) < 3, str(w.scene.pointer))
    check("the key under the finger is highlighted", w.scene.keys_hover == Script.key, str(w.scene.keys_hover))
    check("a pinch on a key presses that key, once", pressed.count(Script.key) == 1, str(pressed))

    # the pinch holds for several frames: still one press
    pump(0.4)
    check("holding the pinch does not press the key again", pressed.count(Script.key) == 1, str(pressed))

    # open the hand, then pinch in the empty room: a click on the room, not a key
    Script.state = "open"
    pump(0.4)
    check("opening the hand releases the key", w.scene.keys_pressed is None)
    Script.room_xy = (120.0, 110.0)
    Script.state = "room"
    pump(0.6)
    check("a pinch away from the keyboard clicks the room", len(clicked) >= 1, str(clicked))
    check("the room click is where the fingertip is", clicked and abs(clicked[0][0] - 120) <= 3
          and abs(clicked[0][1] - 110) <= 3, str(clicked))
    check("a pinch in the room does not press a key", pressed.count(Script.key) == 1, str(pressed))

    # turning camera mode off stops the worker and gives the cursor back to the mouse
    Script.state = "open"
    w._set_camera(False)
    pump(0.3)
    check("camera mode off stops the camera worker", getattr(w, "cam_worker", None) is None)
    check("camera mode off hides the picture and keyboard", not w.scene.cam_on)
    check("camera mode off is remembered", w.cfg.get("camera_on") is False)

    # a missing library is refused with what to install, and camera mode stays off
    with mock.patch.object(ht, "camera_ready", lambda: (False, "Camera mode needs OpenCV. Run pip install -r "
                                                                "requirements-camera.txt")):
        toasts = []
        w.toast = lambda text, *a, **k: toasts.append(text)
        w._set_camera(True)
    check("without the libraries, camera mode says what to install", any("requirements-camera.txt" in t
                                                                          for t in toasts), str(toasts))
    check("without the libraries, camera mode stays off", w.cfg.get("camera_on") is False and not w.scene.cam_on)

    w.close()

print()
print(f"RESULT {sum(ok for _, ok in results)} / {len(results)}")
if failures:
    print(f"{failures} check(s) failed")
    os._exit(1)
print("all camera mode checks passed")
os._exit(0)
