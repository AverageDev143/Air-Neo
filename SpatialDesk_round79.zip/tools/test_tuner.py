"""Checks for the window card (the top-bar button's card): it is a child of the desk, not a window of its own; it
stays inside the desk; it is closed by a press outside it and whenever the windows or the mode change; and its size
buttons act on the window they were opened for, not on a list position.

The placement rule is run on its own (numpy and the standard library only). The Qt widgets are checked by reading the
source, since PySide6 is not needed for that. usage: python tools/test_tuner.py
"""
import ast
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
TUNER_PATH = os.path.join(ROOT, "tuner_ui.py")
SPATIAL_PATH = os.path.join(ROOT, "spatial_desk.py")
INSTALL_PATH = os.path.join(ROOT, "app_install.py")

tuner_src = open(TUNER_PATH, encoding="utf-8").read()
spatial_src = open(SPATIAL_PATH, encoding="utf-8").read()
install_src = open(INSTALL_PATH, encoding="utf-8").read()

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


# ---- the placement rule, run from the source file (the function has no Qt in it)
ns = {}
for node in ast.parse(tuner_src).body:
    if isinstance(node, ast.FunctionDef) and node.name == "card_origin":
        exec(compile(ast.Module([node], []), TUNER_PATH, "exec"), ns)
card_origin = ns["card_origin"]

W, H = 1920, 1080
MARGIN = 8
bad = []
for card_w, card_h in ((260, 300), (340, 420), (520, 600)):
    for x in range(0, W + 1, 37):
        for y in range(0, H + 1, 29):
            left, top = card_origin(x, y, card_w, card_h, W, H)
            inside = (left >= MARGIN and top >= MARGIN
                      and left + card_w <= W - MARGIN and top + card_h <= H - MARGIN)
            if not inside:
                bad.append((card_w, card_h, x, y, left, top))
check("the card stays fully inside the desk for every point, every card size (grid of points)", not bad,
      f"{len(bad)} points, first {bad[:2]}")

check("away from the edges the card sits just down and to the right of the point",
      card_origin(400, 300, 260, 300, W, H) == (412, 312))
check("a point at the top-left corner still gives a card that starts inside the desk",
      card_origin(0, 0, 260, 300, W, H) == (12, 12))
check("a point at the bottom-right corner is pulled back so the card ends at the margin",
      card_origin(W - 1, H - 1, 260, 300, W, H) == (W - 260 - MARGIN, H - 300 - MARGIN))

# the old rule (no clamp) must fail the same check, so the grid check is able to catch a regression
old_left, old_top = 1919 + 12, 1079 + 12
check("the old unclamped rule would have put the card off the desk (the check can catch that)",
      old_left + 260 > W - MARGIN and old_top + 300 > H - MARGIN)

# ---- the card itself: a child widget with no window flags, hidden until it is shown
check("the card is not a tool, popup or topmost window of its own",
      "WindowType.Tool" not in tuner_src and "WindowType.Popup" not in tuner_src
      and "WindowStaysOnTopHint" not in tuner_src)
check("the card takes its parent in the constructor (super().__init__(parent))",
      "super().__init__(parent)" in tuner_src)
check("the card is hidden until it is shown", "        self.hide()\n\n    def paintEvent" in tuner_src)
check("the card puts itself inside its parent (the desk) when shown",
      "self._desk.rect()" in tuner_src and "card_origin(" in tuner_src)
check("the card no longer installs an application-wide filter (that was the old click-away)",
      "QApplication" not in tuner_src and "installEventFilter" not in tuner_src)

# ---- the desk: structure read from the syntax tree
tree = ast.parse(spatial_src)


def find_class(name):
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == name:
            return node
    return None


def find_method(cls, name):
    if cls is None:
        return None
    for node in cls.body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def calls_method(fn, name):
    if fn is None:
        return False
    for node in ast.walk(fn):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == name):
            return True
    return False


main_cls = find_class("MainWindow")
open_fn = find_method(main_cls, "_open_tuner")
check("the top-bar button opens the card from MainWindow", open_fn is not None)

tuner_calls = [n for n in ast.walk(open_fn) if isinstance(n, ast.Call)
               and isinstance(n.func, ast.Name) and n.func.id == "WindowTuner"] if open_fn else []
parent_is_desk = any(kw.arg == "parent" and isinstance(kw.value, ast.Name) and kw.value.id == "self"
                     for call in tuner_calls for kw in call.keywords)
check("the card is created with the desk as its parent (parent=self)", parent_is_desk)

lambdas = [n for n in ast.walk(open_fn) if isinstance(n, ast.Lambda)] if open_fn else []
captures_index = any(
    isinstance(d, ast.Name) and d.id == "idx"
    for lam in lambdas for d in lam.args.defaults
)
check("the card's callbacks hold the window itself, not a list index that can go stale", not captures_index)

check("the card's size buttons find their window by identity", "_resize_window" in spatial_src
      and "q is p" in spatial_src)
reset_fn = find_method(main_cls, "_reset_window_size")
check("Reset size takes the window itself", reset_fn is not None and [a.arg for a in reset_fn.args.args] == ["self", "p"])

for name in ("close_panel", "set_mode", "shutdown", "_open_tuner"):
    check(f"{name} closes the card first", calls_method(find_method(main_cls, name), "_close_tuner"))

check("a press outside the card closes it, from one watcher that is installed once",
      "installEventFilter(self._tuner_watch)" in spatial_src
      and spatial_src.count("installEventFilter(self._tuner_watch)") == 1)
watch_cls = find_class("_TunerWatch")
watch_fn = find_method(watch_cls, "eventFilter")
watches_presses = watch_fn is not None and "MouseButtonPress" in ast.dump(watch_fn)
check("the watcher reacts to mouse presses", watches_presses)
check("the outside-press rule is limited to this window (obj.window() is self)",
      "obj.window() is not self" in spatial_src)

# the card slot exists before anything else in __init__ can touch it
init_fn = find_method(main_cls, "__init__")
first_assign = None
for stmt in init_fn.body:
    if (isinstance(stmt, ast.Assign) and any(isinstance(t, ast.Attribute) and t.attr == "_tuner" for t in stmt.targets)):
        first_assign = stmt.lineno
        break
first_watch = next((n.lineno for n in ast.walk(init_fn) if isinstance(n, ast.Attribute) and n.attr == "_tuner_watch"),
                   None)
check("the card slot is set first in MainWindow.__init__",
      first_assign is not None and first_watch is not None and first_assign < first_watch)

# ---- the version
m = re.search(r'APP_VERSION = "(\d+)"', install_src)
check("the app version is 79 (this round)", m is not None and m.group(1) == "79", f"found {m.group(1) if m else None}")

print()
if failures:
    print(f"{failures} check(s) failed")
    sys.exit(1)
print("all window card checks passed")
