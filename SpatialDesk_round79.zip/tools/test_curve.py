"""Checks for the curved windows: the ray test that clicks use, and the grid the vertex shader bends.
Needs numpy only. The functions are read from spatial_desk.py with `ast`.
usage: python tools/test_curve.py
"""
import ast
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_PATH = os.path.join(HERE, "..", "spatial_desk.py")
with open(SRC_PATH, encoding="utf-8") as f:
    TREE = ast.parse(f.read())

ns = {"np": np, "math": math}
for node in TREE.body:
    if isinstance(node, ast.FunctionDef) and node.name in ("curved_hit", "build_panel_grid"):
        exec(compile(ast.Module([node], []), SRC_PATH, "exec"), ns)
curved_hit, build_panel_grid = ns["curved_hit"], ns["build_panel_grid"]

failures = 0


def check(name, ok, detail=""):
    global failures
    if ok:
        print(f"PASS  {name}")
    else:
        failures += 1
        print(f"FAIL  {name}  {detail}")


def translate(x, y, z):
    m = np.eye(4)
    m[0, 3], m[1, 3], m[2, 3] = x, y, z
    return m


W, H = 2.8, 1.575          # a window 2.8 m wide, 16:9
D = 2.6                    # its distance from you
VIEW = np.array([0.0, 0.0, 0.0, 1.0])


def bent_point_world(x, y, kappa):
    """The same bend the vertex shader applies, placed in front of the viewer (window centre at z = -D)."""
    if kappa <= 1e-9:
        return np.array([x, y, -D, 1.0])
    R = 1.0 / kappa
    phi = x / R
    return np.array([R * math.sin(phi), y, -D + R * (1.0 - math.cos(phi)), 1.0])


def ray_to(point):
    d = point.copy()
    d[3] = 0.0
    return d


flat_place = translate(0.0, 0.0, -D)

# A ray straight at the middle of a flat window hits its centre.
hit = curved_hit(VIEW, ray_to(np.array([0.0, 0.0, -D, 1.0])), flat_place, W, H, 0.0)
check("flat: centre of the window is hit at the centre", hit is not None and abs(hit[1] - 0.5) < 1e-9
      and abs(hit[2] - 0.5) < 1e-9, str(hit))

# A ray at a point on the bent surface should come back to the same texture position.
kappa = 1.0 / D
for x, y in ((0.5, 0.0), (-1.0, 0.4), (1.3, -0.6), (0.0, 0.7)):
    p = bent_point_world(x, y, kappa)
    hit = curved_hit(VIEW, ray_to(p), flat_place, W, H, kappa)
    ok = hit is not None and abs(hit[1] - (x / W + 0.5)) < 1e-6 and abs(hit[2] - (0.5 - y / H)) < 1e-6
    check(f"curved: point x={x:+.1f}, y={y:+.1f} is picked where it is drawn", ok, str(hit))

# Partial curvature (curve 0.5) also round-trips.
k_half = 0.5 / D
p = bent_point_world(0.9, 0.2, k_half)
hit = curved_hit(VIEW, ray_to(p), flat_place, W, H, k_half)
check("half curvature: picked where drawn",
      hit is not None and abs(hit[1] - (0.9 / W + 0.5)) < 1e-6, str(hit))

# Rays that miss: pointing away, or past the edge of the bent window.
check("a ray pointing away misses", curved_hit(VIEW, np.array([0.0, 0.0, 1.0, 0.0]), flat_place, W, H, kappa) is None)
past_edge = bent_point_world(1.6, 0.0, kappa)    # beyond the 1.4 m half width
check("a ray past the edge misses", curved_hit(VIEW, ray_to(past_edge), flat_place, W, H, kappa) is None)

# The bent surface lies on a cylinder of radius 1/kappa around the viewer's axis (through the viewer).
R = 1.0 / kappa
viewer_local = np.array([0.0, 0.0, R])            # the viewer, in the window's own frame
dists = []
for x in np.linspace(-1.4, 1.4, 25):
    for y in (-0.7, 0.0, 0.7):
        p = bent_point_world(x, y, kappa)
        local = p[:3] - np.array([0.0, 0.0, -D]) # window frame: centre at the origin
        dists.append(np.linalg.norm(local[[0, 2]] - viewer_local[[0, 2]]))
check("bent points stay on the cylinder round the viewer", max(abs(d - R) for d in dists) < 1e-9,
      f"max error {max(abs(d - R) for d in dists):.2e}")

# The vertex grid covers the quad, with the same texture coordinates as the flat quad.
grid = build_panel_grid()
verts = grid.reshape(-1, 5)
check("grid has 32 x 24 cells of two triangles", len(verts) == 32 * 24 * 6, str(len(verts)))
check("grid spans the quad", abs(verts[:, 0].min() + 0.5) < 1e-6 and abs(verts[:, 0].max() - 0.5) < 1e-6
      and abs(verts[:, 1].min() + 0.5) < 1e-6 and abs(verts[:, 1].max() - 0.5) < 1e-6)
check("texture coordinates match the flat quad",
      np.allclose(verts[:, 3], verts[:, 0] + 0.5) and np.allclose(verts[:, 4], 0.5 - verts[:, 1]))

print()
if failures:
    print(f"{failures} check(s) failed")
    raise SystemExit(1)
print("all curved window checks passed")
