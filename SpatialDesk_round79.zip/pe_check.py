"""Checks a Windows library (DLL) before it is loaded.

When Windows is asked to load a file that is not a valid program for this computer, it shows a dialog that says the
file "is either not designed to run on Windows or it contains an error". That happens for a 32-bit DLL in 64-bit Python,
a Mac or Linux library saved under a .dll name, or an error page saved as a .dll. This module reads the file's header
first, so the app can say what is wrong and never asks Windows to load a file that cannot load.

It is plain Python: checking a file needs neither Windows nor Qt, so it is tested anywhere.
"""
import os
import struct

IMAGE_FILE_DLL = 0x2000
MACHINE_NAMES = {0x014C: "32-bit (x86)", 0x8664: "64-bit (x64)", 0xAA64: "64-bit (ARM64)"}


def machines_for(bits):
    """The machine types a Python of this bit width can load a DLL for. 64-bit Python also runs on ARM64 Windows."""
    return {0x8664, 0xAA64} if bits == 64 else {0x014C}


def read_header(path):
    """(machine, characteristics) from a Windows program file. Raises ValueError saying what is wrong with it."""
    size = os.path.getsize(path)
    if size < 64:
        raise ValueError("it is too small to be a program")
    with open(path, "rb") as f:
        if f.read(2) != b"MZ":
            raise ValueError("it does not start like a Windows program")
        f.seek(0x3C)
        raw = f.read(4)
        if len(raw) != 4:
            raise ValueError("it is cut short")
        (pe_at,) = struct.unpack("<I", raw)
        if pe_at + 24 > size:
            raise ValueError("it is cut short")
        f.seek(pe_at)
        if f.read(4) != b"PE\x00\x00":
            raise ValueError("it has no Windows program header")
        fields = f.read(20)
        if len(fields) != 20:
            raise ValueError("it is cut short")
    machine, _sections, _stamp, _symtab, _symbols, _opt_size, characteristics = struct.unpack("<HHIIIHH", fields)
    return machine, characteristics


def check_library(path, bits=None):
    """None when the file is a DLL this Python can load. Otherwise a short reason, to show the user, such as
    'is a 32-bit (x86) library, but this Python is 64-bit'."""
    if bits is None:
        bits = struct.calcsize("P") * 8
    if not os.path.isfile(path):
        return "is missing"
    try:
        machine, characteristics = read_header(path)
    except (OSError, ValueError, struct.error) as e:
        return f"is not a Windows library ({e})"
    if not characteristics & IMAGE_FILE_DLL:
        return "is a program, not a library (DLL)"
    if machine not in machines_for(bits):
        name = MACHINE_NAMES.get(machine, f"machine type 0x{machine:04X}")
        return f"is a {name} library, but this Python is {bits}-bit"
    return None


def save_checked(data, path, bits=None):
    """Writes data to path only when it is a library this Python can load. It is written to a temporary file, checked,
    then moved into place, so a bad download never replaces a good file. Returns None on success, or the reason
    it was refused (and then nothing is written)."""
    tmp = path + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    reason = check_library(tmp, bits)
    if reason is not None:
        os.remove(tmp)
        return reason
    os.replace(tmp, path)
    return None
