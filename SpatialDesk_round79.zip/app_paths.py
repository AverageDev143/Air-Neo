"""Where Spatial Desk keeps what you save: your accounts and your settings.

These live in one folder per user, not beside the program files. So they are the same however the app is started
(from its folder, the desktop shortcut, or the Start menu), and they survive moving or reinstalling the program.
Set SPATIAL_DESK_DATA to use another folder; the tests do, so they never touch your real accounts.

No Qt here, so this runs anywhere and can be tested directly.
"""
import os
import shutil
import sys

APP_FOLDER = "Spatial Desk"


def data_dir():
    """The folder for accounts and settings, created by whoever saves into it."""
    override = os.environ.get("SPATIAL_DESK_DATA")
    if override:
        return os.path.abspath(override)
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    elif sys.platform == "darwin":
        base = os.path.join(os.path.expanduser("~"), "Library", "Application Support")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, APP_FOLDER)


def accounts_file():
    return os.path.join(data_dir(), "accounts.json")


def settings_file():
    return os.path.join(data_dir(), "settings.json")


def migrate_from_program_folder(here):
    """Copies the accounts and settings that earlier versions kept beside the program into the data folder.

    Only when the new file is missing, so nothing is overwritten, and the old files are left where they are.
    Returns the list of files that were copied.
    """
    copied = []
    pairs = ((os.path.join(here, "accounts_data", "accounts.json"), accounts_file()),
             (os.path.join(here, "settings.json"), settings_file()))
    for old, new in pairs:
        if os.path.isfile(old) and not os.path.exists(new):
            os.makedirs(os.path.dirname(new), exist_ok=True)
            shutil.copy2(old, new)
            copied.append(new)
    return copied
