"""The window tuner: a small card that opens beside the cursor from a window's top-bar button. It sets the window's
curve, shape and size.

The card is a child widget of the desk window, not a window of its own. A separate top-level window was not painted
until the desk lost focus, and it stayed on screen after the desk closed. As a child it is drawn with the desk, shows
at once, and goes away with it. The desk closes it on a press outside the card (see MainWindow._tuner_outside_press).
"""
from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

TUNER_QSS = """
QLabel#tunerHead { color: #f5f6f8; font-family: "Segoe UI Variable Display", "Segoe UI"; font-size: 13pt; font-weight: 300; background: transparent; }
QLabel#tunerSmall { color: #7b8294; font-size: 9pt; font-weight: 300; background: transparent; }
QPushButton#tunerOpt { background: rgba(255,255,255,8); color: #e6e9ef; border: 1px solid rgba(255,255,255,18); border-radius: 13px; padding: 9px 14px; font-size: 10pt; font-weight: 300; text-align: left; }
QPushButton#tunerOpt:hover { background: rgba(255,255,255,18); border: 1px solid rgba(255,255,255,50); }
QPushButton#tunerOpt:checked { background: #eef0f4; color: #0b0c0f; border: 1px solid #eef0f4; font-weight: 300; }
QPushButton#tunerStep { background: rgba(255,255,255,8); color: #f5f6f8; border: 1px solid rgba(255,255,255,18); border-radius: 13px; padding: 7px 0px; font-size: 13pt; font-weight: 300; min-width: 44px; }
QPushButton#tunerStep:hover { background: rgba(255,255,255,18); }
QPushButton#tunerReset { background: transparent; color: #c9ced9; border: 1px solid rgba(255,255,255,30); border-radius: 13px; padding: 8px 12px; font-size: 9.5pt; font-weight: 300; }
QPushButton#tunerReset:hover { color: #ffffff; border: 1px solid rgba(255,255,255,70); }
"""


def card_origin(x, y, w, h, area_w, area_h, offset=12, margin=8):
    """Top-left corner of a w x h card shown beside the point (x, y) inside an area of area_w x area_h.

    The card sits just down and to the right of the point. Near an edge it is moved back so that the whole card
    stays inside the area, with a margin, and its top-left corner never goes negative."""
    left = max(margin, min(x + offset, area_w - w - margin))
    top = max(margin, min(y + offset, area_h - h - margin))
    return left, top


class WindowTuner(QFrame):
    """Curve on or off, the window's shape, and its size. Choices apply at once; the card stays open until you click away."""

    def __init__(self, title, curved, shape, shape_labels, on_curve, on_shape, on_size, on_reset, parent=None):
        super().__init__(parent)             # a child of the desk: no window flags, so it cannot be left on screen alone
        self._desk = parent                  # the window the card is kept inside
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setObjectName("tuner")
        self.setStyleSheet(TUNER_QSS)
        self.setMinimumWidth(260)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(9)

        head = QLabel(title)
        head.setObjectName("tunerHead")
        lay.addWidget(head)

        lay.addWidget(self._small("Curve"))
        self.curve_btn = QPushButton("Curved window" if curved else "Flat window")
        self.curve_btn.setObjectName("tunerOpt")
        self.curve_btn.setCheckable(True)
        self.curve_btn.setChecked(curved)
        self.curve_btn.toggled.connect(lambda on: self._curve_toggled(on, on_curve))
        lay.addWidget(self.curve_btn)

        lay.addWidget(self._small("Shape"))
        self._shape_btns = {}
        for key, label in shape_labels.items():
            b = QPushButton(label)
            b.setObjectName("tunerOpt")
            b.setCheckable(True)
            b.setChecked(key == shape)
            b.clicked.connect(lambda _c=False, k=key: self._shape_chosen(k, on_shape))
            self._shape_btns[key] = b
            lay.addWidget(b)

        lay.addWidget(self._small("Size"))
        row = QHBoxLayout()
        smaller = QPushButton("\u2212")
        smaller.setObjectName("tunerStep")
        smaller.clicked.connect(lambda: on_size(1 / 1.15))
        bigger = QPushButton("+")
        bigger.setObjectName("tunerStep")
        bigger.clicked.connect(lambda: on_size(1.15))
        reset = QPushButton("Reset size")
        reset.setObjectName("tunerReset")
        reset.clicked.connect(on_reset)
        row.addWidget(smaller)
        row.addWidget(bigger)
        row.addStretch(1)
        row.addWidget(reset)
        lay.addLayout(row)
        self.hide()

    def paintEvent(self, ev):
        """A solid black card with rounded corners, painted here so no style sheet or Windows theme can make it grey."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(rect, 22, 22)
        painter.fillPath(path, QColor(0, 0, 0))
        painter.setPen(QPen(QColor(255, 255, 255, 40), 1))
        painter.drawPath(path)
        painter.end()

    def show_at(self, local_x, local_y):
        """Shows the card beside a point given in the desk's own coordinates, kept fully inside the desk."""
        self.adjustSize()
        area = self._desk.rect()
        x, y = card_origin(local_x, local_y, self.width(), self.height(), area.width(), area.height())
        self.move(x, y)
        self.show()
        self.raise_()

    def _small(self, text):
        lab = QLabel(text)
        lab.setObjectName("tunerSmall")
        return lab

    def _curve_toggled(self, on, callback):
        self.curve_btn.setText("Curved window" if on else "Flat window")
        callback(on)

    def _shape_chosen(self, key, callback):
        for k, b in self._shape_btns.items():
            b.setChecked(k == key)
        callback(key)
