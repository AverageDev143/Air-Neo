"""The Spatial Desk login: pick an account, sign in with its password, or create one with a pre-made profile icon.

The icons are drawn here in code (eight designs, each a gradient with an emblem). None is a copied picture.
The accounts themselves are in accounts_core.py: local to this computer, with no online account behind them.
"""
import copy
import math
import os

from PySide6.QtCore import Property, QEasingCurve, QPointF, QPropertyAnimation, QRectF, Qt, Signal, QPoint
from PySide6.QtGui import QBrush, QColor, QPainter, QPainterPath, QPen, QRadialGradient, QLinearGradient
from PySide6.QtWidgets import (QCheckBox, QFrame, QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QLabel,
                               QLineEdit, QPushButton, QStackedWidget, QVBoxLayout, QWidget)

import accounts_core as ac
import app_icon as spatial_icon

AVATAR_COLORS = {
    "orbit": ("#7dd3fc", "#3730a3"), "ember": ("#fdba74", "#9f1239"), "leaf": ("#86efac", "#14532d"),
    "wave": ("#67e8f9", "#1e3a8a"), "crystal": ("#f5d0fe", "#6b21a8"), "moon": ("#cbd5e1", "#0f172a"),
    "bolt": ("#fde68a", "#78350f"), "sun": ("#fef08a", "#c2410c"),
}

GATE_QSS = """
QLabel#gateTitle { color: #f5f6f8; font-family: "Segoe UI Variable Display", "Segoe UI"; font-size: 40pt; font-weight: 600; background: transparent; }
QLabel#gateSub { color: #9aa2b3; font-size: 13pt; background: transparent; }
QLabel#gateName { color: #f5f6f8; font-size: 13pt; font-weight: 600; background: transparent; }
QLabel#gateSmall { color: #7b8294; font-size: 9.5pt; background: transparent; }
QLabel#gateError { color: #ff9b9b; font-size: 10pt; background: transparent; }
QLabel#gateHead { color: #f5f6f8; font-size: 18pt; font-weight: 600; background: transparent; }
QLineEdit#gateField { background: rgba(255,255,255,8); border: 1px solid rgba(255,255,255,18); border-radius: 14px; color: #f5f6f8; padding: 12px 16px; font-size: 12pt; min-width: 300px; selection-background-color: #5a6275; }
QLineEdit#gateField:focus { border: 1px solid rgba(255,255,255,80); }
QPushButton#gatePrimary { background: #eef0f4; color: #0b0c0f; border: 0; border-radius: 16px; padding: 12px 30px; font-size: 11.5pt; font-weight: 600; }
QPushButton#gatePrimary:hover { background: #ffffff; }
QPushButton#gateGhost { background: transparent; color: #c9ced9; border: 1px solid rgba(255,255,255,30); border-radius: 16px; padding: 11px 24px; font-size: 11pt; }
QPushButton#gateGhost:hover { border: 1px solid rgba(255,255,255,80); color: #ffffff; }
QPushButton#gateCard { background: rgba(255,255,255,7); border: 1px solid rgba(255,255,255,16); border-radius: 26px; }
QPushButton#gateCard:hover { background: rgba(255,255,255,15); border: 1px solid rgba(255,255,255,70); }
QPushButton#gateChoice { background: transparent; border: 2px solid transparent; border-radius: 40px; }
QPushButton#gateChoice:hover { border: 2px solid rgba(255,255,255,60); }
QPushButton#gateChoice:checked { border: 2px solid #eef0f4; }
QPushButton#gateSmall { background: transparent; color: #aab1c0; border: 1px solid rgba(255,255,255,26); border-radius: 13px; padding: 7px 18px; font-size: 9.5pt; }
QPushButton#gateSmall:hover { border: 1px solid rgba(255,255,255,80); color: #ffffff; }
QPushButton#gateSmall:disabled { color: #4f5566; border: 1px solid rgba(255,255,255,12); }
QLabel#gateNotice { color: #e8c07a; font-size: 9.5pt; background: transparent; }
QLabel#gateOk { color: #9ee6bd; font-size: 10.5pt; background: transparent; }
QCheckBox#gateCheck { color: #c9ced9; font-size: 11pt; background: transparent; spacing: 10px; }
QCheckBox#gateCheck::indicator { width: 18px; height: 18px; border-radius: 6px; border: 1px solid rgba(255,255,255,60); background: rgba(255,255,255,8); }
QCheckBox#gateCheck::indicator:checked { background: #eef0f4; border: 1px solid #eef0f4; }
"""


def paint_avatar(p, rect, avatar_id):
    """Draws one pre-made profile icon into rect: a gradient disc with a white emblem."""
    c1, c2 = AVATAR_COLORS.get(avatar_id, AVATAR_COLORS["orbit"])
    side = min(rect.width(), rect.height())
    center = rect.center()
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    grad = QRadialGradient(QPointF(center.x() - side * 0.25, center.y() - side * 0.3), side * 0.85)
    grad.setColorAt(0.0, QColor(c1))
    grad.setColorAt(1.0, QColor(c2))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(grad))
    p.drawEllipse(center, side / 2.0, side / 2.0)
    p.translate(center)
    p.scale(side, side)
    white = QColor(255, 255, 255, 235)
    p.setBrush(QBrush(white))
    p.setPen(QPen(white, 0.055, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    if avatar_id == "orbit":
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(0, 0), 0.26, 0.26)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(white))
        p.drawEllipse(QPointF(0.26 * math.cos(0.7), 0.26 * math.sin(0.7)), 0.07, 0.07)
    elif avatar_id == "ember":
        path = QPainterPath(QPointF(0, -0.36))
        path.cubicTo(QPointF(0.26, -0.1), QPointF(0.26, 0.26), QPointF(0, 0.32))
        path.cubicTo(QPointF(-0.26, 0.26), QPointF(-0.26, -0.1), QPointF(0, -0.36))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawPath(path)
    elif avatar_id == "leaf":
        p.setPen(Qt.PenStyle.NoPen)
        p.save()
        p.rotate(45)
        p.drawEllipse(QPointF(0, 0), 0.13, 0.27)
        p.restore()
        p.setPen(QPen(QColor(c2), 0.03))
        p.drawLine(QPointF(-0.17, 0.17), QPointF(0.17, -0.17))
    elif avatar_id == "wave":
        p.setBrush(Qt.BrushStyle.NoBrush)
        for offset in (-0.09, 0.09):
            pts = [QPointF(x / 20.0 - 0.25, offset + 0.05 * math.sin(x / 20.0 * math.pi * 2.0)) for x in range(21)]
            for a, b in zip(pts, pts[1:]):
                p.drawLine(a, b)
    elif avatar_id == "crystal":
        p.setPen(Qt.PenStyle.NoPen)
        p.drawPolygon([QPointF(0, -0.34), QPointF(0.22, -0.04), QPointF(0, 0.34), QPointF(-0.22, -0.04)])
        p.setPen(QPen(QColor(c2), 0.025))
        p.drawLine(QPointF(-0.22, -0.04), QPointF(0.22, -0.04))
        p.drawLine(QPointF(0, -0.34), QPointF(0, 0.34))
    elif avatar_id == "moon":
        outer = QPainterPath()
        outer.addEllipse(QPointF(0, 0), 0.27, 0.27)
        inner = QPainterPath()
        inner.addEllipse(QPointF(0.12, -0.08), 0.23, 0.23)
        p.setPen(Qt.PenStyle.NoPen)
        p.drawPath(outer.subtracted(inner))
    elif avatar_id == "bolt":
        p.setPen(Qt.PenStyle.NoPen)
        p.drawPolygon([QPointF(0.06, -0.36), QPointF(-0.16, 0.04), QPointF(0.0, 0.04),
                       QPointF(-0.06, 0.36), QPointF(0.18, -0.06), QPointF(0.02, -0.06)])
    elif avatar_id == "sun":
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(0, 0), 0.16, 0.16)
        for k in range(8):
            a = k * math.pi / 4.0
            p.drawLine(QPointF(0.24 * math.cos(a), 0.24 * math.sin(a)), QPointF(0.33 * math.cos(a), 0.33 * math.sin(a)))
    p.restore()


class AvatarLabel(QWidget):
    def __init__(self, avatar, size=120, parent=None):
        super().__init__(parent)
        self.avatar = avatar
        self.setFixedSize(size, size)

    def paintEvent(self, ev):
        p = QPainter(self)
        paint_avatar(p, QRectF(self.rect()), self.avatar)
        p.end()


class AccountCard(QPushButton):
    """A sign-in choice: the account's icon and name. Clicking it chooses the account."""

    def __init__(self, name, avatar, parent=None):
        super().__init__(parent)
        self.setObjectName("gateCard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(180, 210)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 22, 14, 18)
        lay.setSpacing(14)
        art = AvatarLabel(avatar, 112)
        lay.addWidget(art, 0, Qt.AlignmentFlag.AlignHCenter)
        label = QLabel(name)
        label.setObjectName("gateName")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        lay.addWidget(label)
        art.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)


class _Choice(QPushButton):
    def __init__(self, avatar, parent=None):
        super().__init__(parent)
        self.avatar = avatar
        self.setObjectName("gateChoice")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(92, 92)

    def paintEvent(self, ev):
        super().paintEvent(ev)
        p = QPainter(self)
        paint_avatar(p, QRectF(self.rect()).adjusted(7, 7, -7, -7), self.avatar)
        p.end()


def _fade_in(owner, widget, ms=340):
    effect = QGraphicsOpacityEffect(widget)
    widget.setGraphicsEffect(effect)
    anim = QPropertyAnimation(effect, b"opacity", owner)
    anim.setDuration(ms)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setEasingCurve(QEasingCurve.Type.OutCubic)
    anim.finished.connect(lambda: widget.setGraphicsEffect(None))
    anim.start()
    return anim


class LoginGate(QWidget):
    """The first thing you see. signed_in(name) is sent when an account is signed in.

    accounts_path is the saved accounts file. install_offer() says whether to offer the Windows app install after an
    account is created; install_now(places) makes the shortcuts and returns (ok, message), with places a list of
    "Desktop" and "Programs". Both are optional: without them the install step is not shown.
    """
    signed_in = Signal(str)

    def __init__(self, accounts_path, install_offer=None, install_now=None, parent=None):
        super().__init__(parent)
        self.setObjectName("gate")
        self.setStyleSheet(GATE_QSS)
        self.accounts_path = accounts_path
        self.install_offer = install_offer
        self.install_now = install_now
        self.read_only = False          # True when the saved accounts exist but cannot be read or moved aside
        self.notice = ""
        self.data = self._load()
        self.chosen = None
        self._pending = None            # the account just created, while the install step is shown
        self._anims = []

        outer = QVBoxLayout(self)
        outer.setContentsMargins(60, 40, 60, 40)
        self.stack = QStackedWidget()
        outer.addStretch(1)
        outer.addWidget(self.stack, 0, Qt.AlignmentFlag.AlignCenter)
        outer.addStretch(1)
        self.pages = {}
        for name, build in (("pick", self._page_pick), ("password", self._page_password),
                            ("create", self._page_create), ("install", self._page_install)):
            page = build()
            self.pages[name] = page
            self.stack.addWidget(page)
        self._refresh_pick()
        self._go("pick" if self.data["accounts"] else "create")

    # ----- background: a plain dark room, no photograph
    def paintEvent(self, ev):
        p = QPainter(self)
        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0.0, QColor(16, 17, 21))
        grad.setColorAt(1.0, QColor(4, 4, 6))
        p.fillRect(self.rect(), QBrush(grad))
        p.end()

    def _go(self, name):
        self.stack.setCurrentWidget(self.pages[name])
        self._anims.append(_fade_in(self, self.pages[name]))

    # ----- loading and saving: a damaged file is kept, never overwritten
    def _load(self):
        data, status = ac.load_status(self.accounts_path)
        if status == "damaged":
            try:
                kept = ac.set_aside(self.accounts_path)
                self.notice = (f"Your saved accounts could not be read, so the file was kept as "
                               f"{os.path.basename(kept)}.")
            except OSError:
                self.read_only = True
                self.notice = ("Your saved accounts could not be read or moved, so new accounts cannot be saved. "
                               "Check the accounts file, then start the app again.")
        return data

    def _save(self, data):
        """Saves the accounts. Returns False, with the reason shown, when the file cannot be written."""
        if self.read_only:
            return False
        try:
            ac.save(self.accounts_path, data)
            self.notice = ""
            return True
        except OSError as e:
            self.notice = f"Could not save the accounts: {e}"
            return False

    def reset(self):
        """Back to the picker, with the accounts as they are now (after signing out, or Back)."""
        self.data = self._load()
        self.chosen = None
        self._pending = None
        self._refresh_pick()
        self._go("pick" if self.data["accounts"] else "create")

    def _page(self, spacing=16):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(spacing)
        lay.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        return w, lay

    # ----- the picker: the accounts, and a small button at the bottom to add one
    def _page_pick(self):
        w, lay = self._page(26)
        title = QLabel("Spatial Desk")
        title.setObjectName("gateTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)
        self.pick_sub = QLabel("")
        self.pick_sub.setObjectName("gateSub")
        self.pick_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.pick_sub)
        self.cards_host = QWidget()
        self.cards = QGridLayout(self.cards_host)
        self.cards.setSpacing(20)
        lay.addWidget(self.cards_host, 0, Qt.AlignmentFlag.AlignCenter)
        self.pick_notice = QLabel("")
        self.pick_notice.setObjectName("gateNotice")
        self.pick_notice.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pick_notice.setWordWrap(True)
        lay.addWidget(self.pick_notice)
        note = QLabel("These accounts stay on this computer. Nothing is sent anywhere.")
        note.setObjectName("gateSmall")
        note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(note)
        add = QPushButton("Add account")
        add.setObjectName("gateSmall")
        add.setCursor(Qt.CursorShape.PointingHandCursor)
        add.setToolTip("Create another account on this computer")
        add.clicked.connect(self._open_create)
        self.add_button = add
        lay.addWidget(add, 0, Qt.AlignmentFlag.AlignHCenter)
        return w

    def _refresh_pick(self):
        """Brings the picker up to date with the accounts: the subtitle, the cards, and any notice."""
        n = len(self.data["accounts"])
        self.pick_sub.setText("Who is using the desk?" if n else "Create your account to begin")
        self._rebuild_cards()
        self.pick_notice.setText(self.notice)
        self.add_button.setEnabled(not self.read_only)
        self.create_back.setVisible(n > 0)
        self.create_make.setEnabled(not self.read_only)
        self.create_error.setText(self.notice if self.read_only else "")

    def _rebuild_cards(self):
        while self.cards.count():
            item = self.cards.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        items = ac.accounts_list(self.data)
        for k, (name, avatar) in enumerate(items):
            card = AccountCard(name, avatar)
            card.clicked.connect(lambda _c=False, n=name: self._choose(n))
            self.cards.addWidget(card, k // 4, k % 4)

    def _choose(self, name):
        self.chosen = name
        avatar = dict(ac.accounts_list(self.data))[name]
        self.big_avatar.avatar = avatar
        self.big_avatar.update()
        self.chosen_name.setText(name)
        self.password_field.clear()
        self.password_error.setText("")
        self._go("password")
        self.password_field.setFocus()

    # ----- the password
    def _page_password(self):
        w, lay = self._page(18)
        self.big_avatar = AvatarLabel("orbit", 130)
        lay.addWidget(self.big_avatar, 0, Qt.AlignmentFlag.AlignHCenter)
        self.chosen_name = QLabel("")
        self.chosen_name.setObjectName("gateHead")
        self.chosen_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.chosen_name)
        self.password_field = QLineEdit()
        self.password_field.setObjectName("gateField")
        self.password_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_field.setPlaceholderText("password")
        self.password_field.returnPressed.connect(self._sign_in)
        lay.addWidget(self.password_field, 0, Qt.AlignmentFlag.AlignHCenter)
        self.password_error = QLabel("")
        self.password_error.setObjectName("gateError")
        self.password_error.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.password_error)
        row = QHBoxLayout()
        back = QPushButton("Back")
        back.setObjectName("gateGhost")
        back.clicked.connect(lambda: self.reset())
        go = QPushButton("Sign in")
        go.setObjectName("gatePrimary")
        go.clicked.connect(self._sign_in)
        row.addWidget(back)
        row.addWidget(go)
        lay.addLayout(row)
        self.password_card = w
        return w

    def _sign_in(self):
        data = copy.deepcopy(self.data)
        if not ac.sign_in(data, self.chosen or "", self.password_field.text()):
            self.password_error.setText("That password is not right.")
            self._shake(self.password_card)
            return
        self.data = data
        self._save(self.data)            # remembers the account for next time; a failed save does not stop sign-in
        self.password_error.setText("")
        self.signed_in.emit(self.chosen)

    def _shake(self, widget):
        start = widget.pos()
        anim = QPropertyAnimation(widget, b"pos", self)
        anim.setDuration(360)
        anim.setKeyValueAt(0.2, start + QPoint(-12, 0))
        anim.setKeyValueAt(0.45, start + QPoint(10, 0))
        anim.setKeyValueAt(0.7, start + QPoint(-6, 0))
        anim.setEndValue(start)
        anim.start()
        self._anims.append(anim)

    # ----- creating an account
    def _page_create(self):
        w, lay = self._page(14)
        self.create_head = QLabel("New account")
        self.create_head.setObjectName("gateHead")
        self.create_head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.create_head)
        self.new_name = QLineEdit()
        self.new_name.setObjectName("gateField")
        self.new_name.setPlaceholderText("name")
        lay.addWidget(self.new_name, 0, Qt.AlignmentFlag.AlignHCenter)
        pick_label = QLabel("Pick a profile icon")
        pick_label.setObjectName("gateSmall")
        pick_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(pick_label)
        grid = QGridLayout()
        grid.setSpacing(8)
        self._choices = []
        for k, avatar in enumerate(ac.AVATARS):
            b = _Choice(avatar)
            b.clicked.connect(lambda _c=False, a=avatar: self._pick_avatar(a))
            self._choices.append(b)
            grid.addWidget(b, k // 4, k % 4)
        lay.addLayout(grid)
        self._pick_avatar(ac.AVATARS[0])
        self.new_pass = QLineEdit()
        self.new_pass.setObjectName("gateField")
        self.new_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.new_pass.setPlaceholderText(f"password, at least {ac.MIN_PASSWORD} characters")
        lay.addWidget(self.new_pass, 0, Qt.AlignmentFlag.AlignHCenter)
        self.new_pass2 = QLineEdit()
        self.new_pass2.setObjectName("gateField")
        self.new_pass2.setEchoMode(QLineEdit.EchoMode.Password)
        self.new_pass2.setPlaceholderText("type the password again")
        self.new_pass2.returnPressed.connect(self._create)
        lay.addWidget(self.new_pass2, 0, Qt.AlignmentFlag.AlignHCenter)
        self.create_error = QLabel("")
        self.create_error.setObjectName("gateError")
        self.create_error.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.create_error)
        row = QHBoxLayout()
        self.create_back = QPushButton("Back")
        self.create_back.setObjectName("gateGhost")
        self.create_back.clicked.connect(lambda: self.reset())
        make = QPushButton("Create account")
        make.setObjectName("gatePrimary")
        make.clicked.connect(self._create)
        self.create_make = make
        row.addWidget(self.create_back)
        row.addWidget(make)
        lay.addLayout(row)
        self.create_card = w
        return w

    def _open_create(self):
        """The Add account button: a clean form, with Back to the accounts when there are some."""
        for field in (self.new_name, self.new_pass, self.new_pass2):
            field.clear()
        self.create_error.setText(self.notice if self.read_only else "")
        self._pick_avatar(ac.AVATARS[0])
        self.create_back.setVisible(bool(self.data["accounts"]))
        self.create_make.setEnabled(not self.read_only)
        self._go("create")
        self.new_name.setFocus()

    def _pick_avatar(self, avatar):
        self._chosen_avatar = avatar
        for b in self._choices:
            b.setChecked(b.avatar == avatar)

    def _create(self):
        if self.read_only:
            self.create_error.setText(self.notice)
            return
        if self.new_pass.text() != self.new_pass2.text():
            self.create_error.setText("The two passwords do not match.")
            self._shake(self.create_card)
            return
        data = copy.deepcopy(self.data)
        try:
            data = ac.create(data, self.new_name.text(), self.new_pass.text(), self._chosen_avatar)
        except ValueError as e:
            self.create_error.setText(str(e))
            self._shake(self.create_card)
            return
        if not self._save(data):
            self.create_error.setText(self.notice)          # the account was not added, so it can be tried again
            return
        self.data = data
        name = ac.validate_name(self.new_name.text())
        for field in (self.new_name, self.new_pass, self.new_pass2):
            field.clear()
        self.create_error.setText("")
        self.chosen = name
        if self.install_offer is not None and self.install_now is not None and self.install_offer():
            self._pending = name
            self._open_install()
            return
        self.signed_in.emit(name)

    # ----- the Windows app step, after the first account is made
    def _page_install(self):
        w, lay = self._page(14)
        icon = QLabel()
        icon.setPixmap(spatial_icon.pixmap(112))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(icon)
        head = QLabel("Add Spatial Desk to Windows")
        head.setObjectName("gateHead")
        head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(head)
        body = QLabel("Put Spatial Desk on your desktop and in the Start menu, with its own icon. "
                      "Your accounts and settings stay the same. You can do this later in Settings.")
        body.setObjectName("gateSub")
        body.setWordWrap(True)
        body.setAlignment(Qt.AlignmentFlag.AlignCenter)
        body.setMaximumWidth(460)
        lay.addWidget(body)
        self.install_desktop = QCheckBox("Desktop shortcut")
        self.install_desktop.setObjectName("gateCheck")
        self.install_desktop.setChecked(True)
        self.install_start = QCheckBox("Start menu")
        self.install_start.setObjectName("gateCheck")
        self.install_start.setChecked(True)
        boxes = QHBoxLayout()
        boxes.addWidget(self.install_desktop)
        boxes.addSpacing(28)
        boxes.addWidget(self.install_start)
        lay.addLayout(boxes)
        self.install_error = QLabel("")
        self.install_error.setObjectName("gateError")
        self.install_error.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.install_error.setWordWrap(True)
        self.install_error.setMaximumWidth(460)
        lay.addWidget(self.install_error)
        self.install_ok = QLabel("")
        self.install_ok.setObjectName("gateOk")
        self.install_ok.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.install_ok.setWordWrap(True)
        self.install_ok.setMaximumWidth(460)
        self.install_ok.hide()
        lay.addWidget(self.install_ok)
        row = QHBoxLayout()
        self.install_skip = QPushButton("Not now")
        self.install_skip.setObjectName("gateGhost")
        self.install_skip.clicked.connect(self._finish_install)
        self.install_add = QPushButton("Add to Windows")
        self.install_add.setObjectName("gatePrimary")
        self.install_add.clicked.connect(self._do_install)
        row.addWidget(self.install_skip)
        row.addWidget(self.install_add)
        lay.addLayout(row)
        return w

    def _open_install(self):
        self.install_error.setText("")
        self.install_ok.hide()
        self.install_add.setVisible(True)
        self.install_skip.setText("Not now")
        self._go("install")

    def _do_install(self):
        places = [name for name, box in (("Desktop", self.install_desktop), ("Programs", self.install_start))
                  if box.isChecked()]
        ok, message = self.install_now(places) if places else (False, "Choose the desktop, the Start menu, or both.")
        if ok:
            self.install_error.setText("")
            self.install_ok.setText(message)
            self.install_ok.show()
            self.install_add.setVisible(False)
            self.install_skip.setText("Continue")
        else:
            self.install_error.setText(message)

    def _finish_install(self):
        name, self._pending = self._pending, None
        if name is not None:
            self.signed_in.emit(name)
