"""Spatial Desk's app icon, drawn in code: a graphite tile with a glass window in front and a dimmer one behind it,
which gives the sense of depth the app is about. It is drawn at each size Windows asks for. The sizes are packed into
an .ico file for the desktop shortcut, and into the window's own icon.

Needs Qt. The file format itself is in app_install.make_ico, which does not.
"""
import os

from PySide6.QtCore import QBuffer, QIODevice, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QIcon, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap

import app_install

ICON_SIZES = app_install.ICON_SIZES
ICON_FILE = "spatial_desk.ico"


def render(size):
    """The icon at size x size pixels, with a transparent background outside the rounded tile."""
    s = float(size)
    img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    tile = QRectF(s * 0.03, s * 0.03, s * 0.94, s * 0.94)
    tile_path = QPainterPath()
    tile_path.addRoundedRect(tile, s * 0.23, s * 0.23)
    tile_grad = QLinearGradient(0, tile.top(), 0, tile.bottom())
    tile_grad.setColorAt(0.0, QColor(44, 48, 58))
    tile_grad.setColorAt(1.0, QColor(10, 11, 14))
    p.fillPath(tile_path, QBrush(tile_grad))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(QPen(QColor(255, 255, 255, 46), max(1.0, s * 0.012)))
    p.drawPath(tile_path)

    # The window behind: dimmer, up and to the right.
    back = QRectF(s * 0.31, s * 0.22, s * 0.45, s * 0.31)
    p.setPen(QPen(QColor(255, 255, 255, 120), max(1.0, s * 0.01)))
    p.setBrush(QBrush(QColor(255, 255, 255, 62)))
    p.drawRoundedRect(back, s * 0.05, s * 0.05)

    # The window in front, with a soft shadow under it.
    front = QRectF(s * 0.18, s * 0.37, s * 0.58, s * 0.39)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(QColor(0, 0, 0, 90)))
    p.drawRoundedRect(front.translated(0, s * 0.025), s * 0.06, s * 0.06)
    pane_grad = QLinearGradient(0, front.top(), 0, front.bottom())
    pane_grad.setColorAt(0.0, QColor(250, 251, 253))
    pane_grad.setColorAt(1.0, QColor(212, 218, 228))
    p.setBrush(QBrush(pane_grad))
    p.drawRoundedRect(front, s * 0.06, s * 0.06)
    if size >= 48:
        # Title bar strip with its three dots, so the window reads as a window at larger sizes.
        bar = QRectF(front.left(), front.top(), front.width(), front.height() * 0.17)
        # Two separate fills: in one path the two overlapping shapes would cancel out under the default fill rule.
        bar_path = QPainterPath()
        bar_path.addRoundedRect(bar, s * 0.06, s * 0.06)
        p.fillPath(bar_path, QBrush(QColor(38, 42, 50)))
        p.fillRect(QRectF(bar.left(), bar.bottom() - s * 0.06, bar.width(), s * 0.06), QColor(38, 42, 50))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(255, 255, 255, 200)))
        for k in range(3):
            cx = bar.left() + bar.width() * (0.08 + 0.05 * k)
            p.drawEllipse(QRectF(cx - s * 0.012, bar.center().y() - s * 0.012, s * 0.024, s * 0.024))
    p.end()
    return img


def png_bytes(size):
    """The icon at one size, as PNG bytes."""
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    render(size).save(buf, "PNG")
    return bytes(buf.data())


def qicon():
    """The icon for the window and the taskbar, with every size in it."""
    icon = QIcon()
    for size in ICON_SIZES:
        icon.addPixmap(QPixmap.fromImage(render(size)))
    return icon


def pixmap(size):
    """The icon as a pixmap of one size, for showing it on a page."""
    return QPixmap.fromImage(render(size))


def write_icon(folder):
    """Writes the .ico file for the desktop shortcut into folder and returns its path."""
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, ICON_FILE)
    data = app_install.make_ico({size: png_bytes(size) for size in ICON_SIZES})
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)
    return path
