"""Virtual Box's screens inside Spatial Desk: the first-run setup and the tunnel panel.

The logic lives in airneo_core.py. This file only draws the screens and calls that logic. It needs Qt, so it runs
only inside Spatial Desk. The first-run setup is animated: the progress ring fills while the keys are made, each step
fades in as each step arrives.
"""
import math
import os
import threading

from PySide6.QtCore import (Property, QEasingCurve, QObject, QPointF, QPropertyAnimation, QRectF, QSize, Qt, QTimer,
                            Signal)
from PySide6.QtGui import (QBrush, QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap, QPolygonF,
                           QRadialGradient)
from PySide6.QtWidgets import (QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QStackedWidget, QVBoxLayout, QWidget)

import airneo_core as core
import wg_install

SETUP_STEPS = ("Computer", "Keys", "Partner", "Finish")

AIRNEO_QSS = """
QFrame#airneo { background: rgba(14,15,18,250); border: 1px solid rgba(255,255,255,24); border-radius: 30px; }
QLabel#airTitle { color: #f5f6f8; font-family: "Segoe UI Variable Display", "Segoe UI"; font-size: 26pt; font-weight: 300; background: transparent; }
QLabel#airHead { color: #f5f6f8; font-size: 15pt; font-weight: 400; background: transparent; }
QLabel#airBrand { color: #f5f6f8; font-size: 12pt; font-weight: 400; background: transparent; }
QLabel#airBody { color: #a3aaba; font-size: 11pt; background: transparent; }
QLabel#airSmall { color: #6f7688; font-size: 9pt; background: transparent; }
QLabel#airStatus { color: #e4e7ee; font-size: 14pt; font-weight: 400; background: transparent; }
QLabel#airError { color: #ff9b9b; font-size: 10pt; background: transparent; }
QLabel#airBig { color: #f5f6f8; font-size: 22pt; font-weight: 300; background: transparent; }
QLabel#airFeatTitle { color: #eef0f4; font-size: 11pt; font-weight: 400; background: transparent; }
QLabel#airFeatBody { color: #8a91a2; font-size: 10pt; background: transparent; }
QLabel#airMono { color: #c9ced9; font-family: "Consolas", "Menlo", monospace; font-size: 9pt; background: transparent; }
QPushButton#airPrimary { background: #f2f3f6; color: #0b0c0f; border: 0; border-radius: 20px; padding: 12px 30px; font-size: 11pt; font-weight: 400; }
QPushButton#airPrimary:hover { background: #ffffff; }
QPushButton#airPrimary:pressed { background: #d9dce3; }
QPushButton#airPrimary:disabled { background: rgba(255,255,255,30); color: #6b7284; }
QPushButton#airGhost { background: transparent; color: #c9ced9; border: 1px solid rgba(255,255,255,34); border-radius: 20px; padding: 11px 24px; font-size: 10.5pt; }
QPushButton#airGhost:hover { border: 1px solid rgba(255,255,255,90); color: #ffffff; }
QPushButton#airCard { background: rgba(255,255,255,7); color: #f5f6f8; border: 1px solid rgba(255,255,255,20); border-radius: 24px; padding: 22px 24px; text-align: left; font-size: 12.5pt; font-weight: 400; }
QPushButton#airCard:hover { background: rgba(255,255,255,15); border: 1px solid rgba(255,255,255,64); }
QLineEdit#airField { background: rgba(255,255,255,8); border: 1px solid rgba(255,255,255,20); border-radius: 14px; color: #f5f6f8; padding: 11px 16px; font-size: 11pt; selection-background-color: #5a6275; }
QLineEdit#airField:focus { border: 1px solid rgba(255,255,255,80); }
QPushButton#airClose { background: transparent; color: #8c94a6; border: 0; font-size: 16pt; padding: 0 6px; }
QPushButton#airClose:hover { color: #ffffff; }
"""


# ---------- pictures drawn in code (no image files): the emblem, the device and feature icons, the check mark
def _picture(size, draw):
    """A transparent square picture of size x size, painted by draw(painter, size)."""
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    draw(p, float(size))
    p.end()
    return pm


def _pen(color, width):
    pen = QPen(color, width)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    return pen


def emblem_pixmap(size=26):
    """The Virtual Box mark: a dark loop with a gap, on a light tile."""
    def draw(p, s):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(236, 239, 244))
        p.drawRoundedRect(QRectF(0, 0, s, s), s * 0.28, s * 0.28)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(_pen(QColor(17, 18, 22), s * 0.12))
        p.drawArc(QRectF(s * 0.26, s * 0.26, s * 0.48, s * 0.48), 90 * 16, 300 * 16)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(17, 18, 22))
        p.drawEllipse(QPointF(s / 2.0, s / 2.0), s * 0.09, s * 0.09)
    return _picture(size, draw)


def device_pixmap(kind, size=44):
    """A simple computer: a monitor for the PC, a laptop for the Mac."""
    def draw(p, s):
        ink = QColor(236, 239, 244)
        p.setBrush(Qt.BrushStyle.NoBrush)
        if kind == "mac":
            p.setPen(_pen(ink, s * 0.07))
            p.drawRoundedRect(QRectF(s * 0.24, s * 0.2, s * 0.52, s * 0.38), s * 0.04, s * 0.04)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(ink)
            p.drawRoundedRect(QRectF(s * 0.14, s * 0.64, s * 0.72, s * 0.07), s * 0.035, s * 0.035)
        else:
            p.setPen(_pen(ink, s * 0.07))
            p.drawRoundedRect(QRectF(s * 0.14, s * 0.18, s * 0.72, s * 0.5), s * 0.06, s * 0.06)
            p.drawLine(QPointF(s / 2.0, s * 0.68), QPointF(s / 2.0, s * 0.8))
            p.drawLine(QPointF(s * 0.34, s * 0.8), QPointF(s * 0.66, s * 0.8))
    return _picture(size, draw)


def feature_pixmap(kind, size=40):
    """A feature's icon: a light disc with a line glyph in it (a lock, a house, a switch)."""
    def draw(p, s):
        cx = cy = s / 2.0
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(255, 255, 255, 22))
        p.drawEllipse(QPointF(cx, cy), s / 2.0, s / 2.0)
        ink = QColor(236, 239, 244)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(_pen(ink, s * 0.055))
        if kind == "lock":
            p.drawRoundedRect(QRectF(cx - s * 0.2, cy - s * 0.02, s * 0.4, s * 0.3), s * 0.05, s * 0.05)
            p.drawArc(QRectF(cx - s * 0.13, cy - s * 0.27, s * 0.26, s * 0.3), 0, 180 * 16)
        elif kind == "home":
            roof = QPolygonF([QPointF(cx - s * 0.27, cy - s * 0.02), QPointF(cx, cy - s * 0.28),
                              QPointF(cx + s * 0.27, cy - s * 0.02)])
            p.drawPolyline(roof)
            p.drawRect(QRectF(cx - s * 0.19, cy - s * 0.02, s * 0.38, s * 0.27))
        else:
            p.drawRoundedRect(QRectF(cx - s * 0.3, cy - s * 0.15, s * 0.6, s * 0.3), s * 0.15, s * 0.15)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(ink)
            p.drawEllipse(QPointF(cx + s * 0.15, cy), s * 0.09, s * 0.09)
    return _picture(size, draw)


def check_pixmap(size=64):
    """The mark for a finished setup: a mint disc with a check."""
    def draw(p, s):
        mint = QColor(110, 231, 183)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(110, 231, 183, 40))
        p.drawEllipse(QRectF(0, 0, s, s))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(_pen(mint, s * 0.05))
        p.drawEllipse(QRectF(s * 0.05, s * 0.05, s * 0.9, s * 0.9))
        path = QPainterPath()
        path.moveTo(s * 0.31, s * 0.52)
        path.lineTo(s * 0.45, s * 0.65)
        path.lineTo(s * 0.7, s * 0.37)
        p.setPen(_pen(mint, s * 0.07))
        p.drawPath(path)
    return _picture(size, draw)


class StepBar(QWidget):
    """Four short bars across the top of a setup page: the bars before the current step are lit, the current one
    is the brightest, the ones after it are dim."""

    def __init__(self, count, parent=None):
        super().__init__(parent)
        self.count = count
        self.current = 0
        self.setFixedHeight(8)

    def set_current(self, index):
        self.current = index
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        gap = 8.0
        w = (self.width() - gap * (self.count - 1)) / float(self.count)
        for i in range(self.count):
            if i == self.current:
                color = QColor(245, 246, 248)
            elif i < self.current:
                color = QColor(150, 158, 174)
            else:
                color = QColor(255, 255, 255, 36)
            p.setBrush(color)
            p.drawRoundedRect(QRectF(i * (w + gap), 0, w, 6), 3, 3)
        p.end()


def _fade_in(owner, widget, ms=380):
    """Fades a page in. The effect is removed when the fade ends, so text stays sharp."""
    effect = QGraphicsOpacityEffect(widget)
    widget.setGraphicsEffect(effect)
    anim = QPropertyAnimation(effect, b"opacity", owner)
    anim.setDuration(ms)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setEasingCurve(QEasingCurve.Type.OutCubic)
    anim.finished.connect(lambda: widget.setGraphicsEffect(None))
    anim.start()
    return anim


class TunnelRunner(QObject):
    """Starts or stops the tunnel on a worker thread, so a Windows prompt or a slow tool does not freeze the desk.
    done carries: ok, the message, the action, and whether the other computer has answered through the tunnel."""
    done = Signal(bool, str, str, bool)

    def start(self, os_name, conf_path, action, peer_ip=""):
        threading.Thread(target=self._work, args=(os_name, conf_path, action, peer_ip), daemon=True).start()

    def _work(self, os_name, conf_path, action, peer_ip):
        ok, msg, seen = core.tunnel_action(os_name, conf_path, action, peer_ip)
        self.done.emit(ok, msg, action, seen)


class PeerChecker(QObject):
    """Pings the other computer through the tunnel on a worker thread, and says whether it answered."""
    seen = Signal(bool)

    def check(self, os_name, ip):
        threading.Thread(target=lambda: self.seen.emit(core.peer_answers(os_name, ip)), daemon=True).start()


_INSTALL = {"bridge": None, "panel": None}     # the bridge (made once) and the Virtual Box panel that is showing


class InstallBridge(QObject):
    """Carries WireGuard installer messages from its worker thread to the window. The signals are queued, so the window
    is only ever touched on the window's own thread."""
    progress = Signal(str)
    finished_install = Signal(bool, str)

    def __init__(self):
        super().__init__()
        self.progress.connect(self._show)
        self.finished_install.connect(self._done)

    def _show(self, text):
        panel = _INSTALL["panel"]
        if panel is not None:
            panel.install_progress(text)

    def _done(self, ok, text):
        panel = _INSTALL["panel"]
        if panel is not None:
            panel.install_finished(ok, text)


def install_bridge():
    if _INSTALL["bridge"] is None:
        _INSTALL["bridge"] = InstallBridge()
    return _INSTALL["bridge"]


class ProgressRing(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._value = 0.0
        self.setFixedSize(132, 132)

    def get_value(self):
        return self._value

    def set_value(self, v):
        self._value = float(v)
        self.update()

    value = Property(float, get_value, set_value)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(10, 10, 112, 112)
        p.setPen(QPen(QColor(255, 255, 255, 30), 6))
        p.drawEllipse(r)
        p.setPen(QPen(QColor(236, 239, 244), 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawArc(r, 90 * 16, int(-360 * 16 * self._value))
        p.end()


class Orb(QWidget):
    """The tunnel's status light: a soft mint glow when connected, grey when not, with a gentle pulse while it changes."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pulse = 0.0
        self.connected = False
        self.setFixedSize(150, 150)

    def get_pulse(self):
        return self._pulse

    def set_pulse(self, v):
        self._pulse = float(v)
        self.update()

    pulse = Property(float, get_pulse, set_pulse)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        c = QRectF(0, 0, 150, 150).center()
        base = QColor(110, 231, 183) if self.connected else QColor(150, 158, 172)
        grow = 6 * math.sin(self._pulse * math.pi)
        glow = QRadialGradient(c, 62 + grow)
        glow.setColorAt(0.0, QColor(base.red(), base.green(), base.blue(), 120))
        glow.setColorAt(1.0, QColor(base.red(), base.green(), base.blue(), 0))
        p.setBrush(QBrush(glow))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(c, 62 + grow, 62 + grow)
        p.setBrush(QBrush(base))
        p.drawEllipse(c, 26, 26)
        p.end()


def _forget_panel(panel):
    if _INSTALL["panel"] is panel:
        _INSTALL["panel"] = None


class AirNeoPanel(QFrame):
    """Virtual Box's sheet. closed is sent when the user closes it. request_tunnel(action) starts or stops the tunnel."""
    closed = Signal()

    def __init__(self, base_dir, os_name, request_tunnel, parent=None):
        super().__init__(parent)
        self.setObjectName("airneo")
        self.setStyleSheet(AIRNEO_QSS)
        self.base_dir, self.os_name, self.request_tunnel = base_dir, os_name, request_tunnel
        self.paths = core.data_paths(base_dir)
        self.state = core.load_state(self.paths["state"])
        self.pending = False
        self._anims = []
        self.waiting = False          # the tunnel is up, and the other computer has not answered yet
        self.peer_busy = False
        self._editing_peer = False        # True while the key page is used to change the other computer's key
        self.peer_checker = PeerChecker()
        self.peer_checker.seen.connect(self._peer_checked)
        self._peer_timer = QTimer(self)
        self._peer_timer.setInterval(15000)
        self._peer_timer.timeout.connect(self._check_peer)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(40, 28, 40, 34)
        outer.setSpacing(0)
        top = QHBoxLayout()
        top.setSpacing(12)
        mark = QLabel()
        mark.setPixmap(emblem_pixmap(28))
        mark.setFixedSize(28, 28)
        top.addWidget(mark)
        top.addWidget(self._label("Virtual Box", "airBrand", wrap=False))
        top.addStretch(1)
        close = QPushButton("\u00d7")
        close.setObjectName("airClose")
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.clicked.connect(self.closed.emit)
        top.addWidget(close)
        outer.addLayout(top)
        outer.addSpacing(18)
        self.notice = self._label("", "airError")
        outer.addWidget(self.notice)
        self.install_line = self._label("", "airSmall")
        outer.addWidget(self.install_line)
        self._after_install = None                   # what to do once the install succeeds (the keys step)

        self.stack = QStackedWidget()
        outer.addWidget(self.stack, 1)
        self.pages = {}
        for name, build in (("welcome", self._page_welcome), ("device", self._page_device), ("keys", self._page_keys),
                            ("peer", self._page_peer), ("done", self._page_done),
                            ("main", self._page_main)):
            page = build()
            self.pages[name] = page
            self.stack.addWidget(page)
        self._route()
        _INSTALL["panel"] = self
        self.destroyed.connect(lambda *_: _forget_panel(self))
        if self.state.get("tunnel_on") and self.state.get("setup_done"):
            # The tunnel was on when the panel was last closed. Check the other computer again now, rather than assume it.
            self.waiting = True
            self._refresh_main()
            self._peer_timer.start()
            QTimer.singleShot(500, self._check_peer)
        # Virtual Box runs on WireGuard. If it is missing, installing it starts here, without a button press.
        if core.find_wg() is None:
            self._start_install()

    # ----- installing WireGuard (Virtual Box)
    def _start_install(self):
        """Starts the WireGuard install in the background (once). Progress shows under the header."""
        bridge = install_bridge()
        self.notice.setText("")
        if wg_install.is_running():
            self.install_line.setText("Installing Virtual Box is already under way...")
            return
        self.install_line.setText("Virtual Box needs WireGuard, which is not installed. Installing it now...")
        started = wg_install.start(self.os_name, bridge.progress.emit,
                                   lambda ok, text: bridge.finished_install.emit(ok, text))
        if not started:
            self.install_line.setText("Installing Virtual Box is already under way...")

    def install_progress(self, text):
        self.install_line.setText(text)

    def install_finished(self, ok, text):
        if ok:
            self.install_line.setText("")
            after, self._after_install = self._after_install, None
            if after is not None:
                after()                              # the keys step carries on now that WireGuard is there
            else:
                self._refresh_main()
        else:
            self.install_line.setText("")
            self.notice.setText(text)
            if self._after_install is not None:
                self.keys_status.setText("WireGuard could not be installed, so the keys cannot be checked yet.")
                self.keys_retry.show()
                self._after_install = None

    # ----- helpers
    def _page(self, step=None):
        """A page. With step (0 to 3), it starts with the step bar: which part of the setup this is."""
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        if step is not None:
            row = QHBoxLayout()
            row.setSpacing(14)
            bar = StepBar(len(SETUP_STEPS))
            bar.set_current(step)
            row.addWidget(bar, 1)
            row.addWidget(self._label(f"Step {step + 1} of {len(SETUP_STEPS)}  \u00b7  {SETUP_STEPS[step]}",
                                      "airSmall", wrap=False))
            lay.addLayout(row)
            lay.addSpacing(10)
        return w, lay

    def _feature(self, kind, title, body):
        """One row on the welcome page: an icon, a title, and one line of explanation."""
        row = QHBoxLayout()
        row.setSpacing(16)
        icon = QLabel()
        icon.setPixmap(feature_pixmap(kind, 40))
        icon.setFixedSize(40, 40)
        text = QVBoxLayout()
        text.setSpacing(3)
        text.addWidget(self._label(title, "airFeatTitle"))
        text.addWidget(self._label(body, "airFeatBody"))
        row.addWidget(icon, 0, Qt.AlignmentFlag.AlignTop)
        row.addLayout(text, 1)
        return row

    def _show(self, name):
        self.stack.setCurrentWidget(self.pages[name])
        self._anims.append(_fade_in(self, self.pages[name]))
        if name == "keys":
            self._start_keys()
        if name == "peer" and hasattr(self, "own_key"):
            self.own_key.setText(self.state.get("public_key", ""))
        if name == "main":
            self._refresh_main()

    def _go(self, name):
        self._show(name)

    def _save(self):
        try:
            core.save_state(self.paths["state"], self.state)
        except OSError as e:
            self.notice.setText(f"Could not save Virtual Box's settings: {e}")
            return False
        self.notice.setText("")
        return True

    def _route(self):
        if not self.state["setup_done"]:
            self._show("welcome")
        else:
            self._show("main")

    def _label(self, text, role, wrap=True):
        lab = QLabel(text)
        lab.setObjectName(role)
        lab.setWordWrap(wrap)
        return lab

    # ----- first run
    def _page_welcome(self):
        w, lay = self._page()
        lay.addSpacing(6)
        lay.addWidget(self._label("Reach your Mac from this computer", "airTitle"))
        lay.addWidget(self._label("Privately, across your home network. Setup takes about a minute.", "airBody"))
        lay.addSpacing(12)
        lay.addLayout(self._feature("lock", "Encrypted with WireGuard",
                                    "Traffic between your two computers is encrypted. The private keys are made here "
                                    "and never leave this computer."))
        lay.addLayout(self._feature("home", "Works across your home network",
                                    "Connect on your own network, or from outside it if you give the other computer "
                                    "a public address."))
        lay.addLayout(self._feature("toggle", "On or off in one click",
                                    "Connect or disconnect from this panel, or from the tunnel button in the dock."))
        lay.addStretch(1)
        row = QHBoxLayout()
        row.addStretch(1)
        begin = QPushButton("Begin setup")
        begin.setObjectName("airPrimary")
        begin.setCursor(Qt.CursorShape.PointingHandCursor)
        begin.clicked.connect(lambda: self._go("device"))
        row.addWidget(begin)
        lay.addLayout(row)
        return w

    def _page_device(self):
        w, lay = self._page(step=0)
        lay.addWidget(self._label("Which computer is this?", "airHead"))
        lay.addWidget(self._label("Pick the computer you are sitting at now. You set up the other one next.", "airBody"))
        lay.addSpacing(6)
        row = QHBoxLayout()
        row.setSpacing(16)
        for device, title, sub in (("pc", "This PC", "Windows, the one you control from"),
                                   ("mac", "This Mac", "The computer you want to reach")):
            card = QPushButton(f"{title}\n{sub}")
            card.setObjectName("airCard")
            card.setIcon(QIcon(device_pixmap(device, 44)))
            card.setIconSize(QSize(44, 44))
            card.setCursor(Qt.CursorShape.PointingHandCursor)
            card.clicked.connect(lambda _c=False, d=device: self._choose_device(d))
            row.addWidget(card)
        lay.addLayout(row)
        lay.addStretch(1)
        return w

    def _choose_device(self, device):
        self.state["device"] = device
        self._save()
        self._go("keys")

    def _page_keys(self):
        w, lay = self._page(step=1)
        lay.addWidget(self._label("Making this computer's keys", "airHead"))
        ring_row = QHBoxLayout()
        ring_row.addStretch(1)
        self.ring = ProgressRing()
        ring_row.addWidget(self.ring)
        ring_row.addStretch(1)
        lay.addLayout(ring_row)
        self.keys_status = self._label("Keys are created on this computer and never leave it.", "airBody")
        lay.addWidget(self.keys_status)
        self.public_line = QLineEdit()
        self.public_line.setObjectName("airField")
        self.public_line.setReadOnly(True)
        self.public_line.hide()
        lay.addWidget(self.public_line)
        row = QHBoxLayout()
        self.keys_retry = QPushButton("Try again")
        self.keys_retry.setObjectName("airGhost")
        self.keys_retry.clicked.connect(self._start_keys)
        self.keys_retry.hide()
        self.keys_next = QPushButton("Continue")
        self.keys_next.setObjectName("airPrimary")
        self.keys_next.setEnabled(False)
        self.keys_next.clicked.connect(lambda: self._go("peer"))
        row.addWidget(self.keys_retry)
        row.addStretch(1)
        row.addWidget(self.keys_next)
        lay.addLayout(row)
        return w

    def _existing_private(self):
        """This computer's private key when it already has a valid one, else None."""
        try:
            with open(self.paths["key"], "r", encoding="utf-8") as f:
                key = f.read().strip()
            core.check_key(key, "private key")
            return key
        except (OSError, ValueError):
            return None

    def _start_keys(self):
        self.keys_next.setEnabled(False)
        self.keys_retry.hide()
        self.public_line.hide()
        self.keys_status.setText("Making keys\u2026")
        self.ring.value = 0.0
        anim = QPropertyAnimation(self.ring, b"value", self)
        anim.setDuration(1400)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        anim.finished.connect(self._finish_keys)
        anim.start()
        self._anims.append(anim)

    def _finish_keys(self):
        wg = core.find_wg()
        if wg is None:
            # Not installed: install it, and carry on with the keys as soon as it is there.
            self.keys_status.setText("Virtual Box is installing WireGuard first. This step continues when it is done.")
            self.keys_retry.hide()
            self._after_install = self._finish_keys
            if not wg_install.is_running():
                self._start_install()
            return
        existing = self._existing_private()
        if existing is not None:
            # Keep the key this computer already has. A new key would leave the other computer holding one that no
            # longer matches, and the tunnel would never connect.
            try:
                public = core.public_from_private(existing, wg=wg)
            except Exception as e:
                self.keys_status.setText(f"Could not read this computer's key: {e}")
                self.keys_retry.show()
                return
        else:
            try:
                private, public = core.generate_keypair(wg=wg)
            except Exception as e:
                self.keys_status.setText(f"Could not make keys: {e}")
                self.keys_retry.show()
                return
            try:
                core.write_private(self.paths["key"], private + "\n")
            except OSError as e:
                self.keys_status.setText(f"Could not save this computer's key: {e}")
                self.keys_retry.show()
                return
        self.state["public_key"] = public
        self._save()
        self.keys_status.setText("Keys ready. Send this public key to the other computer, or keep it for later.")
        self.public_line.setText(public)
        self.public_line.show()
        self.keys_next.setEnabled(True)

    def _page_peer(self):
        w, lay = self._page(step=2)
        other = "Mac" if self.state.get("device") == "pc" else "PC"
        lay.addWidget(self._label(f"Paste the {other}'s public key", "airHead"))
        lay.addWidget(self._label(f"Run Virtual Box on the {other} too, and copy the public key it shows.", "airBody"))
        lay.addWidget(self._label("This computer's public key (give it to the other computer):", "airBody"))
        self.own_key = QLineEdit()
        self.own_key.setReadOnly(True)
        lay.addWidget(self.own_key)
        if self.state.get("device") == "pc":
            lay.addWidget(self._label(
                "Enter the Mac's address. On the same Wi-Fi, use the Mac's address on that network (on the Mac, run: "
                "ipconfig getifaddr en0). From another network, use the Mac's public address or a dynamic DNS name, and "
                "forward UDP port 51820 on your router to the Mac.", "airBody"))
        self.peer_key = QLineEdit()
        self.peer_key.setObjectName("airField")
        self.peer_key.setPlaceholderText("public key")
        lay.addWidget(self.peer_key)
        self.peer_host = QLineEdit()
        self.peer_host.setObjectName("airField")
        self.peer_host.setPlaceholderText("the Mac's address, e.g. 192.168.1.20, or your-name.ddns.net")
        self.peer_port = QLineEdit(str(core.DEFAULT_PORT))
        self.peer_port.setObjectName("airField")
        self.peer_lan = QLineEdit()
        self.peer_lan.setObjectName("airField")
        self.peer_lan.setPlaceholderText("optional: your home network, e.g. 192.168.1.0/24")
        self.peer_extra = [self.peer_host, self.peer_port, self.peer_lan]
        for f in self.peer_extra:
            lay.addWidget(f)
        self.peer_error = self._label("", "airError")
        lay.addWidget(self.peer_error)
        row = QHBoxLayout()
        back = QPushButton("Back")
        back.setObjectName("airGhost")
        back.clicked.connect(lambda: self._leave_peer())
        nxt = QPushButton("Continue")
        nxt.setObjectName("airPrimary")
        nxt.clicked.connect(self._save_peer)
        row.addWidget(back)
        row.addStretch(1)
        row.addWidget(nxt)
        lay.addLayout(row)
        self._peer_page = w
        return w

    def _save_peer(self):
        try:
            core.check_peer_key(self.peer_key.text().strip(), self.state.get("public_key"), self._existing_private())
            if self.state.get("device") == "pc":
                host = core.check_host(self.peer_host.text().strip())
                port = core.check_port(int(self.peer_port.text().strip()))
                lan = core.check_lan(self.peer_lan.text().strip() or None)
            else:
                host, port, lan = "", core.DEFAULT_PORT, None
        except ValueError as e:
            self.peer_error.setText(str(e))
            return
        self.peer_error.setText("")
        self.state.update({"peer_public": self.peer_key.text().strip(), "host": host, "port": port, "lan": lan})
        if self._editing_peer:
            self._apply_peer_change()
            return
        self._save()
        self._go("done")

    def _page_done(self):
        w, lay = self._page(step=3)
        lay.addStretch(1)
        mark = QLabel()
        mark.setPixmap(check_pixmap(64))
        mark.setFixedSize(64, 64)
        lay.addWidget(mark)
        lay.addWidget(self._label("Virtual Box is ready", "airTitle"))
        lay.addWidget(self._label("Connect from this panel, or from the tunnel button in the dock.", "airBody"))
        lay.addWidget(self._label("On the Mac: if macOS asks whether to allow incoming connections for wireguard-go, "
                                  "click Allow. Without it, the PC cannot reach the Mac.", "airBody"))
        self.done_error = self._label("", "airError")
        lay.addWidget(self.done_error)
        lay.addStretch(2)
        row = QHBoxLayout()
        row.addStretch(1)
        open_btn = QPushButton("Open Virtual Box")
        open_btn.setObjectName("airPrimary")
        open_btn.clicked.connect(self._finish_setup)
        row.addWidget(open_btn)
        lay.addLayout(row)
        return w

    def _finish_setup(self):
        try:
            with open(self.paths["key"], "r", encoding="utf-8") as f:
                private = f.read().strip()
            device = self.state["device"]
            text = core.build_device_config(device, private, self.state["public_key"], self.state["peer_public"],
                                            self.state["host"], self.state["port"], self.state["lan"])
        except (OSError, ValueError, KeyError) as e:
            self.done_error.setText(f"Setup could not finish: {e}")
            return
        try:
            core.write_private(self.paths["conf"], text)
        except OSError as e:
            self.done_error.setText(f"Could not save the tunnel config: {e}")
            return
        self.state["setup_done"] = True
        self._save()
        self._route()

    # ----- the tunnel panel
    def _page_main(self):
        w, lay = self._page()
        orb_row = QHBoxLayout()
        orb_row.addStretch(1)
        self.orb = Orb()
        orb_row.addWidget(self.orb)
        orb_row.addStretch(1)
        lay.addLayout(orb_row)
        self.status_line = self._label("", "airStatus", wrap=False)
        self.status_line.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.status_line)
        self.detail_line = self._label("", "airSmall", wrap=False)
        self.detail_line.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.detail_line)
        self.main_error = self._label("", "airError")
        self.main_error.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.main_error)
        row = QHBoxLayout()
        self.reset_btn = QPushButton("Reset setup")
        self.reset_btn.setObjectName("airGhost")
        self.reset_btn.clicked.connect(self._reset)
        self.toggle_btn = QPushButton("Connect")
        self.toggle_btn.setObjectName("airPrimary")
        self.toggle_btn.clicked.connect(self._toggle)
        self.key_btn = QPushButton("Change key")
        self.key_btn.setObjectName("airGhost")
        self.key_btn.clicked.connect(self._open_peer_editor)
        row.addWidget(self.reset_btn)
        row.addWidget(self.key_btn)
        row.addStretch(1)
        row.addWidget(self.toggle_btn)
        lay.addLayout(row)
        self.pulse_anim = QPropertyAnimation(self.orb, b"pulse", self)
        self.pulse_anim.setDuration(900)
        self.pulse_anim.setStartValue(0.0)
        self.pulse_anim.setEndValue(1.0)
        self.pulse_anim.setLoopCount(-1)
        return w

    def _refresh_main(self):
        on = bool(self.state.get("tunnel_on"))
        address = core.WIN_IP if self.state.get("device") == "pc" else core.MAC_IP
        self.orb.connected = on
        self.orb.update()
        if on and self.waiting:
            self.status_line.setText("Waiting for your " + ("Mac" if self.state.get("device") == "pc" else "PC"))
        else:
            self.status_line.setText("Connected" if on else "Not connected")
        peer = "your Mac" if self.state.get("device") == "pc" else "your PC"
        self.detail_line.setText(f"This computer {address} \u00b7 {peer} \u00b7 port {self.state.get('port')}")
        self.toggle_btn.setText("Disconnect" if on else "Connect")
        self.toggle_btn.setEnabled(not self.pending)

    def _toggle(self):
        if self.pending or not self.state.get("setup_done"):
            return
        if core.find_wg() is None:
            self.main_error.setText("Virtual Box is installing WireGuard. Connect again when it is done.")
            self._start_install()
            return
        action = "down" if self.state.get("tunnel_on") else "up"
        self._start_request(action)

    def _start_request(self, action):
        """Starts a tunnel action on the worker; the result comes back through tunnel_result."""
        self.pending = True
        self.main_error.setText("")
        self.toggle_btn.setEnabled(False)
        self.toggle_btn.setText("Working\u2026")
        self.key_btn.setEnabled(False)
        self.pulse_anim.start()
        self.request_tunnel(action)

    def _open_peer_editor(self):
        """From the main page: changes the other computer's key (and address) without a full reset."""
        if self.pending:
            return
        self._editing_peer = True
        self.peer_key.setText("")
        self.peer_error.setText("")
        if self.state.get("device") == "pc":
            self.peer_host.setText(self.state.get("host", ""))
            self.peer_port.setText(str(self.state.get("port", core.DEFAULT_PORT)))
            self.peer_lan.setText(self.state.get("lan") or "")
        self._go("peer")

    def _leave_peer(self):
        target = "main" if self._editing_peer else "keys"
        self._editing_peer = False
        self._go(target)

    def _apply_peer_change(self):
        """Saves the other computer's new key, rewrites the tunnel config with it, and restarts the tunnel if it is on,
        so the new key takes effect. Used from the main page, after setup."""
        self._editing_peer = False
        try:
            private = self._existing_private()
            if private is None:
                raise ValueError("this computer's key is missing. Reset Virtual Box and set it up again.")
            text = core.build_device_config(self.state["device"], private, self.state["public_key"],
                                            self.state["peer_public"], self.state["host"], self.state["port"],
                                            self.state["lan"])
            core.write_private(self.paths["conf"], text)
        except (OSError, ValueError, KeyError) as e:
            self._save()
            self._go("main")
            self.main_error.setText(f"The new key was saved, but the tunnel config could not be written: {e}")
            return
        self._save()
        self._go("main")
        if self.state.get("tunnel_on"):
            self.main_error.setText("Key updated. Restarting the tunnel with it\u2026")
            self._start_request("restart")
        else:
            self.main_error.setText("Key updated. Connect to use it.")

    def tunnel_result(self, ok, msg, action, peer_seen=True):
        """Called by Spatial Desk when the tunnel command finishes. peer_seen says whether the other computer answered."""
        self.pending = False
        self.key_btn.setEnabled(True)
        self.pulse_anim.stop()
        self.orb.pulse = 0.0
        if ok:
            self.state["tunnel_on"] = action in core.TUNNEL_ON_ACTIONS
            self._save()
            self.waiting = action in core.TUNNEL_ON_ACTIONS and not peer_seen
            if self.waiting:
                self.main_error.setText(self._waiting_text())
                self._peer_timer.start()          # keeps checking, and says so when the other computer answers
            else:
                self.main_error.setText("")
                self._peer_timer.stop()
        else:
            self.waiting = False
            self._peer_timer.stop()
            if action in core.TUNNEL_ON_ACTIONS:      # a failed start means the tunnel is not up
                self.state["tunnel_on"] = False
                self._save()
            self.main_error.setText(msg)
        self._refresh_main()

    def _waiting_text(self):
        if self.state.get("device") == "pc":
            return ("Connected to Virtual Box, but the Mac has not answered yet. Check that Virtual Box is on and "
                    "connected on the Mac, and that the Mac has this PC's public key. If macOS asks whether to allow "
                    "incoming connections for wireguard-go, allow it. This keeps checking.")
        return ("Connected to Virtual Box, but the PC has not answered yet. Check that Virtual Box is on and "
                "connected on the PC, and that the PC has this Mac's public key. This keeps checking.")

    def _check_peer(self):
        if self.peer_busy or not self.state.get("tunnel_on"):
            return
        self.peer_busy = True
        self.peer_checker.check(self.os_name, core.peer_address(self.state.get("device", "")))

    def _peer_checked(self, seen):
        self.peer_busy = False
        if not self.state.get("tunnel_on"):
            self._peer_timer.stop()
            return
        if seen and self.waiting:
            self.waiting = False
            self._peer_timer.stop()
            self.main_error.setText("")
            self._refresh_main()

    def _reset(self):
        if self.state.get("tunnel_on"):
            self.main_error.setText("Disconnect first, then reset Virtual Box.")
            return
        if self.reset_btn.text() == "Reset setup":
            self.reset_btn.setText("Click again to reset")
            QTimer.singleShot(3000, lambda: self.reset_btn.setText("Reset setup"))
            return
        for path in (self.paths["key"], self.paths["conf"]):
            try:
                os.remove(path)
            except OSError:
                pass
        self.state = dict(core.DEFAULT_STATE)
        self._save()
        self.reset_btn.setText("Reset setup")
        self._route()
