# -*- mode: python ; coding: utf-8 -*-
# PyInstaller recipe for "Spatial Desk.app" (macOS). Run on a Mac through build_mac_app.sh, or:
#     pyinstaller --noconfirm spatial_desk_mac.spec
# build_mac_app.sh makes build/icon/SpatialDesk.icns first; the bundle uses it.

a = Analysis(
    ["mac_entry.py"],
    pathex=["."],
    binaries=[],
    datas=[],
    hiddenimports=["OpenGL.platform.darwin"],
    excludes=["tkinter", "pytest"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Spatial Desk",
    debug=False,
    strip=False,
    upx=False,
    console=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="Spatial Desk",
)

app = BUNDLE(
    coll,
    name="Spatial Desk.app",
    icon="build/icon/SpatialDesk.icns",
    bundle_identifier="com.averagedev.spatialdesk",
    info_plist={
        "CFBundleName": "Spatial Desk",
        "CFBundleDisplayName": "Spatial Desk",
        "CFBundleShortVersionString": "1.69",
        "CFBundleVersion": "69",
        "LSMinimumSystemVersion": "11.0",
        "NSHighResolutionCapable": True,
        # macOS shows these prompts the first time the feature is used.
        "NSScreenCaptureUsageDescription":
            "Spatial Desk shows your windows in 3D, so it needs to capture the screen.",
        "NSCameraUsageDescription":
            "Camera mode shows the camera behind your room and tracks your hands.",
    },
)
