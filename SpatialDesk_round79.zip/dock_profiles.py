"""Which dock buttons show, depending on what you are using. No Qt, so it can be tested anywhere.

The dock changes when the window in use is a tunnel window (WireGuard, or the Virtual Box panel). Anything else keeps
the normal dock.
"""
import ntpath

TUNNEL_PROGRAMS = ("wireguard.exe", "wireguard", "wg-quick")
TUNNEL_TITLES = ("wireguard", "virtual box")
DOCK_LAYOUTS = {
    "default": ("home", "mode", "add", "airneo", "settings"),
    "tunnel": ("tunnel", "airneo", "home", "settings"),
}


def profile_for(program_path="", title=""):
    """The dock profile for a window, from its program file name and its title. Case does not matter."""
    name = ntpath.basename(program_path or "").lower()
    text = (title or "").lower()
    if name in TUNNEL_PROGRAMS or any(k in text for k in TUNNEL_TITLES):
        return "tunnel"
    return "default"


def dock_layout(profile):
    return DOCK_LAYOUTS.get(profile, DOCK_LAYOUTS["default"])
