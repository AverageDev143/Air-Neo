2D to 3D needs a depth model. Put this file in this folder:

    depth_anything_v2_small.onnx

Model: Depth Anything V2 Small, in ONNX form. It has about 25 million parameters: roughly 100 MB as a
float32 file, and about half that as float16. Those sizes are from memory, so check the exact file size and the
licence on the model's page before you download it.

Also install the runtime once:

    pip install onnxruntime

Then open Settings, 2D to 3D, and switch on "Depth from 2D". Without the file or the runtime, the app stays flat.
