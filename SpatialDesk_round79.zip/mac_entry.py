"""Starts Spatial Desk as a Mac app. This is the entry point PyInstaller builds "Spatial Desk.app" from.

A Mac app started from Finder gets a minimal PATH, which leaves out Homebrew's folders, where WireGuard
(Virtual Box) is installed. Those folders (Homebrew, /usr/local/bin, MacPorts) are put on PATH here, before anything else runs.
"""
import os

_FALLBACK_PATH = "/usr/bin:/bin:/usr/sbin:/sbin"
os.environ["PATH"] = os.pathsep.join(
    ["/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin", os.environ.get("PATH", _FALLBACK_PATH)])

import spatial_desk  # noqa: E402  (must come after PATH is set)

if __name__ == "__main__":
    spatial_desk.main()
