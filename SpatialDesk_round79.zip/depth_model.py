"""2D to 3D: a depth estimate for a flat picture, from a small monocular depth model.

The model is Depth Anything V2 Small, exported to ONNX. It is not in this project: put the file in the models
folder next to spatial_desk.py as models/depth_anything_v2_small.onnx, and install onnxruntime
(pip install onnxruntime). Without both, nothing here runs and the app stays flat.

The model gives relative depth, where bigger means nearer. How good the result looks depends on the model.
"""
import importlib.util
import logging
import os
import sys
import threading
import time

import numpy as np

log = logging.getLogger("depth")

MODEL_NAME = "depth_anything_v2_small.onnx"
INPUT_W, INPUT_H = 308, 168          # both multiples of 14, the model's patch size: 22 by 12 patches
MEAN = np.array([0.485, 0.456, 0.406], np.float32)
STD = np.array([0.229, 0.224, 0.225], np.float32)


def model_path():
    # A bundled app keeps the model in the user's data folder, not inside the app.
    if getattr(sys, "frozen", False):
        import app_paths
        return os.path.join(app_paths.data_dir(), "models", MODEL_NAME)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", MODEL_NAME)


def model_status():
    """(ready, message). Looks for onnxruntime and the model file without loading either."""
    if importlib.util.find_spec("onnxruntime") is None:
        return False, "onnxruntime is not installed (pip install onnxruntime)"
    if not os.path.isfile(model_path()):
        return False, f"model file not found: {model_path()}"
    return True, "ready"


def resize_bilinear(img, out_w, out_h):
    """Bilinear resize of an HxW or HxWxC array, in numpy only."""
    img = np.asarray(img, np.float32)
    h, w = img.shape[:2]
    ys = np.linspace(0, h - 1, out_h)
    xs = np.linspace(0, w - 1, out_w)
    y0 = np.floor(ys).astype(int)
    y1 = np.minimum(y0 + 1, h - 1)
    x0 = np.floor(xs).astype(int)
    x1 = np.minimum(x0 + 1, w - 1)
    fy = (ys - y0)
    fx = (xs - x0)
    if img.ndim == 3:
        fy = fy[:, None, None]
        fx = fx[None, :, None]
    else:
        fy = fy[:, None]
        fx = fx[None, :]
    top = img[y0][:, x0] * (1 - fx) + img[y0][:, x1] * fx
    bot = img[y1][:, x0] * (1 - fx) + img[y1][:, x1] * fx
    return top * (1 - fy) + bot * fy


def to_model_input(rgb):
    """An RGB picture (HxWx3, 0..255) -> the model's input: 1 x 3 x INPUT_H x INPUT_W, ImageNet-normalised."""
    small = resize_bilinear(rgb, INPUT_W, INPUT_H) / 255.0
    norm = (small - MEAN) / STD
    return norm.transpose(2, 0, 1)[None].astype(np.float32)


def normalise_depth(raw, lo_pct=2.0, hi_pct=98.0):
    """The model's raw output (bigger = nearer) -> 0..1. The extremes are clipped, so one bright spot does not
    flatten the rest of the picture."""
    raw = np.asarray(raw, np.float32)
    lo, hi = np.percentile(raw, [lo_pct, hi_pct])
    if hi - lo < 1e-6:
        return np.zeros_like(raw)
    return np.clip((raw - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)


class Smoother:
    """Blends each new depth map into the last one, so the relief does not shimmer from frame to frame."""

    def __init__(self, alpha=0.35):
        self.alpha = alpha
        self.state = None

    def __call__(self, depth):
        if self.state is None or self.state.shape != depth.shape:
            self.state = depth.astype(np.float32).copy()
        else:
            self.state = self.state + (depth - self.state) * self.alpha
        return self.state


class DepthEstimator:
    def __init__(self, path):
        import onnxruntime as ort          # imported here, so the app runs without it
        self.session = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        self.smooth = Smoother(0.35)

    def estimate(self, rgb):
        """An RGB picture of any size -> depth at INPUT_W x INPUT_H, 0..1, 1 = nearer, smoothed over time."""
        raw = self.session.run(None, {self.input_name: to_model_input(rgb)})[0]
        return self.smooth(normalise_depth(np.squeeze(raw)))


def load_estimator():
    """(estimator, message). The estimator is None when the model or onnxruntime is missing."""
    ready, msg = model_status()
    if not ready:
        return None, msg
    try:
        return DepthEstimator(model_path()), "ready"
    except Exception as e:
        log.exception("could not load the depth model")
        return None, f"could not load the model: {e}"


class DepthWorker:
    """Runs the depth model on its own thread, one picture at a time, and gives each result to the window it came from.
    Several pictures waiting for the same window are replaced by the newest one."""

    def __init__(self, estimator):
        self.estimator = estimator
        self._todo = {}
        self._lock = threading.Lock()
        self._wake = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()

    def submit(self, owner, rgb):
        with self._lock:
            self._todo[id(owner)] = (owner, rgb)
        self._wake.set()

    def _run(self):
        while True:
            self._wake.wait()
            self._wake.clear()
            with self._lock:
                items = list(self._todo.values())
                self._todo.clear()
            for owner, rgb in items:
                try:
                    owner.set_depth(self.estimator.estimate(rgb))
                except Exception:
                    log.exception("depth estimate failed")
                    time.sleep(1.0)
