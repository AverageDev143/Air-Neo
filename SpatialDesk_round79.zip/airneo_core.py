"""Virtual Box: the setup and the tunnel logic behind it. No Qt here, so it can be tested anywhere.

What this is: a WireGuard tunnel between this computer and your Mac, set up from inside Spatial Desk.
What this is not: an account system. There is no server, so "sign in" means a passcode that is stored only on this
computer. It stops someone who walks up to an unlocked desk from changing the tunnel; it does not identify you
to anyone else.

Encryption is WireGuard's. This file writes WireGuard configs and runs WireGuard's own tools; it invents no crypto
except the passcode hashing, which uses the standard library's PBKDF2.
"""
import base64
import hashlib
import hmac
import ipaddress
import json
import ntpath
import os
import re
import secrets
import shlex
import shutil
import subprocess
import sys
import time

PBKDF2_ITERATIONS = 200_000
MIN_PASSCODE = 6
TUNNEL_NET = ipaddress.ip_network("10.66.0.0/24")
MAC_IP = "10.66.0.1"
WIN_IP = "10.66.0.2"
DEFAULT_PORT = 51820
KEY_RE = re.compile(r"^[A-Za-z0-9+/]{43}=$")
HOST_RE = re.compile(r"^[A-Za-z0-9.-]{1,253}$")
SETUP_STEPS = ("welcome", "device", "keys", "peer", "done")
DEVICES = ("pc", "mac")
WG_WINDOWS_DEFAULT = r"C:\Program Files\WireGuard\wg.exe"
WG_WINDOWS_TUNNEL = r"C:\Program Files\WireGuard\wireguard.exe"
DEFAULT_STATE = {"setup_done": False, "device": "", "host": "", "port": DEFAULT_PORT, "lan": None,
                 "public_key": "", "peer_public": "", "passcode": None, "tunnel_on": False}


# ---------- saved state ----------
def load_state(path):
    """The saved state, or the defaults when there is no file or the file is unreadable."""
    state = dict(DEFAULT_STATE)
    try:
        with open(path, "r", encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            state.update({k: v for k, v in saved.items() if k in DEFAULT_STATE})
    except (OSError, ValueError):
        pass
    return state


def ensure_data_dir(folder):
    """Creates Air Neo's folder if it is missing. Owner-only where the system supports it."""
    os.makedirs(folder, mode=0o700, exist_ok=True)


def write_private(path, text):
    """Writes a file that only this user can read (where the system enforces that). Creates the folder first."""
    ensure_data_dir(os.path.dirname(path))
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)


def save_state(path, state):
    ensure_data_dir(os.path.dirname(path))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, path)


def next_step(step):
    i = SETUP_STEPS.index(step)
    return SETUP_STEPS[min(i + 1, len(SETUP_STEPS) - 1)]


# ---------- the local passcode ----------
def make_passcode_record(passcode, salt=None, iterations=PBKDF2_ITERATIONS):
    """A stored form of the passcode: a salt and a PBKDF2 hash. The passcode itself is not kept."""
    if not isinstance(passcode, str) or len(passcode) < MIN_PASSCODE:
        raise ValueError(f"the passcode needs at least {MIN_PASSCODE} characters")
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", passcode.encode("utf-8"), salt, iterations)
    return {"salt": base64.b64encode(salt).decode("ascii"), "iterations": iterations,
            "hash": base64.b64encode(digest).decode("ascii")}


def check_passcode(passcode, record):
    """True when the passcode matches the stored record. Compared in constant time."""
    if not record or not isinstance(passcode, str):
        return False
    salt = base64.b64decode(record["salt"])
    digest = hashlib.pbkdf2_hmac("sha256", passcode.encode("utf-8"), salt, int(record["iterations"]))
    return hmac.compare_digest(base64.b64encode(digest).decode("ascii"), record["hash"])


# ---------- the WireGuard configs ----------
def check_port(port):
    if not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError(f"port must be between 1 and 65535, not {port!r}")
    return port


def check_host(host):
    """An IP address or a host name. Anything else could change the meaning of the config file, so it is refused."""
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass
    if not HOST_RE.match(host or "") or ".." in host or host.startswith((".", "-")):
        raise ValueError(f"not a valid address or host name: {host!r}")
    return host


def check_key(key, label):
    if not isinstance(key, str) or not KEY_RE.match(key):
        raise ValueError(f"{label} is not a WireGuard key")
    return key


def check_lan(lan):
    if lan is None or lan == "":
        return None
    net = ipaddress.ip_network(lan, strict=False)
    if not net.is_private or net.overlaps(TUNNEL_NET):
        raise ValueError("the home network must be private and must not overlap the tunnel's 10.66.0.0/24")
    return str(net)


def build_configs(mac_private, mac_public, win_private, win_public, host, port=DEFAULT_PORT, lan=None):
    """The two WireGuard config texts: (mac, windows). Each holds only its own private key."""
    for key, label in ((mac_private, "Mac private key"), (mac_public, "Mac public key"),
                       (win_private, "PC private key"), (win_public, "PC public key")):
        check_key(key, label)
    host, port, lan = check_host(host), check_port(port), check_lan(lan)
    tunnel = str(TUNNEL_NET)
    mac = (f"[Interface]\nAddress = {MAC_IP}/24\nListenPort = {port}\nPrivateKey = {mac_private}\n\n"
           f"[Peer]\nPublicKey = {win_public}\nAllowedIPs = {WIN_IP}/32\n")
    allowed = tunnel if lan is None else f"{tunnel}, {lan}"
    win = (f"[Interface]\nAddress = {WIN_IP}/24\nPrivateKey = {win_private}\n\n"
           f"[Peer]\nPublicKey = {mac_public}\nEndpoint = {host}:{port}\n"
           f"AllowedIPs = {allowed}\nPersistentKeepalive = 25\n")
    return mac, win


# Where WireGuard's tools can be on a Mac: Homebrew (Apple silicon, then Intel), /usr/local/bin, and MacPorts. A Mac app started from Finder does not
# have these on its PATH, so they are checked directly.
MAC_TOOL_DIRS = ("/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin")   # Homebrew, the source build, MacPorts
MAC_PATH = ":".join(MAC_TOOL_DIRS + ("/usr/bin", "/bin", "/usr/sbin", "/sbin"))


def find_wg():
    """WireGuard's key tool: on the PATH, in Homebrew's folders, or where the Windows installer puts it. None when it
    is not installed."""
    found = shutil.which("wg")
    if found:
        return found
    for folder in MAC_TOOL_DIRS:
        candidate = os.path.join(folder, "wg")
        if os.path.isfile(candidate):
            return candidate
    return WG_WINDOWS_DEFAULT if os.path.isfile(WG_WINDOWS_DEFAULT) else None


def windows_tunnel_exe():
    """WireGuard's program that starts and stops tunnels. Its full path is used when it is installed, because a fresh
    install is not always on PATH until Windows is restarted."""
    return WG_WINDOWS_TUNNEL if os.path.isfile(WG_WINDOWS_TUNNEL) else "wireguard.exe"


def data_paths(base_dir):
    """Where Air Neo keeps its files: next to the app, in a folder only this user can read."""
    folder = os.path.join(base_dir, "airneo_data")
    return {"folder": folder, "state": os.path.join(folder, "state.json"),
            "key": os.path.join(folder, "device.key"), "conf": os.path.join(folder, "airneo.conf")}


def build_device_config(device, own_private, own_public, peer_public, host, port=DEFAULT_PORT, lan=None):
    """This device's WireGuard config, from its own key pair and the other device's public key.
    The private key is this device's only; the other device's public key is what it trusts."""
    if device not in DEVICES:
        raise ValueError("device must be 'pc' or 'mac'")
    check_key(own_private, "private key")
    check_key(own_public, "public key")
    check_key(peer_public, "the other device's public key")
    port, lan = check_port(port), check_lan(lan)
    if device == "mac":
        return (f"[Interface]\nAddress = {MAC_IP}/24\nListenPort = {port}\nPrivateKey = {own_private}\n\n"
                f"[Peer]\nPublicKey = {peer_public}\nAllowedIPs = {WIN_IP}/32\n")
    host = check_host(host)
    allowed = str(TUNNEL_NET) if lan is None else f"{TUNNEL_NET}, {lan}"
    return (f"[Interface]\nAddress = {WIN_IP}/24\nPrivateKey = {own_private}\n\n"
            f"[Peer]\nPublicKey = {peer_public}\nEndpoint = {host}:{port}\n"
            f"AllowedIPs = {allowed}\nPersistentKeepalive = 25\n")


def quiet():
    """Windows flags that keep a helper program from opening a console window in front of the app."""
    return subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0


def generate_keypair(run=subprocess.run, wg="wg"):
    """A WireGuard key pair from the wg tool. Raises FileNotFoundError when WireGuard's tools are not installed."""
    private = run([wg, "genkey"], capture_output=True, text=True, check=True, timeout=15, creationflags=quiet()).stdout.strip()
    public = run([wg, "pubkey"], input=private, capture_output=True, text=True, check=True, timeout=15,
                 creationflags=quiet()).stdout.strip()
    return check_key(private, "private key"), check_key(public, "public key")


# ---------- starting and stopping the tunnel ----------
def mac_shell(action, conf_path):
    """The shell command that runs wg-quick. 'restart' takes the old tunnel down (it may not be up, which is not an
    error) and brings the new config up, so a changed key takes effect."""
    quoted = shlex.quote(conf_path)
    if action == "restart":
        body = f"wg-quick down {quoted} >/dev/null 2>&1; wg-quick up {quoted}"
    else:
        body = f"wg-quick {action} {quoted}"
    return f"export PATH={MAC_PATH}; {body}"


def mac_admin_command(action, conf_path):
    """wg-quick changes the network, so it needs an administrator. This asks macOS for one with its own password box,
    so the app never sees the password. The command runs through osascript, which is built into every Mac, and the
    whole action is one run, so there is one password box, not two.
    Homebrew's folders are put on PATH first, because the shell macOS starts for this has a minimal PATH."""
    shell = mac_shell(action, conf_path)
    escaped = shell.replace("\\", "\\\\").replace('"', '\\"')
    return ["osascript", "-e", f'do shell script "{escaped}" with administrator privileges']


TUNNEL_ACTIONS = ("up", "down", "restart")
TUNNEL_ON_ACTIONS = ("up", "restart")      # the actions that leave the tunnel running


def tunnel_command(os_name, conf_path, action):
    """The command that brings the tunnel up or down on this system. Lists, never shell strings.
    Windows installs the config as a tunnel service (needs an administrator). macOS asks for an administrator through
    macOS's own password box and runs wg-quick. Linux runs wg-quick directly."""
    if action not in TUNNEL_ACTIONS:
        raise ValueError("action must be 'up', 'down' or 'restart'")
    if os_name == "windows":
        if action != "down":                 # 'restart' installs the new config, which replaces the old tunnel
            return [windows_tunnel_exe(), "/installtunnelservice", conf_path]
        name = ntpath.splitext(ntpath.basename(conf_path))[0]
        return [windows_tunnel_exe(), "/uninstalltunnelservice", name]
    if os_name == "macos":
        return mac_admin_command(action, conf_path)
    if os_name == "linux":
        if action == "restart":
            return ["sh", "-c", mac_shell(action, conf_path).split("; ", 1)[1]]
        return ["wg-quick", action, conf_path]
    raise ValueError(f"no tunnel command for {os_name!r}")


def run_tunnel_command(cmd, action, run=subprocess.run):
    """Runs a tunnel command for 'up' or 'down' and reports (ok, status). Never raises."""
    try:
        done = run(cmd, capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        return False, f"{cmd[0]} was not found. Install WireGuard first."
    except subprocess.TimeoutExpired:
        return False, "the tunnel did not respond in time"
    if done.returncode == 0:
        return True, "connected" if action in ("up", "restart") else "disconnected"
    if "(-128)" in (done.stderr or ""):          # macOS: the administrator box was closed without a password
        return False, "the administrator password was not given"
    text = (done.stderr or done.stdout or "").strip().splitlines()
    return False, (text[-1] if text else f"exit code {done.returncode}")


# ---------- what the tunnel's keys and addresses mean ----------
def check_peer_key(peer_public, own_public, own_private):
    """A pasted public key must be the other computer's. This computer's own keys are refused with a clear reason,
    because a key pasted into the wrong place is the most common reason the two never connect."""
    check_key(peer_public, "that public key")
    if own_public and peer_public == own_public:
        raise ValueError("that is this computer's own public key. Paste the public key from the other computer.")
    if own_private and peer_public == own_private:
        raise ValueError("that is a private key, which is never shared. Paste the public key the other computer shows.")
    return peer_public


def public_from_private(private, run=subprocess.run, wg="wg"):
    """The public key that goes with a private key, from the wg tool. Raises when WireGuard's tools are missing."""
    check_key(private, "private key")
    public = run([wg, "pubkey"], input=private, capture_output=True, text=True, check=True, timeout=15,
                 creationflags=quiet()).stdout.strip()
    return check_key(public, "public key")


def peer_address(device):
    """The tunnel address of the other computer: the PC reaches the Mac, and the Mac reaches the PC."""
    return MAC_IP if device == "pc" else WIN_IP


def ping_command(os_name, ip):
    """One ping, with a short wait. Windows and macOS only: the tunnel is checked through the tunnel itself."""
    if os_name == "windows":
        return ["ping", "-n", "1", "-w", "1500", ip]
    if os_name == "macos":
        return ["ping", "-c", "1", "-W", "1500", ip]        # macOS counts this wait in milliseconds
    raise ValueError(f"no ping for {os_name!r}")


def peer_answers(os_name, ip, run=subprocess.run):
    """True when the other computer answers through the tunnel. Windows is read by its TTL line, which stays the same
    in every language; macOS by the 'bytes from' line."""
    try:
        done = run(ping_command(os_name, ip), capture_output=True, text=True, timeout=8, creationflags=quiet())
    except (OSError, subprocess.SubprocessError, ValueError):
        return False
    if done.returncode != 0:
        return False
    text = done.stdout or ""
    if os_name == "windows":
        return ip in text and "TTL=" in text.upper()
    return f"bytes from {ip}" in text


def wait_for_peer(os_name, ip, attempts=10, delay_s=2.0, run=subprocess.run, sleep=time.sleep):
    """Pings the other computer through the tunnel for a while: a new tunnel takes a moment to make its first contact.
    True as soon as it answers, False when it has not after about twenty seconds."""
    for attempt in range(attempts):
        if peer_answers(os_name, ip, run):
            return True
        if attempt < attempts - 1:
            sleep(delay_s)
    return False


# ---------- Windows: starting the tunnel as administrator ----------
class ElevationDeclined(Exception):
    """The Windows prompt for administrator rights was cancelled, so nothing was started."""


WINDOWS_SERVICE_PREFIX = "WireGuardTunnel$"


def windows_tunnel_script(action, conf_path):
    """The command line, run as administrator, that starts or stops the tunnel. Starting first removes any tunnel of the
    same name that is still there (from an earlier run with other keys), so the new config is the one that runs. The
    removal may fail when there is nothing to remove; that is not an error, so it is joined with '&', not '&&'."""
    exe = windows_tunnel_exe()
    name = ntpath.splitext(ntpath.basename(conf_path))[0]
    remove = f'"{exe}" /uninstalltunnelservice {name}'
    if action == "down":
        return remove
    return f'{remove} & "{exe}" /installtunnelservice "{conf_path}"'


def run_as_administrator(program, parameters, timeout_s=90):
    """Runs a program with administrator rights through Windows' own prompt, waits for it, and returns its exit code.
    Raises ElevationDeclined when the prompt is cancelled, and OSError when Windows will not start it. Windows only."""
    import ctypes
    from ctypes import wintypes

    class SHELLEXECUTEINFOW(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("fMask", wintypes.ULONG), ("hwnd", wintypes.HWND),
                    ("lpVerb", wintypes.LPCWSTR), ("lpFile", wintypes.LPCWSTR), ("lpParameters", wintypes.LPCWSTR),
                    ("lpDirectory", wintypes.LPCWSTR), ("nShow", ctypes.c_int), ("hInstApp", wintypes.HINSTANCE),
                    ("lpIDList", ctypes.c_void_p), ("lpClass", wintypes.LPCWSTR), ("hkeyClass", wintypes.HKEY),
                    ("dwHotKey", wintypes.DWORD), ("hIcon", wintypes.HANDLE), ("hProcess", wintypes.HANDLE)]

    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    shell32.ShellExecuteExW.argtypes = [ctypes.POINTER(SHELLEXECUTEINFOW)]
    shell32.ShellExecuteExW.restype = wintypes.BOOL
    kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    SEE_MASK_NOCLOSEPROCESS = 0x00000040
    ERROR_CANCELLED = 1223
    info = SHELLEXECUTEINFOW()
    info.cbSize = ctypes.sizeof(info)
    info.fMask = SEE_MASK_NOCLOSEPROCESS
    info.lpVerb = "runas"
    info.lpFile = program
    info.lpParameters = parameters
    info.nShow = 0                                    # SW_HIDE: no window appears for the tunnel command
    if not shell32.ShellExecuteExW(ctypes.byref(info)):
        error = ctypes.get_last_error()
        if error == ERROR_CANCELLED:
            raise ElevationDeclined()
        raise OSError(error, f"Windows would not start {program} ({ctypes.FormatError(error).strip()})")
    handle = info.hProcess
    try:
        if kernel32.WaitForSingleObject(handle, int(timeout_s * 1000)) != 0:
            raise OSError("the tunnel command did not finish in time")
        code = wintypes.DWORD(0)
        kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        return int(code.value)
    finally:
        kernel32.CloseHandle(handle)


def service_running(name, run=subprocess.run, sleep=time.sleep, tries=6):
    """True when Windows reports the tunnel's service as RUNNING. It can take a second to get there after the install."""
    for attempt in range(tries):
        try:
            done = run(["sc", "query", WINDOWS_SERVICE_PREFIX + name], capture_output=True, text=True, timeout=10,
                       creationflags=quiet())
        except (OSError, subprocess.SubprocessError):
            return False
        if done.returncode == 0 and "RUNNING" in (done.stdout or "").upper():
            return True
        if attempt < tries - 1:
            sleep(1.0)
    return False


def tunnel_action(os_name, conf_path, action, peer_ip="", run=subprocess.run, elevate=None, sleep=time.sleep):
    """Starts ('up') or stops ('down') the tunnel and checks it. Returns (ok, message, peer_seen).

    Windows: the tunnel service is installed or removed as administrator, through Windows' prompt. macOS: wg-quick,
    through the administrator password box. After 'up', the other computer is pinged through the tunnel: ok is True
    once the tunnel is up, and peer_seen says whether the other computer has answered yet."""
    if action not in TUNNEL_ACTIONS:
        raise ValueError("action must be 'up', 'down' or 'restart'")
    if os_name == "windows":
        elevate = run_as_administrator if elevate is None else elevate
        verb = "stop" if action == "down" else "start"
        try:
            code = elevate("cmd.exe", f'/d /c "{windows_tunnel_script(action, conf_path)}"')
        except ElevationDeclined:
            return False, "Windows needs your permission to change the tunnel. Choose Yes at the prompt, then try again.", False
        except OSError as e:
            return False, f"Could not {verb} the tunnel: {e}", False
        if code != 0:
            return False, f"WireGuard could not {verb} the tunnel (code {code}). Open the WireGuard app to see why.", False
        if action == "down":
            return True, "disconnected", False
        name = ntpath.splitext(ntpath.basename(conf_path))[0]
        if not service_running(name, run, sleep):
            return False, "The tunnel service did not start. Open the WireGuard app and check the tunnel.", False
    else:
        ok, msg = run_tunnel_command(tunnel_command(os_name, conf_path, action), action, run)
        if not ok:
            return False, msg, False
        if action == "down":
            return True, "disconnected", False
    if not peer_ip:
        return True, "connected", False
    seen = wait_for_peer(os_name, peer_ip, run=run, sleep=sleep)
    return True, ("connected" if seen else "connected, waiting for the other computer"), seen

