# Spatial Desk for Mac

This builds Spatial Desk as a normal Mac app, **Spatial Desk.app**, with Virtual Box included.
You build it once on your Mac; after that it opens like any other app.

## Build it (on the Mac)

1. Install Python 3.12 and Homebrew if you do not have them:
   `brew install python@3.12`
   Use 3.12 rather than the newest Python. The packages only have downloads for certain versions.
2. Open Terminal, go to this folder, and run:
   `./build_mac_app.sh`
   The first run takes a few minutes. It makes:
   - `dist/Spatial Desk.app`: drag it to Applications
   - `dist/SpatialDesk-mac.zip`: the same app, zipped, to copy to another Mac

## First open (Gatekeeper)

The app is signed for local use, not by an Apple developer account, so macOS stops the first open:

- Open it from Applications with **right-click → Open → Open**, or
- Go to **System Settings → Privacy & Security**, find the message about Spatial Desk, and click **Open Anyway**.

If you copied the zip from another Mac, the file also needs the download mark removed:
`xattr -dr com.apple.quarantine "/Applications/Spatial Desk.app"`

## Permissions

macOS asks the first time a feature needs them:

- **Screen Recording**: to show your windows in 3D. Allow it in System Settings → Privacy & Security → Screen Recording, then open the app again.
- **Camera**: only for camera mode.

## Virtual Box on the Mac

Virtual Box is the WireGuard tunnel between your PC and this Mac. Setup runs from inside the app.

- The app installs WireGuard with Homebrew (`wireguard-tools` and `wireguard-go`). Homebrew must already be installed, from https://brew.sh. The app does not install Homebrew for you.
- WireGuard can also come from MacPorts (`/opt/local/bin`) or a source build in `/usr/local/bin`. The app checks all three folders.
- Starting or stopping the tunnel asks for your Mac's administrator password in macOS's own password box. The app never sees the password.
- Your keys and settings are saved in `~/Library/Application Support/Spatial Desk/`, not inside the app, so they stay when you update or move the app.

## 2D to 3D (optional)

The depth model file goes here, not inside the app:

`~/Library/Application Support/Spatial Desk/models/depth_anything_v2_small.onnx`

See `models/README.txt` for the model and licence.

## Notes

- The Mac build has no RayNeo glasses support. Those are Windows-only, and the app turns that part off on a Mac.
- Build on the Mac you will run it on. The app matches that Mac's chip (Apple silicon or Intel).
- The build includes camera mode (OpenCV and MediaPipe) and the depth runtime (onnxruntime) when they can be installed. If one has no download for your Mac, the script says so and builds without it.
