"""Spatial Desk accounts: a name, a password and a profile icon, kept on this computer. No Qt, no server.

These accounts are local. Nothing is synced or sent anywhere, and there is no online account. The password is kept
only as a PBKDF2 hash (the same hashing Virtual Box uses, in airneo_core), in a file only this user can read.
"""
import datetime
import json
import os
import re
import shutil

from airneo_core import check_passcode, make_passcode_record, write_private

MIN_PASSWORD = 8
AVATARS = ("orbit", "ember", "leaf", "wave", "crystal", "moon", "bolt", "sun")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.-]{1,19}$")
_DUMMY = None


def empty():
    return {"accounts": {}, "last": ""}


def load_status(path):
    """(data, status). Status is "ok", "missing" (no file yet, so there are no accounts), or "damaged" (the file is
    there but cannot be read). The caller must treat "damaged" differently from "missing": saving over a file that
    was not read would lose every account in it."""
    if not os.path.exists(path):
        return empty(), "missing"
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("accounts"), dict):
            return data, "ok"
    except (OSError, ValueError):
        pass
    return empty(), "damaged"


def load(path):
    """The saved accounts, or an empty list when there is no file or it cannot be read."""
    return load_status(path)[0]


def set_aside(path):
    """Moves a damaged accounts file out of the way, under a new name with the time in it. Returns the new path.
    Raises OSError if it cannot be moved, in which case nothing has changed."""
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    kept = f"{path}.damaged-{stamp}"
    os.replace(path, kept)
    return kept


def save(path, data):
    """Writes the accounts without ever leaving a half-written file: the new text goes to a temporary file, which
    then replaces the old one in one step. The previous file is kept beside it as accounts.json.bak."""
    tmp = path + ".tmp"
    write_private(tmp, json.dumps(data, indent=2))
    if os.path.exists(path):
        shutil.copy2(path, path + ".bak")
    os.replace(tmp, path)


def _key(name):
    return name.strip().lower()


def validate_name(name):
    if not isinstance(name, str) or not NAME_RE.match(name.strip()):
        raise ValueError("a name is 2 to 20 letters or digits (spaces, dots, dashes and underscores are fine)")
    return name.strip()


def create(data, name, password, avatar):
    """Adds an account. Names are unique whatever their capitals. Returns the updated data."""
    name = validate_name(name)
    if avatar not in AVATARS:
        raise ValueError("choose one of the profile icons")
    if not isinstance(password, str) or len(password) < MIN_PASSWORD:
        raise ValueError(f"the password needs at least {MIN_PASSWORD} characters")
    if _key(name) in data["accounts"]:
        raise ValueError("that name is already taken")
    data["accounts"][_key(name)] = {"name": name, "avatar": avatar, "record": make_passcode_record(password),
                                    "created": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    data["last"] = _key(name)
    return data


def _dummy_record():
    global _DUMMY
    if _DUMMY is None:
        _DUMMY = make_passcode_record("not-a-real-password", salt=b"0" * 16)
    return _DUMMY


def sign_in(data, name, password):
    """True when the name and password match. An unknown name takes as long as a wrong password, so the
    timing does not show whether a name exists."""
    account = data["accounts"].get(_key(name or ""))
    record = account["record"] if account else _dummy_record()
    ok = check_passcode(password or "", record)
    if account and ok:
        data["last"] = _key(name)
        return True
    return False


def accounts_list(data):
    """(name, avatar) for each account, oldest first, so the picker is in a steady order."""
    items = sorted(data["accounts"].values(), key=lambda a: a["created"])
    return [(a["name"], a["avatar"]) for a in items]


def set_avatar(data, name, avatar):
    if avatar not in AVATARS:
        raise ValueError("choose one of the profile icons")
    account = data["accounts"].get(_key(name))
    if account is None:
        raise ValueError("no such account")
    account["avatar"] = avatar
    return data


def delete(data, name, password):
    """Removes an account, but only with its password."""
    account = data["accounts"].get(_key(name))
    if account is None or not check_passcode(password or "", account["record"]):
        raise ValueError("the password is not right")
    del data["accounts"][_key(name)]
    if data.get("last") == _key(name):
        data["last"] = ""
    return data
