"""Writes the Spatial Desk icon as PNG files in the sizes a Mac .iconset needs. build_mac_app.sh turns the
folder into SpatialDesk.icns with iconutil.

    python3 make_icon.py <folder>
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import app_icon  # noqa: E402

out = sys.argv[1]
os.makedirs(out, exist_ok=True)
for base in (16, 32, 128, 256, 512):
    for scale in (1, 2):
        name = f"icon_{base}x{base}" + ("@2x" if scale == 2 else "") + ".png"
        with open(os.path.join(out, name), "wb") as f:
            f.write(app_icon.png_bytes(base * scale))
print(f"Icon sizes written to {out}")
