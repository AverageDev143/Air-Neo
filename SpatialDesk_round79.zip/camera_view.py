"""The camera worker: reads the webcam, sends the picture to the desk, and runs hand tracking on it, all on its own
thread, so the room never waits for the camera.

Signals: frame (the picture, mirrored as a mirror shows it), hands (the hands in the raw picture, which is what
MediaPipe reads), and status (a line to show: the model downloading, the camera on, or why it cannot start). If the
hand model or the hand tracking cannot start, the picture still shows, and the status says so.
"""
import numpy as np
from PySide6.QtCore import QThread, Signal

import hand_tracking as ht

TRACK_WIDTH = 640          # hands are found on a picture this wide: enough, and fast


class CameraWorker(QThread):
    frame = Signal(object)
    hands = Signal(object)
    status = Signal(str)

    def __init__(self, data_folder, parent=None):
        super().__init__(parent)
        self.data_folder = data_folder

    def run(self):
        model = None
        try:
            model = ht.ensure_model(self.data_folder, report=self.status.emit)
        except RuntimeError as e:
            self.status.emit(str(e))
        cam = ht.Camera()
        if not cam.start():
            self.status.emit(cam.error or "The camera could not start.")
            return
        tracker = None
        if model is not None:
            try:
                tracker = ht.HandTracker(model)
            except Exception as e:
                self.status.emit(f"Hand tracking could not start: {e}")
        self.status.emit("Camera on" if tracker is not None else "Camera on, without hand tracking")
        last = None
        try:
            while not self.isInterruptionRequested():
                bgr = cam.latest()
                if bgr is None or bgr is last:
                    self.msleep(8)
                    continue
                last = bgr
                rgb = bgr[:, :, ::-1]
                self.frame.emit(np.ascontiguousarray(rgb[:, ::-1]))       # the picture, as a mirror shows it
                if tracker is not None:
                    step = max(1, rgb.shape[1] // TRACK_WIDTH)
                    self.hands.emit(tracker.detect(np.ascontiguousarray(rgb[::step, ::step])))
        finally:
            cam.stop()
            if tracker is not None:
                tracker.close()
