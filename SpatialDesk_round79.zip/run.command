#!/bin/bash
# Starts Spatial Desk on a Mac. Double-click this file in Finder, or run ./run.command in Terminal.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found. Install it with: brew install python   (or from python.org), then run this again."
    read -n 1 -s -r -p "Press any key to close."
    exit 1
fi
python3 run.py
