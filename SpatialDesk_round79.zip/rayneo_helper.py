"""
Spatial Desk head-tracking helper for RayNeo Air 3S Pro (and Air 4 Pro, same USB ID).
One file. Run it with:   py rayneo_helper.py --diag     (Windows)
                         python3 rayneo_helper.py --diag (macOS)

On first run it installs the `websockets` package and downloads the RayNeo SDK
library next to this file (into ./sdk), so you don't need to set those up yourself.

It streams orientation to Spatial Desk on ws://127.0.0.1:8765 about 60 times per
second and falls back to mouse mode if anything is missing. See README for details.
"""
import argparse
import asyncio
import ctypes as C
import json
import logging
import math
import os
import platform
import signal
import struct
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.request

import pe_check


# ---------------------------------------------------------------------------
# RayNeo SDK bindings
# ---------------------------------------------------------------------------
VID = 0x1BBB
PID = 0xAF50

RESULT_OK = 0
RESULT_TIMEOUT = -3

EVENT_DEVICE_ATTACHED = 0
EVENT_DEVICE_DETACHED = 1
EVENT_IMU_SAMPLE = 2
EVENT_DEVICE_INFO = 3
EVENT_ERROR = 4
EVENT_LOG = 5
EVENT_NOTIFY = 6
NOTIFY_BUTTON_SPATIAL_MODE = 15

EVENT_SIZE = 144
IMU_SIZE = 72


class VidPid(C.Structure):
    _fields_ = [("vid", C.c_uint16), ("pid", C.c_uint16)]


class ImuSample(C.Structure):
    _fields_ = [
        ("acc", C.c_float * 3),
        ("gyroDps", C.c_float * 3),
        ("gyroRad", C.c_float * 3),
        ("magnet", C.c_float * 3),
        ("temperature", C.c_float),
        ("psensor", C.c_float),
        ("lsensor", C.c_float),
        ("tick", C.c_uint32),
        ("count", C.c_uint32),
        ("flag", C.c_uint8),
        ("checksum", C.c_uint8),
        ("valid", C.c_uint8),
        ("reserved", C.c_uint8),
    ]


class Event(C.Structure):
    # Mirrors RAYNEO_Event: 4 bytes type, 4 bytes padding, 8 bytes seq, then the union.
    _fields_ = [
        ("type", C.c_int32),
        ("_pad", C.c_int32),
        ("seq", C.c_uint64),
        ("data", C.c_ubyte * (EVENT_SIZE - 16)),
    ]


def imu_from_event(ev):
    return ImuSample.from_buffer_copy(bytes(ev.data)[:IMU_SIZE])


def notify_code_from_event(ev):
    return C.c_int32.from_buffer_copy(bytes(ev.data)[0:4]).value


def _library_names():
    system = platform.system()
    if system == "Windows":
        return ["RayNeoSDK.dll"]
    if system == "Darwin":
        return ["libRayNeoSDK.dylib"]
    return ["libRayNeoSDK.so"]


# Why the last library found was refused, for the message to the user (empty when none was refused).
LAST_PROBLEM = {"text": ""}


def library_problem(path):
    """None when this file can be loaded here. On Windows, a reason it cannot (see pe_check); elsewhere any file passes,
    as before, because the Mac and Linux libraries are not checked this way."""
    if platform.system() != "Windows":
        return None
    return pe_check.check_library(path)


def find_library(explicit=None):
    """Search explicit path, RAYNEO_SDK_DIR, ./sdk next to this file, then this folder. A file that cannot be loaded
    is skipped (and its reason kept in LAST_PROBLEM), so a bad copy gets downloaded again instead of loaded."""
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = []
    if explicit:
        candidates.append(explicit)
    env_dir = os.environ.get("RAYNEO_SDK_DIR")
    for d in [env_dir, os.path.join(here, "sdk"), here]:
        if d:
            for name in _library_names():
                candidates.append(os.path.join(d, name))
    for path in candidates:
        if os.path.isfile(path):
            problem = library_problem(path)
            if problem is None:
                return path
            LAST_PROBLEM["text"] = f"{path} {problem}"
    return None


class RayNeoSdk:
    """Thin wrapper. Every method returns plain Python values and raises nothing on SDK errors."""

    def __init__(self, path):
        self.path = path
        problem = library_problem(path)
        if problem:
            raise OSError(f"{path} {problem}. Delete that file and start Spatial Desk again to download a fresh "
                          f"copy, or put the 64-bit RayNeoSDK.dll in the sdk folder.")
        if platform.system() == "Windows" and hasattr(os, "add_dll_directory"):
            # RayNeoSDK.dll needs libusb-1.0.dll from the same folder.
            os.add_dll_directory(os.path.dirname(os.path.abspath(path)))
        self.lib = C.CDLL(path)
        L = self.lib
        L.Rayneo_Create.argtypes = [C.POINTER(C.c_void_p)]
        L.Rayneo_Create.restype = C.c_int
        L.Rayneo_Destroy.argtypes = [C.c_void_p]
        L.Rayneo_Destroy.restype = None
        L.Rayneo_Discovery.argtypes = [C.POINTER(VidPid), C.c_size_t, C.POINTER(C.c_size_t)]
        L.Rayneo_Discovery.restype = C.c_int
        L.Rayneo_SetTargetVidPid.argtypes = [C.c_void_p, C.c_uint16, C.c_uint16]
        L.Rayneo_SetTargetVidPid.restype = C.c_int
        L.Rayneo_Start.argtypes = [C.c_void_p, C.c_uint32]
        L.Rayneo_Start.restype = C.c_int
        L.Rayneo_Stop.argtypes = [C.c_void_p]
        L.Rayneo_Stop.restype = C.c_int
        L.Rayneo_PollEvent.argtypes = [C.c_void_p, C.POINTER(Event), C.c_uint32]
        L.Rayneo_PollEvent.restype = C.c_int
        for name in ["Rayneo_EnableImu", "Rayneo_DisableImu", "Rayneo_RequestDeviceInfo",
                     "Rayneo_DisplaySet2D", "Rayneo_DisplaySet3D"]:
            fn = getattr(L, name)
            fn.argtypes = [C.c_void_p]
            fn.restype = C.c_int
        L.Rayneo_ResultToString.argtypes = [C.c_int]
        L.Rayneo_ResultToString.restype = C.c_char_p

    def result_text(self, rc):
        try:
            return self.lib.Rayneo_ResultToString(rc).decode(errors="replace")
        except Exception:
            return f"result {rc}"

    def discover(self):
        """Return list of (vid, pid) for connected supported devices. Empty list on any error."""
        try:
            buf = (VidPid * 8)()
            count = C.c_size_t(0)
            rc = self.lib.Rayneo_Discovery(buf, 8, C.byref(count))
            if rc != RESULT_OK:
                return []
            return [(buf[i].vid, buf[i].pid) for i in range(min(count.value, 8))]
        except Exception:
            return []

    def create(self):
        ctx = C.c_void_p()
        rc = self.lib.Rayneo_Create(C.byref(ctx))
        return ctx if rc == RESULT_OK and ctx.value else None

    def destroy(self, ctx):
        if ctx:
            self.lib.Rayneo_Destroy(ctx)

    def set_target(self, ctx, vid, pid):
        return self.lib.Rayneo_SetTargetVidPid(ctx, vid, pid) == RESULT_OK

    def start(self, ctx):
        return self.lib.Rayneo_Start(ctx, 0)

    def stop(self, ctx):
        self.lib.Rayneo_Stop(ctx)

    def poll(self, ctx, timeout_ms):
        ev = Event()
        rc = self.lib.Rayneo_PollEvent(ctx, C.byref(ev), timeout_ms)
        return ev if rc == RESULT_OK else None

    def enable_imu(self, ctx):
        return self.lib.Rayneo_EnableImu(ctx) == RESULT_OK

    def disable_imu(self, ctx):
        self.lib.Rayneo_DisableImu(ctx)

    def request_info(self, ctx):
        self.lib.Rayneo_RequestDeviceInfo(ctx)

    def display_2d(self, ctx):
        """Mono mirror mode. The helper always uses this; Spatial Desk renders its own 3D view."""
        return self.lib.Rayneo_DisplaySet2D(ctx) == RESULT_OK

# ---------------------------------------------------------------------------
# Orientation fusion
# ---------------------------------------------------------------------------
YAW_SIGN = -1.0    # flip to +1.0 if turning right moves the view the wrong way
PITCH_SIGN = 1.0   # flip to -1.0 if looking up moves the view the wrong way
ACC_SIGN = 1.0     # flip to -1.0 if the accelerometer reads -1g on Z when flat


def _norm(v):
    m = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    return (v[0] / m, v[1] / m, v[2] / m) if m > 1e-9 else None


def _qmul(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    )


def _qnorm(q):
    w, x, y, z = q
    m = math.sqrt(w * w + x * x + y * y + z * z)
    if m < 1e-12:
        return (1.0, 0.0, 0.0, 0.0)
    return (w / m, x / m, y / m, z / m)


def _qconj(q):
    return (q[0], -q[1], -q[2], -q[3])


G = 9.80665  # accelerometer readings are in m/s^2 on this device


def _rodrigues(axis, angle):
    """3x3 rotation matrix for a rotation of `angle` radians about unit `axis`."""
    x, y, z = axis
    c, s = math.cos(angle), math.sin(angle)
    t = 1 - c
    return [
        [t * x * x + c, t * x * y - s * z, t * x * z + s * y],
        [t * x * y + s * z, t * y * y + c, t * y * z - s * x],
        [t * x * z - s * y, t * y * z + s * x, t * z * z + c],
    ]


def _mat_vec(m, v):
    return (
        m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
        m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
        m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2],
    )


class OrientationFilter:
    """
    Orientation from gyro + accelerometer.

    The pose held still during calibration defines "level": its gravity direction is
    rotated onto +Z, so yaw is always rotation about the vertical and pitch is tilt
    toward or away from you, whatever the glasses' own axes are.
    """

    def __init__(self, accel_gain=1.0, bias_samples=200):
        self.q = (1.0, 0.0, 0.0, 0.0)     # current orientation in the level frame
        self.ref = (1.0, 0.0, 0.0, 0.0)   # orientation at last recenter
        self.bias = [0.0, 0.0, 0.0]       # gyro bias, rad/s, device frame
        self.R = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]  # device -> level
        self.accel_gain = accel_gain
        self._bias_needed = bias_samples
        self._gyro_sum = [0.0, 0.0, 0.0]
        self._acc_sum = [0.0, 0.0, 0.0]
        self._count = 0
        self.calibrated = False

    def calibrate_gyro(self, gyro_rad, acc=None):
        """Feed still-pose samples. After enough of them, the level frame is set."""
        if self.calibrated:
            return True
        for i in range(3):
            self._gyro_sum[i] += gyro_rad[i]
            if acc is not None:
                self._acc_sum[i] += acc[i]
        self._count += 1
        if self._count >= self._bias_needed:
            n = self._count
            self.bias = [v / n for v in self._gyro_sum]
            up = _norm(tuple(v / n for v in self._acc_sum))
            if up is None:
                up = (0.0, 0.0, 1.0)
            self.R = self._level_rotation(up)
            self.calibrated = True
        return self.calibrated

    @staticmethod
    def _level_rotation(up):
        """Rotation that takes the device-frame 'up' vector onto +Z."""
        target = (0.0, 0.0, 1.0)
        dot = max(-1.0, min(1.0, up[0] * target[0] + up[1] * target[1] + up[2] * target[2]))
        if dot > 0.99999:
            return [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
        if dot < -0.99999:
            return _rodrigues((1.0, 0.0, 0.0), math.pi)
        axis = (
            up[1] * target[2] - up[2] * target[1],
            up[2] * target[0] - up[0] * target[2],
            up[0] * target[1] - up[1] * target[0],
        )
        axis = _norm(axis)
        return _rodrigues(axis, math.acos(dot))

    def update(self, acc, gyro_rad, dt):
        if dt <= 0 or dt > 0.5:
            return  # ignore bad timestamps and long gaps instead of jumping
        if not self.calibrated:
            return
        g = _mat_vec(self.R, tuple(gyro_rad[i] - self.bias[i] for i in range(3)))
        a_level = _mat_vec(self.R, tuple(ACC_SIGN * v for v in acc))

        # Accel correction: compare measured gravity with where we think gravity is.
        mag = math.sqrt(sum(c * c for c in a_level))
        a = _norm(a_level)
        if a is not None and 0.8 * G < mag < 1.2 * G:  # only when the glasses are not moving much
            w, x, y, z = self.q
            v = (  # estimated gravity direction in the level frame
                2.0 * (x * z - w * y),
                2.0 * (w * x + y * z),
                w * w - x * x - y * y + z * z,
            )
            err = (
                a[1] * v[2] - a[2] * v[1],
                a[2] * v[0] - a[0] * v[2],
                a[0] * v[1] - a[1] * v[0],
            )
            g = (g[0] + self.accel_gain * err[0], g[1] + self.accel_gain * err[1], g[2] + self.accel_gain * err[2])

        omega = (0.0, g[0], g[1], g[2])
        dq = _qmul(self.q, omega)
        q = (
            self.q[0] + 0.5 * dq[0] * dt,
            self.q[1] + 0.5 * dq[1] * dt,
            self.q[2] + 0.5 * dq[2] * dt,
            self.q[3] + 0.5 * dq[3] * dt,
        )
        self.q = _qnorm(q)

    def set_calibration(self, bias, up):
        """Apply a finished calibration: gyro bias (rad/s, device frame) and the 'up' direction."""
        self.bias = list(bias)
        self.R = self._level_rotation(up)
        self.calibrated = True

    def recenter(self):
        self.ref = self.q

    def _relative(self):
        return _qnorm(_qmul(_qconj(self.ref), self.q))

    def yaw_pitch(self):
        """Return (yaw, pitch) in radians with the renderer's sign convention, relative to recenter."""
        w, x, y, z = self._relative()
        yaw = math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))
        s = max(-1.0, min(1.0, 2.0 * (w * y - z * x)))
        pitch = math.asin(s)
        return YAW_SIGN * yaw, PITCH_SIGN * pitch


HOST = "127.0.0.1"
PORT = 8765
HERE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(HERE, "helper.log")
STALE_AFTER_S = 0.3
RECONNECT_AFTER_S = 3.0


def setup_logging():
    logging.basicConfig(
        filename=LOG_PATH, level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    # Also show on the console so you can see what is happening while testing.
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.INFO)
    logging.getLogger().addHandler(console)
    return logging.getLogger("helper")


log = logging.getLogger("helper")


CALIB_SECONDS = 3.0
CALIB_GYRO_TOL = 0.06   # rad/s away from the running average that counts as moving
CALIB_ACC_TOL = 0.6     # m/s^2 change in acceleration magnitude that counts as moving


class Calibrator:
    """Collects still-pose samples. Restarts the timer if the glasses move."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.n = 0
        self.gsum = [0.0, 0.0, 0.0]
        self.asum = [0.0, 0.0, 0.0]
        self.elapsed = 0.0

    def feed(self, acc, gyro, dt):
        """Returns (state, progress, message). state is 'still', 'moving' or 'done'."""
        if self.n > 0:
            mean_g = [s / self.n for s in self.gsum]
            dg = math.sqrt(sum((gyro[i] - mean_g[i]) ** 2 for i in range(3)))
            mag = math.sqrt(sum(a * a for a in acc))
            if dg > CALIB_GYRO_TOL or abs(mag - G) > CALIB_ACC_TOL:
                self.reset()
                return "moving", 0.0, "Hold still. Starting again..."
        self.n += 1
        for i in range(3):
            self.gsum[i] += gyro[i]
            self.asum[i] += acc[i]
        if 0 < dt <= 0.5:
            self.elapsed += dt
        if self.elapsed >= CALIB_SECONDS:
            return "done", 1.0, "Calibrated"
        return "still", min(1.0, self.elapsed / CALIB_SECONDS), "Keep your head still..."

    def result(self):
        bias = [s / self.n for s in self.gsum]
        up = _norm(tuple(s / self.n for s in self.asum)) or (0.0, 0.0, 1.0)
        return bias, up


class Shared:
    """State shared between the device thread and the WebSocket server."""

    def __init__(self):
        self.lock = threading.Lock()
        self.status = "searching"
        self.yaw = 0.0
        self.pitch = 0.0
        self.events = []
        self.recenter_requested = False
        self.recenter_offset = (0.0, 0.0)  # raw angles at last recenter, for display only
        self.calib_state = "needs_calibration"   # needs_calibration | calibrating | calibrated | failed
        self.calib_progress = 0.0
        self.calib_message = "Not calibrated. Press Calibrate and hold still."
        self.calib_requested = False
        self.saved_calib = None  # (bias, up) from the last good calibration, kept across reconnects

    def set_status(self, s):
        with self.lock:
            if self.status != s:
                log.info("status: %s", s)
            self.status = s

    def set_angles(self, yaw, pitch):
        with self.lock:
            self.yaw = yaw
            self.pitch = pitch

    def push_event(self, name):
        with self.lock:
            self.events.append(name)

    def set_calib(self, state, progress, message):
        with self.lock:
            self.calib_state = state
            self.calib_progress = progress
            self.calib_message = message

    def request_calibrate(self):
        with self.lock:
            self.calib_requested = True

    def take_calib_request(self):
        with self.lock:
            req = self.calib_requested
            self.calib_requested = False
            return req

    def snapshot(self):
        with self.lock:
            out = {"status": self.status, "yaw": self.yaw, "pitch": self.pitch,
                   "events": self.events[:], "calibrated": self.calib_state == "calibrated",
                   "calib": {"state": self.calib_state, "progress": round(self.calib_progress, 2),
                             "message": self.calib_message}}
            self.events.clear()
            return out

    def request_recenter(self):
        with self.lock:
            self.recenter_requested = True


def device_loop(shared, stop, sdk_path, diag):
    """Runs forever until stop is set. Never raises; every failure becomes a status."""
    backoff = 1.0
    sdk_api = None
    if sdk_path:
        try:
            sdk_api = RayNeoSdk(sdk_path)
            log.info("loaded SDK %s", sdk_path)
        except Exception:
            log.exception("could not load SDK %s", sdk_path)
    if sdk_api is None:
        shared.set_status("no_sdk")
        log.warning("no RayNeo SDK library found; use mouse and keyboard in Spatial Desk")
        while not stop.is_set():
            time.sleep(2.0)
        return

    while not stop.is_set():
        ctx = None
        try:
            ctx = sdk_api.create()
            if ctx is None:
                raise RuntimeError("Rayneo_Create failed")

            found = sdk_api.discover()
            if found:
                vid, pid = found[0]
                log.info("discovered VID:PID %04X:%04X", vid, pid)
            else:
                vid, pid = VID, PID  # fallback: try the known identity directly
                log.info("discovery found nothing, trying %04X:%04X directly", vid, pid)
            sdk_api.set_target(ctx, vid, pid)

            rc = sdk_api.start(ctx)
            if rc != RESULT_OK:
                log.info("start failed: %s", sdk_api.result_text(rc))
                shared.set_status("searching")
                sdk_api.destroy(ctx)
                ctx = None
                _sleep(stop, backoff)
                backoff = min(backoff * 2, 10.0)
                continue

            backoff = 1.0
            sdk_api.enable_imu(ctx)
            sdk_api.display_2d(ctx)  # keep the glasses in mono mode; see README
            sdk_api.request_info(ctx)
            filt = OrientationFilter()
            calibrating = False
            calibrator = None
            if shared.saved_calib is not None:
                filt.set_calibration(*shared.saved_calib)
                filt.recenter()
                shared.set_calib("calibrated", 1.0, "Calibrated")
            shared.set_status("ok")
            last_sample = time.monotonic()
            last_t = None
            last_print = 0.0

            while not stop.is_set():
                ev = sdk_api.poll(ctx, 50)
                now = time.monotonic()

                if ev is None:
                    if now - last_sample > RECONNECT_AFTER_S:
                        log.warning("no IMU samples for %.0fs, reconnecting", RECONNECT_AFTER_S)
                        break
                    if now - last_sample > STALE_AFTER_S:
                        shared.set_status("stale")
                    continue

                if ev.type == EVENT_IMU_SAMPLE:
                    s = imu_from_event(ev)
                    if not s.valid:
                        continue
                    last_sample = now
                    if shared.status != "ok":
                        shared.set_status("ok")
                    dt = (now - last_t) if last_t else 0.0
                    last_t = now
                    acc = tuple(s.acc)
                    gyro = tuple(s.gyroRad)

                    if shared.take_calib_request():
                        calibrator = Calibrator()
                        calibrating = True
                        filt = OrientationFilter()
                        shared.set_calib("calibrating", 0.0, "Hold your head still...")
                        log.info("calibration started")

                    if calibrating:
                        state, progress, message = calibrator.feed(acc, gyro, dt)
                        if state == "done":
                            bias, up = calibrator.result()
                            filt.set_calibration(bias, up)
                            filt.recenter()
                            shared.saved_calib = (bias, up)
                            calibrating = False
                            shared.set_calib("calibrated", 1.0, "Calibrated")
                            log.info("calibrated: bias=%s up=%s", [round(b, 4) for b in bias], [round(u, 3) for u in up])
                        else:
                            shared.set_calib("calibrating", progress, message)
                        shared.set_angles(0.0, 0.0)
                    elif filt.calibrated:
                        filt.update(acc, gyro, dt)
                        with shared.lock:
                            if shared.recenter_requested:
                                filt.recenter()
                                shared.recenter_requested = False
                        yaw, pitch = filt.yaw_pitch()
                        shared.set_angles(yaw, pitch)
                        if diag and now - last_print >= 0.25:
                            last_print = now
                            print(f"yaw={yaw:+.2f}  pitch={pitch:+.2f}  (yaw + = head right, pitch + = look up)")
                    elif diag and now - last_print >= 1.0:
                        last_print = now
                        print(shared.calib_message)

                elif ev.type == EVENT_NOTIFY:
                    if notify_code_from_event(ev) == NOTIFY_BUTTON_SPATIAL_MODE:
                        shared.push_event("spatial_button")
                        log.info("spatial mode button pressed")

                elif ev.type == EVENT_DEVICE_DETACHED:
                    log.info("glasses detached")
                    break

            shared.set_status("searching")
            if calibrating:
                shared.set_calib("failed", 0.0, "Glasses disconnected during calibration. Try again.")

        except Exception:
            log.exception("device loop error; retrying")
            shared.set_status("searching")
        finally:
            if ctx is not None:
                try:
                    sdk_api.disable_imu(ctx)
                    sdk_api.display_2d(ctx)
                    sdk_api.stop(ctx)
                except Exception:
                    log.exception("cleanup error")
                sdk_api.destroy(ctx)
        _sleep(stop, backoff)


def _sleep(stop, seconds):
    end = time.monotonic() + seconds
    while not stop.is_set() and time.monotonic() < end:
        time.sleep(0.05)


async def serve(shared, stop):
    import websockets

    clients = set()

    async def handler(ws):
        clients.add(ws)
        log.info("app connected (%d client(s))", len(clients))
        try:
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except Exception:
                    continue
                if msg.get("cmd") == "recenter":
                    shared.request_recenter()
                    log.info("recenter requested")
                elif msg.get("cmd") == "calibrate":
                    if shared.status in ("ok", "stale"):
                        shared.set_calib("calibrating", 0.0, "Hold your head still...")
                        shared.request_calibrate()
                        log.info("calibration requested")
                    else:
                        shared.set_calib("failed", 0.0, "Glasses not connected.")
        except Exception:
            pass
        finally:
            clients.discard(ws)
            log.info("app disconnected")

    async def pump():
        while not stop.is_set():
            if clients:
                payload = json.dumps(shared.snapshot())
                websockets.broadcast(clients, payload)
            await asyncio.sleep(1 / 60)

    async with websockets.serve(handler, HOST, PORT):
        log.info("listening on ws://%s:%d", HOST, PORT)
        await pump()

# ---------------------------------------------------------------------------
# One-time setup: Python package and SDK library
# ---------------------------------------------------------------------------
SDK_RELEASES = {
    "Windows": "https://github.com/verncat/RayNeo-Air-3S-Pro-OpenVR/releases/latest/download/rayneo-sdk-windows-latest.tar.gz",
    "Darwin": "https://github.com/verncat/RayNeo-Air-3S-Pro-OpenVR/releases/latest/download/rayneo-sdk-macos-latest.tar.gz",
}


def ensure_websockets():
    try:
        import websockets  # noqa: F401
        return True
    except ImportError:
        print("First run: installing the 'websockets' package (one time)...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "websockets>=12"])
            return True
        except Exception as e:
            print(f"Could not install websockets automatically: {e}")
            print("Run this once, then start the helper again:  py -m pip install websockets")
            return False


def ensure_sdk(here, report=print):
    """Download the RayNeo SDK library next to this file if it is missing. Never raises."""
    if find_library():
        return True
    url = SDK_RELEASES.get(platform.system())
    if not url:
        report("No SDK download for this OS. Put libRayNeoSDK.so in ./sdk, or pass --sdk PATH.")
        return False
    dest = os.path.join(here, "sdk")
    os.makedirs(dest, exist_ok=True)
    report("Downloading the RayNeo SDK (one time, a few MB)...")
    try:
        with tempfile.TemporaryDirectory() as tmp:
            archive = os.path.join(tmp, "sdk.tar.gz")
            urllib.request.urlretrieve(url, archive)
            found = 0
            with tarfile.open(archive) as t:
                for member in t.getmembers():
                    name = os.path.basename(member.name)
                    if member.isfile() and (name.endswith(".dll") or name.endswith(".dylib") or name.endswith(".so")):
                        data = t.extractfile(member).read()
                        target = os.path.join(dest, name)
                        if platform.system() == "Windows" and name.endswith(".dll"):
                            reason = pe_check.save_checked(data, target)
                            if reason is not None:
                                report(f"Skipped {name} from the download: it {reason}.")
                                continue
                        else:
                            with open(target, "wb") as f:
                                f.write(data)
                        found += 1
            report(f"SDK files saved to {dest} ({found} file(s))")
    except Exception as e:
        report(f"Could not download the SDK: {e}")
        report("Download it by hand from https://github.com/verncat/RayNeo-Air-3S-Pro-OpenVR/releases")
        report("and put RayNeoSDK.dll and libusb-1.0.dll (Windows) in the sdk folder next to this file.")
        return False
    if platform.system() == "Windows" and not os.path.isfile(os.path.join(dest, "libusb-1.0.dll")):
        report("libusb-1.0.dll is missing from the SDK folder. The glasses cannot be opened without it.")
    return find_library() is not None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sdk", help="path to the SDK library file (optional)")
    parser.add_argument("--diag", action="store_true", help="print raw IMU values and angles")
    args = parser.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    setup_logging()
    print("Spatial Desk helper starting...")

    if not ensure_websockets():
        return 1
    import websockets  # noqa: F401  (now guaranteed)

    if not args.sdk:
        ensure_sdk(here)
    sdk_path = find_library(args.sdk)
    if sdk_path:
        print(f"SDK: {sdk_path}")
    else:
        print("SDK: not found. Running in mouse mode. The helper will keep waiting.")

    shared = Shared()
    if args.diag and shared.saved_calib is None:
        shared.request_calibrate()
    stop = threading.Event()
    t = threading.Thread(target=device_loop, args=(shared, stop, sdk_path, args.diag), daemon=True)
    t.start()

    def shutdown(*_):
        stop.set()

    signal.signal(signal.SIGINT, shutdown)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, shutdown)

    print(f"Listening on ws://{HOST}:{PORT}  (Ctrl+C to stop)")
    if args.diag:
        print("Diagnostic mode: hold still 2s, then turn your head right and look up.")
    try:
        asyncio.run(serve(shared, stop))
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        t.join(timeout=3)
        log.info("helper stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
