"""Installs Spatial Desk as a Windows app: a shortcut on the desktop and one in the Start menu, both with the app's icon.

The parts that do not need Windows are plain Python and are tested anywhere: the icon file format, the shortcut
plan and the record of what was installed. Creating the shortcuts runs PowerShell (WScript.Shell, the same API the
Windows shortcut dialogs use), so it works only on Windows. Everything the script needs is passed in environment
variables, never spliced into the command, so a folder with spaces, quotes or non-ASCII letters cannot break it.

The shortcut starts the program with pythonw.exe, so no console window opens. It runs spatial_desk.py in the project
folder, and it finds the accounts and settings in the user's data folder, so the same accounts open from the shortcut
as from the folder.
"""
import base64
import re
import ctypes
import json
import os
import struct
import subprocess
import sys
import time

import app_paths

ICON_SIZES = (16, 24, 32, 48, 64, 128, 256)
SHORTCUT_NAME = "Spatial Desk"
SHORTCUT_TEXT = "Spatial Desk: your windows in 3D"
APP_USER_MODEL_ID = "AverageDev143.SpatialDesk"
RECORD_FILE = "windows_app.json"
# Bump with each round. A record from another version makes the shortcuts be checked and made again.
APP_VERSION = "79"
_PLACES = {"Desktop": "your desktop", "Programs": "the Start menu"}

# PowerShell, run with -EncodedCommand so nothing in it is ever re-parsed by the command line.
PS_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$shell = New-Object -ComObject WScript.Shell
foreach ($where in ($env:SD_WHERE -split ';')) {
    $folder = [Environment]::GetFolderPath($where)
    if (-not $folder) { throw "Windows has no folder for $where" }
    $path = Join-Path $folder ($env:SD_NAME + '.lnk')
    $link = $shell.CreateShortcut($path)
    $link.TargetPath = $env:SD_TARGET
    $link.Arguments = $env:SD_ARGS
    $link.WorkingDirectory = $env:SD_WORKDIR
    $link.IconLocation = $env:SD_ICON + ',0'
    $link.Description = $env:SD_DESC
    $link.Save()
    Write-Output $path
}
"""


def make_ico(pngs):
    """An .ico file from PNG images. pngs maps each size (square, in pixels) to its PNG bytes.

    Windows reads PNG images stored inside an .ico directly (Windows Vista and later), so nothing is re-encoded.
    """
    sizes = sorted(pngs)
    header = struct.pack("<HHH", 0, 1, len(sizes))
    entries = b""
    body = b""
    offset = 6 + 16 * len(sizes)
    for size in sizes:
        data = pngs[size]
        width = 0 if size >= 256 else size          # 0 stands for 256 in an .ico entry
        entries += struct.pack("<BBBBHHII", width, width, 0, 0, 1, 32, len(data), offset)
        body += data
        offset += len(data)
    return header + entries + body


def python_for_shortcut(executable=None):
    """pythonw.exe beside the given Python, so the shortcut opens no console window. Falls back to that Python."""
    exe = executable or sys.executable
    candidate = os.path.join(os.path.dirname(exe), "pythonw.exe")
    return candidate if os.path.isfile(candidate) else exe


def shortcut_plan(here, python_exe, icon_path):
    """Everything a shortcut needs, as plain values."""
    return {
        "name": SHORTCUT_NAME,
        "target": python_exe,
        "arguments": f'"{os.path.join(here, "spatial_desk.py")}"',
        "workdir": here,
        "icon": icon_path,
        "description": SHORTCUT_TEXT,
    }


def shortcut_environment(plan, places):
    """The environment the PowerShell script reads the shortcut from."""
    return {
        "SD_WHERE": ";".join(places),
        "SD_NAME": plan["name"],
        "SD_TARGET": plan["target"],
        "SD_ARGS": plan["arguments"],
        "SD_WORKDIR": plan["workdir"],
        "SD_ICON": plan["icon"],
        "SD_DESC": plan["description"],
    }


def shortcut_paths_from(lines):
    """The shortcut paths the PowerShell script printed. Anything else it printed (a warning, say) is not a shortcut,
    so it is dropped and never recorded as one (a recorded non-path would be reported missing on every start)."""
    found = []
    for line in lines:
        text = line.strip()
        if re.match(r"^[A-Za-z]:[\\/].*\.lnk$", text, re.IGNORECASE) and text not in found:
            found.append(text)
    return found


def create_shortcuts(plan, places=("Desktop", "Programs")):
    """Creates the shortcuts. Returns (ok, message, paths): the paths of the shortcuts that were written."""
    if os.name != "nt":
        return False, "Desktop shortcuts are made on Windows.", []
    if not places:
        return False, "Choose the desktop, the Start menu, or both.", []
    env = dict(os.environ, **shortcut_environment(plan, places))
    encoded = base64.b64encode(PS_SCRIPT.encode("utf-16-le")).decode("ascii")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
             "-EncodedCommand", encoded],
            env=env, capture_output=True, timeout=90, creationflags=flags)
    except (OSError, subprocess.SubprocessError) as e:
        return False, f"Could not run PowerShell to make the shortcuts: {e}", []
    out = proc.stdout.decode("utf-8", errors="replace").splitlines()
    paths = shortcut_paths_from(out)
    if proc.returncode != 0 or not paths:
        err = proc.stderr.decode("utf-8", errors="replace").strip()
        return False, "The shortcuts could not be made." + (f" {err}" if err else ""), paths
    names = " and ".join(_PLACES.get(p, p) for p in places)
    return True, f"Spatial Desk is on {names}.", paths


def record_path():
    return os.path.join(app_paths.data_dir(), RECORD_FILE)


def load_record():
    """The record of the last install, or {} when there is none or it cannot be read."""
    try:
        with open(record_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def is_installed():
    """True once the shortcuts have been made on this computer."""
    return bool(load_record().get("shortcuts"))


def places_from_paths(paths):
    """Which places the shortcuts are in, read from their paths (for a record written before places were kept)."""
    found = set()
    for path in paths:
        found.add("Programs" if "start menu" in path.lower() else "Desktop")
    return [p for p in ("Desktop", "Programs") if p in found]


def shortcut_check(record, here, python_exe, version=APP_VERSION, exists=os.path.isfile):
    """What a start needs for the shortcuts: (make, reason, places). Nothing is made when the app was never installed,
    because the install offer is what asks for that. Otherwise the shortcuts are made again when one is missing, when
    the record is from another version, or when the app or its Python has moved. Plain values only, so it is tested
    anywhere."""
    paths = record.get("shortcuts") if isinstance(record, dict) else None
    if not paths:
        return False, "", []
    reasons = []
    if record.get("version") != version:
        reasons.append("new version" if record.get("version") else "first check on this version")
    if record.get("here") != here:
        reasons.append("app folder changed")
    if record.get("python") != python_exe:
        reasons.append("Python changed")
    missing = [p for p in paths if not exists(p)]
    if missing:
        reasons.append(f"{len(missing)} shortcut{'s' if len(missing) != 1 else ''} missing")
    places = record.get("places") or places_from_paths(paths)
    return bool(reasons), ", ".join(reasons), places


def record_install(paths, icon_path, here=None, python_exe=None, places=None, version=APP_VERSION):
    """Remembers what was installed, so the app knows it does not need to offer it again, and what to check on later
    starts: the version, the app's folder, the Python it runs with and the places the shortcuts are in."""
    os.makedirs(app_paths.data_dir(), exist_ok=True)
    text = json.dumps({"shortcuts": paths, "icon": icon_path, "installed": time.strftime("%Y-%m-%d %H:%M:%S"),
                       "version": version, "here": here, "python": python_exe,
                       "places": list(places) if places else places_from_paths(paths)}, indent=2)
    tmp = record_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, record_path())


def install_as_windows_app(here, places=("Desktop", "Programs")):
    """Makes the icon, then the shortcuts. Returns (ok, message)."""
    if os.name != "nt":
        return False, "Desktop shortcuts are made on Windows."
    import app_icon                       # Qt is needed only for drawing the icon
    icon_path = app_icon.write_icon(app_paths.data_dir())
    python_exe = python_for_shortcut()
    plan = shortcut_plan(here, python_exe, icon_path)
    ok, message, paths = create_shortcuts(plan, places)
    if ok:
        record_install(paths, icon_path, here=here, python_exe=python_exe, places=places)
    return ok, message


def refresh_shortcuts(here, record=None, python_exe=None, exists=os.path.isfile):
    """Run at every start. If the shortcuts are missing, come from another version, or the app has moved, they are
    made again with the current app and icon. Returns None when nothing was needed, else (ok, message)."""
    if os.name != "nt":
        return None
    rec = load_record() if record is None else record
    py = python_exe or python_for_shortcut()
    make, reason, places = shortcut_check(rec, here, py, exists=exists)
    if not make:
        return None
    import app_icon                       # Qt is needed only for drawing the icon
    icon_path = app_icon.write_icon(app_paths.data_dir())
    plan = shortcut_plan(here, py, icon_path)
    ok, message, paths = create_shortcuts(plan, places)
    if ok:
        record_install(paths, icon_path, here=here, python_exe=py, places=places)
    return ok, f"Shortcuts made again ({reason}). {message}" if ok else f"Shortcuts ({reason}): {message}"


def set_app_user_id():
    """Gives the running program its own identity on the Windows taskbar, so it shows the Spatial Desk icon rather
    than Python's. Harmless anywhere else."""
    if os.name == "nt":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
        except Exception:
            pass
