"""Camera and hands for Spatial Desk: the camera picture behind the room, a cursor from your index finger, a pinch to
press, and a keyboard drawn where the desk is in the picture.

The geometry, the pinch, the keyboard layout and the key text are plain Python and numpy, so they are tested without a
camera. The camera (OpenCV) and the hand model (MediaPipe) are optional installs (requirements-camera.txt). Without
them the app says what to install and runs as before. The hand model is one file, downloaded the first time camera
mode is turned on, into the data folder.
"""
import math
import os
import threading
import time
import urllib.request
from importlib.util import find_spec

import numpy as np

MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/"
             "hand_landmarker.task")
MODEL_FILE = "hand_landmarker.task"
INDEX_TIP, THUMB_TIP, WRIST, MIDDLE_MCP = 8, 4, 0, 9   # MediaPipe landmark numbers
PINCH_ON, PINCH_OFF = 0.35, 0.55    # a pinch starts below the first ratio and ends above the second (no flicker)


def camera_ready():
    """(ok, message): whether the camera and hand libraries are installed. Nothing is imported."""
    missing = [name for name, mod in (("OpenCV", "cv2"), ("MediaPipe", "mediapipe")) if find_spec(mod) is None]
    if missing:
        return False, (f"Camera mode needs {' and '.join(missing)}. In the project folder run: "
                       "pip install -r requirements-camera.txt")
    return True, "Camera ready"


# ---- where the camera picture sits on the screen
def cover_map(nx, ny, frame_w, frame_h, screen_w, screen_h, mirror=True):
    """Where a point of the camera picture lands on the screen, when the picture covers the whole screen the way a
    background does (cropped at the edges, never stretched). nx, ny run 0..1 across the raw frame. The picture is
    mirrored, as a mirror shows it, so a hand moving right moves right on the screen."""
    if mirror:
        nx = 1.0 - nx
    s = max(screen_w / float(frame_w), screen_h / float(frame_h))
    shown_w, shown_h = frame_w * s, frame_h * s
    left, top = (shown_w - screen_w) / 2.0, (shown_h - screen_h) / 2.0
    return nx * shown_w - left, ny * shown_h - top


def cover_crop(frame_w, frame_h, screen_w, screen_h):
    """The part of the camera picture shown, as (x, y) fractions, when it covers the screen. One of them is 1."""
    frame_aspect = frame_w / float(frame_h)
    screen_aspect = screen_w / float(screen_h)
    return min(1.0, screen_aspect / frame_aspect), min(1.0, frame_aspect / screen_aspect)


# ---- hands
def index_tip(hand):
    """The index fingertip of one hand (21 landmarks), as (x, y) in 0..1 of the raw frame."""
    return hand[INDEX_TIP][0], hand[INDEX_TIP][1]


def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def pinch_ratio(hand):
    """How far the thumb tip is from the index tip, as a fraction of the palm's size. Small means pinched."""
    palm = max(1e-6, _dist(hand[WRIST], hand[MIDDLE_MCP]))
    return _dist(hand[THUMB_TIP], hand[INDEX_TIP]) / palm


class Pinch:
    """Turns the pinch ratio into presses: update() returns "down" once when a pinch starts, "up" once when it ends."""

    def __init__(self, on=PINCH_ON, off=PINCH_OFF):
        self.on, self.off = on, off
        self.down = False

    def update(self, ratio):
        if not self.down and ratio < self.on:
            self.down = True
            return "down"
        if self.down and ratio > self.off:
            self.down = False
            return "up"
        return None


# ---- the keyboard, drawn where the desk is in the picture
KEY_ROWS = [
    ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Back"],
    ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
    ["Shift", "Z", "X", "C", "V", "B", "N", "M", "Enter"],
    ["Space"],
]
KEY_WIDTH = {"Back": 1.6, "Shift": 1.6, "Enter": 1.6, "Space": 5.0}
KEY_GAP = 0.06                      # gap between keys, as a fraction of a key's width


def _row_units(row):
    return sum(KEY_WIDTH.get(k, 1.0) for k in row)


def keyboard_rect(screen_w, screen_h):
    """Where the keyboard sits on the screen: the lower middle, where a desk is in a picture of a desk. (x, y, w, h)."""
    w = screen_w * 0.5
    h = w * 0.42
    return (screen_w - w) / 2.0, screen_h * 0.9 - h, w, h


def keyboard_keys(width, height):
    """Every key of the keyboard for a keyboard of width x height: (label, x0, y0, x1, y1), in the same units."""
    total = max(_row_units(r) for r in KEY_ROWS)
    unit = width / total
    row_h = height / len(KEY_ROWS)
    keys = []
    for r, row in enumerate(KEY_ROWS):
        x = (width - _row_units(row) * unit) / 2.0
        y0 = r * row_h
        for label in row:
            w = KEY_WIDTH.get(label, 1.0) * unit
            g = w * KEY_GAP
            keys.append((label, x + g, y0 + g, x + w - g, y0 + row_h - g))
            x += w
    return keys


def key_at(keys, x, y):
    """The label of the key under (x, y), or None."""
    for label, x0, y0, x1, y1 in keys:
        if x0 <= x <= x1 and y0 <= y <= y1:
            return label
    return None


def label_text(label, shift):
    """What a key sends: (text, vk, next_shift). text is typed as characters, vk is a virtual key, and next_shift is
    whether the next letter is capitals (Shift makes the next letter a capital, then turns off)."""
    if label == "Shift":
        return None, None, not shift
    if label == "Back":
        return None, 0x08, shift
    if label == "Enter":
        return None, 0x0D, False
    if label == "Space":
        return " ", None, False
    if len(label) == 1 and label.isalpha():
        return (label.upper() if shift else label.lower()), None, False
    return label, None, False


# ---- the camera, on its own thread
class Camera:
    """A webcam read on its own thread. latest() is the newest frame (BGR), or None until one arrives."""

    def __init__(self, index=0):
        self.index = index
        self.error = None
        self._cap = None
        self._frame = None
        self._lock = threading.Lock()
        self._stop = threading.Event()

    def start(self):
        try:
            import cv2
        except ImportError:
            self.error = "OpenCV is not installed (pip install -r requirements-camera.txt)"
            return False
        backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
        cap = cv2.VideoCapture(self.index, backend)
        if not cap.isOpened():
            cap.release()
            self.error = "No camera found. Plug one in, or pick another camera in Settings."
            return False
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self._cap = cap
        threading.Thread(target=self._run, name="camera", daemon=True).start()
        return True

    def _run(self):
        while not self._stop.is_set():
            ok, frame = self._cap.read()
            if not ok:
                time.sleep(0.02)
                continue
            with self._lock:
                self._frame = frame

    def latest(self):
        with self._lock:
            return self._frame

    def stop(self):
        self._stop.set()
        if self._cap is not None:
            self._cap.release()
            self._cap = None


def ensure_model(folder, report=None):
    """The path of the hand model in folder, downloading it the first time. Raises RuntimeError saying why it could
    not, and where to put the file by hand."""
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, MODEL_FILE)
    if os.path.isfile(path) and os.path.getsize(path) > 100_000:
        return path
    if report:
        report("Downloading the hand model once (a few megabytes)...")
    tmp = path + ".part"
    try:
        with urllib.request.urlopen(MODEL_URL, timeout=60) as resp, open(tmp, "wb") as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                f.write(chunk)
        os.replace(tmp, path)
    except OSError as e:
        raise RuntimeError(f"The hand model could not be downloaded ({e}). Put {MODEL_FILE} in {folder} "
                           "to use hand tracking.") from e
    return path


class HandTracker:
    """MediaPipe hand landmarks for frames from the camera. Make it on the thread that uses it."""

    def __init__(self, model_path):
        import mediapipe as mp
        from mediapipe.tasks.python import BaseOptions
        from mediapipe.tasks.python.vision import HandLandmarker, HandLandmarkerOptions, RunningMode
        self._mp = mp
        options = HandLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=model_path),
            running_mode=RunningMode.VIDEO, num_hands=2,
            min_hand_detection_confidence=0.5, min_hand_presence_confidence=0.5, min_tracking_confidence=0.5)
        self._landmarker = HandLandmarker.create_from_options(options)
        self._t0 = time.monotonic()
        self._last_ms = -1

    def detect(self, rgb):
        """The hands in an RGB frame: a list of hands, each 21 (x, y, z) landmarks in 0..1 of the frame."""
        image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb))
        ms = max(self._last_ms + 1, int((time.monotonic() - self._t0) * 1000))
        self._last_ms = ms
        result = self._landmarker.detect_for_video(image, ms)
        return [[(p.x, p.y, p.z) for p in hand] for hand in result.hand_landmarks]

    def close(self):
        self._landmarker.close()
