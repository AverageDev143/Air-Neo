# Spatial Desk: summary of changes

## Clicking into virtual windows
- Problem 1: the first fix posted window messages (PostMessage). Clicks did nothing in most apps.
- Problem 2: the next version moved the real pointer and clicked. The click worked, but Windows
  activated the real app, so the spatial view disappeared.
- Current method (`click_window_at` / `_send_click`):
  1. Converts the clicked point on the virtual window to screen coordinates.
  2. Remembers the Spatial Desk window and the pointer position.
  3. Sends one absolute left click (SendInput, virtual-desktop coordinates) at that spot.
  4. Puts the pointer back where it was.
  5. Re-activates the Spatial Desk window.
- Status: NOT verified on Windows. Known risks:
  - If another window covers the spot, the click lands on that window instead.
  - Apps that ignore synthetic clicks will still not respond.
  - The pointer moves for about 60 ms, which may flicker.

## Interface
- Dark neutral palette (graphite and white), replacing the cyan accent.
- Home screen: widget cards (calendar, Gmail, Drive, PC connection) on the left; coloured icons
  with labels on the right (Launcher, Hover, Recenter, Calibrate, Layout, Windows, 3D space, Settings);
  page dots.
- Dock: hidden on the flat home screen, shown in 3D mode.
- Status: plain text (time, mode, setup), no pill.
- Window controls: plain glyphs, no box.

## Not done
- Glass window cards and the icon-led title bar from the references (need Windows to test).
- Curved multi-screen layout and blurred photo backgrounds from the references.
- Real app logos on the tiles.

## How it was checked
- Rendered the main window on a Linux virtual display (Xvfb + PySide6) and compared screenshots.
- Click behaviour cannot be checked there; it needs Windows.

## Round 12 changes
- Home: vivid gradient app tiles with white glyphs; home panel widened so all four columns fit.
- Dock: glass capsule, shown on the home screen as well as in 3D.
- Arc layout: spread capped by window count (gentle arc for 3 windows); windows shrink when there are 3 or more, so the outer windows stay inside the view. Verified with synthetic windows in 3D mode, not with real captures.

## Round 13 changes
- Liquid glass: GlassFrame paints the dock and the home widget panel (translucent body, thin sheen, lit edge at top-left). This is an approximation; it does not blur or refract the scene behind.
- Dock buttons: glass hover state. Layout is unchanged (one row of icons).

## Round 14 changes
- Liquid glass is real now: the 3D scene is captured about 4 times a second, blurred, and shown behind the glass dock and home widget panel. The glass adds a light tint, a thin specular band, and a lit rim.
- Limitation: the backdrop updates about 4 times a second, so it can lag behind fast motion in 3D mode.
- Test wallpaper: set with Settings > background image. For best results use a large image (the room reference is only 512x335).

## Round 15 changes
- Window title bar: added the reference's left-hand icons (document, ring, up-caret). These are visual only; they do not do anything yet.
- Keyboard shortcuts and Qt-side mouse clicks were tested with synthetic events on Linux; all passed. Win32 clicks into real windows are still untested.

## Round 16 changes (windows)
- Default window width raised to 2.8 m, so a window fills about the same share of the frame as the reference.
- Removed the white glow around the focused window and reduced the rim, to match the reference's plain edge.

## Round 17 changes (window title bar)
- Title bar is now a flat, translucent grey strip with thin icons (was a black capsule with an outline).
- Window rim thinned further.
- Title bar height raised so its proportions are not stretched.
- Known gap: a small gap remains between the title bar and the window; the reference attaches them.

## Round 18 changes (title bar)
- Title bar slimmed, with smaller and lighter icons, for a cleaner look.

## Round 19 changes (title bar)
- Title bar is a centred, rounded pill spanning about 73% of the window width (not end to end), with a gap above the window, as in the reference.
- Icons: document, ring, and caret on the left; pull, push, maximise, and close on the right. Hit testing uses the same positions.

## Round 20 changes (title bar)
- Left icons clustered at the left end; right buttons clustered at the right end, so the bar no longer looks spread out.
- Bar made more transparent (fill alpha 190 focused, 160 unfocused).

## Round 21 changes (title bar)
- Icons smaller and lighter; bar moved closer to the window, to match the reference crop.

## Round 22 changes (title bar)
- Up-caret moved to the centre of the bar.
- Bar made slightly smaller (narrower and shorter).

## Round 23 changes (title bar)
- Bar length reduced to two-thirds, still centred.

## Round 24 changes (dock)
- Dock uses flat "soft" glass: the glossy band and heavy bevel are removed, leaving the blurred backdrop, a dark tint, and a thin light edge.
- INAIR dock images could not be found online; the dock was matched to the crop provided by the user.

## Round 25 changes (dock and status strip)
- Dock icons are coloured per action (blue, cyan, violet, green, red, amber, grey).
- Status strip under the dock: Wi-Fi symbol and clock. No battery icon, because the app has no battery reading.

## Round 26 changes (dock, Windows)
- Dock now uses coloured rounded app tiles (one colour per action, white glyphs, thin sheen), in a tighter glass pill, as in the reference. The 3D button is white, as the main action. Hover and checked states are kept.
- Status line under the dock: Wi-Fi, volume, battery (only when the PC has one, read from GetSystemPowerStatus, refreshed about every 30 s) and the clock.
- Not verified on Windows (rendered code could not be run in this environment). The Wi-Fi and volume symbols are decorative; they do not read the real network or sound state.

## Round 27 changes (dock, closer to the reference)
- Dock has no glass pill: the tiles float on the room, as in the reference.
- Tiles are solid, vivid squircles with a bright rim and a solid white glyph (were gradient tiles with line glyphs).
- Tighter pitch (tile + 4 px, no spacing) and a vivid palette, one colour per action.
- Hover and checked states use a soft wash, no outline.
- Status line is smaller and quieter (8 pt, thinner strokes, lower opacity).
- Not verified on Windows.

## Round 28 changes (dock uses real Microsoft app logos)
- The dock now lists the Microsoft apps found on this PC: Word, Excel, PowerPoint, Outlook, OneNote, Edge, Teams (if installed), File Explorer and Notepad. Each icon is read from the program's own .exe, so the logos are the real ones.
- Clicking an app opens it (os.startfile). Apps that are not installed are left out.
- After the apps, a divider, then 3D, Launcher and Settings. Hover, Recenter, Windows, Arrangement, Calibrate, Full screen and Minimise are still on the home screen and keyboard shortcuts (H, R, P, L, F11).
- Not verified on Windows. Office and Teams paths cover the common installs (Office 2016/2019/365 under Program Files); Microsoft Store versions of apps are not found.

## Round 29 changes (dock)
- Launcher, Settings and the other dock controls are plain white glyphs with no coloured tile, closer to the reference's floating icons. The 3D button stays as the one solid white tile.
- Not verified on Windows. The reference is a visionOS dock; no screenshot of the real window could be taken here.

## Round 30 changes (dock, closer to the reference)
- Dock shows only the real Microsoft app logos from the PC, plus plain white glyphs for the controls (3D, Launcher, Settings). No coloured tiles, letter tiles or divider line.
- An app whose logo Windows cannot read is left out of the dock.
- Not verified on Windows. Earlier mock-ups were placeholders and are not a preview of the real window.
- Fix: restored the make_glyph_icon helper that a Round 30 edit had removed (NameError at start-up).

## Round 31 changes (window size and capture)
- The app window opens filling the screen's work area (was a fixed 1280x800).
- Window captures are kept up to 2560 px wide (was 1920), so text stays sharper.
- Not verified on Windows. Click mapping and window scaling still need the helper.log from a real run.

## Round 32 changes (clicks, edges, sharpness)
- Clicks in virtual windows are posted to the window (WM_LBUTTONDOWN/UP) at the clicked spot. The real pointer no longer moves. Some apps (browsers, Store apps) may ignore posted clicks; for those, tick "Click with the real pointer" in Settings to use the old method.
- Window textures use mipmaps, so small text no longer shimmers or turns to noise when the window is far away.
- Rounded window corners are antialiased (were hard-edged), and the 3D view uses 4x multisampling.
- Not verified on Windows. The glasses' own pixel count still limits how small text can be read; a narrower field of view (Settings) makes text bigger.

## Round 33 changes (home screen, sharpness)
- The home screen no longer appears after the launch animation. Show or hide it with the home button in the dock or the Home key.
- Window captures are shrunk with smooth filtering (was skipping pixels), so text no longer breaks up.
- Windows use anisotropic filtering where the driver supports it, so text at an angle stays sharper.
- Not verified on Windows. Closer matching to INAIR OS is limited: the only reference available is one screenshot.

## Round 34 changes (window ratio, look sensitivity)
- Press T to cycle the focused window through Auto, Landscape, Widescreen and Portrait. The picture is cropped to the new shape, not stretched. The title bar is never cropped.
- Settings > Look sensitivity (50 to 200%) scales how fast the view turns, for both the mouse and the glasses.
- Not verified on Windows.

## Round 35 changes (closer to INAIR: dock, title bar, status, home)
- Dock: larger tiles (46 px) and a little more spacing.
- Title bar: lighter, more see-through glass (size and buttons unchanged).
- Status line at the top: softer text.
- Home screen: roomier grid, larger rounder app tiles, clearer labels.
- Not verified on Windows. Send a new screenshot so the next round can be checked against the references.
