"""
Spatial Desk: a native Windows app for RayNeo Air glasses, styled after INAIR OS.

Frameless window, OpenGL starfield space, floating windows at variable depth, hover and follow
modes, and head tracking from rayneo_helper.py (same folder).
Run:  py spatial_desk.py
"""
import ctypes
import json
import math
import os
import platform
import sys
import threading
import time
from ctypes import wintypes

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
IS_WIN = platform.system() == "Windows"

if IS_WIN:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # per-monitor DPI aware, before any window exists
    except Exception:
        pass

from PySide6.QtCore import Qt, QTimer, QPoint, QPointF, QSize
from PySide6.QtCore import QRectF, QObject, QEvent, QFileInfo
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QIcon, QImage, QLinearGradient, QPainter, QPainterPath,
                           QPalette, QPen, QPixmap, QPolygonF, QSurfaceFormat)
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QFileIconProvider, QComboBox, QFileDialog, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QProgressBar, QPushButton, QScrollArea, QSlider, QSpinBox, QToolButton,
    QVBoxLayout, QWidget,
)
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL import GL as gl

import rayneo_helper as rh

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PANEL_W = 2.8                   # default width of a window, metres
HDR_W, HDR_H = 1024, 88        # title bar texture size, pixels
DEFAULT_DIST = 2.6              # default distance from you, metres
MIN_DIST, MAX_DIST = 1.2, 8.0
EXPAND_FACTOR = 1.6             # a window made "fullscreen" is this many times wider
FOV_DEFAULT, FOV_MIN, FOV_MAX = 62.0, 40.0, 90.0   # vertical field of view of the room camera
MAX_PANELS_DEFAULT = 4
MAX_PANELS_LIMIT = 8
PANEL_CORNER = 0.07             # corner radius of a window in space, metres
RATIOS = {"auto": None, "landscape": 9 / 16, "widescreen": 9 / 21, "portrait": 16 / 9}   # height / width
CORNER_RADIUS = 30              # corner radius of the app window, pixels
GLOW_PAD = 0.16                 # how far the soft glow behind a window reaches, metres
ACCENT = (0.92, 0.94, 0.97)     # the one accent colour of the interface, RGB 0..1
ACCENT_HEX = "#eceff4"
SETTINGS_PATH = os.path.join(HERE, "settings.json")

# Window arrangements, in the order the layout button cycles through: (key, label)
LAYOUTS = (("focus", "Focus"), ("code", "Stage"), ("wide", "Arc"), ("layers", "Layers"))
LAYOUT_GAP = {"focus": 0.12, "code": 0.22, "wide": 0.32, "layers": 0.0}   # space between windows, radians
THEMES = {                      # name: (top colour, bottom colour), RGB 0..1
    "space": ((0.080, 0.082, 0.090), (0.012, 0.012, 0.014)),
    "aurora": ((0.070, 0.078, 0.082), (0.010, 0.012, 0.014)),
    "dusk": ((0.095, 0.085, 0.080), (0.014, 0.012, 0.012)),
}
DEFAULT_SETTINGS = {
    "theme": "space", "layout": "code", "follow": False, "fov": FOV_DEFAULT,
    "max_panels": MAX_PANELS_DEFAULT, "fade_ms": 1200, "notify": True, "intro": True, "bg_path": "",
    "pointer_click": False, "look_speed": 1.0,
}


def load_settings():
    data = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            data.update({k: v for k, v in saved.items() if k in DEFAULT_SETTINGS})
    except Exception:
        pass
    if data["theme"] not in THEMES:
        data["theme"] = "space"
    if data["layout"] not in dict(LAYOUTS):
        data["layout"] = "code"
    return data


def save_settings(data):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception:
        rh.log.exception("could not save settings")


# ---------------------------------------------------------------------------
# Windows API (window list, window pictures, capture exclusion)
# ---------------------------------------------------------------------------
HANDLE = ctypes.c_void_p

if IS_WIN:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)

    class RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                    ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                    ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                    ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                    ("biClrImportant", wintypes.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 1)]

    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, HANDLE, wintypes.LPARAM)

    user32.GetWindowRect.argtypes = [HANDLE, ctypes.POINTER(RECT)]
    user32.GetWindowRect.restype = wintypes.BOOL
    user32.IsIconic.argtypes = [HANDLE]
    user32.IsIconic.restype = wintypes.BOOL
    user32.IsWindowVisible.argtypes = [HANDLE]
    user32.IsWindowVisible.restype = wintypes.BOOL
    user32.GetWindowTextLengthW.argtypes = [HANDLE]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [HANDLE, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
    user32.EnumWindows.restype = wintypes.BOOL
    user32.GetWindowDC.argtypes = [HANDLE]
    user32.GetWindowDC.restype = HANDLE
    user32.ReleaseDC.argtypes = [HANDLE, HANDLE]
    user32.ReleaseDC.restype = ctypes.c_int
    user32.PrintWindow.argtypes = [HANDLE, HANDLE, wintypes.UINT]
    user32.PrintWindow.restype = wintypes.BOOL
    user32.SetWindowDisplayAffinity.argtypes = [HANDLE, wintypes.DWORD]
    user32.SetWindowDisplayAffinity.restype = wintypes.BOOL
    gdi32.CreateCompatibleDC.argtypes = [HANDLE]
    gdi32.CreateCompatibleDC.restype = HANDLE
    gdi32.CreateCompatibleBitmap.argtypes = [HANDLE, ctypes.c_int, ctypes.c_int]
    gdi32.CreateCompatibleBitmap.restype = HANDLE
    gdi32.SelectObject.argtypes = [HANDLE, HANDLE]
    gdi32.SelectObject.restype = HANDLE
    gdi32.DeleteObject.argtypes = [HANDLE]
    gdi32.DeleteObject.restype = wintypes.BOOL
    gdi32.DeleteDC.argtypes = [HANDLE]
    gdi32.DeleteDC.restype = wintypes.BOOL
    gdi32.GetDIBits.argtypes = [HANDLE, HANDLE, wintypes.UINT, wintypes.UINT, ctypes.c_void_p,
                                ctypes.POINTER(BITMAPINFO), wintypes.UINT]
    gdi32.GetDIBits.restype = ctypes.c_int


def window_rect(hwnd):
    if not IS_WIN:
        return None
    rc = RECT()
    if user32.GetWindowRect(hwnd, ctypes.byref(rc)):
        return rc.left, rc.top, rc.right, rc.bottom
    return None


def list_windows(own_hwnd):
    """Visible, titled, reasonably sized windows, excluding this app."""
    if not IS_WIN:
        return []
    found = []

    def visit(hwnd, _lparam):
        if hwnd == own_hwnd or not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length == 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value.strip()
        rect = window_rect(hwnd)
        if title and rect and rect[2] - rect[0] >= 240 and rect[3] - rect[1] >= 160 and title != "Program Manager":
            found.append((hwnd, title))
        return True

    proc = WNDENUMPROC(visit)  # keep a reference alive for the call
    user32.EnumWindows(proc, 0)
    return found


def list_screens():
    import mss
    with mss.mss() as sct:
        return [(i, f"Screen {i}") for i in range(1, len(sct.monitors))]


def capture_window_pixels(hwnd, w, h):
    """
    The window's own picture as BGRA rows (top to bottom), even when other windows cover it.
    Returns None if Windows refuses, so the caller can fall back to a screen grab.
    """
    if not IS_WIN or w <= 0 or h <= 0:
        return None
    hdc_win = user32.GetWindowDC(hwnd)
    if not hdc_win:
        return None
    hdc_mem = gdi32.CreateCompatibleDC(hdc_win)
    bmp = gdi32.CreateCompatibleBitmap(hdc_win, w, h)
    old = gdi32.SelectObject(hdc_mem, bmp)
    try:
        if not user32.PrintWindow(hwnd, hdc_mem, 2):  # 2 = PW_RENDERFULLCONTENT
            return None
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = w
        info.bmiHeader.biHeight = -h  # negative height = rows top to bottom
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0  # BI_RGB
        buf = (ctypes.c_ubyte * (w * h * 4))()
        lines = gdi32.GetDIBits(hdc_mem, bmp, 0, h, ctypes.cast(buf, ctypes.c_void_p), ctypes.pointer(info), 0)
        if lines != h:
            return None
        return np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 4).copy()
    finally:
        gdi32.SelectObject(hdc_mem, old)
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(hwnd, hdc_win)


if IS_WIN:
    user32.PostMessageW.argtypes = [HANDLE, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.PostMessageW.restype = wintypes.BOOL
    user32.ScreenToClient.argtypes = [HANDLE, ctypes.POINTER(wintypes.POINT)]
    user32.ScreenToClient.restype = wintypes.BOOL
    user32.ChildWindowFromPoint.argtypes = [HANDLE, wintypes.POINT]
    user32.ChildWindowFromPoint.restype = HANDLE
    user32.SetForegroundWindow.argtypes = [HANDLE]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    user32.SetCursorPos.restype = wintypes.BOOL
    user32.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t]
    user32.mouse_event.restype = None


MOUSEEVENTF_MOVE, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0001, 0x0002, 0x0004
MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_VIRTUALDESK = 0x8000, 0x4000
INPUT_MOUSE = 0


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class _INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUT_UNION)]


if IS_WIN:
    user32.SendInput.argtypes = [wintypes.UINT, ctypes.c_void_p, ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    user32.GetSystemMetrics.argtypes = [ctypes.c_int]
    user32.GetSystemMetrics.restype = ctypes.c_int
    user32.GetForegroundWindow.restype = HANDLE


def _send_click(x, y):
    """One left click at absolute screen (x, y). Each event carries its own position."""
    vl, vt = user32.GetSystemMetrics(76), user32.GetSystemMetrics(77)          # virtual desktop origin
    vw, vh = user32.GetSystemMetrics(78), user32.GetSystemMetrics(79)          # virtual desktop size
    vw, vh = max(2, vw), max(2, vh)
    dx = int((x - vl) * 65535 / (vw - 1))
    dy = int((y - vt) * 65535 / (vh - 1))
    base = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK | MOUSEEVENTF_MOVE
    for flags in (base, base | MOUSEEVENTF_LEFTDOWN, base | MOUSEEVENTF_LEFTUP):
        ev = INPUT()
        ev.type = INPUT_MOUSE
        ev.u.mi = MOUSEINPUT(dx, dy, 0, flags, 0, 0)
        user32.SendInput(1, ctypes.byref(ev), ctypes.sizeof(INPUT))
        time.sleep(0.015)


def click_window_at(hwnd, u, v):
    """
    Clicks inside another window at (u, v). Sends one absolute left click at that spot, puts
    your pointer back where it was, and re-activates the Spatial Desk window so the spatial view
    stays on top. Returns False if the window is gone.
    """
    rect = window_rect(hwnd)
    if not IS_WIN or rect is None:
        return False
    x = rect[0] + int(round(u * (rect[2] - rect[0])))
    y = rect[1] + int(round(v * (rect[3] - rect[1])))
    own = user32.GetForegroundWindow()          # this Spatial Desk window, which the user is using
    saved = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(saved))
    _send_click(x, y)
    time.sleep(0.06)
    user32.SetCursorPos(saved.x, saved.y)
    if own:
        user32.SetForegroundWindow(own)         # stay in the spatial view instead of jumping to the app
    return True


def _click_screen_at(x, y):
    saved = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(saved))
    _send_click(x, y)
    time.sleep(0.02)
    user32.SetCursorPos(saved.x, saved.y)
    return True


def click_window_message(hwnd, u, v):
    """
    Clicks inside another window without moving your pointer: a left-button press and release are
    posted to the control under the spot. Some modern apps (browsers, Store apps) may ignore these.
    """
    rect = window_rect(hwnd)
    if not IS_WIN or rect is None:
        return False
    x = rect[0] + int(round(u * (rect[2] - rect[0])))
    y = rect[1] + int(round(v * (rect[3] - rect[1])))
    client = wintypes.POINT(x, y)
    user32.ScreenToClient(hwnd, ctypes.byref(client))
    child = user32.ChildWindowFromPoint(hwnd, client)
    target = child or hwnd
    tp = wintypes.POINT(x, y)
    user32.ScreenToClient(target, ctypes.byref(tp))
    lparam = ((tp.y & 0xFFFF) << 16) | (tp.x & 0xFFFF)
    user32.PostMessageW(target, 0x0201, 1, lparam)      # WM_LBUTTONDOWN, MK_LBUTTON
    time.sleep(0.04)
    user32.PostMessageW(target, 0x0202, 0, lparam)      # WM_LBUTTONUP
    return True


def click_grab(grab, u, v, pointer=False):
    if grab.kind == "window":
        if pointer:
            return click_window_at(grab.ident, u, v)    # moves the real pointer (older method)
        return click_window_message(grab.ident, u, v)
    import mss
    with mss.MSS() as sct:
        m = sct.monitors[grab.ident]
        x = m["left"] + int(u * m["width"])
        y = m["top"] + int(v * m["height"])
    if IS_WIN:
        return _click_screen_at(x, y)
    return False


def exclude_from_capture(hwnd):
    """Stops this app's own window appearing in screen captures (prevents the mirror loop)."""
    if IS_WIN:
        try:
            user32.SetWindowDisplayAffinity(hwnd, 0x11)  # WDA_EXCLUDEFROMCAPTURE
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Frame capture. Each source runs in its own thread and keeps the latest frame.
# ---------------------------------------------------------------------------
def blur_backdrop(image, width, height):
    """Blurred, slightly dimmed copy of the 3D scene, used behind liquid-glass surfaces."""
    small = image.scaled(max(8, width // 6), max(8, height // 6),
                         Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    small = small.convertToFormat(QImage.Format.Format_RGBA8888)
    w, h, stride = small.width(), small.height(), small.bytesPerLine()
    raw = np.frombuffer(small.constBits(), dtype=np.uint8, count=h * stride).reshape(h, stride // 4, 4)[:, :w]
    a = raw.astype(np.float32)
    for _ in range(4):                                  # repeated cross blur ~ gaussian
        p = np.pad(a, ((1, 1), (1, 1), (0, 0)), mode="edge")
        a = (p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:] + 4.0 * a) / 8.0
    a = np.clip(a * 0.78, 0, 255).astype(np.uint8)      # slightly dimmer so the glass reads
    a = np.ascontiguousarray(a)
    out = QImage(a.data, w, h, w * 4, QImage.Format.Format_RGBA8888).copy()
    return QPixmap.fromImage(out).scaled(width, height, Qt.AspectRatioMode.IgnoreAspectRatio,
                                         Qt.TransformationMode.SmoothTransformation)


def read_battery():
    """(percent, on_charger) from Windows, or None when this PC has no battery."""
    if not IS_WIN:
        return None
    try:
        class SYSTEM_POWER_STATUS(ctypes.Structure):
            _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                        ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                        ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]
        st = SYSTEM_POWER_STATUS()
        kernel32 = ctypes.WinDLL("kernel32")
        if not kernel32.GetSystemPowerStatus(ctypes.byref(st)):
            return None
        pct = st.BatteryLifePercent
        if pct == 255 or (st.BatteryFlag & 128):          # 255 = unknown, 128 = no system battery
            return None
        return int(pct), st.ACLineStatus == 1
    except Exception:
        return None


class StatusStrip(QWidget):
    """
    Small line under the dock, as in the reference: Wi-Fi, volume, battery (when the PC has one)
    and the clock. The Wi-Fi and volume symbols are decorative; only the battery and clock are live.
    """
    BATTERY_COL = 56
    TIME_W = 46

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._battery = None
        self._battery_t = None
        self.refresh_power()

    def _time_x(self):
        return self.BATTERY_COL + 56 if self._battery else self.BATTERY_COL

    def refresh_power(self):
        """Re-reads the battery about every 30 seconds. Returns True if the width changed."""
        now = time.monotonic()
        if self._battery_t is not None and now - self._battery_t < 30.0:
            return False
        self._battery_t = now
        before = self.width()
        self._battery = read_battery()
        self.setFixedSize(self._time_x() + self.TIME_W, 22)
        return self.width() != before

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        ink = QColor(236, 240, 246, 190)
        mid = self.height() / 2.0
        wire = QPen(ink, 1.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)

        # Wi-Fi: three arcs
        p.setPen(wire)
        p.setBrush(Qt.BrushStyle.NoBrush)
        cx, base = 10.0, mid + 3.0
        for r in (3.5, 6.5, 9.5):
            p.drawArc(QRectF(cx - r, base - r, 2 * r, 2 * r), 45 * 16, 90 * 16)

        # Volume: speaker cone and two waves
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(ink)
        p.drawPolygon(QPolygonF([QPointF(25, mid - 2.6), QPointF(28, mid - 2.6), QPointF(32, mid - 5.5),
                                 QPointF(32, mid + 5.5), QPointF(28, mid + 2.6), QPointF(25, mid + 2.6)]))
        p.setPen(wire)
        p.setBrush(Qt.BrushStyle.NoBrush)
        for r in (3.5, 6.5):
            p.drawArc(QRectF(32 - r, mid - r, 2 * r, 2 * r), -45 * 16, 90 * 16)

        # Battery, if the PC has one
        if self._battery:
            pct, _charging = self._battery
            x0 = self.BATTERY_COL
            p.setPen(QPen(ink, 1.2))
            p.drawRoundedRect(QRectF(x0, mid - 5, 20, 10), 2.6, 2.6)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(ink)
            fill = max(0.0, 16.0 * pct / 100.0)
            p.drawRoundedRect(QRectF(x0 + 2, mid - 3, fill, 6), 1.2, 1.2)
            p.drawRoundedRect(QRectF(x0 + 20.6, mid - 2.2, 1.8, 4.4), 0.8, 0.8)

        # Clock
        p.setPen(ink)
        font = QFont("Segoe UI Variable Text", 8)
        font.setWeight(QFont.Weight.Medium)
        p.setFont(font)
        if self._battery:
            p.drawText(QRectF(self.BATTERY_COL + 25, 0, 30, self.height()),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, f"{self._battery[0]}%")
        p.drawText(QRectF(self._time_x(), 0, self.TIME_W, self.height()),
                   Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, time.strftime("%H:%M"))
        p.end()


class GlassFrame(QFrame):
    """
    Liquid-glass surface. It shows the blurred 3D scene behind it (the window keeps that picture
    up to date), then adds a light tint, a soft specular band across the top, and a lit rim.
    """
    def __init__(self, parent=None, radius=26, strength=1.0, soft=False):
        super().__init__(parent)
        self.radius = radius
        self.strength = strength
        self.soft = soft          # flat modern glass: no gloss band, a thin light edge only
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)

    def paintEvent(self, ev):
        s = self.strength
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        rad = min(self.radius, r.height() / 2.0)
        path = QPainterPath()
        path.addRoundedRect(r, rad, rad)

        # 1. the blurred scene behind the glass
        win = self.window()
        backdrop = getattr(win, "backdrop", None)
        if backdrop is not None:
            origin = self.mapTo(win, QPoint(0, 0))
            p.save()
            p.setClipPath(path)
            src_rect = QRectF(origin.x() + r.x(), origin.y() + r.y(), r.width(), r.height())
            p.drawPixmap(r, backdrop, src_rect)
            p.restore()
        else:
            p.fillPath(path, QColor(18, 18, 22, int(200 * s)))

        # 2. light tint, brighter toward the top
        tint = QLinearGradient(r.topLeft(), r.bottomLeft())
        tint.setColorAt(0.0, QColor(255, 255, 255, int((12 if self.soft else 30) * s)))
        tint.setColorAt(1.0, QColor(255, 255, 255, int((4 if self.soft else 6) * s)))
        p.fillPath(path, tint)

        # 3. specular band across the upper edge (skipped for flat glass)
        band_h = min(r.height() * 0.22, 26.0)
        band = QPainterPath()
        band_rect = QRectF(r.left() + rad * 0.6, r.top() + 2.5, r.width() - rad * 1.2, band_h)
        band.addRoundedRect(band_rect, band_h / 2.0, band_h / 2.0)
        bg = QLinearGradient(band_rect.topLeft(), band_rect.bottomLeft())
        bg.setColorAt(0.0, QColor(255, 255, 255, 0 if self.soft else int(46 * s)))
        bg.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.fillPath(band, bg)

        # 4. rim: a bright thin edge plus an inner highlight just inside it
        inner = QPainterPath()
        inner.addRoundedRect(r.adjusted(2.5, 2.5, -2.5, -2.5), max(rad - 2.5, 0), max(rad - 2.5, 0))
        ig = QLinearGradient(r.topLeft(), r.bottomRight())
        ig.setColorAt(0.0, QColor(255, 255, 255, int((22 if self.soft else 70) * s)))
        ig.setColorAt(0.5, QColor(255, 255, 255, 0))
        ig.setColorAt(1.0, QColor(255, 255, 255, int((10 if self.soft else 30) * s)))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QBrush(ig), 1.0))
        p.drawPath(inner)
        edge = QLinearGradient(r.topLeft(), r.bottomRight())
        edge.setColorAt(0.0, QColor(255, 255, 255, int((120 if self.soft else 170) * s)))
        edge.setColorAt(0.5, QColor(255, 255, 255, int((28 if self.soft else 40) * s)))
        edge.setColorAt(1.0, QColor(255, 255, 255, int((70 if self.soft else 110) * s)))
        p.setPen(QPen(QBrush(edge), 1.0 if self.soft else 1.3))
        p.drawPath(path)
        p.end()


class _SheetWatch(QObject):
    """Restores the home screen whenever the launcher sheet opens or closes."""
    def __init__(self, win):
        super().__init__(win)
        self.win = win

    def eventFilter(self, obj, ev):
        if ev.type() in (QEvent.Type.Show, QEvent.Type.Hide):
            QTimer.singleShot(0, self.win._refresh_home)
        return False


def downscale_frame(shot, max_w):
    """Shrinks a capture to max_w pixels wide with smooth filtering, so text stays readable."""
    h, w = shot.shape[:2]
    if w <= max_w:
        return np.ascontiguousarray(shot)
    nh = max(1, int(round(h * max_w / w)))
    src = np.ascontiguousarray(shot)
    img = QImage(src.data, w, h, w * 4, QImage.Format.Format_ARGB32)
    small = img.scaled(max_w, nh, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    small = small.convertToFormat(QImage.Format.Format_ARGB32)
    return np.frombuffer(small.constBits(), dtype=np.uint8, count=nh * max_w * 4).reshape(nh, max_w, 4).copy()


class Grabber:
    MAX_WIDTH = 2560  # frames are downscaled to this width; higher keeps text sharp up close

    def __init__(self, kind, ident, fps=24):
        self.kind = kind          # "screen" (ident = monitor index) or "window" (ident = hwnd)
        self.ident = ident
        self.fps = fps
        self.started = time.monotonic()
        self.error = None         # last problem, shown in the window list
        self._lock = threading.Lock()
        self._frame = None
        self._version = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _grab_window(self, sct):
        rect = window_rect(self.ident)
        if rect is None or user32.IsIconic(self.ident):
            return None
        w, h = rect[2] - rect[0], rect[3] - rect[1]
        picture = capture_window_pixels(self.ident, w, h)
        if picture is not None:
            return picture
        # Fallback: copy the screen under the window (fails if something covers it).
        region = {"left": rect[0], "top": rect[1], "width": w, "height": h}
        return np.asarray(sct.grab(region))

    def _run(self):
        import mss
        period = 1.0 / self.fps
        try:
            with mss.mss() as sct:
                while not self._stop.is_set():
                    started = time.monotonic()
                    try:
                        if self.kind == "screen":
                            shot = np.asarray(sct.grab(dict(sct.monitors[self.ident])))
                        else:
                            shot = self._grab_window(sct)
                            if shot is None:
                                self.error = "window is closed or minimised"
                                time.sleep(0.25)
                                continue
                        self.error = None
                        frame = downscale_frame(shot, self.MAX_WIDTH)
                        with self._lock:
                            self._frame = frame
                            self._version += 1
                    except Exception as e:
                        self.error = f"{type(e).__name__}: {e}"
                        rh.log.exception("capture failed for %s %s", self.kind, self.ident)
                        time.sleep(0.5)
                    spent = time.monotonic() - started
                    if spent < period:
                        time.sleep(period - spent)
        except Exception:
            rh.log.exception("capture thread stopped")

    def latest(self):
        with self._lock:
            return self._version, self._frame

    def has_picture(self):
        with self._lock:
            return self._frame is not None

    def age(self):
        return time.monotonic() - self.started

    def stop(self):
        self._stop.set()


# ---------------------------------------------------------------------------
# Matrix helpers (row-major, used with GL_TRUE transpose)
# ---------------------------------------------------------------------------
def perspective(fovy_deg, aspect, near, far):
    f = 1.0 / math.tan(math.radians(fovy_deg) / 2.0)
    m = np.zeros((4, 4), np.float32)
    m[0, 0] = f / aspect
    m[1, 1] = f
    m[2, 2] = (far + near) / (near - far)
    m[2, 3] = 2.0 * far * near / (near - far)
    m[3, 2] = -1.0
    return m


def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1]], np.float32)


def rot_y(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]], np.float32)


def translate(x, y, z):
    m = np.eye(4, dtype=np.float32)
    m[0, 3], m[1, 3], m[2, 3] = x, y, z
    return m


def scale(x, y, z):
    return np.diag([x, y, z, 1.0]).astype(np.float32)


# Two triangles covering a unit square centred on the origin. Columns: x, y, z, u, v.
QUAD = np.array([
    -0.5, -0.5, 0.0, 0.0, 1.0,
     0.5, -0.5, 0.0, 1.0, 1.0,
     0.5,  0.5, 0.0, 1.0, 0.0,
    -0.5, -0.5, 0.0, 0.0, 1.0,
     0.5,  0.5, 0.0, 1.0, 0.0,
    -0.5,  0.5, 0.0, 0.0, 0.0,
], np.float32)
SCALE2 = scale(2.0, 2.0, 1.0)  # covers the whole screen in clip space



VS = """#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
uniform mat4 uMvp;
out vec2 vUv;
void main() { vUv = aUv; gl_Position = uMvp * vec4(aPos, 1.0); }
"""
VS_PANEL = """#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
uniform mat4 uMvp;
uniform vec2 uSize;
out vec2 vUv;
out vec2 vLocal;
void main() {
    vUv = aUv;
    vLocal = aPos.xy * uSize;   // position in metres, centred on the window
    gl_Position = uMvp * vec4(aPos, 1.0);
}
"""
FS_PANEL = """#version 330 core
in vec2 vUv;
in vec2 vLocal;
out vec4 fragColor;
uniform sampler2D uTex;
uniform float uAlpha;
uniform float uDim;
uniform vec2 uSize;
uniform float uRadius;
uniform vec3 uEdge;
uniform float uEdgeAmt;
uniform vec2 uCrop;                                    // part of the picture shown, so a new shape is cropped, not stretched
void main() {
    vec2 half_size = uSize * 0.5;
    vec2 q = abs(vLocal) - (half_size - vec2(uRadius));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
    float aa = clamp(0.5 - d / max(fwidth(d), 1e-6), 0.0, 1.0);   // antialiased rounded corners
    if (aa <= 0.0) discard;
    vec4 t = texture(uTex, (vUv - 0.5) * uCrop + 0.5);
    float rim = smoothstep(-0.010, -0.002, d);         // thin lit edge, like a pane of glass
    vec3 c = mix(t.rgb, uEdge, rim * uEdgeAmt);
    fragColor = vec4(c * (1.0 - uDim), t.a * uAlpha * aa);
}
"""
FS_GLOW = """#version 330 core
in vec2 vUv;
in vec2 vLocal;
out vec4 fragColor;
uniform vec2 uSize;      // size of the whole glow quad, window plus padding
uniform float uRadius;
uniform float uPad;
uniform float uFalloff;
uniform vec3 uColor;
uniform float uAlpha;
void main() {
    vec2 half_size = uSize * 0.5 - vec2(uPad);
    vec2 q = abs(vLocal) - (half_size - vec2(uRadius));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
    float a = exp(-max(d, 0.0) * uFalloff) * (1.0 - smoothstep(uPad * 0.6, uPad, d));
    a *= smoothstep(-0.006, 0.0, d);                    // nothing under the window itself
    fragColor = vec4(uColor, a * uAlpha);
}
"""
FS_BG = """#version 330 core
in vec2 vUv;
out vec4 fragColor;
uniform vec3 uTop;
uniform vec3 uBottom;
uniform sampler2D uBg;
uniform int uUseTex;
uniform float uDim;
uniform vec2 uRes;
uniform float uRadius;
void main() {
    vec2 half_size = uRes * 0.5;
    vec2 q = abs(gl_FragCoord.xy - half_size) - (half_size - vec2(uRadius));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
    if (d > 0.0) discard;
    vec3 c = mix(uBottom, uTop, 1.0 - vUv.y);
    vec2 g = vUv - vec2(0.5, 0.30);                    // a soft glow of colour high in the void
    c += uTop * 0.9 * exp(-dot(g, g) * 7.0);
    if (uUseTex == 1) c = texture(uBg, vUv).rgb;
    fragColor = vec4(c * (1.0 - uDim), 1.0);
}
"""
UNIFORMS = ("uMvp", "uTex", "uAlpha", "uDim", "uTop", "uBottom", "uBg", "uUseTex", "uRes", "uRadius", "uSize",
            "uColor", "uTime", "uScale", "uWarp", "uEdge", "uEdgeAmt", "uPad", "uFalloff", "uCrop")

FS_FADE = """#version 330 core
out vec4 fragColor;
uniform float uAlpha;
void main() { fragColor = vec4(0.0, 0.0, 0.0, uAlpha); }
"""
INTRO_STARS_END = 2.6          # seconds: the starfield has slowed and the title has gone
INTRO_END = 3.4                # seconds: windows have faded in and the launch animation hands over

VS_STAR = """#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in float aSize;
layout(location = 2) in float aPhase;
uniform mat4 uMvp;
uniform float uTime;
uniform float uScale;
uniform float uWarp;
out float vB;
void main() {
    vec4 p = uMvp * vec4(aPos, 1.0);
    p.xy *= 1.0 + uWarp * 3.0;                         // warp: stars rush outward from the centre of view
    gl_Position = p;
    gl_PointSize = aSize * uScale * (0.8 + 0.2 * sin(uTime * 1.7 + aPhase)) * (1.0 + uWarp * 2.2);
    vB = (0.55 + 0.45 * sin(uTime * 1.3 + aPhase)) * (1.0 + 0.6 * uWarp);
}
"""
FS_STAR = """#version 330 core
in float vB;
out vec4 fragColor;
uniform float uAlpha;
void main() {
    float d = length(gl_PointCoord - vec2(0.5));
    float a = smoothstep(0.5, 0.0, d);
    fragColor = vec4(vec3(0.86, 0.93, 1.0), a * min(vB, 1.0) * uAlpha);
}
"""


def build_stars(count=1400, radius=40.0, seed=7):
    """Random stars on a far sphere: x, y, z, size, phase per star."""
    rng = np.random.default_rng(seed)
    v = rng.normal(size=(count, 3))
    v /= np.linalg.norm(v, axis=1, keepdims=True)
    size = rng.uniform(1.0, 3.4, size=(count, 1)) ** 1.5
    phase = rng.uniform(0, 2 * math.pi, size=(count, 1))
    return np.hstack([v * radius, size, phase]).astype(np.float32).ravel()


def make_intro_image():
    """The product name and device name, drawn once as a transparent image."""
    img = QImage(1600, 500, QImage.Format.Format_RGBA8888)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    big = QFont("Segoe UI Variable Display", 110)
    big.setWeight(QFont.Weight.Light)
    big.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 8)
    p.setFont(big)
    p.setPen(QColor(240, 246, 252, 245))
    p.drawText(QRectF(0, 40, 1600, 280), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter,
               "Spatial Desk")
    small = QFont("Segoe UI Variable Text", 32)
    small.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 6)
    p.setFont(small)
    p.setPen(QColor(int(ACCENT[0] * 255), int(ACCENT[1] * 255), int(ACCENT[2] * 255), 220))
    p.drawText(QRectF(0, 330, 1600, 80), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter,
               "RayNeo Air 3S Pro")
    p.end()
    return np.frombuffer(img.constBits(), dtype=np.uint8, count=1600 * 500 * 4).reshape(500, 1600, 4).copy()


def _smooth(a, b, x):
    t = min(1.0, max(0.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)


def paint_icon(p, kind, r, color):
    """Simple line icons drawn with QPainter."""
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    cx, cy = x + w / 2.0, y + h / 2.0
    m = min(w, h) * 0.24
    pen = QPen(color, max(1.6, min(w, h) * 0.085))
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.save()
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)

    def line(a, b, c, d):
        p.drawLine(QPointF(a, b), QPointF(c, d))

    if kind == "add":
        line(cx, y + m, cx, y + h - m)
        line(x + m, cy, x + w - m, cy)
    elif kind == "minus":
        line(x + m, cy, x + w - m, cy)
    elif kind == "3d":
        p.drawPolygon(QPolygonF([QPointF(cx, y + m), QPointF(x + w - m, cy),
                                 QPointF(cx, y + h - m), QPointF(x + m, cy)]))
        line(x + m, cy, x + w - m, cy)
    elif kind == "flat":
        p.drawRoundedRect(QRectF(x + m, y + m, w - 2 * m, h * 0.55 - m), 3, 3)
        line(x + m, y + h - m, x + w - m, y + h - m)
    elif kind == "recenter":
        p.drawEllipse(QPointF(cx, cy), w * 0.26, h * 0.26)
        line(cx, y + m * 0.5, cx, y + m * 1.1)
        line(cx, y + h - m * 1.1, cx, y + h - m * 0.5)
        line(x + m * 0.5, cy, x + m * 1.1, cy)
        line(x + w - m * 1.1, cy, x + w - m * 0.5, cy)
    elif kind == "calibrate":
        p.drawEllipse(QPointF(cx, cy), w * 0.3, h * 0.3)
        p.drawPoint(QPointF(cx, cy))
    elif kind == "windows":
        p.drawRoundedRect(QRectF(x + m * 0.7, y + m * 0.9, w - m * 1.4, h - m * 1.8), 3, 3)
        line(x + w * 0.62, y + m * 0.9, x + w * 0.62, y + h - m * 0.9)
    elif kind == "settings":
        for k in (0.3, 0.5, 0.7):
            line(x + m, y + h * k, x + w - m, y + h * k)
    elif kind == "fullscreen":
        s_ = m * 0.9
        for ax, ay, dx, dy in ((x + m, y + m, 1, 1), (x + w - m, y + m, -1, 1),
                               (x + m, y + h - m, 1, -1), (x + w - m, y + h - m, -1, -1)):
            line(ax, ay, ax + dx * s_, ay)
            line(ax, ay, ax, ay + dy * s_)
    elif kind == "minimise":
        line(x + m, y + h - m, x + w - m, y + h - m)
    elif kind == "close":
        line(x + m, y + m, x + w - m, y + h - m)
        line(x + w - m, y + m, x + m, y + h - m)
    elif kind == "maximise":
        p.drawRoundedRect(QRectF(x + m, y + m, w - 2 * m, h - 2 * m), 3, 3)
    elif kind == "restore":
        p.drawRoundedRect(QRectF(x + m * 1.5, y + m * 0.7, w - 2.2 * m - m * 0.8, h - 2.2 * m - m * 0.8), 3, 3)
        p.drawRoundedRect(QRectF(x + m * 0.8, y + m * 1.5, w - 2.2 * m - m * 0.8, h - 2.2 * m - m * 0.8), 3, 3)
    elif kind == "hover":      # windows pinned in the room
        p.drawEllipse(QPointF(cx, cy - h * 0.12), w * 0.17, h * 0.17)
        line(cx, cy + h * 0.05, cx, y + h - m)
    elif kind == "follow":     # windows that travel with your gaze
        p.drawRoundedRect(QRectF(x + m, cy - h * 0.2, w * 0.4, h * 0.4), 3, 3)
        p.drawPolyline(QPolygonF([QPointF(x + w * 0.64, cy - h * 0.17), QPointF(x + w - m, cy),
                                  QPointF(x + w * 0.64, cy + h * 0.17)]))
    elif kind == "layers":
        p.drawRoundedRect(QRectF(x + m * 1.5, y + m * 0.8, w - 3 * m, h * 0.42), 3, 3)
        p.drawRoundedRect(QRectF(x + m, y + h * 0.42, w - 3 * m, h * 0.42), 3, 3)
    elif kind == "home":
        p.drawPolygon(QPolygonF([QPointF(cx, y + m * 0.6), QPointF(x + w - m, cy), QPointF(x + w - m * 1.3, cy),
                                 QPointF(x + w - m * 1.3, y + h - m), QPointF(x + m * 1.3, y + h - m),
                                 QPointF(x + m * 1.3, cy), QPointF(x + m, cy)]))
    elif kind == "grid":
        s_ = (w - 2 * m) * 0.42
        for gx in (x + m, x + w - m - s_):
            for gy in (y + m, y + h - m - s_):
                p.drawRoundedRect(QRectF(gx, gy, s_, s_), 2, 2)
    p.restore()


def make_icon(kind, color=None, px=64):
    c = color or QColor(236, 242, 250)
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    paint_icon(p, kind, QRectF(0, 0, px, px), c)
    p.end()
    return QIcon(QPixmap.fromImage(img))


DOCK_TILE = 46                  # size of one app tile in the dock, pixels


def make_tile_icon(kind, top, bottom, glyph, size=DOCK_TILE):
    """A solid app-style squircle: a vivid colour, a bright rim along the top edge, and a solid glyph."""
    px = size * 2
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    r = QRectF(0, 0, px, px).adjusted(1, 1, -1, -1)
    path = QPainterPath()
    path.addRoundedRect(r, px * 0.27, px * 0.27)
    grad = QLinearGradient(r.topLeft(), r.bottomLeft())
    grad.setColorAt(0.0, top)
    grad.setColorAt(1.0, bottom)
    p.fillPath(path, grad)
    rim = QLinearGradient(r.topLeft(), QPointF(r.left(), r.top() + r.height() * 0.35))
    rim.setColorAt(0.0, QColor(255, 255, 255, 110))
    rim.setColorAt(1.0, QColor(255, 255, 255, 0))
    p.setPen(QPen(QBrush(rim), 2.4))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawPath(path)
    paint_icon(p, kind, QRectF(px * 0.22, px * 0.22, px * 0.56, px * 0.56), glyph)
    p.end()
    return QIcon(QPixmap.fromImage(img))


def find_installed_apps():
    """
    Microsoft apps installed on this PC, as (name, exe path). Each icon is read from the program
    itself, so the logos are the real ones. Only apps that exist are returned.
    """
    if not IS_WIN:
        return []
    import glob
    roots = [os.environ.get("ProgramFiles", r"C:\Program Files"),
             os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")]
    sysroot = os.environ.get("SystemRoot", r"C:\Windows")
    office = r"Microsoft Office\root\Office*\{}"
    patterns = [
        ("Word", office.format("WINWORD.EXE")),
        ("Excel", office.format("EXCEL.EXE")),
        ("PowerPoint", office.format("POWERPNT.EXE")),
        ("Outlook", office.format("OUTLOOK.EXE")),
        ("OneNote", office.format("ONENOTE.EXE")),
        ("Edge", r"Microsoft\Edge\Application\msedge.exe"),
        ("Teams", r"Microsoft\Teams\current\Teams.exe"),
    ]
    found = []
    for name, rel in patterns:
        for root in roots:
            hits = sorted(glob.glob(os.path.join(root, rel)), reverse=True)   # newest version first
            if hits:
                found.append((name, hits[0]))
                break
    for name, exe in (("Explorer", "explorer.exe"), ("Notepad", "notepad.exe")):
        path = os.path.join(sysroot, exe)
        if os.path.exists(path):
            found.append((name, path))
    return found


def make_app_icon(exe_path):
    """The program's own logo at dock size, or a null icon if Windows gives none (then the app is skipped)."""
    px = DOCK_TILE * 2
    pm = QFileIconProvider().icon(QFileInfo(exe_path)).pixmap(QSize(px, px))
    if pm.isNull():
        return QIcon()
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    p.drawPixmap(QRectF(0, 0, px, px), pm, QRectF(pm.rect()))
    p.end()
    return QIcon(QPixmap.fromImage(img))


def make_glyph_icon(kind, size=DOCK_TILE):
    """A plain white glyph with no tile behind it, as the reference shows for its small icons."""
    px = size * 2
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    paint_icon(p, kind, QRectF(px * 0.16, px * 0.16, px * 0.68, px * 0.68), QColor(246, 248, 252, 240))
    p.end()
    return QIcon(QPixmap.fromImage(img))


def make_icon_button(kind, slot, tip, primary=False, checkable=False, tint=None):
    """One dock tile in a vivid app colour. The 3D button is near-white, as the main action."""
    base = QColor(tint) if tint else QColor(255, 255, 255)
    if primary:
        top, bottom, glyph = QColor(246, 248, 252), QColor(206, 212, 224), QColor(12, 12, 14)
    else:
        top, bottom = base.lighter(110), base.darker(112)
        glyph = QColor(255, 255, 255)
    b = QPushButton()
    b.setObjectName("apptile")
    b.setIcon(make_glyph_icon(kind))
    b.setIconSize(QSize(DOCK_TILE, DOCK_TILE))
    b.setToolTip(tip)
    b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    b.setCheckable(checkable)
    b.setFixedSize(DOCK_TILE + 4, DOCK_TILE + 4)
    b.clicked.connect(slot)
    return b


# Buttons on a window's title bar: (name, centre x in pixels). Used for drawing and for clicking.
# The bar spans the middle of the window (about 73% of its width), as in the reference.
BAR_X0, BAR_X1 = HDR_W * 0.2667, HDR_W * 0.7333     # two-thirds of the previous length, still centred
BAR_W = BAR_X1 - BAR_X0
HDR_BTNS = (("pull", BAR_X0 + 0.70 * BAR_W), ("push", BAR_X0 + 0.77 * BAR_W),
            ("max", BAR_X0 + 0.86 * BAR_W), ("close", BAR_X0 + 0.94 * BAR_W))
HDR_BTN_HALF = 36
HDR_ICON = {"pull": "minus", "push": "add", "max": "maximise", "close": "close"}


def title_hit(u):
    """Which title bar button sits at horizontal position u (0..1), or None."""
    x = u * HDR_W
    for key, cx in HDR_BTNS:
        if abs(x - cx) <= HDR_BTN_HALF:
            return key
    return None


def make_title_bar(name, has_picture, focused, dist, expanded):
    """Slim, sleek title bar: a rounded translucent strip centred above the window, with thin icons.
    Left: document, ring, up-caret. Right: pull, push, maximise and close."""
    img = QImage(HDR_W, HDR_H, QImage.Format.Format_RGBA8888)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    bar_top, bar_h = 27.0, 44.0            # a little smaller, still close to the window
    mid = bar_top + bar_h / 2.0
    # translucent pill, no outline
    path = QPainterPath()
    path.addRoundedRect(QRectF(BAR_X0, bar_top, BAR_W, bar_h), bar_h / 2.0, bar_h / 2.0)
    p.fillPath(path, QColor(40, 40, 46, 150 if focused else 120))          # lighter glass
    # left glyphs (visual only)
    p.setBrush(Qt.BrushStyle.NoBrush)
    ink = QColor(226, 230, 238, 200)
    for frac, glyph in ((0.05, "doc"), (0.11, "ring"), (0.5, "caret")):    # doc and ring at the left, caret centred
        cx = BAR_X0 + frac * BAR_W
        p.save()
        p.translate(cx, mid)
        p.scale(0.55, 0.55)
        p.setPen(QPen(ink, 3.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        if glyph == "doc":
            p.drawRoundedRect(QRectF(-11, -14, 22, 28), 4, 4)
            p.drawLine(QPointF(-6, -4), QPointF(6, -4))
            p.drawLine(QPointF(-6, 3), QPointF(6, 3))
        elif glyph == "ring":
            p.drawEllipse(QPointF(0, 0), 11, 11)
        else:
            p.drawPolyline(QPolygonF([QPointF(-12, 5), QPointF(0, -6), QPointF(12, 5)]))
        p.restore()
    # right buttons (these are the real controls)
    p.setPen(Qt.PenStyle.NoPen)
    for key, cx in HDR_BTNS:
        kind = HDR_ICON[key]
        if key == "max" and expanded:
            kind = "restore"
        paint_icon(p, kind, QRectF(cx - 11, mid - 10, 22, 20), ink)
    p.end()
    ptr = img.constBits()
    return np.frombuffer(ptr, dtype=np.uint8, count=HDR_W * HDR_H * 4).reshape(HDR_H, HDR_W, 4).copy()


def _program(vs_src, fs_src):
    def shader(kind, src):
        s = gl.glCreateShader(kind)
        gl.glShaderSource(s, src)
        gl.glCompileShader(s)
        if not gl.glGetShaderiv(s, gl.GL_COMPILE_STATUS):
            raise RuntimeError(gl.glGetShaderInfoLog(s).decode(errors="replace"))
        return s

    prog = gl.glCreateProgram()
    gl.glAttachShader(prog, shader(gl.GL_VERTEX_SHADER, vs_src))
    gl.glAttachShader(prog, shader(gl.GL_FRAGMENT_SHADER, fs_src))
    gl.glLinkProgram(prog)
    if not gl.glGetProgramiv(prog, gl.GL_LINK_STATUS):
        raise RuntimeError(gl.glGetProgramInfoLog(prog).decode(errors="replace"))
    return prog


def _make_texture(width, height, data=None, fmt=None, mip=False):
    tex = gl.glGenTextures(1)
    gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
    for pname, val in ((gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR_MIPMAP_LINEAR if mip else gl.GL_LINEAR), (gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR),
                       (gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE), (gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)):
        gl.glTexParameteri(gl.GL_TEXTURE_2D, pname, val)
    if mip:
        try:
            gl.glTexParameterf(gl.GL_TEXTURE_2D, 0x84FE, 8.0)   # GL_TEXTURE_MAX_ANISOTROPY_EXT
        except Exception:
            pass
    if data is not None:
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, width, height, 0, fmt or gl.GL_RGBA,
                        gl.GL_UNSIGNED_BYTE, data)
    return tex


# ---------------------------------------------------------------------------
# 3D scene: a starfield void with windows floating at their own depth
# ---------------------------------------------------------------------------
class Scene(QOpenGLWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.start_time = None          # set on the first frame, so the intro is always seen
        self.skip_intro = False
        self.intro_ended = False
        self.on_intro_end = None
        self.panels = []
        self.focused = None             # the window you last touched; gets the accent glow
        self.layout_name = "code"
        self.fov = FOV_DEFAULT
        self.follow = False             # False = hover (windows fixed in the room), True = follow your gaze
        self._fy = self._fp = 0.0       # where the follow rig currently points
        self.bg_top, self.bg_bottom = THEMES["space"]
        self.bg_tex = None
        self.bg_use = False
        self.bg_pending = None
        self.yaw = self.pitch = self.e = self.dim = 0.0
        self._last_view = np.eye(4, dtype=np.float32)
        self.on_click = None
        self.on_wheel = None
        self._press = None
        self.on_look = None
        self.on_gl_error = None
        self._drag = None
        self._to_delete = []
        self._uniforms = {}
        self._gl_failed = False
        self._warp_amp = 0.0
        self._warp_t0 = 0.0
        self._warp_dur = 0.2
        self._last_paint = None
        self.reserved_right = 0   # pixels on the right taken by the window list
        self.setMinimumSize(640, 400)

    # ----- starfield transition and follow rig
    def kick_warp(self, amount, dur=0.2):
        """Starfield rush: the signature transition when windows grow, shrink, open, close or move in depth."""
        self._warp_amp = max(amount, self._current_warp())
        self._warp_t0 = time.monotonic()
        self._warp_dur = dur

    def _current_warp(self):
        if self._warp_amp <= 0.0:
            return 0.0
        x = (time.monotonic() - self._warp_t0) / self._warp_dur
        if x >= 6.0:
            self._warp_amp = 0.0
            return 0.0
        return self._warp_amp * x * math.exp(1.0 - x)   # quick rise, long soft settle

    def set_follow(self, on):
        self.follow = bool(on)

    def reset_follow(self):
        self._fy = self._fp = 0.0

    def _follow_step(self, dt):
        """Windows stay put for small head movements, then drift after your gaze. Bigger windows drift slower."""
        if not self.follow:
            return
        widest = max([p.get("w_space", PANEL_W) for p in self.panels] or [PANEL_W])
        rate = 5.0 / (0.5 + widest)
        a = 1.0 - math.exp(-dt * rate)
        for attr, target, dead in (("_fy", self.yaw, 0.06), ("_fp", self.pitch, 0.05)):
            cur = getattr(self, attr)
            d = target - cur
            if abs(d) > dead:
                cur += (d - math.copysign(dead, d)) * a
                setattr(self, attr, cur)

    # ----- layout
    def _half_width_at(self, d):
        aspect = max(1.2, self.width() / max(1, self.height())) if self.height() else 1.6
        return math.tan(math.radians(self.fov) / 2.0) * aspect * d

    @staticmethod
    def _angle_for(width, dist):
        return 2.0 * math.asin(min(0.95, width / (2.0 * dist)))

    def relayout(self):
        """Places every window: a fitted row in setup, and an arrangement in 3D that avoids overlap."""
        panels = self.panels
        n = len(panels)
        if n == 0:
            self.update()
            return
        gap_flat = 0.18
        # Setup row: sized to fit the space left of the window list, so nothing overlaps or runs off the edge.
        d0 = panels[0].get("dist", DEFAULT_DIST)
        widths = [PANEL_W * (EXPAND_FACTOR if p.get("expanded") else 1.0) for p in panels]
        half = self._half_width_at(d0)
        view_w = max(1, self.width())
        visible_frac = max(0.3, (view_w - self.reserved_right) / view_w)
        usable = 2.0 * half * visible_frac * 0.86
        free = usable - gap_flat * (n - 1)
        if sum(widths) > free > 0:
            f = free / sum(widths)
            widths = [w * f for w in widths]
        shift = -(self.reserved_right / view_w) * half  # centre the row in the visible area
        x = shift - (sum(widths) + gap_flat * (n - 1)) / 2.0
        for p, w in zip(panels, widths):
            p["w_flat"] = w
            p["flat"] = np.array([x + w / 2.0, 0.0, -d0], np.float32)
            x += w + gap_flat

        gap = LAYOUT_GAP[self.layout_name]
        if self.layout_name == "code":
            # Main window in the middle, the others in columns on either side, further back.
            main = next((i for i, p in enumerate(panels) if p.get("expanded")), 0)
            main_w = PANEL_W * (EXPAND_FACTOR if panels[main].get("expanded") else 1.0)
            main_d = panels[main].get("dist", DEFAULT_DIST)
            centres = {main: 0.0}
            spans = {main: main_w}
            right = self._angle_for(main_w, main_d) / 2.0 + gap
            left = -right
            side_w = PANEL_W * 0.8
            for k, i in enumerate([i for i in range(n) if i != main]):
                d = panels[i].get("dist", DEFAULT_DIST) + 0.8
                w = side_w
                ang = self._angle_for(w, d)
                if k % 2 == 0:
                    centres[i] = right + ang / 2.0
                    right += ang + gap
                else:
                    centres[i] = left - ang / 2.0
                    left -= ang + gap
                spans[i] = w
            for i, p in enumerate(panels):
                d = p.get("dist", DEFAULT_DIST) + (0.8 if i != main else 0.0)
                self._set_space(p, centres[i], d, spans[i])
        elif self.layout_name == "layers":
            # Windows stacked front to back, each on its own depth, fanned out a little so every one shows.
            main = next((i for i, p in enumerate(panels) if p.get("expanded")), 0)
            order = [main] + [i for i in range(n) if i != main]
            for rank, i in enumerate(order):
                p = panels[i]
                own = p.get("dist", DEFAULT_DIST)
                d = own + 0.55 * rank
                base_w = PANEL_W * (EXPAND_FACTOR if p.get("expanded") else 1.0)
                w = base_w * (d / own) * (0.92 ** rank)       # farther windows keep about the same apparent size
                step = (rank + 1) // 2
                centre = (1 if rank % 2 else -1) * 0.17 * step if rank else 0.0
                self._set_space(p, centre, d, w, y=0.11 * rank)
        else:
            # Ring around you: each window takes its own angle, with a gap between neighbours.
            widths = [PANEL_W * (EXPAND_FACTOR if p.get("expanded") else 1.0) for p in panels]
            dists = [p.get("dist", DEFAULT_DIST) for p in panels]
            spans = [self._angle_for(w, d) for w, d in zip(widths, dists)]
            total = sum(spans) + gap * (n - 1)
            if n >= 3:                          # side windows sit closer to the edge; keep them inside the view
                widths = [w * 0.75 for w in widths]
            limit = min(5.4, 0.5 + 0.25 * n)   # a gentle arc that stays inside the view (about 90 deg for 3 windows)
            if total > limit:
                f = limit / total
                widths = [w * f for w in widths]
                spans = [self._angle_for(w, d) for w, d in zip(widths, dists)]
                total = sum(spans) + gap * (n - 1)
            cursor = -total / 2.0
            for i, p in enumerate(panels):
                c = cursor + spans[i] / 2.0
                self._set_space(p, c, dists[i], widths[i])
                cursor += spans[i] + gap
        self.update()

    @staticmethod
    def _set_space(p, centre, dist, width, y=0.0):
        p["space"] = np.array([math.sin(centre) * dist, y, -math.cos(centre) * dist], np.float32)
        p["rot_space"] = -centre  # turns each window to face you
        p["w_space"] = width

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.relayout()

    def set_layout(self, name):
        self.layout_name = name
        self.relayout()

    def set_fov(self, degrees):
        self.fov = float(min(FOV_MAX, max(FOV_MIN, degrees)))
        self.relayout()

    def drop_panel(self, p):
        if p.get("tex") is not None:
            self._to_delete.append(p["tex"])
        if p.get("hdr_tex") is not None:
            self._to_delete.append(p["hdr_tex"])
        if p is self.focused:
            self.focused = None
        self.panels = [q for q in self.panels if q is not p]
        self.relayout()

    def set_view(self, yaw, pitch, e, dim):
        self.yaw, self.pitch, self.e, self.dim = yaw, pitch, e, dim
        self.update()

    def set_theme(self, name):
        self.bg_top, self.bg_bottom = THEMES[name]
        self.bg_use = False
        self.update()

    def set_background_image(self, path):
        img = QImage(path)
        if img.isNull():
            return False
        img = img.convertToFormat(QImage.Format.Format_RGBA8888)
        w, h = img.width(), img.height()
        bpl = img.bytesPerLine()
        raw = np.frombuffer(img.constBits(), dtype=np.uint8, count=bpl * h)
        raw = raw.reshape(h, bpl)[:, : w * 4].reshape(h, w, 4).copy()
        self.bg_pending = (w, h, raw)
        self.update()
        return True

    # ----- GL setup
    def initializeGL(self):
        try:
            rh.log.info("OpenGL %s on %s", gl.glGetString(gl.GL_VERSION).decode(errors="replace"),
                        gl.glGetString(gl.GL_RENDERER).decode(errors="replace"))
        except Exception:
            pass
        gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
        self.prog_panel = _program(VS_PANEL, FS_PANEL)
        self.prog_glow = _program(VS_PANEL, FS_GLOW)
        self.prog_bg = _program(VS, FS_BG)
        self.prog_star = _program(VS_STAR, FS_STAR)
        self.prog_fade = _program(VS, FS_FADE)
        for prog in (self.prog_panel, self.prog_glow, self.prog_bg, self.prog_star, self.prog_fade):
            self._uniforms[prog] = {n: gl.glGetUniformLocation(prog, n) for n in UNIFORMS}

        self.vao = gl.glGenVertexArrays(1)
        self.vbo = gl.glGenBuffers(1)
        gl.glBindVertexArray(self.vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, QUAD.nbytes, QUAD, gl.GL_STATIC_DRAW)
        gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(0))
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(1, 2, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(12))
        gl.glEnableVertexAttribArray(1)

        stars = build_stars()
        self.star_count = len(stars) // 5
        self.star_vao = gl.glGenVertexArrays(1)
        self.star_vbo = gl.glGenBuffers(1)
        gl.glBindVertexArray(self.star_vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.star_vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, stars.nbytes, stars, gl.GL_STATIC_DRAW)
        gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(0))
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(1, 1, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(12))
        gl.glEnableVertexAttribArray(1)
        gl.glVertexAttribPointer(2, 1, gl.GL_FLOAT, gl.GL_FALSE, 20, ctypes.c_void_p(16))
        gl.glEnableVertexAttribArray(2)
        gl.glBindVertexArray(0)

        self.intro_tex = _make_texture(1600, 500, make_intro_image())
        self.white_tex = _make_texture(1, 1, np.array([235, 242, 255, 255], np.uint8))
        self.accent_tex = _make_texture(1, 1, np.array([int(c * 255) for c in ACCENT] + [255], np.uint8))

        gl.glEnable(gl.GL_PROGRAM_POINT_SIZE)
        gl.glEnable(gl.GL_BLEND)
        gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)
        gl.glClearColor(0.0, 0.0, 0.0, 1.0)

    def _sync_texture(self, p):
        version, frame = p["grab"].latest()
        if frame is None or version == p.get("ver"):
            return
        p["ver"] = version
        h, w = frame.shape[:2]
        if p.get("tex") is None:
            p["tex"] = _make_texture(w, h, mip=True)
            p["shape"] = None
        gl.glBindTexture(gl.GL_TEXTURE_2D, p["tex"])
        if p.get("shape") != (h, w):
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, w, h, 0, gl.GL_BGRA, gl.GL_UNSIGNED_BYTE, frame)
            p["shape"] = (h, w)
        else:
            gl.glTexSubImage2D(gl.GL_TEXTURE_2D, 0, 0, 0, w, h, gl.GL_BGRA, gl.GL_UNSIGNED_BYTE, frame)
        gl.glGenerateMipmap(gl.GL_TEXTURE_2D)   # smaller copies, so small text does not shimmer or alias
        p["aspect"] = h / w  # the window keeps the capture's shape, so nothing is stretched

    def _t(self):
        now = time.monotonic()
        if self.start_time is None:
            self.start_time = now
        return now - self.start_time

    def _sync_title(self, p, focused):
        has = p["grab"].has_picture()
        key = (p["name"], has, focused, bool(p.get("expanded")), round(p.get("dist", DEFAULT_DIST), 1))
        if p.get("hdr_key") == key:
            return
        p["hdr_key"] = key
        raw = make_title_bar(p["name"], has, focused, p.get("dist", DEFAULT_DIST), bool(p.get("expanded")))
        if p.get("hdr_tex") is None:
            p["hdr_tex"] = _make_texture(HDR_W, HDR_H)
        gl.glBindTexture(gl.GL_TEXTURE_2D, p["hdr_tex"])
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, HDR_W, HDR_H, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, raw)

    # ----- drawing
    def paintGL(self):
        if self._gl_failed:
            return
        try:
            self._paint()
        except Exception:
            self._gl_failed = True
            rh.log.exception("OpenGL drawing failed; the 3D view is disabled. Restart the app to retry.")
            if self.on_gl_error:
                self.on_gl_error()

    def _paint(self):
        for tex in self._to_delete:
            gl.glDeleteTextures([tex])
        self._to_delete = []

        now = time.monotonic()
        dt = min(0.1, now - self._last_paint) if self._last_paint else 0.016
        self._last_paint = now

        dpr = self.devicePixelRatioF()
        pw, ph = max(1, int(self.width() * dpr)), max(1, int(self.height() * dpr))
        gl.glViewport(0, 0, pw, ph)
        gl.glClear(gl.GL_COLOR_BUFFER_BIT)

        if self.bg_pending is not None:
            w, h, raw = self.bg_pending
            self.bg_pending = None
            if self.bg_tex is None:
                self.bg_tex = _make_texture(w, h)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self.bg_tex)
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, w, h, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, raw)
            self.bg_use = True

        # Background (with the rounded frame of the app window)
        gl.glBindVertexArray(self.vao)
        u = self._uniforms[self.prog_bg]
        gl.glUseProgram(self.prog_bg)
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, SCALE2)
        gl.glUniform3f(u["uTop"], *self.bg_top)
        gl.glUniform3f(u["uBottom"], *self.bg_bottom)
        gl.glUniform1f(u["uDim"], self.dim)
        gl.glUniform1i(u["uUseTex"], 1 if self.bg_use else 0)
        gl.glUniform1i(u["uBg"], 1)
        gl.glUniform2f(u["uRes"], pw, ph)
        gl.glUniform1f(u["uRadius"], CORNER_RADIUS * dpr)
        if self.bg_use:
            gl.glActiveTexture(gl.GL_TEXTURE1)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self.bg_tex)
            gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

        aspect = max(0.01, self.width() / max(1, self.height()))
        proj = perspective(self.fov, aspect, 0.05, 60.0)
        # Head movement moves the camera, so windows stay fixed in the room (hover) unless follow carries them.
        view = rot_x(-self.pitch * self.e) @ rot_y(self.yaw * self.e)
        self._last_view = view

        t = self._t()
        if self.skip_intro:
            t = INTRO_END + 1.0
        warp = self._current_warp()
        if t < INTRO_STARS_END:
            warp = max(warp, 2.2 * (1.0 - _smooth(0.0, INTRO_STARS_END, t)))   # fly in, then slow to a stop

        # Starfield: far away, so it only follows head rotation
        u = self._uniforms[self.prog_star]
        gl.glUseProgram(self.prog_star)
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view).astype(np.float32))
        gl.glUniform1f(u["uTime"], self._t())
        gl.glUniform1f(u["uScale"], dpr)
        gl.glUniform1f(u["uAlpha"], 1.0)
        gl.glUniform1f(u["uWarp"], warp)
        gl.glBindVertexArray(self.star_vao)
        gl.glDrawArrays(gl.GL_POINTS, 0, self.star_count)

        # Launch animation, part 1: stars rush in from black, then the title shows with the windows still hidden
        if t < INTRO_STARS_END:
            title = _smooth(0.9, 1.6, t) * (1.0 - _smooth(2.0, INTRO_STARS_END, t))
            if title > 0.0:
                self._draw_title(title)
            black = 1.0 - _smooth(0.0, 0.6, t)
            if black > 0.0:
                self._draw_black(black)
            return

        alpha = _smooth(INTRO_STARS_END - 0.2, INTRO_END, t)   # windows fade in over the stars
        self._draw_windows(proj, view, dt, alpha)

        if t >= INTRO_END and not self.intro_ended:
            self.intro_ended = True
            if self.on_intro_end is not None:
                self.on_intro_end()

    def _draw_windows(self, proj, view, dt, alpha):
        e = self.e
        self._follow_step(dt)
        fy, fp = self._fy * e, self._fp * e
        F = rot_y(-fy) @ rot_x(fp)      # the inverse of the view turn, so a following window stays in front of you

        # Ease each window to where it should be, so layout changes glide instead of jump.
        k = 1.0 - math.exp(-dt * 10.0)
        items = []
        for p in self.panels:
            self._sync_texture(p)
            if p.get("tex") is None or "flat" not in p:
                continue
            tw = p["w_flat"] * (1.0 - e) + p.get("w_space", p["w_flat"]) * e
            tpos = p["flat"] * (1.0 - e) + p["space"] * e
            trot = p.get("rot_space", 0.0) * e
            if "aw" not in p:
                p["aw"], p["apos"], p["arot"] = tw, tpos.copy(), trot
            else:
                p["aw"] += (tw - p["aw"]) * k
                p["apos"] = p["apos"] + (tpos - p["apos"]) * k
                p["arot"] += (trot - p["arot"]) * k
            items.append(p)
        items.sort(key=lambda q: -float(np.linalg.norm(q["apos"])))   # far windows first, so near ones cover them

        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindVertexArray(self.vao)
        for p in items:
            focused = p is self.focused
            w = p["aw"]
            cap = p.get("aspect", 0.5625)
            target = RATIOS.get(p.get("ratio", "auto"))
            if target is None:
                h, crop = w * cap, (1.0, 1.0)
            else:
                h = w * target
                crop = (1.0, target / cap) if target < cap else (cap / target, 1.0)
            base = F @ translate(*p["apos"]) @ rot_y(p["arot"])
            model = base @ scale(w, h, 1.0)
            p["pick"] = {"model": model, "w": w, "h": h}

            # Soft glow behind the window: accent for the one you are working in, faint white for the rest
            g = self._uniforms[self.prog_glow]
            gl.glUseProgram(self.prog_glow)
            gw, gh = w + 2 * GLOW_PAD, h + 2 * GLOW_PAD
            gm = base @ translate(0.0, 0.0, -0.003) @ scale(gw, gh, 1.0)
            gl.glUniformMatrix4fv(g["uMvp"], 1, gl.GL_TRUE, (proj @ view @ gm).astype(np.float32))
            gl.glUniform2f(g["uSize"], gw, gh)
            gl.glUniform1f(g["uRadius"], PANEL_CORNER)
            gl.glUniform1f(g["uPad"], GLOW_PAD)
            gl.glUniform1f(g["uFalloff"], 20.0)
            gl.glUniform3f(g["uColor"], *(ACCENT if focused else (0.80, 0.88, 1.0)))
            gl.glUniform1f(g["uAlpha"], 0.0)
            gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

            # The window itself
            u = self._uniforms[self.prog_panel]
            gl.glUseProgram(self.prog_panel)
            gl.glUniform1f(u["uDim"], self.dim)
            gl.glUniform1f(u["uAlpha"], alpha)
            gl.glUniform1i(u["uTex"], 0)
            gl.glUniform1f(u["uRadius"], PANEL_CORNER)
            gl.glUniform3f(u["uEdge"], *(ACCENT if focused else (0.85, 0.90, 1.0)))
            gl.glUniform1f(u["uEdgeAmt"], 0.12 if focused else 0.04)
            gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view @ model).astype(np.float32))
            gl.glUniform2f(u["uSize"], w, h)
            gl.glUniform2f(u["uCrop"], *crop)
            gl.glBindTexture(gl.GL_TEXTURE_2D, p["tex"])
            gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

            # Title capsule above the window
            self._sync_title(p, focused)
            gl.glUniform1f(u["uEdgeAmt"], 0.0)
            gl.glUniform2f(u["uCrop"], 1.0, 1.0)   # the title bar is never cropped
            if p.get("hdr_tex") is not None:
                hh = w * HDR_H / HDR_W
                bar = base @ translate(0.0, h / 2.0 + hh / 2.0 + 0.03, 0.0) @ scale(w, hh, 1.0)
                p["pick_hdr"] = {"model": bar, "w": w, "h": hh}
                gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view @ bar).astype(np.float32))
                gl.glUniform2f(u["uSize"], w, hh)
                gl.glUniform1f(u["uRadius"], hh * 0.5)
                gl.glBindTexture(gl.GL_TEXTURE_2D, p["hdr_tex"])
                gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

            # Grabber pill under the window
            gpw, gph = 0.30, 0.030
            pill = base @ translate(0.0, -h / 2.0 - 0.07, 0.0) @ scale(gpw, gph, 1.0)
            gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, (proj @ view @ pill).astype(np.float32))
            gl.glUniform2f(u["uSize"], gpw, gph)
            gl.glUniform1f(u["uRadius"], gph * 0.5)
            gl.glUniform1f(u["uAlpha"], (0.95 if focused else 0.38) * alpha)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self.accent_tex if focused else self.white_tex)
            gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

    def _draw_title(self, alpha):
        sx = 0.7
        sy = sx * (self.width() / max(1, self.height())) * (500.0 / 1600.0)
        u = self._uniforms[self.prog_panel]
        gl.glUseProgram(self.prog_panel)
        gl.glBindVertexArray(self.vao)
        gl.glUniformMatrix4fv(u["uMvp"], 1, gl.GL_TRUE, scale(2 * sx, 2 * sy, 1.0))
        gl.glUniform2f(u["uSize"], 2 * sx, 2 * sy)
        gl.glUniform1f(u["uRadius"], 0.0)
        gl.glUniform1f(u["uAlpha"], alpha)
        gl.glUniform1f(u["uDim"], 0.0)
        gl.glUniform1f(u["uEdgeAmt"], 0.0)
        gl.glUniform1i(u["uTex"], 0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self.intro_tex)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

    def _draw_black(self, alpha):
        gl.glUseProgram(self.prog_fade)
        gl.glBindVertexArray(self.vao)
        gl.glUniformMatrix4fv(self._uniforms[self.prog_fade]["uMvp"], 1, gl.GL_TRUE, SCALE2)
        gl.glUniform1f(self._uniforms[self.prog_fade]["uAlpha"], alpha)
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 6)

    def pick(self, px, py):
        """What is under the cursor: (kind, index, u, v), kind = 'body' or 'header'; u, v run 0..1 from the top-left."""
        W, H = max(1, self.width()), max(1, self.height())
        tan_h = math.tan(math.radians(self.fov) / 2.0)    # the same field of view the picture is drawn with
        dir_view = np.array([(2.0 * px / W - 1.0) * tan_h * (W / H), (1.0 - 2.0 * py / H) * tan_h, -1.0, 0.0])
        inv_view = np.linalg.inv(self._last_view.astype(np.float64))
        origin = inv_view @ np.array([0.0, 0.0, 0.0, 1.0])
        direction = inv_view @ dir_view
        best = None
        for i, p in enumerate(self.panels):
            for key, kind in (("pick", "body"), ("pick_hdr", "header")):
                info = p.get(key)
                if not info:
                    continue
                inv = np.linalg.inv(info["model"].astype(np.float64))
                lo, ld = inv @ origin, inv @ direction
                if abs(ld[2]) < 1e-9:
                    continue
                t = -lo[2] / ld[2]
                if t <= 0:
                    continue
                hx, hy = lo[0] + t * ld[0], lo[1] + t * ld[1]
                if abs(hx) <= 0.5 and abs(hy) <= 0.5 and (best is None or t < best[0]):
                    best = (t, kind, i, hx + 0.5, 0.5 - hy)
        if best is None:
            return None
        return best[1], best[2], best[3], best[4]

    # ----- mouse
    def mousePressEvent(self, ev):
        if IS_WIN and (ev.modifiers() & Qt.KeyboardModifier.AltModifier):
            handle = self.window().windowHandle()
            if handle is not None:
                handle.startSystemMove()  # Alt + drag moves the frameless window
            return
        if ev.button() == Qt.MouseButton.LeftButton:
            self._drag = ev.position()
            self._press = ev.position()

    def mouseMoveEvent(self, ev):
        if self._drag is not None and self.on_look is not None:
            p = ev.position()
            self.on_look(p.x() - self._drag.x(), p.y() - self._drag.y())
            self._drag = p

    def mouseReleaseEvent(self, ev):
        if self._press is not None and ev.button() == Qt.MouseButton.LeftButton:
            moved = (ev.position() - self._press).manhattanLength()
            if moved < 6 and self.on_click is not None:
                self.on_click(ev.position().x(), ev.position().y())
        self._press = None
        self._drag = None

    def wheelEvent(self, ev):
        if self.on_wheel is not None:
            self.on_wheel(ev.position().x(), ev.position().y(), ev.angleDelta().y())


# ---------------------------------------------------------------------------
# Glasses tracking, using the helper in this process
# ---------------------------------------------------------------------------
class Tracker:
    def __init__(self):
        self.shared = rh.Shared()
        self.stop_event = threading.Event()
        self.available = True
        self.message = "Starting…"   # shown in the status pill while the SDK is set up
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _report(self, text):
        self.message = text
        rh.log.info("SDK: %s", text)

    def _run(self):
        path = rh.find_library()
        if not path:
            try:
                rh.ensure_sdk(HERE, report=self._report)  # downloads the SDK once
                path = rh.find_library()
            except Exception as e:
                self._report(f"SDK setup failed: {e}")
                path = None
        if path:
            try:
                rh.RayNeoSdk(path)  # loads the DLL now, so a problem shows up here
                self._report("SDK ready. Looking for glasses…")
            except Exception as e:
                self._report(f"SDK could not load: {e}")
                path = None
        if not path:
            self.available = False
            if self.message.startswith("Starting"):
                self._report("SDK not found in the sdk folder")
        rh.device_loop(self.shared, self.stop_event, path, False)

    def snapshot(self):
        return self.shared.snapshot()

    def calibrate(self):
        self.shared.request_calibrate()

    def recenter(self):
        self.shared.request_recenter()

    def close(self):
        self.stop_event.set()


# ---------------------------------------------------------------------------
# Styling: dark glass capsules with one cool accent
# ---------------------------------------------------------------------------
QSS = """
QWidget { color: #f4f6f9; font-family: "Segoe UI Variable Text", "Segoe UI", sans-serif; font-size: 9pt; }
QFrame#glass {
    background: rgba(12,12,14,222); border: 1px solid rgba(255,255,255,28); border-radius: 26px;
}
QFrame#capsule {
    background: rgba(12,12,14,222); border: 1px solid rgba(255,255,255,28); border-radius: 19px;
}
QFrame#dock { background: transparent; border: 0; }
QFrame#statusbar { background: transparent; border: 0; }
QFrame#winctl { background: transparent; border: 0; }
QFrame#row { background: rgba(255,255,255,12); border: 1px solid transparent; border-radius: 16px; }
QFrame#row[focused="true"] { background: rgba(255,255,255,20); border: 1px solid rgba(255,255,255,140); }
QLabel { background: transparent; }
QLabel#brand { color: rgba(244,246,249,190); font-size: 9pt; font-weight: 600; letter-spacing: 3px; }
QLabel#title { font-size: 17pt; font-weight: 300; letter-spacing: 1px; }
QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; border: 0; }
QFrame#sheet { background: rgba(10,10,12,238); border: 1px solid rgba(255,255,255,14); border-radius: 30px; }
QLabel#sheettitle { font-size: 18pt; font-weight: 300; color: #f4f6f9; }
QLabel#section { color: rgba(244,246,249,115); font-size: 7.5pt; font-weight: 600; letter-spacing: 2px; }
QLabel#muted, QLabel#hint { color: rgba(244,246,249,140); font-size: 8.5pt; }
QLabel#clock { font-size: 9.5pt; font-weight: 600; }
QLabel#status { color: rgba(244,246,249,170); font-size: 8.5pt; letter-spacing: 0.3px; }
QLabel#name { color: #f4f6f9; font-size: 9pt; }
QLabel#dist { color: rgba(244,246,249,130); font-size: 8pt; }
QLabel#warn { color: #f0be64; font-size: 8pt; }
QLabel#badge {
    background: rgba(255,255,255,30); color: #eceff4; border-radius: 9px; font-weight: 700; font-size: 9pt;
}
QPushButton {
    background: transparent; border: 0; border-radius: 12px; padding: 5px 11px; font-size: 9pt; font-weight: 500;
}
QPushButton:hover { background: rgba(255,255,255,22); }
QPushButton:pressed { background: rgba(255,255,255,34); }
QPushButton#primary { background: #eceff4; color: #0c0c0e; border-radius: 17px; padding: 8px 18px; font-weight: 600; }
QPushButton#primary:hover { background: #ffffff; }
QPushButton#dock { min-width: 42px; max-width: 42px; min-height: 42px; max-height: 42px; padding: 0; border-radius: 16px;
    background: transparent; }
QPushButton#dock:hover { background: rgba(255,255,255,30); border: 1px solid rgba(255,255,255,70); }
QPushButton#dock:checked { background: rgba(255,255,255,44); border: 1px solid rgba(255,255,255,170); }
QPushButton#dockmain { min-height: 42px; max-height: 42px; min-width: 54px; max-width: 54px; padding: 0;
    border-radius: 21px; background: #eceff4; }
QPushButton#dockmain:hover { background: #ffffff; }
QPushButton#apptile { background: transparent; border: 0; border-radius: 12px; padding: 0; }
QPushButton#apptile:hover { background: rgba(255,255,255,18); }
QPushButton#apptile:checked { background: rgba(255,255,255,30); }
QPushButton#seg { border-radius: 14px; padding: 6px 10px; color: rgba(244,246,249,160); background: rgba(255,255,255,9); }
QPushButton#seg:checked { background: rgba(255,255,255,40); color: #f4f6f9; border: 1px solid rgba(255,255,255,150); }
QPushButton#tool { padding: 0; min-width: 24px; max-width: 24px; min-height: 22px; max-height: 22px;
    border-radius: 11px; background: rgba(255,255,255,14); }
QPushButton#tool:hover { background: rgba(255,255,255,34); }
QPushButton#tool:checked { background: rgba(255,255,255,50); }
QPushButton#remove { padding: 0; min-width: 24px; max-width: 24px; min-height: 22px; max-height: 22px;
    color: rgba(244,246,249,140); border-radius: 11px; }
QPushButton#remove:hover { color: #ff8192; }
QPushButton#ctl { padding: 0; min-width: 32px; max-width: 32px; min-height: 26px; max-height: 26px; border-radius: 13px; }
QPushButton#ctl:hover { background: rgba(255,255,255,26); }
QToolButton#tile {
    background: transparent; border: 1px solid transparent; border-radius: 20px;
    padding: 8px 8px 6px 8px; color: #f4f6f9; font-size: 9pt;
}
QToolButton#tile:hover { background: rgba(255,255,255,14); border: 1px solid rgba(255,255,255,40); }
QProgressBar { background: rgba(255,255,255,20); border: 0; border-radius: 2px; max-height: 4px; min-height: 4px; }
QProgressBar::chunk { background: #eceff4; border-radius: 2px; }
QComboBox, QSpinBox {
    background: rgba(255,255,255,12); border: 1px solid rgba(255,255,255,24); border-radius: 12px; padding: 4px 10px;
}
QComboBox QAbstractItemView { background: #111113; color: #f4f6f9; selection-background-color: #3a3c44; }
QSlider::groove:horizontal { height: 4px; background: rgba(255,255,255,26); border-radius: 2px; }
QSlider::sub-page:horizontal { background: #eceff4; border-radius: 2px; }
QSlider::handle:horizontal { background: #ffffff; width: 16px; height: 16px; margin: -6px 0; border-radius: 8px; }
QCheckBox { spacing: 8px; }
QScrollArea { background: transparent; border: 0; }
QScrollBar:vertical { background: transparent; width: 8px; margin: 2px; }
QScrollBar::handle:vertical { background: rgba(255,255,255,50); border-radius: 4px; min-height: 30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QFrame#home { background: transparent; border: 0; }
QFrame#widgetbox { background: transparent; border: 0; }
QFrame#calcard { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #f7f7f9, stop:1 #d9dce2); border: 0; border-radius: 22px; }
QLabel#calweek { color: #e5483c; font-size: 10pt; font-weight: 700; background: transparent; }
QLabel#calday { color: #111114; font-size: 46pt; font-weight: 300; background: transparent; }
QLabel#calname { color: #3b3e46; font-size: 8.5pt; font-weight: 600; background: transparent; }
QFrame#minicard { background: rgba(255,255,255,20); border: 1px solid rgba(255,255,255,20); border-radius: 22px; }
QFrame#wide { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2b3a52, stop:1 #14202f); border: 0; border-radius: 22px; }
QLabel#minilabel { color: #f4f6f9; font-size: 10pt; font-weight: 500; background: transparent; }
QLabel#applabel { color: rgba(244,246,249,235); font-size: 10.5pt; font-weight: 500; background: transparent; }
QLabel#pagedots { color: rgba(255,255,255,150); font-size: 7pt; background: transparent; }
"""

TILE_W, TILE_H = 224, 126


def make_button(text, slot=None, primary=False, tool=False):
    b = QPushButton(text)
    b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    if primary:
        b.setObjectName("primary")
    if tool:
        b.setObjectName("tool")
    if slot is not None:
        b.clicked.connect(slot)
    return b


def _tile_pixmap(image):
    """A launcher tile picture: the window's own image on a rounded card, or None to leave it blank."""
    pm = QPixmap(TILE_W, TILE_H)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, TILE_W, TILE_H), 14, 14)
    p.setClipPath(clip)
    p.fillRect(QRectF(0, 0, TILE_W, TILE_H), QColor(255, 255, 255, 14))
    if image is not None:
        scaled = image.scaled(TILE_W, TILE_H, Qt.AspectRatioMode.KeepAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)
        p.drawImage(int((TILE_W - scaled.width()) / 2), int((TILE_H - scaled.height()) / 2), scaled)
    p.end()
    return pm


def _letter_tile(name):
    """Fallback tile when a picture is not available: a soft gradient with the first letter."""
    hue = sum(ord(c) for c in name) % 360
    pm = QPixmap(TILE_W, TILE_H)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, TILE_W, TILE_H), 14, 14)
    p.setClipPath(clip)
    grad = QLinearGradient(0, 0, TILE_W, TILE_H)
    grad.setColorAt(0.0, QColor.fromHsv(hue, 110, 120))
    grad.setColorAt(1.0, QColor.fromHsv((hue + 40) % 360, 130, 55))
    p.fillRect(QRectF(0, 0, TILE_W, TILE_H), grad)
    f = QFont("Segoe UI Variable Display", 38)
    f.setWeight(QFont.Weight.Light)
    p.setFont(f)
    p.setPen(QColor(255, 255, 255, 220))
    p.drawText(QRectF(0, 0, TILE_W, TILE_H), Qt.AlignmentFlag.AlignCenter, (name.strip()[:1] or "?").upper())
    p.end()
    return pm


def capture_thumbnail(kind, ident, name):
    """One quick picture of a window or screen for the launcher; falls back to a letter tile."""
    try:
        arr = None
        if kind == "window":
            rect = window_rect(ident)
            if rect:
                arr = capture_window_pixels(ident, rect[2] - rect[0], rect[3] - rect[1])
        else:
            import mss
            with mss.mss() as sct:
                arr = np.asarray(sct.grab(dict(sct.monitors[ident])))
        if arr is not None:
            step = max(1, arr.shape[1] // 640)
            arr = np.ascontiguousarray(arr[::step, ::step])
            h, w = arr.shape[:2]
            img = QImage(arr.data, w, h, w * 4, QImage.Format.Format_RGB32).copy()   # BGRA bytes, alpha ignored
            return _tile_pixmap(img)
    except Exception:
        rh.log.exception("thumbnail failed for %s", name)
    return _letter_tile(name)


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.cfg = load_settings()
        self.setWindowTitle("Spatial Desk")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setStyleSheet(QSS)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAutoFillBackground(True)
        pal = self.palette()
        pal.setColor(QPalette.ColorRole.Window, QColor(5, 6, 10))
        self.setPalette(pal)
        self.resize(1600, 960)                 # replaced by the full work area in main()

        self.panels = []                       # dicts: grab, name, dist, expanded, plus GL fields
        self.max_panels = int(self.cfg["max_panels"])
        self.mode = "setup"
        self.target = 0.0
        self.progress = 0.0
        self.fade_ms = int(self.cfg["fade_ms"])
        self.notify_on = bool(self.cfg["notify"])
        self.follow = bool(self.cfg["follow"])
        self.layout_name = self.cfg["layout"]
        self.theme_name = self.cfg["theme"]
        self.bg_path = self.cfg["bg_path"]
        self.mouse_yaw = 0.0
        self.mouse_pitch = 0.0
        self.live = False
        self.side_wanted = False
        self.show_intro = bool(self.cfg["intro"])
        self.intro_running = self.show_intro
        self.sheet_kind = None
        self._excluded = False
        self.home_wanted = False      # the home screen only shows when you press the home button or Home
        self.look_speed = float(self.cfg.get("look_speed", 1.0))

        self.tracker = Tracker()

        self.scene = Scene(self)
        self.backdrop = None
        self._backdrop_timer = QTimer(self)
        self._backdrop_timer.timeout.connect(self._update_backdrop)
        self._backdrop_timer.start(250)
        self.scene.on_look = self._look
        self.scene.on_click = self._on_click
        self.scene.on_wheel = self._on_wheel
        self.scene.on_intro_end = self._end_intro
        self.scene.on_gl_error = lambda: self.toast("3D view failed. See helper.log")
        self.scene.layout_name = self.layout_name
        self.scene.set_fov(self.cfg["fov"])
        self.scene.set_follow(self.follow)
        if self.bg_path and os.path.exists(self.bg_path) and self.scene.set_background_image(self.bg_path):
            pass
        else:
            self.bg_path = ""
            self.scene.set_theme(self.theme_name)
        self.scene.skip_intro = not self.show_intro

        self._build_top()
        self._build_side()
        self._build_dock()
        self._build_empty()
        self._build_sheet()
        self._build_toast()
        self._build_hint()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(16)
        self.watch_timer = QTimer(self)
        self.watch_timer.timeout.connect(self._watch_pictures)
        self.watch_timer.start(1000)

        self._place()
        self._refresh_list()
        self._refresh_chrome()
        self._apply_visibility()
        if not self.show_intro:
            self._end_intro()
        else:
            QTimer.singleShot(6000, self._end_intro)

    # ----- settings
    def _save(self):
        self.cfg.update({
            "theme": self.theme_name, "layout": self.layout_name, "follow": self.follow, "fov": self.scene.fov,
            "max_panels": self.max_panels, "fade_ms": self.fade_ms, "notify": self.notify_on,
            "intro": self.show_intro, "bg_path": self.bg_path,
        })
        save_settings(self.cfg)

    # ----- construction
    def _capsule(self, parent=None):
        f = QFrame(parent or self)
        f.setObjectName("capsule")
        return f

    def _pill(self, text=""):
        f = self._capsule()
        lay = QHBoxLayout(f)
        lay.setContentsMargins(16, 8, 16, 8)
        lay.setSpacing(8)
        f.dot = QLabel("●")
        f.dot.setStyleSheet("font-size: 9pt; color: #eceff4;")
        f.label = QLabel(text)
        f.label.setObjectName("status")
        lay.addWidget(f.dot)
        lay.addWidget(f.label)
        f.adjustSize()
        return f

    def _build_top(self):
        self.brand = QLabel("SPATIAL DESK", self)
        self.brand.setObjectName("brand")
        self.brand.adjustSize()

        # Status capsule at the top centre: time, glasses, and how windows behave
        self.status = QFrame(self)
        self.status.setObjectName("statusbar")
        lay = QHBoxLayout(self.status)
        lay.setContentsMargins(18, 8, 18, 8)
        lay.setSpacing(10)
        self.clock_lbl = QLabel(time.strftime("%H:%M"))
        self.clock_lbl.setObjectName("clock")
        self.dot = QLabel("●")
        self.dot.hide()
        self.dot.setStyleSheet("font-size: 9pt; color: #8a96ad;")
        self.track_lbl = QLabel("Connecting…")
        self.track_lbl.setObjectName("status")
        self.mode_lbl = QLabel("Flat setup")
        self.mode_lbl.setObjectName("status")
        sep = QLabel("·")
        sep.setObjectName("muted")
        for w in (self.clock_lbl, self.dot, self.track_lbl, sep, self.mode_lbl):
            lay.addWidget(w)
        self.status.adjustSize()

        # Window controls at the top right
        self.capsule = QFrame(self)
        self.capsule.setObjectName("winctl")
        cap = QHBoxLayout(self.capsule)
        cap.setContentsMargins(6, 4, 6, 4)
        cap.setSpacing(2)
        self.min_btn = QPushButton()
        self.full_btn = QPushButton()
        self.close_btn = QPushButton()
        for b, k, slot in ((self.min_btn, "minimise", self.showMinimized),
                           (self.full_btn, "fullscreen", self.toggle_fullscreen),
                           (self.close_btn, "close", self.close)):
            b.setObjectName("ctl")
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setIcon(make_icon(k, px=32))
            b.setIconSize(QSize(14, 14))
            b.clicked.connect(slot)
            cap.addWidget(b)
        self.capsule.adjustSize()

    def _build_side(self):
        self.side = QFrame(self)
        self.side.setObjectName("glass")
        lay = QVBoxLayout(self.side)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(9)
        self.side_head = QLabel("WINDOWS")
        self.side_head.setObjectName("section")
        lay.addWidget(self.side_head)
        self.list_box = QWidget()
        self.list_lay = QVBoxLayout(self.list_box)
        self.list_lay.setContentsMargins(0, 0, 0, 0)
        self.list_lay.setSpacing(6)
        lay.addWidget(self.list_box)
        lay.addStretch(1)

        lay_head = QLabel("ARRANGEMENT")
        lay_head.setObjectName("section")
        lay.addWidget(lay_head)
        grid = QGridLayout()
        grid.setSpacing(6)
        self.layout_buttons = {}
        for k, (name, label) in enumerate(LAYOUTS):
            b = QPushButton(label)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setChecked(name == self.layout_name)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(lambda _checked=False, n=name: self.set_layout(n))
            self.layout_buttons[name] = b
            grid.addWidget(b, k // 2, k % 2)
        lay.addLayout(grid)

        beh_head = QLabel("WINDOW BEHAVIOUR")
        beh_head.setObjectName("section")
        lay.addWidget(beh_head)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.behaviour_buttons = {}
        for key, label in (("hover", "Hover"), ("follow", "Follow")):
            b = QPushButton(label)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setChecked((key == "follow") == self.follow)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(lambda _checked=False, k=key: self.set_follow(k == "follow"))
            self.behaviour_buttons[key] = b
            row.addWidget(b)
        lay.addLayout(row)
        hint = QLabel("Hover pins windows in the room. Follow lets them drift after your gaze. "
                      "Scroll over a window to pull it closer or push it away.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        self.side.setFixedWidth(290)

    def _build_dock(self):
        self.dock = QFrame(self)
        self.dock.setObjectName("dock")
        lay = QHBoxLayout(self.dock)
        lay.setContentsMargins(6, 2, 6, 2)
        lay.setSpacing(3)
        # Hidden holder: controls that are not in the dock still exist for the rest of the app.
        self._parked = QWidget(self)
        self._parked.hide()
        self.btn_add = make_icon_button("grid", self.open_picker, "Launcher: add a window or screen  (A)", tint="#3d8bff")
        self.btn_panel = make_icon_button("windows", self.toggle_panel, "Windows  (P)", checkable=True, tint="#22c3e6")
        self.btn_layout = make_icon_button("layers", self.cycle_layout, "Arrangement  (L)", tint="#8b5cf6")
        self.btn_mode = make_icon_button("3d", self.toggle_mode, "Enter 3D space  (Space)", primary=True)
        self.btn_follow = make_icon_button("hover", self.toggle_follow, "Hover or follow  (H)", checkable=True, tint="#ff9f1a")
        self.btn_recenter = make_icon_button("recenter", self.recenter, "Recenter  (R)", tint="#34c759")
        self.btn_calib = make_icon_button("calibrate", self.open_calibration, "Calibrate glasses", tint="#ff4d6d")
        self.btn_settings = make_icon_button("settings", self.open_settings, "Settings", tint="#8e8e93")
        self.btn_full = make_icon_button("fullscreen", self.toggle_fullscreen, "Full screen  (F11)", tint="#ffcc00")
        self.btn_min = make_icon_button("minimise", self.showMinimized, "Minimise", tint="#ff9f0a")

        for name, exe in find_installed_apps():
            icon = make_app_icon(exe)
            if icon.isNull():
                continue
            b = QPushButton()
            b.setObjectName("apptile")
            b.setIcon(icon)
            b.setIconSize(QSize(DOCK_TILE, DOCK_TILE))
            b.setToolTip(f"Open {name}")
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setFixedSize(DOCK_TILE + 4, DOCK_TILE + 4)
            b.clicked.connect(lambda _c=False, n=name, e=exe: self._launch_app(n, e))
            lay.addWidget(b)
        lay.addSpacing(10)
        self.btn_home = make_icon_button("home", self.toggle_home, "Home  (Home key)", tint="#ff6fd0")
        for b in (self.btn_home, self.btn_mode, self.btn_add, self.btn_settings):
            lay.addWidget(b)
        for b in (self.btn_panel, self.btn_layout, self.btn_follow, self.btn_recenter,
                  self.btn_calib, self.btn_full, self.btn_min):
            b.setParent(self._parked)
        self._update_layout_button()
        self._update_follow_button()
        self.status_strip = StatusStrip(self)
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self._tick_clock)
        self.clock_timer.start(1000)

    def _launch_app(self, name, exe):
        try:
            os.startfile(exe)
            self.toast(f"Opening {name}")
        except Exception:
            rh.log.exception("could not open %s", exe)
            self.toast(f"Could not open {name}")

    def _tick_clock(self):
        if hasattr(self, "status_strip"):
            if self.status_strip.refresh_power():
                self._place()
            self.status_strip.update()
        text = time.strftime("%H:%M")
        if self.clock_lbl.text() != text:
            self.clock_lbl.setText(text)
            if hasattr(self, "home_day"):
                self.home_day.setText(time.strftime("%d"))
                self.home_wd.setText(time.strftime("%a"))

    def _build_empty(self):
        """Home screen after the reference: widget cards on the left, labelled colour app tiles on the right."""
        self.empty = QFrame(self)
        self.empty.setObjectName("home")
        root = QHBoxLayout(self.empty)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(28)

        # ----- widget column
        wbox = GlassFrame(None, radius=30)
        wbox.setObjectName("widgetbox")
        wg = QGridLayout(wbox)
        wg.setContentsMargins(14, 14, 14, 14)
        wg.setSpacing(10)

        cal = QFrame()
        cal.setObjectName("calcard")
        cal.setFixedSize(150, 156)
        cl = QVBoxLayout(cal)
        cl.setContentsMargins(14, 12, 14, 12)
        self.home_wd = QLabel(time.strftime("%a"))
        self.home_wd.setObjectName("calweek")
        self.home_day = QLabel(time.strftime("%d"))
        self.home_day.setObjectName("calday")
        cal_name = QLabel("Calendar")
        cal_name.setObjectName("calname")
        cl.addWidget(self.home_wd)
        cl.addWidget(self.home_day)
        cl.addStretch(1)
        cl.addWidget(cal_name)
        wg.addWidget(cal, 0, 0, 2, 1)

        for col, (name, glyph, tint) in enumerate((("Gmail", "M", "#f2b8a2"), ("Drive", "D", "#f5e09a"))):
            card = QFrame()
            card.setObjectName("minicard")
            card.setFixedSize(150, 72)
            cll = QHBoxLayout(card)
            cll.setContentsMargins(14, 0, 14, 0)
            dot = QLabel(glyph)
            dot.setFixedSize(28, 28)
            dot.setAlignment(Qt.AlignmentFlag.AlignCenter)
            dot.setStyleSheet(f"background: {tint}; color: #111; border-radius: 9px; font-weight: 700;")
            lab = QLabel(name)
            lab.setObjectName("minilabel")
            cll.addWidget(dot)
            cll.addWidget(lab)
            wg.addWidget(card, col, 1)

        pc = QFrame()
        pc.setObjectName("wide")
        pc.setFixedSize(312, 124)
        pl = QVBoxLayout(pc)
        pl.setContentsMargins(16, 12, 16, 12)
        pc_name = QLabel("PC connection")
        pc_name.setObjectName("minilabel")
        pl.addWidget(pc_name)
        pl.addStretch(1)
        wg.addWidget(pc, 2, 0, 1, 2)
        root.addWidget(wbox)

        # ----- app tiles
        apps = QVBoxLayout()
        apps.setSpacing(14)
        grid = QGridLayout()
        grid.setSpacing(28)
        actions = (("Launcher", "grid", self.open_picker, "#4f8bff", "#2a5bd8"),
                   ("Hover", "hover", self.toggle_follow, "#ffa64d", "#f0692b"),
                   ("Recenter", "recenter", self.recenter, "#4fd58a", "#1f9e62"),
                   ("Calibrate", "calibrate", self.open_calibration, "#ff7a8a", "#e0445a"),
                   ("Layout", "layers", self.cycle_layout, "#a67cff", "#6d45e6"),
                   ("Windows", "windows", self.toggle_panel, "#39c6e8", "#1a8fb8"),
                   ("3D space", "3d", self.toggle_mode, "#ff6fd0", "#c437a6"),
                   ("Settings", "settings", self.open_settings, "#8d939e", "#565c67"))
        for i, (label, icon, slot, bg, fg) in enumerate(actions):
            col = QVBoxLayout()
            col.setSpacing(8)
            btn = QToolButton()
            btn.setObjectName("appicon")
            btn.setIcon(make_icon(icon, QColor(255, 255, 255), px=96))
            btn.setIconSize(QSize(60, 60))
            btn.setFixedSize(104, 104)
            btn.setStyleSheet(
                f"QToolButton#appicon {{ background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {bg}, stop:1 {fg});"
                " border: 0; border-radius: 28px; }"
                "QToolButton#appicon:hover { border: 1px solid rgba(255,255,255,140); }")
            btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            btn.clicked.connect(slot)
            lab = QLabel(label)
            lab.setObjectName("applabel")
            lab.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            col.addWidget(btn, 0, Qt.AlignmentFlag.AlignHCenter)
            col.addWidget(lab, 0, Qt.AlignmentFlag.AlignHCenter)
            wrap = QWidget()
            wrap.setFixedWidth(124)
            wrap.setLayout(col)
            grid.addWidget(wrap, i // 4, i % 4)
        apps.addLayout(grid)
        dots = QLabel("\u25CF   \u25CB   \u25CB")
        dots.setObjectName("pagedots")
        dots.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        apps.addWidget(dots)
        root.addLayout(apps)
        self.empty.setFixedWidth(960)
        self.empty.setFixedHeight(400)

    def _build_sheet(self):
        self.sheet = QFrame(self)
        self.sheet.setObjectName("sheet")
        self._sheet_watch = _SheetWatch(self)
        self.sheet.installEventFilter(self._sheet_watch)
        self.sheet_lay = QVBoxLayout(self.sheet)
        self.sheet_lay.setContentsMargins(28, 26, 28, 24)
        self.sheet_lay.setSpacing(11)
        self.sheet.setFixedWidth(460)
        self.sheet.hide()

    def _update_backdrop(self):
        if not self.isVisible() or self.width() < 2:
            return
        image = self.scene.grabFramebuffer()
        if image.isNull():
            return
        self.backdrop = blur_backdrop(image, self.width(), self.height())
        for w in (self.empty, self.dock, self.side):
            w.update()

    def _refresh_home(self):
        home_ok = self.home_wanted and self.mode != "spatial" and not self.sheet.isVisible()
        self.empty.setVisible(home_ok)

    def _build_toast(self):
        self.toast_frame = self._pill("")
        self.toast_frame.hide()
        self.toast_timer = QTimer(self)
        self.toast_timer.setSingleShot(True)
        self.toast_timer.timeout.connect(self.toast_frame.hide)

    def _build_hint(self):
        self.hint_frame = self._pill("Space or Esc: back to flat")
        self.hint_frame.hide()
        self.hint_timer = QTimer(self)
        self.hint_timer.setSingleShot(True)
        self.hint_timer.timeout.connect(self.hint_frame.hide)

    # ----- placement and visibility
    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.scene.setGeometry(self.rect())
        self._place()

    def showEvent(self, ev):
        super().showEvent(ev)
        if not self._excluded:
            exclude_from_capture(int(self.winId()))
            self._excluded = True

    def _place(self):
        W, H = self.width(), self.height()
        self.brand.move(32, 34)
        self.status.adjustSize()
        self.status.move((W - self.status.width()) // 2, 24)
        self.capsule.adjustSize()
        self.capsule.move(W - self.capsule.width() - 24, 24)
        self.side.setFixedHeight(max(300, H - 190))
        self.side.move(W - self.side.width() - 28, 84)
        self.dock.adjustSize()
        self.dock.move((W - self.dock.width()) // 2, H - self.dock.height() - 34)
        self.status_strip.move((W - self.status_strip.width()) // 2, H - 34 + 6)
        self.empty.adjustSize()
        self.empty.move((W - self.empty.width()) // 2, (H - self.empty.height()) // 2)
        self.sheet.adjustSize()
        self.sheet.move((W - self.sheet.width()) // 2, max(20, (H - self.sheet.height()) // 2))
        above_dock = H - self.dock.height() - 34 - 14
        self.toast_frame.adjustSize()
        self.toast_frame.move((W - self.toast_frame.width()) // 2, above_dock - self.toast_frame.height())
        self.hint_frame.adjustSize()
        self.hint_frame.move((W - self.hint_frame.width()) // 2, above_dock - self.hint_frame.height())

    def _apply_visibility(self):
        """Setup shows the room controls. 3D keeps a calm dock and status bar, and hides what needs the desktop."""
        if self.intro_running:
            for w in (self.brand, self.status, self.dock, self.status_strip, self.capsule, self.side, self.empty):
                w.hide()
            self.sheet.hide()
            return
        spatial = self.mode == "spatial"
        self.brand.setVisible(not spatial)
        self.status.show()
        self.capsule.show()
        self.close_btn.setVisible(not spatial)
        self.dock.show()
        self.status_strip.show()
        for b in (self.btn_add, self.btn_calib, self.btn_panel):
            b.setVisible(not spatial)
        self.side.setVisible(self.side_wanted and not spatial)
        self.btn_panel.setChecked(self.side_wanted)
        self.scene.reserved_right = (self.side.width() + 40) if (self.side_wanted and not spatial) else 0
        self.scene.relayout()
        self.empty.setVisible(self.home_wanted and not spatial and not self.sheet.isVisible())
        if spatial and self.sheet_kind != "settings":
            self.sheet.hide()
        if spatial:
            self.toast_frame.hide()
        self._place()

    # ----- actions
    def toast(self, msg):
        if not self.notify_on or self.mode == "spatial":
            return
        self.toast_frame.label.setText(msg)
        self.toast_frame.adjustSize()
        self._place()
        self.toast_frame.show()
        self.toast_frame.raise_()
        self.toast_timer.start(2600)

    def _focus(self, p):
        if self.scene.focused is not p:
            self.scene.focused = p
            self._refresh_list()

    def add_source(self, kind, ident, name):
        if len(self.panels) >= self.max_panels:
            self.toast(f"Up to {self.max_panels} windows (change in Settings)")
            return
        grab = Grabber(kind, ident)
        p = {"grab": grab, "name": name, "dist": DEFAULT_DIST, "expanded": False}
        self.panels.append(p)
        self.scene.panels = self.panels
        self.scene.focused = p
        self.scene.relayout()
        self.scene.kick_warp(0.6)
        self._refresh_list()
        self.toast(f"Added {name}")

    def remove_panel(self, index):
        if 0 <= index < len(self.panels):
            p = self.panels.pop(index)
            p["grab"].stop()
            self.scene.drop_panel(p)
            self.scene.panels = self.panels
            if self.scene.focused is None and self.panels:
                self.scene.focused = self.panels[-1]
            self.scene.kick_warp(0.7)
            self._refresh_list()
            self.toast(f"Removed {p['name']}")

    def nudge_panel(self, index, delta, warp=0.45):
        """Pull a window closer (negative) or push it further away (positive)."""
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            new = min(MAX_DIST, max(MIN_DIST, p.get("dist", DEFAULT_DIST) + delta))
            if abs(new - p.get("dist", DEFAULT_DIST)) < 1e-6:
                return
            p["dist"] = new
            self.scene.relayout()
            self.scene.kick_warp(warp)
            self._refresh_list()

    def toggle_expand(self, index):
        if 0 <= index < len(self.panels):
            p = self.panels[index]
            p["expanded"] = not p.get("expanded", False)
            self.scene.relayout()
            self.scene.kick_warp(1.0)       # the starfield rush when a window grows or shrinks
            self._refresh_list()

    def set_mode(self, mode):
        if mode == self.mode:
            return
        self.mode = mode
        self.target = 1.0 if mode == "spatial" else 0.0
        self.scene.kick_warp(1.5 if mode == "spatial" else 1.0, dur=0.3)
        self.btn_mode.setIcon(make_icon("flat" if mode == "spatial" else "3d", QColor(12, 12, 14)))
        self.btn_mode.setToolTip("Back to flat setup  (Space)" if mode == "spatial" else "Enter 3D space  (Space)")
        if mode == "spatial":
            self.hint_frame.show()
            self.hint_frame.raise_()
            self.hint_timer.start(3500)
        else:
            self.hint_frame.hide()
            self.hint_timer.stop()
        self._apply_visibility()
        self._refresh_chrome()

    def toggle_mode(self):
        self.set_mode("setup" if self.mode == "spatial" else "spatial")

    def cycle_ratio(self):
        p = self.scene.focused
        if p is None:
            self.toast("Pick a window first")
            return
        order = list(RATIOS)
        p["ratio"] = order[(order.index(p.get("ratio", "auto")) + 1) % len(order)]
        self.scene.kick_warp(0.4)
        self.toast(f"Window ratio: {p['ratio'].capitalize()}")

    def toggle_home(self):
        self.home_wanted = not self.home_wanted
        if self.home_wanted and self.mode == "spatial":
            self.set_mode("setup")
        self._apply_visibility()

    def toggle_panel(self):
        self.side_wanted = not self.side_wanted
        self._apply_visibility()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def set_layout(self, name):
        self.layout_name = name
        self.scene.set_layout(name)
        self.scene.kick_warp(0.5)
        for key, b in self.layout_buttons.items():
            b.setChecked(key == name)
        self._update_layout_button()
        self._save()
        self.toast(f"Arrangement: {dict(LAYOUTS)[name]}")

    def cycle_layout(self):
        keys = [k for k, _ in LAYOUTS]
        self.set_layout(keys[(keys.index(self.layout_name) + 1) % len(keys)])

    def _update_layout_button(self):
        self.btn_layout.setToolTip(f"Arrangement: {dict(LAYOUTS)[self.layout_name]}  (L)")

    def set_follow(self, on):
        self.follow = bool(on)
        self.scene.set_follow(self.follow)
        for key, b in self.behaviour_buttons.items():
            b.setChecked((key == "follow") == self.follow)
        self._update_follow_button()
        self._refresh_chrome()
        self._save()
        self.toast("Follow: windows travel with your gaze" if self.follow else "Hover: windows stay where they are")

    def toggle_follow(self):
        self.set_follow(not self.follow)

    def _update_follow_button(self):
        self.btn_follow.setIcon(make_icon("follow" if self.follow else "hover"))
        self.btn_follow.setChecked(self.follow)
        self.btn_follow.setToolTip("Follow: windows travel with your gaze  (H)" if self.follow
                                   else "Hover: windows stay fixed in the room  (H)")

    def recenter(self):
        if self.live:
            self.tracker.recenter()
        else:
            self.mouse_yaw = 0.0
            self.mouse_pitch = 0.0
        self.scene.reset_follow()
        self.toast("Recentered")

    def _end_intro(self):
        self.intro_running = False
        self._apply_visibility()

    def _on_click(self, x, y):
        hit = self.scene.pick(x, y)
        if hit is None:
            return
        kind, idx, u, v = hit
        if idx >= len(self.panels):
            return
        p = self.panels[idx]
        self._focus(p)
        if kind == "header":
            action = title_hit(u)
            if action == "pull":
                self.nudge_panel(idx, -0.3)
            elif action == "push":
                self.nudge_panel(idx, +0.3)
            elif action == "max":
                self.toggle_expand(idx)
            elif action == "close":
                self.remove_panel(idx)
            return
        ok = click_grab(p["grab"], u, v, pointer=bool(self.cfg.get("pointer_click", False)))
        self.toast(f"Clicked {p['name']}" if ok else f"Could not click {p['name']}")

    def _on_wheel(self, x, y, delta):
        hit = self.scene.pick(x, y)
        if hit is None or hit[1] >= len(self.panels):
            return
        self._focus(self.panels[hit[1]])
        self.nudge_panel(hit[1], -0.15 * (delta / 120.0), warp=0.35)

    def _look(self, dx, dy):
        if self.mode == "spatial" and not self.live:
            self.mouse_yaw += dx * 0.003 * self.look_speed
            self.mouse_pitch -= dy * 0.003 * self.look_speed

    def _ensure_flat(self):
        if self.mode == "spatial":
            self.set_mode("setup")

    # ----- launcher
    def open_picker(self):
        self._ensure_flat()
        self._clear_sheet()
        self.sheet_kind = "picker"
        self._sheet_title("Launcher")
        self._sheet_text("Pick a screen or window to bring into your space.")
        own = int(self.winId()) if IS_WIN else 0
        options = []
        try:
            options += [("screen", idx, name) for idx, name in list_screens()]
        except Exception:
            rh.log.exception("could not list screens")
        try:
            options += [("window", hwnd, title) for hwnd, title in list_windows(own)]
        except Exception:
            rh.log.exception("could not list windows")
        if not options:
            self._sheet_text("Nothing to capture yet. Open a window and try again.")
        else:
            holder = QWidget()
            grid = QGridLayout(holder)
            grid.setContentsMargins(0, 0, 0, 0)
            grid.setSpacing(12)
            metrics = QFontMetrics(self.font())
            for n, (kind, ident, name) in enumerate(options):
                tile = QToolButton()
                tile.setObjectName("tile")
                tile.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                tile.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
                tile.setIcon(QIcon(capture_thumbnail(kind, ident, name)))
                tile.setIconSize(QSize(TILE_W, TILE_H))
                tile.setText(metrics.elidedText(name, Qt.TextElideMode.ElideRight, TILE_W - 8))
                tile.setToolTip(name)
                tile.setFixedSize(TILE_W + 18, TILE_H + 46)
                tile.clicked.connect(lambda _c=False, k=kind, i=ident, nm=name: self._pick(k, i, nm))
                grid.addWidget(tile, n // 3, n % 3)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(holder)
            scroll.setFixedHeight(min(460, ((len(options) + 2) // 3) * (TILE_H + 58) + 6))
            self.sheet_lay.addWidget(scroll)
        self._sheet_close_row()
        self._show_sheet(width=820)

    def _pick(self, kind, ident, name):
        self.sheet.hide()
        self.add_source(kind, ident, name)

    def open_calibration(self):
        self._ensure_flat()
        self._clear_sheet()
        self.sheet_kind = "calib"
        self._sheet_title("Calibrate glasses")
        self._sheet_text("Put the glasses on, look straight ahead, and keep your head still for 3 seconds.")
        self.calib_bar = QProgressBar()
        self.calib_bar.setRange(0, 100)
        self.calib_bar.setValue(0)
        self.calib_bar.setTextVisible(False)
        self.sheet_lay.addWidget(self.calib_bar)
        self.calib_msg = QLabel("Not started.")
        self.calib_msg.setObjectName("hint")
        self.sheet_lay.addWidget(self.calib_msg)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(make_button("Close", self.sheet.hide))
        row.addWidget(make_button("Start", self._start_calibration, primary=True))
        self.sheet_lay.addLayout(row)
        self._show_sheet()

    def _start_calibration(self):
        self.tracker.calibrate()
        self.calib_msg.setText("Hold your head still…")

    def open_settings(self):
        self._clear_sheet()
        self.sheet_kind = "settings"
        self._sheet_title("Settings")

        theme_lbl = QLabel("Space")
        theme_lbl.setObjectName("hint")
        self.theme_box = QComboBox()
        for name in THEMES:
            self.theme_box.addItem(name.capitalize(), name)
        self.theme_box.addItem("Custom image…", "custom")
        self.theme_box.setCurrentIndex(self.theme_box.count() - 1 if self.bg_path else
                                       max(0, self.theme_box.findData(self.theme_name)))
        self.theme_box.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.theme_box.activated.connect(self._theme_changed)
        self.sheet_lay.addWidget(theme_lbl)
        self.sheet_lay.addWidget(self.theme_box)

        self.fov_lbl = QLabel(f"Field of view  {int(self.scene.fov)}°")
        self.fov_lbl.setObjectName("hint")
        self.fov_slider = QSlider(Qt.Orientation.Horizontal)
        self.fov_slider.setRange(int(FOV_MIN), int(FOV_MAX))
        self.fov_slider.setValue(int(self.scene.fov))
        self.fov_slider.valueChanged.connect(self._fov_changed)
        self.fov_slider.sliderReleased.connect(self._save)
        fov_hint = QLabel("Narrower makes everything feel bigger and closer. Wider shows more of the room.")
        fov_hint.setObjectName("hint")
        fov_hint.setWordWrap(True)
        self.sheet_lay.addWidget(self.fov_lbl)
        self.sheet_lay.addWidget(self.fov_slider)
        self.sheet_lay.addWidget(fov_hint)

        max_lbl = QLabel("Maximum windows")
        max_lbl.setObjectName("hint")
        self.max_box = QSpinBox()
        self.max_box.setRange(1, MAX_PANELS_LIMIT)
        self.max_box.setValue(self.max_panels)
        self.max_box.valueChanged.connect(self._set_max_panels)
        self.sheet_lay.addWidget(max_lbl)
        self.sheet_lay.addWidget(self.max_box)

        fade_lbl = QLabel("Transition time (ms)")
        fade_lbl.setObjectName("hint")
        self.fade_box = QSpinBox()
        self.fade_box.setRange(200, 4000)
        self.fade_box.setSingleStep(100)
        self.fade_box.setValue(self.fade_ms)
        self.fade_box.valueChanged.connect(self._set_fade)
        self.sheet_lay.addWidget(fade_lbl)
        self.sheet_lay.addWidget(self.fade_box)

        self.intro_box = QCheckBox("Show launch animation next time")
        self.intro_box.setChecked(self.show_intro)
        self.intro_box.toggled.connect(self._set_intro)
        self.sheet_lay.addWidget(self.intro_box)

        self.notify_box = QCheckBox("Show notifications")
        self.notify_box.setChecked(self.notify_on)
        self.notify_box.toggled.connect(self._set_notify)
        self.sheet_lay.addWidget(self.notify_box)

        self.pointer_box = QCheckBox("Click with the real pointer (moves the mouse)")
        self.pointer_box.setChecked(bool(self.cfg.get("pointer_click", False)))
        self.pointer_box.toggled.connect(self._set_pointer_click)
        self.sheet_lay.addWidget(self.pointer_box)

        speed_lbl = QLabel(f"Look sensitivity  {int(self.look_speed * 100)}%")
        speed_lbl.setObjectName("hint")
        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setRange(50, 200)
        self.speed_slider.setValue(int(self.look_speed * 100))
        self.speed_slider.valueChanged.connect(lambda v, lbl=speed_lbl: self._set_look_speed(v, lbl))
        self.sheet_lay.addWidget(speed_lbl)
        self.sheet_lay.addWidget(self.speed_slider)

        keys = QLabel("Space = 3D or flat · H = hover or follow · L = arrangement · R = recenter · T = window ratio · Home = home screen · A = launcher · "
                      "P = windows · F11 = full screen · Esc = back · Scroll over a window = pull or push · "
                      "Alt + drag = move")
        keys.setObjectName("hint")
        keys.setWordWrap(True)
        self.sheet_lay.addWidget(keys)
        self._sheet_close_row()
        self._show_sheet()

    def _set_max_panels(self, value):
        self.max_panels = value
        self._save()
        # Never hide windows that are already open; just stop adding more.
        self.toast(f"Up to {value} windows")

    def _set_fade(self, value):
        self.fade_ms = value
        self._save()

    def _set_intro(self, value):
        self.show_intro = value
        self._save()

    def _set_look_speed(self, value, label):
        self.look_speed = value / 100.0
        self.cfg["look_speed"] = self.look_speed
        label.setText(f"Look sensitivity  {value}%")
        self._save()

    def _set_pointer_click(self, value):
        self.cfg["pointer_click"] = bool(value)
        self._save()

    def _set_notify(self, value):
        self.notify_on = value
        self._save()

    def _fov_changed(self, value):
        self.scene.set_fov(value)
        self.fov_lbl.setText(f"Field of view  {value}°")

    def _theme_changed(self, _index):
        choice = self.theme_box.currentData()
        if choice == "custom":
            path, _ = QFileDialog.getOpenFileName(self, "Choose a background image", "",
                                                  "Images (*.png *.jpg *.jpeg *.bmp)")
            if path and self.scene.set_background_image(path):
                self.bg_path = path
                self._save()
                self.toast("Background set")
        else:
            self.theme_name = choice
            self.bg_path = ""
            self.scene.set_theme(choice)
            self._save()

    # ----- sheet helpers
    def _clear_sheet(self):
        while self.sheet_lay.count():
            item = self.sheet_lay.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
            lay = item.layout()
            if lay is not None:
                while lay.count():
                    sub = lay.takeAt(0).widget()
                    if sub is not None:
                        sub.deleteLater()

    def _sheet_title(self, text):
        t = QLabel(text)
        t.setObjectName("sheettitle")
        self.sheet_lay.addWidget(t)

    def _sheet_text(self, text):
        t = QLabel(text)
        t.setObjectName("hint")
        t.setWordWrap(True)
        self.sheet_lay.addWidget(t)

    def _sheet_close_row(self):
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(make_button("Close", self.sheet.hide))
        self.sheet_lay.addLayout(row)

    def _show_sheet(self, width=460):
        self.sheet.setFixedWidth(width)
        self.sheet.adjustSize()
        self.sheet.move((self.width() - self.sheet.width()) // 2, max(20, (self.height() - self.sheet.height()) // 2))
        self.sheet.show()
        self.sheet.raise_()

    # ----- window list
    def _clear_layout(self, lay):
        while lay.count():
            item = lay.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _refresh_list(self):
        self._clear_layout(self.list_lay)
        n = len(self.panels)
        self.side_head.setText(f"WINDOWS  ·  {n}")
        if not self.panels:
            empty = QLabel("No windows yet.")
            empty.setObjectName("hint")
            self.list_lay.addWidget(empty)
        for i, p in enumerate(self.panels):
            row = QFrame()
            row.setObjectName("row")
            row.setProperty("focused", p is self.scene.focused)
            h = QHBoxLayout(row)
            h.setContentsMargins(8, 6, 6, 6)
            h.setSpacing(4)
            grab = p["grab"]
            problem = (not grab.has_picture()) and grab.age() > 4.0
            badge = QLabel((p["name"].strip()[:1] or "?").upper())
            badge.setObjectName("badge")
            badge.setFixedSize(26, 26)
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label = QLabel(self._elide(p["name"] + ("  · no picture" if problem else ""), 96))
            label.setObjectName("warn" if problem else "name")
            label.setToolTip((grab.error or "") if problem else p["name"])
            dist = QLabel(f"{p.get('dist', DEFAULT_DIST):.1f} m")
            dist.setObjectName("dist")
            dist.setFixedWidth(40)
            dist.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            h.addWidget(badge)
            h.addWidget(label, 1)
            h.addWidget(dist)
            pull = make_button("", lambda _c=False, idx=i: self.nudge_panel(idx, -0.3), tool=True)
            pull.setIcon(make_icon("minus", px=32))
            pull.setIconSize(QSize(12, 12))
            pull.setToolTip("Pull closer")
            push = make_button("", lambda _c=False, idx=i: self.nudge_panel(idx, +0.3), tool=True)
            push.setIcon(make_icon("add", px=32))
            push.setIconSize(QSize(12, 12))
            push.setToolTip("Push further away")
            big = make_button("", lambda _c=False, idx=i: self.toggle_expand(idx), tool=True)
            big.setIcon(make_icon("maximise", px=32))
            big.setIconSize(QSize(12, 12))
            big.setCheckable(True)
            big.setChecked(bool(p.get("expanded")))
            big.setToolTip("Make this the main window (large)")
            remove = make_button("", lambda _c=False, idx=i: self.remove_panel(idx))
            remove.setObjectName("remove")
            remove.setIcon(make_icon("close", px=32))
            remove.setIconSize(QSize(12, 12))
            remove.setToolTip("Remove")
            for b in (pull, push, big, remove):
                h.addWidget(b)
            self.list_lay.addWidget(row)
        self._apply_visibility()

    def _elide(self, text, width):
        return QFontMetrics(self.font()).elidedText(text, Qt.TextElideMode.ElideRight, width)

    def _watch_pictures(self):
        if any(not p["grab"].has_picture() and p["grab"].age() > 4.0 for p in self.panels):
            self._refresh_list()

    # ----- per-frame
    def _tick(self):
        step = 0.016 / max(0.2, self.fade_ms / 1000.0)
        if self.progress < self.target:
            self.progress = min(self.target, self.progress + step)
        elif self.progress > self.target:
            self.progress = max(self.target, self.progress - step)
        e = self.progress * self.progress * (3.0 - 2.0 * self.progress)
        dim = math.sin(math.pi * self.progress) * 0.3     # only a gentle dip: the starfield rush carries the change

        snap = self.tracker.snapshot()
        for ev in snap.get("events", []):
            if ev == "spatial_button":
                self.toggle_mode()
        calibrated = bool(snap.get("calibrated"))
        status = snap.get("status", "none")
        self.live = status in ("ok", "stale") and calibrated

        if self.live:
            yaw, pitch = snap.get("yaw", 0.0) * self.look_speed, snap.get("pitch", 0.0) * self.look_speed
        else:
            yaw, pitch = self.mouse_yaw, self.mouse_pitch
        self.scene.set_view(yaw, pitch, e, dim)

        calib = snap.get("calib", {}) or {}
        self._refresh_chrome(status, calibrated, calib)
        self.btn_full.setToolTip("Windowed  (F11)" if self.isFullScreen() else "Full screen  (F11)")
        if self.sheet_kind == "calib" and self.sheet.isVisible():
            self.calib_bar.setValue(int(calib.get("progress", 0) * 100))
            self.calib_msg.setText(calib.get("message", ""))

    def _refresh_chrome(self, status="none", calibrated=False, calib=None):
        calib = calib or {}
        if not self.tracker.available:
            text, color = "Mouse", "#7d828c"
            self.status.setToolTip(self.tracker.message)
        elif status == "searching" and self.tracker.message.startswith(("Downloading", "SDK ready")):
            text, color = self.tracker.message, "#c9ced8"
        elif calib.get("state") == "calibrating":
            text, color = "Calibrating…", "#c9ced8"
        elif status in ("ok", "stale") and not calibrated:
            text, color = "Calibrate glasses", "#c9ced8"
        elif status == "ok":
            text, color = "Glasses tracking", "#f4f6f9"
        elif status == "stale":
            text, color = "Glasses signal weak", "#c9ced8"
        elif status == "searching":
            text, color = "Looking for glasses", "#c9ced8"
        else:
            text, color = "Mouse", "#7d828c"
        mode = ("Follow" if self.follow else "Hover") if self.mode == "spatial" else "Flat setup"
        changed = False
        if self.track_lbl.text() != text:
            self.track_lbl.setText(text)
            changed = True
        if self.mode_lbl.text() != mode:
            self.mode_lbl.setText(mode)
            changed = True
        style = f"font-size: 9pt; color: {color};"
        if self.dot.styleSheet() != style:
            self.dot.setStyleSheet(style)
        if changed:
            self.status.adjustSize()
            self._place()

    # ----- input
    def keyPressEvent(self, ev):
        key = ev.key()
        if key == Qt.Key.Key_Escape:
            if self.sheet.isVisible():
                self.sheet.hide()
            elif self.mode == "spatial":
                self.set_mode("setup")
            elif self.isFullScreen():
                self.showNormal()
        elif key == Qt.Key.Key_Space:
            self.toggle_mode()
        elif key == Qt.Key.Key_R:
            self.recenter()
        elif key == Qt.Key.Key_P:
            self.toggle_panel()
        elif key == Qt.Key.Key_H:
            self.toggle_follow()
        elif key == Qt.Key.Key_L:
            self.cycle_layout()
        elif key == Qt.Key.Key_A:
            self.open_picker()
        elif key == Qt.Key.Key_T:
            self.cycle_ratio()
        elif key == Qt.Key.Key_Home:
            self.toggle_home()
        elif key == Qt.Key.Key_F11:
            self.toggle_fullscreen()
        elif self.mode == "spatial" and not self.live and key in (
                Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            if key == Qt.Key.Key_Left:
                self.mouse_yaw -= 0.05
            elif key == Qt.Key.Key_Right:
                self.mouse_yaw += 0.05
            elif key == Qt.Key.Key_Up:
                self.mouse_pitch += 0.05
            else:
                self.mouse_pitch -= 0.05
        else:
            super().keyPressEvent(ev)

    def closeEvent(self, ev):
        self._save()
        self.shutdown()
        super().closeEvent(ev)

    def shutdown(self):
        self.tracker.close()
        for p in self.panels:
            p["grab"].stop()


def main():
    rh.setup_logging()
    fmt = QSurfaceFormat()
    fmt.setVersion(3, 3)
    fmt.setSamples(4)                     # 4x multisampling smooths edges
    fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CoreProfile)
    QSurfaceFormat.setDefaultFormat(fmt)
    app = QApplication(sys.argv)
    win = MainWindow()
    area = app.primaryScreen().availableGeometry()   # fill the screen, minus the taskbar
    win.setGeometry(area)
    win.show()
    app.aboutToQuit.connect(win.shutdown)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
