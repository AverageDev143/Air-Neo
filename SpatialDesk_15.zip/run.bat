@echo off
cd /d "%~dp0"
py -m pip install -q -r requirements.txt
py spatial_desk.py
pause
